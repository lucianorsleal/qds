"""Dados de um site para os experimentos (Seções III-A, III-B e V-B do artigo).

Lê o que o pacote de coleta gravou em dados/processados/<SITE>/:
    potencia_horaria.parquet   série horária limpa (y, céu claro, diurno, QC, bloco, mês de teste)
    gfs_horario.parquet        GFS horário por ciclo (ciclo_utc, valido_utc, lead_h, variáveis)
    particoes.csv              treino, validação, 12 janelas de calibração e 12 meses de teste
e monta, sem olhar o futuro:
    - o envelope empírico de céu claro P̃cs (p99 do treino na mesma hora, ±15 dias, suavizado);
    - as entradas do TFT por papel (Tabela 2): passado observado (k, y e estatísticas móveis de k),
      conhecidas nos dois lados (geometria, P̃cs e calendário) e futuras conhecidas (GFS do ciclo
      disponível com latência de 5 h, até 36 h à frente);
    - a tabela de pares de avaliação (emissão, hora-alvo, horizonte) da validação, das janelas de
      calibração e do ano de teste, com os grupos do artigo (hora, regime do NWP), a estação local
      e a classe de céu do dia (diagnósticos);
    - as entradas tabulares dos baselines de árvores e do LSTM do artigo 1.

Índices: a série é uma grade horária contínua t = 0..T-1 (início da hora em UTC). Uma emissão no
índice i (instante t0 = início da hora i) usa as horas observadas i-120..i-1 e prevê as horas
i..i+35 (passo j = 0..35). O horizonte h (1, 3 ou 6 h) é o passo j = h-1; o day-ahead usa a emissão das
12:00 locais de D-1 e os passos j = 12..35 (as 24 horas de D).
"""

from __future__ import annotations

import hashlib
import logging
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from .config import H_LEAD_PISO, H_PASSO, HORIZONTES

log = logging.getLogger("exp")

VERSAO_CACHE = 5   # muda quando a montagem das entradas muda (refaz o cache do site); 5: lacunas do envelope
ENC = 120          # horas de passado no codificador
DEC = 36           # horas futuras no decodificador
PAD = DEC + 2      # folga no fim da grade
LAT_GFS_H = 5      # latência de disseminação do GFS
JANELAS_ROLL = (6, 12, 24, 48)

FEAT_ROLL = [f"k_{e}_{w}h" for w in JANELAS_ROLL for e in ("media", "dp", "min", "max")]
FEAT_PASSADO = ["k", "y"] + FEAT_ROLL                                   # 18
FEAT_CONHECIDO = ["cos_zen", "ghi_cs", "pcs", "sin_h", "cos_h", "sin_doy", "cos_doy", "sin_mes", "cos_mes"]  # 9
FEAT_NWP = ["ghi_nwp", "k_nwp", "tcc", "t2m", "rh2m", "t2m_x_rh2m", "u10", "v10", "lead"]  # 9
VARS_GFS = ["ghi_nwp", "k_nwp", "tcc", "t2m", "rh2m", "t2m_x_rh2m", "u10", "v10"]

# grupos de variáveis da Fig. 9 (ordem das linhas da figura)
GRUPOS_VSN = ["Past clear-sky index", "Rolling statistics", "NWP clear-sky index", "NWP GHI", "Cloud cover",
              "Temperature/RH", "Wind (u, v)", "Solar geometry", "Calendar"]
_GRUPO_DE = {"k": 0, "y": 0, **{f: 1 for f in FEAT_ROLL}, "k_nwp": 2, "ghi_nwp": 3, "tcc": 4, "t2m": 5,
             "rh2m": 5, "t2m_x_rh2m": 5, "u10": 6, "v10": 6, "cos_zen": 7, "ghi_cs": 7, "pcs": 7,
             "sin_h": 8, "cos_h": 8, "sin_doy": 8, "cos_doy": 8, "sin_mes": 8, "cos_mes": 8, "lead": 8}
VARS_ENC = FEAT_PASSADO + FEAT_CONHECIDO      # 27 variáveis do VSN do codificador
VARS_DEC = FEAT_NWP + FEAT_CONHECIDO          # 18 variáveis do VSN do decodificador
GRUPO_ENC = np.array([_GRUPO_DE[v] for v in VARS_ENC])
GRUPO_DEC = np.array([_GRUPO_DE[v] for v in VARS_DEC])


def grupo_dec(n_lag: int = 0) -> np.ndarray:
    """Grupos do VSN do decodificador. Com tft: lags_decodificador > 0, os k das últimas n_lag horas entram no
    fim do vetor do decodificador e contam como 'Past clear-sky index'."""
    return np.concatenate([GRUPO_DEC, np.full(int(n_lag), _GRUPO_DE["k"], dtype=GRUPO_DEC.dtype)])

REGIMES = ["Clear", "Partly", "Overcast"]
TERCIS = ["Low", "Mid", "High"]
ESTACOES = ["Winter", "Spring", "Summer", "Autumn"]
CEU = ["Sun", "LC", "HC"]
HORAS_GRUPO = list(range(6, 19))  # 13 grupos de hora local padrão


def regime_de(k_nwp: np.ndarray, limiares=(0.4, 0.8)) -> np.ndarray:
    """0 = claro (k >= 0,8), 1 = parcialmente nublado, 2 = encoberto (k < 0,4)."""
    k = np.nan_to_num(np.asarray(k_nwp, dtype=float), nan=0.0)
    return np.where(k >= limiares[1], 0, np.where(k >= limiares[0], 1, 2)).astype(np.int8)


def p_piso(h_nome: str) -> float:
    return min(7.0, 5.0 + 0.1 * H_LEAD_PISO[h_nome])


@dataclass
class Site:
    codigo: str
    cfg_site: dict
    y_max: float
    t_utc: pd.DatetimeIndex
    n: int                                # T (sem a folga)
    y: np.ndarray                         # potência normalizada observada (NaN se faltante)
    valido: np.ndarray                    # alvo válido: diurno, com dado e dia mantido no QC
    diurno: np.ndarray
    hora_lst: np.ndarray
    data_ord: np.ndarray                  # dia local (ordinal)
    doy: np.ndarray
    mes: np.ndarray
    bloco: np.ndarray                     # 0 fora, 1 treino, 2 validação, 3 calibração inicial, 4 teste
    mes_teste: np.ndarray
    pcs: np.ndarray
    ghi_cs: np.ndarray
    cos_zen: np.ndarray
    estacao: np.ndarray
    ceu: np.ndarray                       # classe de céu do dia local (diagnóstico)
    k_fill: np.ndarray
    y_fill: np.ndarray
    rolling: np.ndarray                   # (T, 16)
    conhecido: np.ndarray                 # (T, 9) cru
    nwp: np.ndarray                       # (T, 36, 9) cru, por emissão
    nwp_ok: np.ndarray                    # (T,) emissão com NWP disponível
    stats: dict                           # médias e desvios para padronizar
    janelas: pd.DataFrame                 # calibração/teste por mês
    sky_k: np.ndarray = field(default=None)
    indisp: np.ndarray = field(default=None)   # (k, 3): ordinal do 1º e do último dia e nº de dias sem a usina
    pcs_preenchidos: int = 0              # dias do ano do envelope de céu claro preenchidos (sem dado de treino)

    # ----------------------------------------------------------------- entradas padronizadas
    def passado_pad(self, k_fill=None, y_fill=None, rolling=None) -> np.ndarray:
        k_fill = self.k_fill if k_fill is None else k_fill
        y_fill = self.y_fill if y_fill is None else y_fill
        rolling = self.rolling if rolling is None else rolling
        P = np.column_stack([k_fill, y_fill, rolling]).astype(np.float32)
        return _padronizar(P, self.stats["passado"])

    def conhecido_pad(self) -> np.ndarray:
        return _padronizar(self.conhecido.astype(np.float32), self.stats["conhecido"])

    def nwp_pad(self, nwp=None) -> np.ndarray:
        nwp = self.nwp if nwp is None else nwp
        return _padronizar(nwp.astype(np.float32), self.stats["nwp"])


def _padronizar(X: np.ndarray, st: tuple) -> np.ndarray:
    m, s = st
    Z = (X - m) / s
    return np.nan_to_num(Z, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32)


def _stats(X: np.ndarray, linhas=None) -> tuple:
    A = X if linhas is None else X[linhas]
    A = A.reshape(-1, A.shape[-1]).astype(np.float64)
    m = np.nanmean(A, axis=0)
    s = np.nanstd(A, axis=0)
    s = np.where(~np.isfinite(s) | (s < 1e-6), 1.0, s)
    m = np.where(np.isfinite(m), m, 0.0)
    return m.astype(np.float32), s.astype(np.float32)


# ============================================================================ céu claro empírico
def envelope_ceu_claro(y, valido, hora, doy, treino, janela=15, sigma_dias=5.0, perc=99.0, ref=None,
                       info=None) -> np.ndarray:
    """P̃cs(hora, dia do ano): p99 da potência de treino na mesma hora, ±15 dias, suavizado (gaussiano
    circular no dia do ano). Devolve a tabela (24, 367); índice 0 do dia do ano não é usado.

    Com `ref` (GHI de céu claro de cada hora), os dias do ano sem nenhum dado de treino nas horas de sol alto (a
    usina sem dado válido naquela época do ano em todos os anos do treino, como a Laundry do YUL em out-dez) são
    preenchidos com a razão envelope/ref interpolada no dia do ano, vezes ref, em vez de ficarem em zero. Sem
    essas lacunas a tabela é idêntica à de antes. `info` (dict), se dado, recebe 'dias_preenchidos'."""
    tab = np.full((24, 367), np.nan)
    m = treino & valido & np.isfinite(y)
    for hh in range(24):
        sel = m & (hora == hh)
        if sel.sum() < 10:
            continue
        d_h, y_h = doy[sel].astype(int), y[sel]
        for d in range(1, 367):
            dist = np.abs(d_h - d)
            dist = np.minimum(dist, 366 - dist)
            v = y_h[dist <= janela]
            if v.size >= 5:
                tab[hh, d] = np.percentile(v, perc)
    if ref is not None:
        tab, n_pre = _preencher_lacunas_envelope(tab, hora, doy, ref)
        if info is not None:
            info["dias_preenchidos"] = n_pre
    tab = np.nan_to_num(tab, nan=0.0)
    # suavização gaussiana circular no dia do ano
    off = np.arange(-int(3 * sigma_dias), int(3 * sigma_dias) + 1)
    ker = np.exp(-0.5 * (off / sigma_dias) ** 2)
    ker /= ker.sum()
    lin = tab[:, 1:]
    lis = np.zeros_like(lin)
    for o, w in zip(off, ker):
        lis += w * np.roll(lin, -o, axis=1)
    tab[:, 1:] = lis
    return tab


def _preencher_lacunas_envelope(tab, hora, doy, ref, frac_alto=0.5, ref_min=20.0, viz=15) -> tuple:
    """Preenche os dias do ano em que o envelope não tem valor em nenhuma hora de sol alto (GHI de céu claro >=
    frac_alto do máximo do dia). Em cada hora, a razão envelope/ref dos dias conhecidos (mediana móvel de `viz`
    dias conhecidos) é interpolada no dia do ano, de forma circular, e multiplicada pelo ref médio da hora naquele
    dia. Devolve (tabela, nº de dias do ano preenchidos); sem lacunas, a tabela volta intacta."""
    R = np.zeros((24, 367))
    ok = np.isfinite(ref) & (doy >= 1) & (doy <= 366)
    m = pd.DataFrame({"h": hora[ok].astype(int), "d": doy[ok].astype(int),
                      "r": np.asarray(ref, dtype=np.float64)[ok]}).groupby(["h", "d"])["r"].mean()
    R[m.index.get_level_values(0).to_numpy(), m.index.get_level_values(1).to_numpy()] = m.to_numpy()
    pico = R[:, 1:].max(axis=0)
    alto = (R[:, 1:] >= frac_alto * pico[None, :]) & (pico[None, :] > ref_min)
    sem = np.array([bool(alto[:, k].any()) and bool(np.isnan(tab[alto[:, k], k + 1]).all()) for k in range(366)])
    if not sem.any():
        return tab, 0
    out = tab.copy()
    dias = np.arange(1, 367)
    for hh in range(24):
        r_h = R[hh, 1:]
        q = tab[hh, 1:] / np.where(r_h > ref_min, r_h, np.nan)
        conh = np.isfinite(q) & ~sem
        alvo = sem & (r_h > ref_min)
        if conh.sum() < 2 or not alvo.any():
            continue
        x = dias[conh]
        v = pd.Series(q[conh]).rolling(viz, center=True, min_periods=1).median().to_numpy()
        out[hh, dias[alvo]] = np.interp(dias[alvo], x, v, period=366) * r_h[alvo]
    return out, int(sem.sum())


# ============================================================================ passado observado
def entradas_passado(y, valido_entrada, pcs, diurno):
    """k e y com lacunas preenchidas por persistência do índice de céu claro (último k diurno válido)
    e as estatísticas móveis de k (média, desvio, mínimo, máximo em 6/12/24/48 h), só com o passado."""
    pc = np.maximum(pcs, 0.02)
    k = np.where(valido_entrada & np.isfinite(y), np.clip(y / pc, 0.0, 1.5), np.nan)
    k_d = pd.Series(np.where(diurno, k, np.nan))
    # persistência: último k diurno válido, propagado só nas horas diurnas
    k_ff = k_d.ffill().to_numpy()
    k_fill = np.where(diurno, np.nan_to_num(k_ff, nan=0.0), 0.0)
    y_fill = np.where(diurno, k_fill * pcs, 0.0)
    y_fill = np.where(valido_entrada & np.isfinite(y), y, y_fill)
    base = pd.Series(np.where(diurno, k_fill, np.nan))
    cols = []
    for w in JANELAS_ROLL:
        r = base.rolling(w, min_periods=1)
        cols += [r.mean(), r.std(ddof=0), r.min(), r.max()]
    R = pd.concat(cols, axis=1).ffill().fillna(0.0).to_numpy(dtype=np.float32)
    return k_fill.astype(np.float32), y_fill.astype(np.float32), R


# ============================================================================ estações e céu
def estacoes(doy: np.ndarray, lat: float) -> np.ndarray:
    """Estação local de três meses centrada em solstícios e equinócios (hemisférios alinhados)."""
    centros = np.array([355, 80, 172, 266])  # inverno, primavera, verão, outono no hemisfério norte
    d = np.abs(doy[:, None] - centros[None, :])
    d = np.minimum(d, 365 - d)
    e = np.argmin(d, axis=1)
    if lat < 0:
        e = np.array([2, 3, 0, 1])[e]
    return e.astype(np.int8)


def classes_ceu(y, pcs, valido, diurno, data_ord) -> np.ndarray:
    """Classe do dia (Seção V-B): Sun se K_d >= 0,75 e V_d <= 0,08; HC se K_d < 0,40; LC nos demais."""
    df = pd.DataFrame({"d": data_ord, "y": np.where(valido, y, np.nan), "p": np.where(valido, pcs, np.nan),
                       "k": np.where(valido, np.clip(y / np.maximum(pcs, 0.02), 0, 1.5), np.nan)})
    df = df[diurno]
    g = df.groupby("d")
    Kd = g["y"].sum(min_count=1) / g["p"].sum(min_count=1)
    Vd = g["k"].apply(lambda s: np.nanmean(np.abs(np.diff(s.dropna().to_numpy()))) if s.notna().sum() > 1 else np.nan)
    cls = pd.Series(1, index=Kd.index, dtype=np.int8)
    cls[(Kd >= 0.75) & (Vd <= 0.08)] = 0
    cls[Kd < 0.40] = 2
    return pd.Series(data_ord).map(cls).fillna(1).astype(np.int8).to_numpy()


# ============================================================================ GFS por emissão
def _tabela_ciclos(gfs: pd.DataFrame, max_off: int = 74):
    c = pd.DatetimeIndex(gfs["ciclo_utc"]).tz_convert("UTC")
    v = pd.DatetimeIndex(gfs["valido_utc"]).tz_convert("UTC")
    c0 = c.min().floor("6h")
    ci = ((c - c0) / pd.Timedelta(hours=6)).astype(int).to_numpy()
    off_h = ((v - c) / pd.Timedelta(hours=1)).to_numpy()
    o = np.floor(off_h + 1e-6).astype(int)
    frac = float(np.median(off_h - o))
    nc = int(ci.max()) + 1
    G = np.full((nc, max_off, len(VARS_GFS)), np.nan, dtype=np.float32)
    ok = (o >= 0) & (o < max_off)
    vals = gfs[VARS_GFS].to_numpy(dtype=np.float32)
    G[ci[ok], o[ok]] = vals[ok]
    return G, c0, frac


def nwp_por_emissao(t_utc: pd.DatetimeIndex, G, c0, emissoes: np.ndarray, atraso_h: int = 0,
                    recuos: int = 4) -> tuple:
    """(nwp (n, 36, 9) com o lead na última coluna, ok (n,)) do ciclo disponível em cada emissão:
    maior ciclo c com c + 5 h <= t0 (menos atraso_h); se faltar, recua 6 h por vez (até 24 h)."""
    t0 = t_utc[emissoes]
    c = (t0 - pd.Timedelta(hours=LAT_GFS_H)).floor("6h") - pd.Timedelta(hours=atraso_h)
    ci0 = np.round(((c - c0) / pd.Timedelta(hours=6)).to_numpy()).astype(int)
    base_off = np.round(((t0 - c) / pd.Timedelta(hours=1)).to_numpy() - 1e-6).astype(int)
    n = len(emissoes)
    out = np.full((n, DEC, len(VARS_GFS)), np.nan, dtype=np.float32)
    lead = np.full((n, DEC), np.nan, dtype=np.float32)
    j = np.arange(DEC)
    for r in range(recuos + 1):
        ci = ci0 - r
        off = base_off[:, None] + j[None, :] + 6 * r
        valid_idx = (ci >= 0) & (ci < G.shape[0])
        cic = np.clip(ci, 0, G.shape[0] - 1)
        offc = np.clip(off, 0, G.shape[1] - 1)
        cand = G[cic[:, None], offc]                               # (n, 36, 8)
        cand[~valid_idx] = np.nan
        cand[(off < 0) | (off >= G.shape[1])] = np.nan
        falta = ~np.isfinite(out[..., 0]) & np.isfinite(cand[..., 0])
        out[falta] = cand[falta]
        lead[falta] = (off + 1)[falta]
    ok = np.isfinite(out[..., 0]).mean(axis=1) >= 0.9
    nwp = np.concatenate([out, lead[..., None]], axis=2)
    return nwp, ok


# ============================================================================ carga principal
def _assinatura(arquivos) -> str:
    h = hashlib.sha1()
    for a in arquivos:
        st = a.stat()
        h.update(f"{a.name}:{st.st_size}:{int(st.st_mtime)}".encode())
    return h.hexdigest()[:12]


def capacidade_indisponivel(y, diurno, manter, data_ord, treino, disp: dict, codigo: str = "") -> tuple:
    """Horas de dias em que a usina esteve quase toda indisponível (QC extra, Seção V-B).

    Um dia é marcado quando o máximo diário de y numa janela centrada de `janela_dias` dias fica abaixo de
    `frac_p99` vezes o p99 diurno do treino, em trechos de pelo menos `min_dias` dias. Nuvens não derrubam
    o máximo de uma semana inteira a esse ponto; usina parada ou registro corrompido derrubam (no YUL com a
    Laundry, de 01/01 a 18/02/2022 a coluna da usina no arquivo do DKASC traz ~1 kW). Todos os dias marcados
    saem das entradas; nos trechos, conta só os dias que o QC da coleta tinha mantido (os outros já estavam fora dos
    alvos). Devolve (máscara horária, trechos (k, 3) com o ordinal do primeiro e do último dia e o nº de dias que
    a regra tira além do QC; trechos só com dias já removidos pelo QC não entram)."""
    out = np.zeros(len(y), dtype=bool)
    trechos = np.zeros((0, 3), dtype=np.int64)
    if not disp or float(disp.get("frac_p99", 0)) <= 0:
        return out, trechos
    ok = diurno & manter & np.isfinite(y)
    ref = float(np.nanpercentile(y[ok & treino], 99)) if (ok & treino).any() else np.nan
    if not np.isfinite(ref) or ref <= 0:
        return out, trechos
    dias = pd.Series(np.where(diurno & np.isfinite(y), y, np.nan)).groupby(data_ord).max()
    dias = dias.reindex(np.arange(dias.index.min(), dias.index.max() + 1))
    janela = int(disp.get("janela_dias", 7))
    rmax = dias.rolling(janela, center=True, min_periods=max(1, janela // 2)).max()
    baixo = (rmax < float(disp["frac_p99"]) * ref).to_numpy()
    mantido = (pd.Series(diurno & manter).groupby(data_ord).any()
               .reindex(dias.index, fill_value=False).to_numpy(dtype=bool))     # dia que o QC da coleta manteve
    marcados = np.zeros(len(baixo), dtype=bool)
    lista = []
    i = 0
    while i < len(baixo):
        if baixo[i]:
            j = i
            while j + 1 < len(baixo) and baixo[j + 1]:
                j += 1
            if j - i + 1 >= int(disp.get("min_dias", 3)):
                marcados[i:j + 1] = True
                extra = int(mantido[i:j + 1].sum())
                if extra:
                    lista.append((int(dias.index[i]), int(dias.index[j]), extra))
                d0 = pd.Timestamp.fromordinal(int(dias.index[i])).date()
                d1 = pd.Timestamp.fromordinal(int(dias.index[j])).date()
                log.warning("%s: potência registrada muito abaixo da capacidade de %s a %s (%d dias, %s; máximo "
                            "semanal < %.0f%% do p99 do treino: usina parada ou registro corrompido); esses dias "
                            "ficam fora do experimento", codigo, d0, d1, j - i + 1,
                            f"{extra} deles mantidos pelo QC da coleta" if extra else "todos já removidos pelo QC",
                            100 * float(disp["frac_p99"]))
            i = j + 1
        else:
            i += 1
    dias_marcados = set(dias.index[marcados].tolist())
    if dias_marcados:
        out = np.isin(data_ord, np.fromiter(dias_marcados, dtype=np.int64))
    if lista:
        trechos = np.array(lista, dtype=np.int64)
    return out, trechos


def meses_teto_baixo(proc, arq_part) -> tuple:
    """Meses em que o teto mensal (p99) da potência ficou abaixo de 80% da referência de céu claro da coleta
    (resumo.json, 'meses_teto_abaixo_80pct'). Devolve (todos, só os do período de teste), como textos
    'AAAA-MM (razão)'. Muitos meses assim, sobretudo no ano de teste, indicam que a saída não acompanha a
    irradiância (limitação imposta pela rede ou unidades fora), o que nenhum previsor resolve."""
    import json

    arq = proc / "resumo.json"
    if not arq.exists():
        return [], []
    try:
        todos = [str(x) for x in json.loads(arq.read_text(encoding="utf-8")).get("meses_teto_abaixo_80pct", [])]
        t = pd.read_csv(arq_part)
        te = t[t["bloco"] == "teste"]
        ini, fim = str(te["inicio_lst"].min())[:7], str(te["fim_lst"].max())[:7]
        teste = [x for x in todos if ini <= x[:7] < fim]
    except Exception:  # noqa: BLE001
        return [], []
    return todos, teste


def razao_teto(texto: str) -> float:
    """'2025-08 (0.56)' -> 0.56 (NaN se não der para ler)."""
    try:
        return float(texto.split("(")[1].split(")")[0])
    except Exception:  # noqa: BLE001
        return float("nan")


def conferir_processado(s: dict, proc) -> str:
    """'' se a coleta processada (resumo.json) bate com o config.yaml da coleta (usina, período e Pnom); senão,
    o que difere. Pega, por exemplo, o YUL ainda processado com o Desert Gardens depois da troca pela Laundry."""
    import json
    from pathlib import Path

    arq = Path(proc) / "resumo.json"
    if not arq.exists():
        return ""
    try:
        rz = json.loads(arq.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return ""
    dif = []
    if rz.get("nome") is not None and str(rz["nome"]) != str(s.get("nome")):
        dif.append(f"usina “{rz['nome']}” (config: “{s.get('nome')}”)")
    per = f"{s.get('inicio')} a {s.get('fim')}"
    if rz.get("periodo") is not None and str(rz["periodo"]) != per:
        dif.append(f"período {rz['periodo']} (config: {per})")
    if s.get("pnom_kw") is not None and rz.get("pnom_kw") is not None \
            and abs(float(rz["pnom_kw"]) - float(s["pnom_kw"])) > 0.05:
        dif.append(f"Pnom {rz['pnom_kw']} kW (config: {s['pnom_kw']} kW)")
    return "; ".join(dif)


def carregar_site(cfg: dict, codigo: str, pastas: dict) -> Site:
    from .config import site as site_cfg

    s = site_cfg(cfg, codigo)
    proc = pastas["proc"]
    arq_p, arq_g, arq_part = proc / "potencia_horaria.parquet", proc / "gfs_horario.parquet", proc / "particoes.csv"
    for a in (arq_p, arq_part):
        if not a.exists():
            raise SystemExit(f"falta {a}; rode a coleta (rodar_potencia.bat) antes")
    dif = conferir_processado(s, proc)
    if dif:
        raise SystemExit(f"{codigo}: a coleta processada não bate com o config.yaml da coleta ({dif}). Refaça a "
                         f"coleta do site: no PC, coleta_dados\\rodar_yul.bat para o YUL; em geral, "
                         f"'python coletar.py processar --sites {codigo}' na pasta coleta_dados.")
    todos, teste = meses_teto_baixo(proc, arq_part)
    if sum(razao_teto(x) < 0.70 for x in teste) >= 2:     # verões quentes ficam em 0,76-0,80 (GEO): não avisa
        log.warning("%s: em %d meses (%d do ano de teste: %s) o teto mensal da potência ficou abaixo de 80%% da "
                    "referência de céu claro da coleta. Nesses meses a saída não acompanha a irradiância (limitação "
                    "imposta pela rede ou unidades fora), e os intervalos e a comparação entre métodos neste site "
                    "refletem isso. Veja o README, seção 6.", codigo, len(todos), len(teste), ", ".join(teste))
    if not arq_g.exists():
        raise SystemExit(
            f"falta {arq_g}.\nO GFS de {codigo} ainda não foi processado. Termine o download do GFS e rode "
            "'python coletar.py processar --sites " + codigo + "' na pasta coleta_dados (ou o rodar_gfs.bat).")
    disp = dict(cfg.get("disponibilidade") or {})
    assin = (_assinatura([arq_p, arq_g, arq_part]) + f"-ymax{s['y_max']}-v{VERSAO_CACHE}-"
             + hashlib.sha1(repr(sorted(disp.items())).encode()).hexdigest()[:6])
    cache = pastas["cache"] / f"site_{assin}.npz"
    if cache.exists():
        try:
            return _ler_cache(cache, s, arq_part)
        except Exception as e:  # noqa: BLE001
            log.warning("cache %s ilegível (%s); refazendo", cache.name, e)
    log.info("%s: montando a série horária, o envelope de céu claro e as entradas", codigo)
    p = pd.read_parquet(arq_p)
    p["tempo_utc"] = pd.to_datetime(p["tempo_utc"], utc=True)
    p = p.sort_values("tempo_utc").drop_duplicates("tempo_utc").set_index("tempo_utc")
    grade = pd.date_range(p.index.min(), p.index.max(), freq="h")
    p = p.reindex(grade)
    n = len(p)
    tz = s["fuso_lst"]
    lst = grade.tz_convert(tz)
    hora = lst.hour.to_numpy().astype(np.int16)
    doy = lst.dayofyear.to_numpy().astype(np.int16)
    mes = lst.month.to_numpy().astype(np.int16)
    data_ord = np.array([d.toordinal() for d in lst.date], dtype=np.int32)
    y = p["y"].to_numpy(dtype=np.float64)
    diurno = p["diurno"].fillna(False).to_numpy(dtype=bool)
    manter = p["manter_dia"].fillna(False).to_numpy(dtype=bool)
    cod_bloco = {"fora": 0, "treino": 1, "validacao": 2, "calibracao_inicial": 3, "teste": 4}
    bloco = p["bloco"].map(cod_bloco).fillna(0).to_numpy(dtype=np.int8)
    indisp, trechos_indisp = capacidade_indisponivel(y, diurno, manter, data_ord, bloco == 1, disp, codigo)
    y = np.where(indisp & diurno, np.nan, y)  # dias sem a usina: fora dos alvos e tratados como falta nas entradas
    valido = diurno & manter & np.isfinite(y)
    if s["y_max"] == "auto":                 # ȳ: maior y diurno válido do treino, arredondado para cima (0,01)
        s["y_max"] = float(np.ceil(np.nanmax(y[valido & (bloco == 1)]) * 100.0 - 1e-9) / 100.0)
    log.info("%s: limite físico ȳ = %.2f", codigo, s["y_max"])
    mes_teste = p["mes_teste"].fillna(0).to_numpy(dtype=np.int8)
    ghi_cs = p["ghi_cs"].fillna(0.0).to_numpy(dtype=np.float32)
    cos_zen = p["cos_zenite"].fillna(0.0).to_numpy(dtype=np.float32)

    info_env = {}
    tab = envelope_ceu_claro(y, valido, hora, doy, bloco == 1, ref=ghi_cs, info=info_env)
    pcs_preenchidos = int(info_env.get("dias_preenchidos", 0))
    if pcs_preenchidos:
        log.warning("%s: %d dias do ano sem nenhum dado de treino nas horas de sol (em todos os anos do treino); "
                    "o envelope de céu claro desses dias vem da razão envelope/GHI de céu claro, interpolada no dia "
                    "do ano", codigo, pcs_preenchidos)
    pcs = tab[hora, np.clip(doy, 1, 366)].astype(np.float32)
    pcs = np.where(diurno, pcs, 0.0).astype(np.float32)
    # entradas: só o que se sabe no instante da emissão (dado diurno presente); o QC do dia inteiro decide
    # apenas quais horas entram como alvo de treino, calibração e avaliação
    k_fill, y_fill, R = entradas_passado(y, diurno & np.isfinite(y), pcs, diurno)
    conhecido = np.column_stack([
        cos_zen, ghi_cs / 1000.0, pcs,
        np.sin(2 * np.pi * hora / 24), np.cos(2 * np.pi * hora / 24),
        np.sin(2 * np.pi * doy / 365.25), np.cos(2 * np.pi * doy / 365.25),
        np.sin(2 * np.pi * mes / 12), np.cos(2 * np.pi * mes / 12)]).astype(np.float32)

    log.info("%s: lendo o GFS e montando as entradas futuras (ciclo disponível, latência de %d h)", codigo, LAT_GFS_H)
    g = pd.read_parquet(arq_g, columns=["ciclo_utc", "valido_utc"] + VARS_GFS)
    G, c0, _ = _tabela_ciclos(g)
    nwp_pad = np.full((n + PAD, DEC, len(FEAT_NWP)), np.nan, dtype=np.float32)
    ok_pad = np.zeros(n + PAD, dtype=bool)
    idx = np.arange(n)
    for a in range(0, n, 20000):
        b = min(n, a + 20000)
        nw, ok = nwp_por_emissao(grade, G, c0, idx[a:b])
        nwp_pad[a:b], ok_pad[a:b] = nw, ok
    del G, g

    def pad1(x, v=0):
        return np.concatenate([x, np.full((PAD,) + x.shape[1:], v, dtype=x.dtype)])

    est = estacoes(doy.astype(int), float(s["lat"]))
    ceu = classes_ceu(y, pcs, valido, diurno, data_ord)
    treino = (bloco == 1)
    stats = {"passado": _stats(np.column_stack([k_fill, y_fill, R]), treino),
             "conhecido": _stats(conhecido, treino),
             "nwp": _stats(nwp_pad[:n][treino & ok_pad[:n]])}
    t_ext = pd.date_range(grade[0], periods=n + PAD, freq="h")
    site = Site(codigo=codigo, cfg_site=s, y_max=s["y_max"], t_utc=t_ext, n=n,
                y=pad1(y, np.nan), valido=pad1(valido, False), diurno=pad1(diurno, False),
                hora_lst=pad1(hora), data_ord=pad1(data_ord), doy=pad1(doy), mes=pad1(mes),
                bloco=pad1(bloco), mes_teste=pad1(mes_teste), pcs=pad1(pcs), ghi_cs=pad1(ghi_cs),
                cos_zen=pad1(cos_zen), estacao=pad1(est), ceu=pad1(ceu), k_fill=pad1(k_fill), y_fill=pad1(y_fill),
                rolling=pad1(R), conhecido=pad1(conhecido), nwp=nwp_pad, nwp_ok=ok_pad, stats=stats,
                janelas=_janelas(arq_part), indisp=trechos_indisp, pcs_preenchidos=pcs_preenchidos)
    pct = 100.0 * (1 - ok_pad[:n][bloco >= 1].mean())
    log.info("%s: %d horas (%s a %s); emissões sem NWP: %.2f%%", codigo, n, grade[0], grade[-1], pct)
    if pct > 5:
        log.warning("%s: %.1f%% das emissões sem GFS; confira se o download do GFS terminou", codigo, pct)
    _gravar_cache(cache, site)
    return site


def verificar_nwp(site: Site, minimo: float = 0.95) -> None:
    """Para com uma mensagem clara se o GFS não cobre o período do experimento (download incompleto)."""
    n = site.n
    ok = site.nwp_ok[:n]
    alvo = site.valido[:n]
    aval = alvo & (site.bloco[:n] >= 2)
    trein = alvo & (site.bloco[:n] == 1)
    c_aval = float(ok[aval].mean()) if aval.any() else 0.0
    c_trein = float(ok[trein].mean()) if trein.any() else 0.0
    if c_aval >= minimo and c_trein >= minimo - 0.05:
        return
    com = np.where(ok)[0]
    ult = str(site.t_utc[com.max()])[:16] if com.size else "nenhum"
    fim = str(site.t_utc[np.where(site.bloco[:n] == 4)[0].max()])[:16] if (site.bloco[:n] == 4).any() else "?"
    raise SystemExit(
        f"O GFS de {site.codigo} cobre só {100 * c_trein:.0f}% das horas de treino e {100 * c_aval:.0f}% das de "
        f"validação, calibração e teste (última emissão com GFS: {ult}; o teste vai até {fim}).\n"
        "Parece que o download do GFS não terminou. Termine o download e rode de novo o processamento do GFS "
        f"('python coletar.py processar --sites {site.codigo}' na pasta coleta_dados) antes dos experimentos.\n"
        "Se faltar um trecho do arquivo do GFS e você quiser seguir assim mesmo, baixe 'nwp_cobertura_minima' no "
        "config_experimentos.yaml.")


def _janelas(arq_part) -> pd.DataFrame:
    t = pd.read_csv(arq_part)
    for c in ("inicio_utc", "fim_utc"):
        t[c] = pd.to_datetime(t[c], utc=True)
    cal = t[t["bloco"] == "calibracao"].set_index("mes_teste")
    te = t[t["bloco"] == "teste"].set_index("mes_teste")
    return pd.DataFrame({"cal_ini": cal["inicio_utc"], "cal_fim": cal["fim_utc"],
                         "te_ini": te["inicio_utc"], "te_fim": te["fim_utc"]}).sort_index()


_CAMPOS = ["y", "valido", "diurno", "hora_lst", "data_ord", "doy", "mes", "bloco", "mes_teste", "pcs", "ghi_cs",
           "cos_zen", "estacao", "ceu", "k_fill", "y_fill", "rolling", "conhecido", "nwp", "nwp_ok", "indisp"]


def _gravar_cache(caminho, site: Site) -> None:
    d = {c: getattr(site, c) for c in _CAMPOS}
    d["t0"] = np.array([site.t_utc[0].value], dtype=np.int64)
    d["n"] = np.array([site.n])
    d["y_max"] = np.array([site.y_max], dtype=np.float64)
    d["pcs_preenchidos"] = np.array([int(site.pcs_preenchidos)], dtype=np.int64)
    for k, (m, s_) in site.stats.items():
        d[f"st_{k}_m"], d[f"st_{k}_s"] = m, s_
    tmp = caminho.with_name(caminho.stem + ".tmp.npz")
    np.savez(tmp, **d)
    tmp.replace(caminho)
    for velho in caminho.parent.glob("site_*.npz"):      # versões antigas do cache da série (dados ou código)
        if velho != caminho:
            try:
                velho.unlink()
            except OSError:
                pass


def _ler_cache(caminho, s: dict, arq_part) -> Site:
    with np.load(caminho) as z:
        d = {c: z[c] for c in _CAMPOS}
        t0 = pd.Timestamp(int(z["t0"][0]), tz="UTC")
        n = int(z["n"][0])
        s = dict(s, y_max=float(z["y_max"][0]))
        stats = {k: (z[f"st_{k}_m"], z[f"st_{k}_s"]) for k in ("passado", "conhecido", "nwp")}
        pre = int(z["pcs_preenchidos"][0]) if "pcs_preenchidos" in z.files else 0
    t = pd.date_range(t0, periods=len(d["y"]), freq="h")
    return Site(codigo=s["codigo"], cfg_site=s, y_max=s["y_max"], t_utc=t, n=n, stats=stats,
                janelas=_janelas(arq_part), pcs_preenchidos=pre, **d)


# ============================================================================ pares de avaliação
def tabela_pares(site: Site, blocos=(2, 3, 4), limiares=(0.4, 0.8)) -> pd.DataFrame:
    """Pares (emissão i, passo j, alvo t = i + j) dos quatro horizontes, só com alvos válidos dos blocos
    pedidos (padrão: validação, calibração inicial e teste)."""
    n = site.n
    alvo_ok = site.valido[:n] & np.isin(site.bloco[:n], blocos)
    linhas = []
    for hi, h in enumerate(HORIZONTES):
        if h == "DA":
            emis = np.where(site.hora_lst[:n] == 12)[0]
            for j in range(12, 36):
                t = emis + j
                m = (t < n) & (emis >= ENC)
                linhas.append(pd.DataFrame({"h": hi, "i": emis[m], "j": j, "t": t[m]}))
        else:
            j = H_PASSO[h] - 1
            t = np.arange(ENC + j, n)
            linhas.append(pd.DataFrame({"h": hi, "i": t - j, "j": j, "t": t}))
    P = pd.concat(linhas, ignore_index=True)
    P = P[alvo_ok[P["t"].to_numpy()]].reset_index(drop=True)
    # sem GFS para a hora-alvo (nem nos ciclos de reserva até 24 h antes) a previsão não segue a especificação:
    # o par sai de todos os métodos, em vez de cair no regime "encoberto" com NWP imputado
    k_nwp = site.nwp[P["i"].to_numpy(), P["j"].to_numpy(), FEAT_NWP.index("k_nwp")]
    sem = ~np.isfinite(k_nwp)
    if sem.any():
        log.info("%s: %d de %d pares sem GFS para a hora-alvo ficam de fora (%.2f%%)", site.codigo, int(sem.sum()),
                 len(P), 100.0 * sem.mean())
        P, k_nwp = P[~sem].reset_index(drop=True), k_nwp[~sem]
    t, i, j = P["t"].to_numpy(), P["i"].to_numpy(), P["j"].to_numpy()
    P["y"] = site.y[t].astype(np.float32)
    P["pcs"] = site.pcs[t]
    P["hora"] = np.clip(site.hora_lst[t], 6, 18).astype(np.int8)
    P["k_nwp"] = k_nwp
    P["regime"] = regime_de(P["k_nwp"].to_numpy(), limiares)
    P["data"] = site.data_ord[t]
    P["paridade"] = (site.data_ord[t] % 2).astype(np.int8)
    P["bloco"] = site.bloco[t]
    P["mes_teste"] = site.mes_teste[t]
    P["estacao"] = site.estacao[t]
    P["ceu"] = site.ceu[t]
    P["mes"] = site.mes[t]
    return P


def mascara_janela(site: Site, P: pd.DataFrame, ini, fim) -> np.ndarray:
    tt = site.t_utc[P["t"].to_numpy()]
    return np.asarray((tt >= ini) & (tt < fim))


# ============================================================================ entradas tabulares
def tabular(site: Site, i: np.ndarray, j: np.ndarray, k_fill=None, rolling=None, nwp=None) -> np.ndarray:
    """Entradas tabulares de um par (emissão i, passo j): k das 3 últimas horas, k da mesma hora nos 5 dias
    mais recentes disponíveis, estatísticas móveis em t0, GFS da hora-alvo, geometria e calendário."""
    k_fill = site.k_fill if k_fill is None else k_fill
    rolling = site.rolling if rolling is None else rolling
    nwp = site.nwp if nwp is None else nwp
    t = i + j
    lag = [k_fill[i - 1], k_fill[i - 2], k_fill[i - 3]]
    dmin = np.ceil((j + 1) / 24.0).astype(int)
    mesma = [k_fill[np.maximum(t - 24 * (dmin + d), 0)] for d in range(5)]
    X = np.column_stack(lag + mesma + [rolling[i - 1], nwp[i, j], site.conhecido[t]])
    return np.nan_to_num(X.astype(np.float32), nan=0.0)


NOMES_TABULAR = (["k_l1", "k_l2", "k_l3"] + [f"k_dia{d + 1}" for d in range(5)] + FEAT_ROLL + FEAT_NWP
                 + FEAT_CONHECIDO)


def contexto_lstm(site: Site, i: np.ndarray, j: np.ndarray, k_fill=None, rolling=None, nwp=None) -> np.ndarray:
    """Vetor c_τ do LSTM do artigo 1 (Tabela de entradas): 5 lags da mesma hora, estatísticas móveis,
    GFS, geometria e calendário da hora-alvo (39 entradas, sem padronizar)."""
    X = tabular(site, i, j, k_fill, rolling, nwp)
    return X[:, 3:]


def sequencia_lstm_base(site: Site, k_fill=None, y_fill=None) -> np.ndarray:
    """Matriz (T, 6) de onde saem as sequências do LSTM: k, y, sin/cos da hora e do dia do ano."""
    k_fill = site.k_fill if k_fill is None else k_fill
    y_fill = site.y_fill if y_fill is None else y_fill
    c = site.conhecido
    return np.column_stack([k_fill, y_fill, c[:, 3], c[:, 4], c[:, 5], c[:, 6]]).astype(np.float32)


# ============================================================================ degradações (Seção V-D)
def lacunas_aleatorias(site: Site, frac: float, rng: np.random.Generator, desde: int) -> np.ndarray:
    """Máscara de horas removidas do histórico de potência: lacunas de 1 a 24 h até tirar `frac` das horas
    diurnas válidas a partir do índice `desde`."""
    n = site.n
    alvo = site.valido[:n].copy()
    alvo[:desde] = False
    total = alvo.sum()
    tirar = np.zeros(n, dtype=bool)
    removidas = 0
    tent = 0
    while removidas < frac * total and tent < 10_000_000:
        tent += 1
        ini = int(rng.integers(desde, n))
        L = int(rng.integers(1, 25))
        seg = slice(ini, min(n, ini + L))
        novas = (alvo[seg] & ~tirar[seg]).sum()
        tirar[seg] = True
        removidas += novas
    return np.concatenate([tirar, np.zeros(PAD, dtype=bool)])


def passado_com_lacunas(site: Site, tirar: np.ndarray):
    ve = site.diurno & np.isfinite(site.y) & ~tirar
    n = site.n
    k, y_, R = entradas_passado(site.y[:n], ve[:n], site.pcs[:n], site.diurno[:n])
    pad = lambda x: np.concatenate([x, np.zeros((PAD,) + x.shape[1:], dtype=x.dtype)])  # noqa: E731
    return pad(k), pad(y_), pad(R)


def nwp_ruidoso(site: Site, rel_sd: float, rng: np.random.Generator, emissoes: np.ndarray) -> np.ndarray:
    """Ruído multiplicativo no GHI e no índice de céu claro do GFS (mesmo fator) e aditivo na nebulosidade,
    com desvio relativo rel_sd (S1, S2)."""
    nw = site.nwp.copy()
    sub = nw[emissoes]
    f = 1.0 + rel_sd * rng.standard_normal(sub.shape[:2]).astype(np.float32)
    ig, ik, ic = FEAT_NWP.index("ghi_nwp"), FEAT_NWP.index("k_nwp"), FEAT_NWP.index("tcc")
    sub[..., ig] = np.maximum(sub[..., ig] * f, 0.0)
    sub[..., ik] = np.clip(sub[..., ik] * f, 0.0, 1.5)
    sub[..., ic] = np.clip(sub[..., ic] + rel_sd * rng.standard_normal(sub.shape[:2]).astype(np.float32), 0.0, 1.0)
    nw[emissoes] = sub
    return nw


def nwp_atrasado(site: Site, cfg: dict, emissoes: np.ndarray, atraso_h: int = 24) -> np.ndarray:
    """NWP do ciclo emitido 24 h antes (S3)."""
    g = pd.read_parquet(cfg["pasta_processados"] / site.codigo / "gfs_horario.parquet",
                        columns=["ciclo_utc", "valido_utc"] + VARS_GFS)
    G, c0, _ = _tabela_ciclos(g)
    nw = site.nwp.copy()
    out, _ = nwp_por_emissao(site.t_utc, G, c0, emissoes, atraso_h=atraso_h)
    nw[emissoes] = out
    return nw
