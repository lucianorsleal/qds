"""Experimentos do artigo CCP-Boot-TFT-ICSO-PP (artigo 2), um site por vez.

Módulos:
    config      leitura do config_experimentos.yaml e do config.yaml da coleta
    dados       séries horárias, envelope de céu claro, entradas do TFT, pares de avaliação
    redes       TFT (Lim et al., 2021) e LSTM do artigo 1, em PyTorch puro
    treino      treino com bootstrap por dias, jitter, early stopping; inferência e cache
    conformal   camadas de calibração (split, Mondrian, BatchMVP, conformal condicional)
    fitness     funções de aptidão do Estágio 3 (IS condicional e IS Mondrian, validação cruzada)
    otimizadores ICSO-PP, ICSO, CSO, CMA-ES, L-SHADE, PSO e TPE com o mesmo orçamento
    baselines   CH-PeEn, LightGBM + CQR, HEC-XGB
    metricas    IS, PICP, PINAW, CRPS, FSS, WGC, CCD, coberturas por grupo, DM, Holm, Wilcoxon
    pipeline    orquestra as etapas por semente, com cache e retomada
    relatorio   agrega as sementes e grava os CSVs no formato do artigo; junta os sites
"""

__version__ = "3.1.1"   # 3.1.1: YUL com a Laundry (2021-2025) e regra de disponibilidade contada além do QC; v3.1: LightGBM com alvo k, scripts do Linux; v3: híbrido TFT + LightGBM, escalas de cada lado, sem ICSO-PP
