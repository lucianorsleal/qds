# Rodada final no Linux (GPU NVIDIA) — pacote v3.1

Roteiro para rodar os experimentos do artigo do zero numa máquina Linux com GPU NVIDIA:

- **Sites:** GEO, BRA e YUL. O YUL passa a ser a usina Laundry, em 2021–2025 com teste em 2025 (README, seção 6,
  item 21).
- **Sementes:** 10, que é o que o artigo diz.
- **Modelo:** v3.1 (pacote 3.1.1).

No fim saem as tabelas, figuras, macros e o guia do artigo.

**Tempo:** a coleta do YUL é feita antes, no PC, em poucos minutos (passo 1). No Linux, GEO e BRA levam ~4–8 h e
o YUL mais ~1–3 h.

## 0. O que a máquina precisa

- **GPU:** Linux com GPU NVIDIA e driver instalado (`nvidia-smi` mostra a placa).
- **Python:** 3.10, 3.11 ou 3.12, com `venv`. No Ubuntu: `sudo apt install python3-venv tmux`.
- **Disco e rede:** ~30 GB livres e internet para o pip.
- **tmux**, para deixar as rodadas andando com o terminal fechado. O básico:
  - `tmux new -s nome` cria a sessão;
  - `Ctrl+B` e depois `D` sai dela sem parar nada;
  - `tmux attach -t nome` volta.

## 1. No PC: refazer a coleta do YUL e levar as pastas

Primeiro, no PC, dê dois cliques em `C:\Users\Luciano\Downloads\novo_artigo\coleta_dados\rodar_yul.bat`. Com os
arquivos do DKASC e o GFS de 2021–2025 já baixados, leva poucos minutos:

1. Confere a Laundry (`verificar_yul.py`). A tabela mostra 18 meses "removido", que a coleta tira (maio a dezembro
   de 2021 e de 2022 e jan/2022, com outro canal na coluna da usina, e nov/2023, sem dados), e deve terminar com
   "OK".
   - **Se aparecer "ATENÇÃO"**, o script para. Não processe o YUL; mande a tabela impressa para eu analisar.
2. Reprocessa a série do YUL e o GFS. No `dados\processados\relatorio_coleta.md`, o YUL deve aparecer como
   "Laundry", 327,6 kW, com ~38% dos dias removidos no QC.

Depois abra o PowerShell na pasta `C:\Users\Luciano\Downloads\novo_artigo` e gere um arquivo único:

```powershell
tar -czf rodada_final.tgz --exclude=experimentos/.venv --exclude=coleta_dados/.venv --exclude=__pycache__ `
  --exclude=experimentos/resultados `
  --exclude=experimentos/resultados_rapido --exclude=experimentos/saida_artigo `
  --exclude=experimentos/saida_artigo_rapido --exclude=experimentos/versao1 --exclude=experimentos/versao2 `
  --exclude=experimentos/versao3 `
  --exclude=coleta_dados/dados/brutos `
  --exclude=coleta_dados/gdex_token.txt --exclude=coleta_dados/hf_token.txt `
  experimentos coleta_dados artigo2_3sites
```

O arquivo fica com alguns centos de MB. O comando deixa de fora:
- **Resultados antigos:** a rodada final é do zero na máquina nova, com o mesmo hardware em todas as sementes.
- **Dados brutos da coleta** (DKASC, PVDAQ e GFS, vários GB): os três sites vão já processados, com o YUL que o
  `rodar_yul.bat` acabou de refazer.
- **Arquivos de token:** a coleta pelo THREDDS não usa login.

Copie o `rodada_final.tgz` para a máquina Linux (scp, WinSCP ou pendrive) e extraia:

```bash
mkdir -p ~/novo_artigo && tar -xzf rodada_final.tgz -C ~/novo_artigo && cd ~/novo_artigo && ls
# experimentos  coleta_dados  artigo2_3sites
grep '"nome"' coleta_dados/dados/processados/YUL/resumo.json      # deve dizer "Laundry"
```

As três pastas precisam ficar lado a lado, porque o `config_experimentos.yaml` procura a coleta em
`../coleta_dados`. Se o YUL não disser "Laundry" (o `rodar_yul.bat` não rodou no PC), refaça a coleta do YUL no
Linux com `cd ~/novo_artigo/coleta_dados && bash linux_yul.sh`, numa sessão tmux própria: sem os brutos, ele
baixa o DKASC e o GFS do YUL (~132 mil pedidos ao THREDDS do NCAR, ~20 h; retomável).

## 2. Instalar (uma vez)

```bash
cd ~/novo_artigo/experimentos
bash linux/instalar.sh
```

O script:
- cria o `.venv`;
- instala o PyTorch com CUDA para a placa e as dependências;
- roda o autoteste da camada conformal;
- mostra a GPU e o número de núcleos. A linha que começa com "PyTorch" deve citar a sua placa, não
  "nenhuma (CPU)".

## 3. Teste rápido (10–15 min, recomendado)

```bash
bash linux/rodar.sh --perfil rapido --site BRA
```

O teste roda todas as etapas com 1 semente, 2 membros e 2 épocas. Os números não servem para o artigo; ele só
confere que a GPU, o LightGBM, o XGBoost e os processos paralelos funcionam na máquina. Grava em
`resultados_rapido/` e `saida_artigo_rapido/`, separado da rodada final. Deve terminar com o log
"Saídas do artigo".

## 4. Experimentos dos três sites, 10 sementes (sessão tmux)

```bash
cd ~/novo_artigo/experimentos
.venv/bin/python executar.py verificar                 # dados e cobertura do GFS dos três sites: tudo "ok"
tmux new -s exp
bash linux/rodar.sh
```

- **Ordem:** GEO, BRA e YUL, como no `config_experimentos.yaml`. Para rodar um de cada vez:
  `bash linux/rodar.sh --site GEO BRA` e depois `bash linux/rodar.sh --site YUL`.
- **Retomada:** se parar (queda de energia, terminal fechado), rode o mesmo comando; o que já está pronto é pulado.
- **Andamento:** `tail -f resultados/GEO/logs/experimentos.log`. O tempo de cada semente aparece no log.
- **Resumo:** `.venv/bin/python executar.py status` mostra o que já ficou pronto.
- **Velocidade:** com mais de 17 núcleos, dá para pôr `processos: 24` (ou núcleos − 2) no
  `config_experimentos.yaml` antes de começar. Só muda a velocidade, não os resultados.
- **No log do YUL** aparecem dois avisos esperados: "potência registrada muito abaixo da capacidade de 2021-12-31
  a 2022-02-15 (47 dias, todos já removidos pelo QC)", o trecho de jan–fev/2022 em que a coluna da Laundry traz
  ~1 kW, e "54 dias do ano sem nenhum dado de treino nas horas de sol", o preenchimento do envelope de céu claro
  de meados de outubro ao início de dezembro (README, seção 6, item 27).

## 5. Relatório final e artigo

Com os três sites prontos:

```bash
bash linux/rodar.sh --latex ../artigo2_3sites
```

O comando:
- confere que não falta nada (o que já está pronto é pulado);
- gera o relatório de cada site e junta os três;
- produz tabelas, macros, figuras e o guia em `saida_artigo/`;
- copia tudo para o projeto LaTeX.

Se a máquina tiver LaTeX: `cd ../artigo2_3sites && latexmk -pdf main.tex`.

## 6. Trazer de volta

```bash
cd ~/novo_artigo/experimentos
bash linux/empacotar_resultados.sh
```

O script cria `~/novo_artigo/resultados_final.tgz` com:
- CSVs, logs e manifestos de cada site;
- `saida_artigo/` e o projeto LaTeX;
- `resultados/hardware.txt`, com o modelo da CPU e da GPU e as versões, que vão para a Tab. 12.

Copie esse arquivo para `C:\Users\Luciano\Downloads\novo_artigo` no PC (não precisa extrair) e me avise: eu
confiro os resultados e adapto o texto do artigo à v3.1 com os números finais. As previsões e os caches ficam na
máquina Linux (vários GB); não apague até o artigo fechar.

## Problemas comuns

| Sintoma | O que fazer |
|---|---|
| `nvidia-smi` não existe ou o instalar mostra "nenhuma (CPU)" | instale o driver da NVIDIA da distribuição e rode `bash linux/instalar.sh` de novo |
| `nvidia-smi` mostra "CUDA Version: 11.x" e o PyTorch não vê a GPU | driver antigo para o PyTorch com CUDA 12.8: atualize o driver ou, com o `.venv` ativo, `pip install --force-reinstall torch --index-url https://download.pytorch.org/whl/cu118` |
| `CUDA out of memory` | outra coisa está usando a GPU (`nvidia-smi`); feche e rode de novo. O TFT usa pouca memória |
| `verificar_yul.py` termina com "ATENÇÃO" | não processe o YUL; mande a tabela. GEO e BRA seguem normalmente |
| (só se refizer a coleta do YUL no Linux) o GFS fica parado ou o log mostra 429/503 | o servidor do NCAR está cheio; a coleta faz pausas de 5–60 min sozinha. Se insistir, use `--trabalhadores 16` no `linux_yul.sh` |
| `executar.py verificar` acusa falta de dados ou GFS incompleto no YUL | o YUL processado não veio do PC: rode o `rodar_yul.bat` no PC e leve só a pasta `coleta_dados/dados/processados/YUL`, ou rode `bash linux_yul.sh` no Linux |
| "No space left on device" | as previsões ocupam ~2 GB por site; libere espaço e rode de novo |
| quer recomeçar um site do zero | apague `experimentos/resultados/<SITE>` e rode de novo |
