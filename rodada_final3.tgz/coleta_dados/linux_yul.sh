#!/usr/bin/env bash
# Coleta do YUL com a usina Laundry (DKASC, fonte 11), 2021-2025, teste 2025, no Linux. Pode interromper e rodar
# de novo. Só é preciso se o YUL processado não tiver vindo do PC (veja RODADA_FINAL_LINUX.md, passo 0).
#   1) ambiente .venv e dependências
#   2) potência do DKASC, Yulara 2021-2025 (ao rodar, você aceita os termos de uso do DKASC, como na coleta anterior)
#   3) confere a Laundry: meses com outro canal na coluna saem pela coleta; se aparecer ATENÇÃO (corte de potência
#      ou canal suspeito), PARA aqui (não processe)
#   4) processa a potência
#   5) baixa o GFS do YUL (~132 mil pedidos ao THREDDS do NCAR, ~20 h a ~1,8 pedido/s; retomável). Se a pasta
#      dados/brutos/gfs/YUL tiver vindo do PC, só confere
#   6) processa o YUL com o GFS
# Uso, de dentro da pasta coleta_dados:   bash linux_yul.sh
set -euo pipefail
cd "$(dirname "$0")"
PY="${PYTHON:-python3}"
"$PY" -c 'import sys; assert sys.version_info >= (3, 10), "precisa de Python 3.10 ou mais novo"'
[ -d .venv ] || "$PY" -m venv .venv
# shellcheck disable=SC1091
source .venv/bin/activate
python -m pip install --upgrade pip wheel >/dev/null
pip install -r requirements.txt
export PYTHONUNBUFFERED=1
echo "== 1/5 Potência do DKASC (Yulara 2021-2025) =="
python coletar.py baixar --sites YUL --fontes dkasc --aceito-termos-dkasc
echo "== 2/5 Conferindo a Laundry (corte de potência e canais) =="
python verificar_yul.py
echo "== 3/5 Processando a potência do YUL =="
python coletar.py processar --sites YUL --sem-gfs
echo "== 4/5 GFS do YUL (longo se não veio do PC; Ctrl+C e rode de novo para retomar) =="
python coletar.py baixar --sites YUL --fontes gfs --trabalhadores 32 --refazer-falhas
echo "== 5/5 Processando o YUL com o GFS =="
python coletar.py processar --sites YUL
echo "Fim. Confira dados/processados/relatorio_coleta.md e a pasta dados/processados/YUL."
