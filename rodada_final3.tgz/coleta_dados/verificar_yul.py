"""Confere a usina do YUL (id_fonte do config.yaml; hoje a Laundry) nos arquivos anuais do DKASC antes de processar.

Para cada mês do período do YUL no config.yaml:
  * fora_120: fração das leituras diurnas acima de 120% da nominal. É a coluna da usina trazendo outro canal: em
    2017-2022, de ~26/04 a 31/12, os arquivos do DKASC trazem um contador de energia na coluna de potência da
    Laundry. A coleta descarta essas leituras e o QC remove os dias, então o trecho sai do experimento sem entrar
    com valores errados;
  * nos dias claros (piranômetro), comparada com os outros sistemas de Yulara:
      - zero: dias claros em que a usina não passa de 1% da nominal (01/01 a 18/02/2022: ~1 kW). A regra de saída
        zero do QC remove esses dias;
      - corte: fração dos dias claros com o meio-dia abaixo de 80% do máximo do dia. Fica perto de 0 numa usina sem
        limitação; no Desert Gardens, de 2021 em diante, fica perto de 1 (a microrrede do resort corta a saída);
      - pico: mediana do pico do dia / kWp, contra a dos vizinhos com valores plausíveis (30-120% da nominal).
Situação de cada mês: ok, parcial, removido (a coleta tira o trecho) ou ATENÇÃO (corte de potência ou canal
suspeito que o QC da coleta não remove).

Uso:   python verificar_yul.py [--config config.yaml]
Código de saída 1 só se algum mês ficar em ATENÇÃO: aí não processe o YUL com esse período; mande a tabela para
análise. Meses removidos ou parciais não impedem o processamento.
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

# sistemas de Yulara com medição própria de potência: id da fonte no DKASC -> (sigla, kWp)
SISTEMAS = {5: ("DG", 1058.4), 10: ("SS", 226.8), 11: ("LD", 327.6), 8: ("CA", 105.9)}
RE_POT = re.compile(r"^(\d+)_.*Active_Power$")
LIM_ALTA = 1.2      # a coleta descarta as leituras acima de 120% da nominal
LIM_ZERO = 0.01     # pico do dia abaixo disso com sol: regra de saída zero do QC (qc.saida_zero.y_max)
MIN_CLAROS = 3      # dias claros válidos para julgar corte e canal num mês


def ler_ano(arq: Path, ids) -> pd.DataFrame:
    cab = pd.read_csv(arq, nrows=0).columns
    usar = {}
    for c in cab:
        m = RE_POT.match(c)
        if m and int(m.group(1)) in ids:
            usar[c] = f"P{int(m.group(1))}"
        elif c.lower() == "timestamp":
            usar[c] = "t"
        elif c.endswith("Pyranometer_1") and "PYR" not in usar.values():
            usar[c] = "PYR"
    faltam = {"t", "PYR", f"P{ids[0]}"} - set(usar.values())
    if faltam:
        raise SystemExit(f"{arq.name}: colunas não encontradas: {sorted(faltam)}")
    df = pd.read_csv(arq, usecols=list(usar), low_memory=False).rename(columns=usar)
    df["t"] = pd.to_datetime(df["t"], errors="coerce")
    df = df.dropna(subset=["t"]).set_index("t").sort_index()
    df = df[~df.index.duplicated()].apply(pd.to_numeric, errors="coerce")
    df.loc[(df["PYR"] > 2000) | (df["PYR"] < -50), "PYR"] = np.nan
    return df


def estatisticas_dia(df: pd.DataFrame, alvo: str, kwp: dict) -> pd.DataFrame:
    """Uma linha por dia: dia claro?, leituras da usina descartadas ou faltando, razão meio-dia/máximo e pico/kWp."""
    dia_ = df.between_time("07:00", "18:00")
    p = dia_[alvo]
    alta = p > LIM_ALTA * kwp[alvo]
    por_dia = pd.DataFrame({"fora_120": alta.groupby(dia_.index.normalize()).mean(),
                            "falta": p.isna().groupby(dia_.index.normalize()).mean()})
    limpo = df.copy()
    limpo[alvo] = limpo[alvo].mask(limpo[alvo] > LIM_ALTA * kwp[alvo])
    h = limpo.resample("30min").mean()
    linhas = []
    for dia, x in h.groupby(h.index.normalize()):
        x = x.between_time("07:00", "18:00")
        r = {"dia": dia, "claro": False}
        pyr = x["PYR"].to_numpy(dtype=float)
        if len(pyr) and np.isnan(pyr).sum() <= 2 and np.nanmax(pyr) >= 750:
            pp = pd.Series(pyr).interpolate().to_numpy()
            r["claro"] = bool(np.nansum(np.abs(np.diff(pp, 2))) <= 0.6 * np.nanmax(pp))   # sem nuvens passando
        if r["claro"]:
            meio = x.between_time("11:30", "13:30")
            for nome, k in kwp.items():
                mx = x[nome].max()
                r[f"{nome}_razao"] = meio[nome].mean() / mx if mx == mx and mx > 0 else np.nan
                r[f"{nome}_pico"] = mx / k if mx == mx else np.nan
        linhas.append(r)
    return pd.DataFrame(linhas).set_index("dia").join(por_dia)


def mensal(r: pd.DataFrame, alvo: str, vizinhos: list) -> pd.DataFrame:
    mes = r.index.to_period("M")
    tab = pd.DataFrame({"fora_120": r["fora_120"].groupby(mes).mean(), "falta": r["falta"].groupby(mes).mean()})
    claros = r[r["claro"]]
    usavel = claros[(claros["fora_120"] + claros["falta"]) <= 0.10]        # dia que a coleta mantém
    m_c, m_u = claros.index.to_period("M"), usavel.index.to_period("M")
    tab["claros"] = claros.groupby(m_c).size()
    tab["validos"] = usavel.groupby(m_u).size()
    zero = usavel[f"{alvo}_pico"] < LIM_ZERO
    tab["zero"] = zero.groupby(m_u).sum()
    ok = usavel[~zero]
    m_o = ok.index.to_period("M")
    tab["n_julgados"] = ok.groupby(m_o).size()
    tab["corte"] = (ok[f"{alvo}_razao"] < 0.8).groupby(m_o).mean()
    tab["pico"] = ok[f"{alvo}_pico"].groupby(m_o).median()
    cortes, picos = [], []
    for v in vizinhos:
        pl = claros[(claros[f"{v}_pico"] >= 0.3) & (claros[f"{v}_pico"] <= LIM_ALTA)]   # potência plausível
        mv = pl.index.to_period("M")
        cortes.append((pl[f"{v}_razao"] < 0.8).groupby(mv).mean().rename(v))
        picos.append(pl[f"{v}_pico"].groupby(mv).median().rename(v))
    tab["viz_corte"] = pd.concat(cortes, axis=1).median(axis=1) if cortes else np.nan
    tab["viz_pico"] = pd.concat(picos, axis=1).median(axis=1) if picos else np.nan
    for c in ("claros", "validos", "zero", "n_julgados"):
        tab[c] = tab[c].fillna(0).astype(int)
    return tab


def situacao(t) -> str:
    julgar = t.n_julgados >= MIN_CLAROS
    ref_corte = t.viz_corte if t.viz_corte == t.viz_corte else 0.0
    if julgar and t.corte >= 0.25 and t.corte - ref_corte >= 0.2:
        return "ATENÇÃO: corte de potência"
    if julgar and t.viz_pico == t.viz_pico and t.pico < 0.6 * t.viz_pico:
        return "ATENÇÃO: canal suspeito"
    if t.fora_120 >= 0.5:
        return "removido: outro canal na coluna"
    if t.falta >= 0.5:
        return "removido: sem dados"
    if t.validos > 0 and t.zero == t.validos:
        return "removido: saída zero"
    notas = []
    if t.fora_120 > 0.01:
        notas.append(f"outro canal em {100 * t.fora_120:.0f}%")
    if t.falta > 0.10:
        notas.append(f"falta {100 * t.falta:.0f}%")
    if t.zero:
        notas.append(f"{t.zero} dia(s) com saída zero")
    if notas:
        return "parcial: " + ", ".join(notas)
    return "ok" if julgar else "ok (poucos dias claros)"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.yaml")
    a = ap.parse_args()
    raiz = Path(a.config).resolve().parent
    cfg = yaml.safe_load(open(a.config, encoding="utf-8"))
    site = cfg["sites"]["YUL"]
    sid = int(site["id_fonte"])
    sigla, kw_tab = SISTEMAS.get(sid, (f"F{sid}", float("nan")))
    kwp_alvo = float(site.get("pnom_kw") or kw_tab)
    ids = [sid] + [i for i in SISTEMAS if i != sid]
    kwp = {f"P{i}": (kwp_alvo if i == sid else SISTEMAS[i][1]) for i in ids}
    nomes = {f"P{i}": (sigla if i == sid else SISTEMAS[i][0]) for i in ids}
    ini, fim = pd.Timestamp(str(site["inicio"])), pd.Timestamp(str(site["fim"])) + pd.Timedelta(days=1)
    pasta = raiz / cfg.get("pasta_dados", "dados") / "brutos" / "YUL"
    partes = []
    for ano in range(ini.year, fim.year + 1):
        arq = pasta / f"Yulara_{ano}.csv"
        if not arq.exists():
            if pd.Timestamp(f"{ano}-01-01") < fim:
                print(f"falta {arq} (rode antes: python coletar.py baixar --sites YUL --fontes dkasc "
                      "--aceito-termos-dkasc)")
                return 1
            continue
        print(f"  lendo {arq.name}", flush=True)
        partes.append(ler_ano(arq, ids))
    df = pd.concat(partes).sort_index()
    df = df[(df.index >= ini) & (df.index < fim)]
    for c in kwp:
        if c not in df:
            df[c] = np.nan
    alvo = f"P{sid}"
    r = estatisticas_dia(df, alvo, kwp)
    if not r["claro"].any():
        print("nenhum dia claro encontrado: confira o piranômetro nos arquivos")
        return 1
    tab = mensal(r, alvo, [c for c in kwp if c != alvo])
    tab["situacao"] = [situacao(t) for t in tab.itertuples()]
    pd.set_option("display.width", 250)
    pd.set_option("display.max_rows", 500)
    pd.set_option("display.max_colwidth", 60)
    print(f"\n{site.get('nome', 'YUL')}: fonte {sid} ({sigla}, {kwp_alvo:g} kWp) contra "
          f"{', '.join(nomes[c] for c in kwp if c != alvo)}, por mês")
    print("  fora_120 = fração das leituras diurnas acima de 120% da nominal (outro canal; a coleta descarta)")
    print("  falta    = fração das leituras diurnas ausentes")
    print("  claros / validos = dias claros e, deles, os que a coleta mantém; zero = dias claros com saída zero")
    print("  corte    = fração dos dias claros com o meio-dia abaixo de 80% do máximo do dia (0 = sem corte)")
    print("  pico     = mediana do pico do dia / kWp; viz_* = mediana dos vizinhos com potência plausível\n")
    mostrar = tab.drop(columns=["n_julgados"]).copy()
    for c in ("fora_120", "falta", "corte", "pico", "viz_corte", "viz_pico"):
        mostrar[c] = mostrar[c].round(2)
    print(mostrar.to_string())
    ruins = tab.index[tab["situacao"].str.startswith("ATENÇÃO")]
    removidos = tab.index[tab["situacao"].str.startswith("removido")]
    parciais = tab.index[tab["situacao"].str.startswith("parcial")]
    print(f"\nMeses: {len(tab)} | ok {len(tab) - len(ruins) - len(removidos) - len(parciais)} | parciais "
          f"{len(parciais)} | removidos pela coleta {len(removidos)} | atenção {len(ruins)}")
    if len(removidos):
        print("Removidos pela coleta (o QC tira esses dias; não entram no experimento): "
              + ", ".join(str(m) for m in removidos))
    if len(ruins):
        print(f"\nATENÇÃO: meses com corte de potência ou canal suspeito na usina {sigla}: "
              f"{', '.join(str(m) for m in ruins)}. Não processe o YUL com este período; mande a tabela para análise.")
        return 1
    print(f"\nOK: a usina {sigla} não mostra corte nem canal suspeito entre {ini.date()} e "
          f"{(fim - pd.Timedelta(days=1)).date()}. Pode processar.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
