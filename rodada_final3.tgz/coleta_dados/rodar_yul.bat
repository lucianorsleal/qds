@echo off
REM Coleta do YUL com a usina Laundry (DKASC, fonte 11), 2021-2025, teste 2025, no Windows:
REM   1) potencia do DKASC de Yulara 2021-2025 (os arquivos ja baixados sao mantidos; aceite dos termos do DKASC)
REM   2) confere a Laundry (verificar_yul.py): meses com outro canal na coluna saem pela coleta; se aparecer
REM      ATENCAO (corte de potencia ou canal suspeito), para aqui
REM   3) processa a potencia do YUL
REM   4) GFS do YUL (o de 2021-2025 ja esta baixado: so confere e completa o que faltar)
REM   5) processa o YUL com o GFS
REM Com os arquivos ja baixados, leva poucos minutos. Use depois que o rodar_coleta.bat ja tiver criado o
REM ambiente .venv. So pode haver uma janela da coleta aberta.
setlocal EnableExtensions
cd /d "%~dp0"
title Coleta do YUL (Laundry 2021-2025)
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
if not exist ".venv\Scripts\python.exe" (
  echo Ambiente .venv nao encontrado. Rode primeiro o rodar_coleta.bat
  pause
  exit /b 1
)
echo == 1/5 Potencia do DKASC (Yulara 2021-2025) ==
".venv\Scripts\python.exe" coletar.py baixar --sites YUL --fontes dkasc --aceito-termos-dkasc
if errorlevel 1 goto erro
echo.
echo == 2/5 Conferindo a Laundry (corte de potencia e canais) ==
".venv\Scripts\python.exe" verificar_yul.py
if errorlevel 1 goto atencao
echo.
echo == 3/5 Processando a potencia do YUL ==
".venv\Scripts\python.exe" coletar.py processar --sites YUL --sem-gfs
if errorlevel 1 goto erro
echo.
echo == 4/5 GFS do YUL (ja baixado; so confere) ==
".venv\Scripts\python.exe" coletar.py baixar --sites YUL --fontes gfs --trabalhadores 32 --refazer-falhas
if errorlevel 1 goto erro
echo.
echo == 5/5 Processando o YUL com o GFS ==
".venv\Scripts\python.exe" coletar.py processar --sites YUL
if errorlevel 1 goto erro
echo.
echo Fim. Confira dados\processados\relatorio_coleta.md e a pasta dados\processados\YUL
pause
exit /b 0
:atencao
echo.
echo A Laundry mostrou corte de potencia ou canal suspeito (tabela acima). NAO processe o YUL:
echo mande a tabela para analise. GEO e BRA seguem normalmente.
pause
exit /b 1
:erro
echo.
echo Algo falhou (detalhes em dados\logs\coleta.log). Rode de novo: o que ja foi baixado fica salvo.
pause
exit /b 1
