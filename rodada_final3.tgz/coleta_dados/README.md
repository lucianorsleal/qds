# Coleta de dados — CCP-Boot-TFT-ICSO-PP (artigo 2)

Este pacote baixa e prepara os dados do artigo: as séries de potência de **três usinas FV**, uma por
clima, com anos de teste entre 2022 e 2025, e as previsões arquivadas do GFS 0,25°. Cada site é **uma
usina só**, como os dois parques do artigo Boot-LSTM-ICSO-PP (Bazionis et al., IEEE Access, 2024): nada
de somar telhados ou frotas de sistemas. O resultado são séries horárias limpas, prontas para os
modelos, além de um relatório com os números da Tabela 4 e dos itens em roxo do rascunho.

| Site | Fonte | Clima | O que é | Período (teste) |
|---|---|---|---|---|
| YUL | DKASC, Yulara (AU) | BWh | Laundry: usina de solo de 327,6 kWp, inclinação fixa, 5 min | 2021–2025 (2025) |
| BRA | ONS, geração horária por usina | BSh | Conj. Ituverava (BA), 196 MW, 1 h | jul/2019–jun/2023 (jul/2022–jun/2023) |
| GEO | PVDAQ 9069, Simon Solar Farm (Geórgia, EUA) | Cfa | usina de 33 MW AC, 40 inversores, 5 min | 2016–nov/2023 (dez/2022–nov/2023) |
| todos | NCAR GDEX d084001 (GFS 0,25°) | — | caixa 4×4 em volta de cada site, 6 variáveis | todo o período de cada site |

Conjuntos antigos: `config_5sites.yaml` (ASP, BRA, GEO, UKF e HKG; ASP, UKF e HKG somavam arranjos de
pesquisa, telhados residenciais e telhados de campus) e `config_artigo1.yaml` (ASP, GTB, UTR e BRA de
2015–2022). Use com `python coletar.py --config ARQUIVO ...`.

## Mudança de 22/10/2026: YUL passa a ser a usina Laundry (2021–2025, teste 2025)

O YUL agora é a **Laundry** (fonte 11 do DKASC, 327,6 kWp, solo), no mesmo período de antes (2021–2025, teste
2025), com o mesmo GFS. O Desert Gardens (fonte 5) saiu por dois motivos:

- **Corte de potência.** De 2021 em diante a microrrede do resort corta a saída do Desert Gardens nos dias claros: o
  meio-dia fica em 20–40% do pico do dia, contra 98% nos vizinhos de Yulara.
- **Coluna trocada.** Em 2017–2022, de 25–26/04 a 31/12 de cada ano, as colunas de potência do Desert Gardens, da
  Service Station e da Laundry nos arquivos anuais do DKASC trazem outros canais. Por isso a tentativa de 21/10/2026
  (Desert Gardens em 2017–2020) também não servia: o `verificar_yul.py` acusou 14 dos 16 trimestres.

Na Laundry, nesses trechos de 2021 e 2022 a coluna traz um contador de energia (milhões): a coleta descarta as
leituras acima de 120% da nominal e o QC remove os dias. De 01/01 a 18/02/2022 (e em cinco dias de jan/2021) ela
traz ~1 kW, e a regra de saída zero remove os dias. De 2023 a 2025 a Laundry não tem corte nem canal trocado
(meio-dia a 98–99% do pico nos dias claros). Ficam 616 dias no treino (jan–abr/2021, fev–abr/2022 e jan/2023–jul/2024, ~6.850 horas diurnas
válidas), 80 na validação, 77 na 1ª calibração e 354 no teste; o QC remove 38% dos dias do período.

O `verificar_yul.py` agora confere a usina do `id_fonte` e separa o que a coleta já remove (outro canal na coluna,
saída zero) do que impediria o processamento (corte de potência ou canal suspeito com valores plausíveis). O
`rodar_yul.bat` (Windows) e o `bash linux_yul.sh` (Linux) fazem tudo: com os arquivos do DKASC e o GFS de 2021–2025
já baixados, leva poucos minutos. Os arquivos `Yulara_2017.csv` a `Yulara_2020.csv` em `dados/brutos/YUL` não são
mais usados e podem ser apagados. O config com o Desert Gardens em 2021–2025 ficou em `config_yul_2021-2025.yaml`.

Também mudou em `coleta/fontes/dkasc.py`: a decisão de que a coluna está em W (e não em kW) ignora as leituras
impossíveis até em W (o contador de energia); antes, o contador fazia o ano inteiro ser dividido por 1000.

## 1. Antes de começar

- **Python 3.10 ou mais novo.** No Windows, instale em <https://www.python.org/downloads/> e marque
  *Add python.exe to PATH*.
- **Nenhum login é preciso.** As três fontes de potência e o GFS são abertos (o DKASC pede só o aceite
  dos termos, que o `rodar_potencia.bat` já registra).
- **Espaço em disco:** ~5 GB (os arquivos anuais do DKASC e o CSV de inversores do PVDAQ, de 1,8 GB).
- **Tempo:** a potência leva de minutos a ~1 h, dependendo da conexão. O GFS vem do THREDDS do NCAR:
  ~440 mil pedidos para as três usinas. Com 32 pedidos simultâneos o servidor respondeu ~1,8 pedido/s
  nos arquivos de 2019 em diante (2–3 dias); com 8, só ~0,4 pedido/s. Pode ser interrompido e
  retomado.
- Deixe o computador ligado e sem hibernar durante o GFS.

## 2. Como rodar

### Jeito mais simples (Windows)

1. Dê dois cliques em **`rodar_potencia.bat`**. Ele acha o Python, cria o ambiente `.venv`, instala as
   dependências (log em `dados\logs\instalacao.log`), testa o acesso às fontes (`verificar`), baixa e
   processa a potência das três usinas. O aceite dos termos do DKASC já vai registrado.
2. Confira `dados\processados\relatorio_coleta.md`.
3. Dê dois cliques em **`rodar_gfs.bat`**: baixa o GFS de todos os sites (etapa longa, retomável) e no
   fim processa tudo de novo com o NWP.

### GFS pelo subset do GDEX (experimental)

O caminho pelo *Get a Subset* do GDEX (`rodar_gfs_gdex.bat`, `python coletar.py gdex` e
`python coletar.py importar-gfs PASTA`) ainda não está validado: no pedido de teste (out/2026) o
importador só reconheceu o DSWRF nos arquivos netCDF do GDEX e não gravou nada. Use o THREDDS
(`rodar_gfs.bat`). Se for tentar, o pedido é por caixa em graus inteiros em volta de cada site, com
*Initialization Time* começando um dia antes do necessário (o formulário desloca o início para 03:00),
as seis variáveis, os níveis de superfície, atmosfera inteira, 2 m e 10 m e os produtos f003–f072 com
as médias correspondentes; acima de ~150 mil arquivos o pedido pode ser recusado, e cada usuário pode
ter no máximo 8 pedidos abertos.

`rodar_coleta.bat` faz as duas etapas de uma vez (pergunta pelos termos do DKASC). Só pode haver uma
janela da coleta aberta de cada vez. Se o servidor THREDDS do NCAR sair do ar, a coleta do GFS faz
pausas de 5 a 60 min e continua sozinha quando ele volta. Enquanto a coleta roda, o Windows não entra
em suspensão automática.

### Passo a passo (qualquer sistema)

```bash
python -m venv .venv
.venv\Scripts\activate            # Windows  (Linux/Mac: source .venv/bin/activate)
pip install -r requirements.txt

python coletar.py verificar                                   # tudo deve dar OK
python coletar.py baixar --fontes dkasc ons pvdaq --aceito-termos-dkasc
python coletar.py processar --sem-gfs                         # séries de potência + QC + relatório
python coletar.py baixar --fontes gfs --trabalhadores 32       # 2-3 dias; Ctrl+C e rode de novo para retomar
python coletar.py processar                                   # agora com o GFS
```

Comandos úteis:

| Comando | Para quê |
|---|---|
| `python coletar.py status` | o que já foi baixado e quantos dias do GFS faltam |
| `python coletar.py baixar --fontes gfs --estimar` | só conta os pedidos pendentes e estima o tempo |
| `python coletar.py baixar --fontes gfs --refazer-falhas` | repete só os pedidos do GFS que falharam |
| `python coletar.py baixar --fontes gfs --sites GEO --gfs-inicio 2023-03-10 --gfs-fim 2023-03-11` | teste rápido com 2 dias |
| `python coletar.py processar --sites BRA` | reprocessa um site só (por exemplo, após mudar o `config.yaml`) |

Tudo fica registrado em `dados/logs/coleta.log`.

## 3. O que sai

```
dados/
  brutos/YUL|BRA|GEO/...               arquivos originais, como baixados
  brutos/gfs/<SITE>/<AAAA>/<AAAAMMDD>.npz  caixa 4x4 de cada ciclo e hora de previsão
  processados/
    relatorio_coleta.md                 resumo para o artigo (Tab. 4, QC, checagem de fuso, cobertura do GFS)
    resumo_sites.csv
    <SITE>/potencia_horaria.parquet|csv série horária limpa (uma linha por hora local)
    <SITE>/qc_diario.csv                flags do QC por dia (com o máximo diário, o teto de 31 dias e o nível do platô)
    <SITE>/gfs_horario.parquet          GFS horário para cada ciclo (todas as antecedências)
    <SITE>/gfs_dia_seguinte.parquet     entradas do horizonte DA (emissão 12:00 local, ciclo disponível)
    <SITE>/particoes.csv                treino, validação, 12 janelas de calibração e 12 meses de teste
    <SITE>/unidades.csv                 (YUL) a usina e a disponibilidade; (GEO) os inversores
    <SITE>/checagem_fuso_mensal.csv     defasagem entre a potência e o sol, mês a mês
    <SITE>/checagem_teto_mensal.csv     teto mensal de y (p99), para achar meses com capacidade indisponível
```

**`potencia_horaria`** — uma linha por hora de relógio local padrão `[t, t+1h)`:

| Coluna | Significado |
|---|---|
| `tempo_utc`, `tempo_lst` | início da hora em UTC e em hora padrão local (em YUL, UTC+09:30, as horas começam em hh:30 UTC) |
| `y` | potência média normalizada `P/Pnom` |
| `p_kw` | potência média (kW) |
| `capacidade_kw` | (GEO) capacidade dos inversores com dado na hora; nele, `y = p_kw / capacidade_kw` |
| `disponibilidade` | fração das amostras (YUL, BRA) ou da capacidade dos inversores (GEO) com dado na hora |
| `n_unidades` | inversores com dado na hora (GEO); 1 ou 0 em YUL |
| `restrita` | (BRA, só com `restricao_ons: true` e período a partir de abr/2024) hora com geração limitada pelo ONS (constrained-off); `y` fica vazio nela |
| `zenite`, `cos_zenite`, `ghi_cs` | zênite no meio da hora e GHI de céu claro médio (Ineichen-Perez, pvlib) |
| `diurno` | zênite < 85° |
| `manter_dia` | `False` se o dia foi removido pelo QC da Seção V-B |
| `bloco`, `mes_teste` | treino / validacao / calibracao_inicial / teste, e o mês de teste (1–12) |

**`gfs_horario`** — uma linha por (ciclo, hora-alvo): `ciclo_utc`, `valido_utc` (início da hora-alvo),
`lead_h` (horas do ciclo até o **fim** da hora-alvo), `ghi_nwp` (W/m²), `ghi_cs`, `k_nwp = ghi_nwp/ghi_cs`,
`tcc` (0–1), `t2m` (°C), `rh2m` (%), `t2m_x_rh2m`, `u10`, `v10` (m/s).

Para montar as entradas dos modelos **sem olhar o futuro**, use `coleta/nwp_selecao.py`:

```python
import pandas as pd
from coleta.nwp_selecao import entradas_intradiarias, entradas_dia_seguinte

gfs = pd.read_parquet("dados/processados/GEO/gfs_horario.parquet")
emissoes = pd.date_range("2022-12-01 05:00", "2023-11-30 23:00", freq="h", tz="UTC")
x = entradas_intradiarias(gfs, emissoes)               # 36 horas-alvo por emissão, latência de 5 h
x_s3 = entradas_intradiarias(gfs, emissoes, atraso_h=24)  # teste de estresse S3 (ciclo de 24 h antes)
da = entradas_dia_seguinte(gfs, "Etc/GMT+5")           # DA: emissão 12:00 local de D-1, 24 h de D
```

Em YUL, as emissões devem cair em hh:30 UTC (horas cheias locais).

## 4. Decisões tomadas (todas ajustáveis no `config.yaml`)

**YUL.** Usina Laundry do sistema solar de Yulara (resort de Ayers Rock, NT), publicada pelo DKASC:
327,6 kWp de silício policristalino, montagem de solo com inclinação fixa, em operação desde 2016. O
DKASC não publica a inclinação da Laundry; as outras duas usinas de solo do mesmo projeto (Desert
Gardens e Service Station) têm 15° para o norte, e a forma do dia claro da Laundry contra a Service
Station dá 13–15° e 0–10° para leste. É a coluna `11_..._Active_Power` dos arquivos anuais
`Yulara_AAAA.csv` (5 min, kW, carimbo no **fim** do intervalo, hora local ACST); os outros sistemas
de Yulara (o Desert Gardens, cortado pela microrrede do resort de 2021 em diante, a Service Station,
os telhados e o total do resort) ficam de fora. A potência horária é a média
das amostras de 5 min; a hora vale com ≥ 80% delas (`disponibilidade_min_hora`). Leituras acima de 120%
da nominal são descartadas. Paradas da usina com sol ficam para o QC (saída zero). O DKASC não publica
as coordenadas do arranjo; vale o ponto do resort no `config.yaml` (a caixa do GFS é a mesma em
qualquer ponto do resort).

**BRA.** Geração horária verificada do Conj. Ituverava (`CJU_BATBV`, Tabocas do Brejo Velho, BA): 7
usinas de 28 MW (196 MW) em operação desde o fim de 2017, com capacidade estável em 2019–2023. O
período vai de jul/2019 a jun/2023 e o teste de jul/2022 a jun/2023, antes do apagão de 15/08/2023 e da
onda de *constrained-off*: em 2025 o ONS limitou a geração das grandes usinas FV do Nordeste em 50–65%
das horas de sol (14–45% da energia), o que deixaria o teste com menos da metade das horas diurnas e
quase sem os picos de dias claros. Antes de abr/2024 o ONS não publica o corte por usina; vale o filtro
de perfis achatados do QC. O ponto do site é a subestação coletora informada pelo ONS no dataset
*Fator de Capacidade* (`brutos/BRA/coordenadas.json`). Para um período a partir de abr/2024, ligue
`restricao_ons: true`: a hora com alguma semi-hora limitada em alguma usina do conjunto sai da série
(`y` vazio, coluna `restrita`) e não conta como dado faltante no QC.

**GEO.** Potência AC dos 40 inversores de 825 kW da Simon Solar Farm (PVDAQ 9069, Solar Data Prize
2023), 5 min (`9069_electrical_ac.csv`, 1,8 GB). De jun/2022 até o fim dos dados parte dos inversores
fica parada, e o medidor de exportação entrega só 65–75% da potência nominal em todo o período de teste.
Por isso `y` é a potência dos inversores com dado dividida pela capacidade deles (razão de somas sobre
os inversores da mesma usina). Uma amostra de inversor em ~0 enquanto a mediana dos outros passa de 0,2 fica de fora, e o
inversor que num dia de sol produz ≤ 5% da energia da mediana fica de fora o dia inteiro. A hora vale com
≥ 50% da capacidade instalada com dado (`disponibilidade_min_frota`). O medidor serve de conferência
(`razao_medidor_soma_inversores` no resumo, perdas de ~1–2%) e de série alternativa
(`potencia: medidor`). Os carimbos estão em hora civil (EST/EDT): `fuso_dados: America/New_York`. O
consumo noturno (valores negativos) vira 0. O teste vai de dez/2022 a nov/2023, porque os dados
terminam em 29/11/2023.

**Horas e fusos.** Tudo é agregado em horas de relógio **local padrão**: ACST, BRT e EST fixos.
Os 13 grupos horários do artigo usam esse relógio. O pipeline compara, mês a mês, o centro da curva de
potência com o do céu claro. Se o fuso ou o rótulo do intervalo estiverem errados, aparece uma
defasagem de ~1 h no relatório.

Em BRA, os dados do ONS seguem o horário de Brasília, que até 16/02/2019 incluía o horário de verão
(o arquivo de 2019 começa nele). Por isso `fuso_dados: America/Sao_Paulo`: o pipeline converte cada hora
para UTC com o deslocamento certo e só depois agrega em BRT fixo. Em GEO vale o mesmo com
`America/New_York` (EST/EDT).

**QC (Seção V-B).** Um dia é removido em qualquer destes casos:

- tem mais de 10% das horas diurnas sem dado;
- tem saída ≈ 0 por ≥ 2 h com sol alto (falha de inversor ou neve);
- tem um platô de ≥ 4 h com variação < 0,5% por hora. O platô é chamado de clipping quando está no
  teto da usina naquelas semanas (y ≥ 0,95, ou ≥ 90% do p90 do máximo diário nos 31 dias em volta) e
  de curtailment quando fica bem abaixo dele. Os dois são removidos; o rótulo só muda o relatório.

O relatório também mostra o **teto mensal** (p99 de y nas horas diurnas dividido pelo p99 do céu
claro no plano dos módulos no mesmo mês) e lista os meses em que ele ficou abaixo de 80% do usual.
Quedas assim, que duram meses, indicam capacidade indisponível (inversores ou blocos da usina
parados), não tempo ruim. O plano de referência vem de `inclinacao_ref`/`azimute_ref` no
`config.yaml` (GEO 20°/sul, YUL 15°/norte) ou, na falta, de inclinação = |latitude| voltada para o
equador. É só um diagnóstico: não remove nada.

**GFS.** Seis variáveis do arquivo d084001: DSWRF e nebulosidade total (médias), T2m, UR2m, u10 e v10.

- **Horas de previsão.** Baixa f003–f048 de todos os ciclos. Com a latência de 5 h e o decodificador
  de 36 h, as antecedências vão de 6 h a 47 h, inclusive no DA. Na janela de calibração+teste também
  baixa f051–f072, porque o teste S3 usa o ciclo de 24 h antes.
- **Médias de 3 h.** As médias do GFS reiniciam a cada 6 h. O pipeline converte tudo em médias de 3 h
  com `média[3,6] = 2·média[0,6] − média[0,3]`.
- **GHI horário.** Vem do índice de céu claro: `k = DSWRF/GHI_cs` em cada janela de 3 h,
  interpolado linearmente para o meio de cada hora e multiplicado pelo GHI de céu claro da hora.
- **Demais variáveis.** São interpoladas linearmente no tempo.
- **Ponto do site.** Interpolação bilinear na caixa 4×4.
- **Período.** O arquivo 0,25° cobre todos os períodos (começa em 15/01/2015). Pelo THREDDS são ~440
  mil pedidos para as três usinas. Cada pedido obriga o servidor a abrir um GRIB de ~500 MB, e os
  arquivos de meados de 2019 em diante (GFS v15) são bem mais lentos: ~3 pedidos/s em 2016 contra
  ~0,5 em 2019+ com 8 pedidos simultâneos, e ~1,8 com 32.

## 5. Termos de uso e citações

- **DKASC (YUL).** Os dados têm copyright da Desert Knowledge Australia (administrados pela Ekistica).
  - **Sem consentimento formal, só é permitido reproduzir ou distribuir até 5.000 células de dados.**
    Portanto, não publique os dados processados de YUL no repositório do artigo; publique só os
    scripts, que baixam os dados da fonte.
  - Os termos exigem citar o DKASC e trazer, junto aos dados publicados, o aviso de isenção de
    responsabilidade da página de termos. Copie o texto exato de
    <https://dkasolarcentre.com.au/download/terms-conditions>.
  - Ao mencionar o sistema, inclua o ano de instalação (Yulara, Laundry, 2016).
- **ONS (BRA).** CC-BY 4.0, *Dados Abertos ONS — Geração por Usina em Base Horária* e *Restrição de
  Operação por Constrained-off de Usinas Fotovoltaicas — Detalhamento por Usina*. Os dados passam por
  consistência recorrente e podem mudar depois de publicados, então anote a data do download.
- **PVDAQ (GEO).** CC-BY 4.0. NREL, *Photovoltaic Data Acquisition (PVDAQ) Public Datasets*, OEDI
  (https://data.openei.org/submissions/4568), sistema 9069 do 2023 DOE Solar Data Prize.
- **GFS.** NCEP/NOAA, *NCEP GFS 0.25 Degree Global Forecast Grids Historical Archive*, NSF NCAR GDEX,
  doi:10.5065/D65D8PWK.

## 6. O que atualizar no artigo depois de rodar

Abra `dados/processados/relatorio_coleta.md`. Ele traz:

- Tab. 4: local, capacidade e período de teste das três usinas;
- Seção V-B: a porcentagem de dias removidos por site e, em GEO, a disponibilidade dos inversores;
- `group_sizes.csv` para o `tools/wgc_reference.py` (horas diurnas de teste por grupo, já com os
  regimes do NWP).

## 7. Problemas comuns

- **`verificar` falha em uma fonte.** Pode ser firewall ou proxy da rede da universidade; tente outra
  rede.
- **GFS lento ou com muitas falhas.** O servidor público do NCAR pode estar ocupado. Se aparecerem
  muitas falhas ou pausas, reduza `trabalhadores` no `config.yaml` (32 funcionou bem; 8 é o mais
  conservador), deixe rodando e depois use `--refazer-falhas`. Pedidos que voltam 404 são
  horas ausentes no próprio arquivo do NCAR, e os que voltam 400 mesmo com os nomes de variáveis lidos
  do próprio arquivo são arquivos ilegíveis no servidor; os dois contam como ausentes (raros). O processamento interpola sobre uma hora de
  previsão ausente e, se faltar o ciclo inteiro, as funções de `nwp_selecao.py` usam o ciclo anterior.
- **Pouca memória.** O CSV de inversores do GEO (1,8 GB) é lido em blocos; 8 GB de RAM bastam.
