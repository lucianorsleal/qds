# Relatório da coleta de dados — CCP-Boot-TFT-ICSO-PP

Gerado em 2026-10-22 14:43.

## Valores para a Tabela 4 e para os itens em roxo do artigo

| Site | Local (lat, lon) | Köppen | Sistema | Pnom | Período (teste) | Dias removidos no QC |
|---|---|---|---|---|---|---|
| YUL | -25.2400, 130.9900 | BWh | Yulara, NT, AU (Laundry, DKASC) | 327.6 kW (kWp: potência nominal DC da usina informada pelo DKASC) | 2021-01-01 a 2025-12-31 (2025) | 38.28% |
| BRA | -12.5831, -44.1067 | BSh | Conj. Ituverava | 196.0 MW (kW_ac (capacidade instalada informada pelo ONS)) | 2019-07-01 a 2023-06-30 (jul/2022–jun/2023) | 5.13% |
| GEO | 33.6762, -83.6760 | Cfa | Social Circle, GA, US (Simon Solar Farm, PVDAQ 9069) — 40 unidades | 33.0 MW (kW_ac instalados (40 inversores de 825 kW); y = potência AC dos inversores com dado / capacidade deles) | 2016-03-01 a 2023-11-30 (dez/2022–nov/2023) | 8.16% |

## YUL — Yulara, NT, AU (Laundry, DKASC)

- Horas diurnas com dado: 68.08% (primeira 2020-12-31 20:30:00+00:00, última 2025-12-31 08:30:00+00:00 UTC)
- Percentil 99,9 de y nas horas diurnas: 0.841 (limite físico ȳ)
- QC: 699 de 1826 dias removidos (faltantes 34.45%, saída zero 3.83%, curtailment 0.0%, clipping 0.0%)
- Checagem de fuso: defasagem mediana -0.079 h; meses com |defasagem| > 0,5 h: 1
- Teto mensal (p99 de y nas horas diurnas): de 0.004 a 0.869; meses com teto < 80% do usual (já descontado o céu claro do mês no plano 15° / azimute 0°): 2 — 2022-01 (0.00), 2023-01 (0.78) (quedas longas indicam capacidade indisponível; veja checagem_teto_mensal.csv)
- GFS: 7313 ciclos; arquivos ok 131581, ausentes no arquivo do NCAR 275, falhas 0; GHI faltante 0.0%
- p_max_observado_kw: 291.4
- qc_pct_dias_com_restricao_ons: 0.0

## BRA — Tabocas do Brejo Velho, BA, BR (Conj. Ituverava, ONS)

- Horas diurnas com dado: 100.0% (primeira 2019-07-01 10:00:00+00:00, última 2023-06-30 19:00:00+00:00 UTC)
- Percentil 99,9 de y nas horas diurnas: 1.0103 (limite físico ȳ)
- QC: 75 de 1461 dias removidos (faltantes 0.0%, saída zero 1.64%, curtailment 1.1%, clipping 2.4%)
- Checagem de fuso: defasagem mediana -0.068 h; meses com |defasagem| > 0,5 h: 2
- Teto mensal (p99 de y nas horas diurnas): de 0.822 a 1.02; meses com teto < 80% do usual (já descontado o céu claro do mês no plano 13° / azimute 0°): nenhum (quedas longas indicam capacidade indisponível; veja checagem_teto_mensal.csv)
- GFS: 5853 ciclos; arquivos ok 108322, ausentes no arquivo do NCAR 142, falhas 0; GHI faltante 0.0%
- soma_potencia_efetiva_mw: 196.0
- qc_pct_dias_com_restricao_ons: 0.0

## GEO — Social Circle, GA, US (Simon Solar Farm, PVDAQ 9069)

- Horas diurnas com dado: 93.49% (primeira 2016-03-01 13:00:00+00:00, última 2023-11-28 21:00:00+00:00 UTC)
- Percentil 99,9 de y nas horas diurnas: 0.9989 (limite físico ȳ)
- QC: 231 de 2831 dias removidos (faltantes 6.92%, saída zero 1.24%, curtailment 0.0%, clipping 0.0%)
- Checagem de fuso: defasagem mediana -0.014 h; meses com |defasagem| > 0,5 h: 0
- Teto mensal (p99 de y nas horas diurnas): de 0.754 a 1.0; meses com teto < 80% do usual (já descontado o céu claro do mês no plano 20° / azimute 180°): 8 — 2021-06 (0.80), 2021-07 (0.78), 2021-08 (0.79), 2022-07 (0.80), 2023-06 (0.78), 2023-07 (0.76), 2023-08 (0.78), 2023-09 (0.79) (quedas longas indicam capacidade indisponível; veja checagem_teto_mensal.csv)
- GFS: 11333 ciclos; arquivos ok 195928, ausentes no arquivo do NCAR 216, falhas 0; GHI faltante 0.0%
- disponibilidade_frota_diurna_media: 0.8709
- qc_pct_dias_com_restricao_ons: 0.0
- system_id: 9069
- canais_potencia: inversores (40 x potência AC); medidor 1: 2016-02-17 a 2019-04-04; medidor 2: 2020-03-26 a 2023-11-29
