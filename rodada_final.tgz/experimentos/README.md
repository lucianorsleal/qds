# Experimentos do artigo 2 (CCP-Boot-TFT-GBM, antes CCP-Boot-TFT-ICSO-PP) — pacote v3.1

Este pacote roda todos os experimentos do artigo nos três sites — **YUL** (Desert Gardens, Yulara,
DKASC), **BRA** (Conj. Ituverava, ONS) e **GEO** (Simon Solar Farm, PVDAQ 9069) — e entrega, prontos para
o projeto LaTeX:

- as **tabelas** do artigo em LaTeX (`tables/tab_*.tex`, com os mesmos nomes que o `main.tex` inclui),
  inclusive a Tab. 4 de sites e dados;
- as **figuras** de resultados em PDF e PNG (`figuras/`), além dos CSVs que as figuras em pgfplots leem;
- os **macros** com todos os números citados no texto (`macros/results_macros.tex`, os `\R...` do
  `main.tex`) e a referência amostral do WGC (`macros/wgc_reference.tex`);
- o **guia** `GUIA_ARTIGO.md`: onde cada saída entra, o que muda no texto com estes sites e, frase por
  frase, se os números confirmam o que a Seção VI do rascunho diz.

Os dados vêm do pacote de coleta (`../coleta_dados`): a série horária limpa, o GFS processado e as
partições de cada site. Nada é baixado de novo.

## Novidades da v3.1 (21/10/2026): rodada final

- **LightGBM com alvo k** (`lgbm: alvo: k`; seção 6, item 26): o LightGBM quantílico aprende o índice de céu claro
  k = y/pcs, como o TFT, e os quantis voltam a y multiplicados por pcs. Vale para o LightGBM do híbrido, para o
  baseline LightGBM + CQR (o mesmo modelo) e para o estresse. Decidido só com a validação (o teste não entrou).
  `alvo: y` volta ao comportamento da v3.
- **YUL em 2017–2020 (teste 2020)**, antes do corte de potência do Desert Gardens (seção 6, item 21). A coleta do
  YUL precisa ser refeita (potência e GFS): `coleta_dados/linux_yul.sh`, que para se o `verificar_yul.py` achar
  corte ou canal trocado.
- **Rodada final no Linux:** `RODADA_FINAL_LINUX.md` e os scripts da pasta `linux/` (instalação, rodada,
  empacotamento dos resultados). No Linux os processos do Estágio 4 usam `forkserver`, e `processos: auto` vai
  até 16 núcleos.
- **No PC (Windows), o mesmo roteiro com os `.bat`:** `instalar_experimentos.bat` (uma vez; conserta o
  matplotlib); `coleta_dados\rodar_yul.bat` (coleta do YUL 2017–2020, ~1 dia por causa do GFS); ao mesmo tempo,
  `rodar_experimentos.bat --site GEO BRA` (10 sementes); depois `rodar_experimentos.bat --site YUL` e
  `gerar_relatorio.bat --latex ..\artigo2_3sites`. No PC as sementes 0–2 já rodadas reaproveitam os TFTs (a
  passagem para a v3.1 move para `resultados\<SITE>_antigo_<data>` só o que depende do LightGBM e do proposto).
  Para o artigo, use os resultados de uma máquina só (a Tab. 12 traz o hardware).
- Mudar para a v3.1 refaz o que depende do LightGBM e do proposto (os TFTs ficam). Para a rodada final, rode do
  zero na máquina nova, sem copiar a pasta `resultados`.

## Novidades da v3 (20/10/2026): modelo híbrido TFT + LightGBM, sem o ICSO-PP nas cabeças

Na rodada de 20/10/2026 (GEO e BRA, 3 sementes), o modelo da v2 não tinha o menor IS em nenhum horizonte: em
1 h o LightGBM + CQR era muito mais estreito, e o ICSO-PP do Estágio 3 piorava o IS no teste (sobreajustava a
validação). Um teste com as saídas reais da rodada (semente 0) mostrou o que funciona; a v3 é esse modelo
(seção 6, itens 24 e 25):

- **Base híbrida:** o ensemble de TFTs (com as cabeças do Adam, sem reotimização) é combinado, em cada
  horizonte e mês de teste, com o LightGBM quantílico que o pacote já tinha como baseline. O peso do TFT
  (grade 0; 0,2; …; 1) é escolhido em cada janela de calibração pelo IS condicional em validação cruzada
  pelas metades dos dias da janela. Nada do mês de teste entra na escolha.
- **Escalas de cada lado:** a camada condicional usa uma escala para o lado de baixo e outra para o de cima,
  tiradas dos quantis de cada modelo (antes, uma escala só, simétrica).
- **Resultado na semente 0** (IS, % de Pnom; GEO com o TFT da v2.1 e BRA com o da v2): GEO 37,4 / 43,1 /
  46,8 / 47,1 e BRA 66,6 / 88,1 / 88,4 / 88,1 em 1 h / 3 h / 6 h / DA, contra 51,1 / 52,2 / 53,4 / 51,3 e
  88,8 / 90,2 / 91,2 / 91,7 do modelo da v2, com o pior grupo coberto em 92–96%.
- **Tabelas:** a ablação ganha B4 (escalas de cada lado), B5 (= proposto), B4h (o ICSO-PP nas cabeças, no
  lugar da Tab. 10), B5f (peso fixo da validação) e B5g (só o LightGBM); as camadas L1–L7 e o BatchMVP
  passam a usar a mesma base híbrida; o estresse e o custo são refeitos para o híbrido. A Tab. 10 e a Fig. 8
  (otimizadores) saem; entra a figura do peso do TFT por mês (`fig_weights`).
- **Nome provisório:** CCP-Boot-TFT-GBM (macro `\RModelName`; troque em `exp/artigo.py`, constante MODELO).
- **Resultados já rodados:** a v3 reaproveita os TFTs (se a seção `tft` do config não mudou) e os baselines
  (CH-PeEn, LightGBM + CQR, HEC-XGB, PRIOR, B4e, TFT nativo) e refaz só o que depende do proposto. Os quantis
  do LightGBM são calculados uma vez por semente na primeira rodada da v3 (é o mesmo modelo do baseline
  LightGBM + CQR, com a mesma semente; ficam em `cache\s<N>\lgbm_quantis.npz`). A comparação de
  otimizadores da v2 saiu das etapas padrão (`--etapas otimizadores` ainda roda).

## Novidades da v2.1 (20/10/2026)

- **Horizontes intradiários do TFT** (seção 6, item 23): duas opções novas em `tft:` no
  `config_experimentos.yaml`. `lags_decodificador` dá ao decodificador o k das últimas horas, já observadas na
  emissão; `peso_intradiario` e `passos_intradiarios` dão peso maior aos primeiros passos do decodificador na
  perda. Na rodada de 20/10/2026, com as opções desligadas, o TFT quase não usava as últimas observações: em
  1 h, o RMSE foi de 14,9% de Pnom contra 10,5% do LightGBM e do PRIOR. Ligadas (3 e 5), num membro do GEO o
  RMSE de validação em 1 h caiu de 11,8% para 10,2%, e o do DA de 13,4% para 12,8%. **Ligadas no config desde
  20/10/2026:** a próxima rodada refaz o que depende do TFT nas sementes já rodadas (os resultados antigos vão
  para `resultados\<SITE>_antigo_<data>\`).
- **Manifesto:** mudar só a seção `tft` refaz só o que depende do TFT; CH-PeEn, LightGBM, HEC-XGB, PRIOR e
  B4e ficam como estão (antes, qualquer mudança no TFT refazia tudo).
- **Artigo:** a Fig. 9 entra no `main.tex` por `\input{figuras/fig_vsn_pgfplots}` (acompanha o número de
  sites de cada rodada), as frases do site desértico usam `\RDesertSite` e `\RCloudierSites`, e a legenda
  gerada da Fig. 9 não afirma mais que o passado domina em 1 h (confira na seção 4 do guia). O guia mostra a
  redução de IS por horizonte quando o sinal muda.

## Novidades da v2 (19/10/2026)

- **Sem o Chronos.** O artigo não compara com modelo de fundação: a etapa `chronos`, o baseline e o pacote
  `chronos-forecasting` saíram. São 8 métodos na Tab. 5 e nos postos de Friedman (Fig. 12). Os resultados
  já calculados continuam valendo; arquivos `CHRONOS.npz` que existirem são ignorados. O guia diz o que
  tirar do texto (Seções I-B, V-C e VI-A).
- **Memória da GPU:** cada etapa devolve a memória ao terminar, e em GPUs com menos de 8 GB o XGBoost do
  HEC roda na CPU (na v1, a rodada parou por falta de memória na semente 1).
- **Época do TFT = 4.000 janelas sorteadas** (seção 6, item 22): com todas as janelas a cada época, a
  validação piorava desde a 2ª época e o treino desperdiçava 10 épocas; agora a perda de validação é menor
  e o treino dos TFTs fica cerca de 4 vezes mais curto. Essa mudança refaz a semente 0 já rodada na v1 (os
  resultados dela vão para `resultados\GEO_antigo_<data>\`).
- **Fig. 9** com as conexões residuais do TFT (seção 6, item 8); o log mostra a melhor época de cada TFT.
- **`gerar_relatorio.bat --perfil rapido`** gera as saídas do teste rápido; sem resultados, o comando avisa
  o que rodar.
- A v1 está guardada em `versao1\`, só para consulta: rode sempre os `.bat` desta pasta.

> **YUL em 2017–2020.** De 2021 em diante a saída do Desert Gardens é cortada pela rede isolada de Yulara (e de
> mai/2021 a dez/2022 a coluna da usina vem trocada nos arquivos do DKASC); por isso o YUL usa 2017–2020, com
> teste em 2020 (seção 6, item 21). A coleta desse período precisa ser feita antes de rodar o YUL.

## 1. Antes de rodar

- **O GFS dos três sites precisa estar processado** (`coleta_dados\dados\processados\<SITE>\gfs_horario.parquet`
  cobrindo todo o período). Já está, para YUL, BRA e GEO. Se faltar o arquivo, ou se ele cobrir menos de
  95% das horas de validação, calibração e teste (download incompleto), o script para e diz até onde o
  GFS vai.
- **GPU NVIDIA.** O instalador detecta a placa e instala o PyTorch com CUDA. Sem GPU tudo funciona, mas
  os 300 TFTs (3 sites × 10 sementes × 10 membros) levariam semanas na CPU.
- **Espaço:** ~3 GB para o ambiente Python e ~2 GB de resultados por site.

## 2. Instalação (uma vez)

Dê dois cliques em **`instalar_experimentos.bat`**. Ele:

1. cria o ambiente `.venv` nesta pasta, separado do da coleta;
2. instala o PyTorch para a sua GPU (CUDA 12.8 nas RTX 20xx ou mais novas; CUDA 12.6 nas GTX 9xx/10xx),
   LightGBM, XGBoost, Optuna, cma e matplotlib (log em `resultados\instalacao.log`);
3. roda `executar.py verificar`, que mostra a GPU encontrada e se os arquivos dos três sites estão no
   lugar.

**Já instalou uma versão anterior deste pacote?** Rode o `instalar_experimentos.bat` de novo depois de
copiar os arquivos novos: ele aproveita o `.venv` e só acrescenta o que falta (o matplotlib, que gera as
figuras do artigo). Os resultados que já existem são aproveitados. Deixe a janela aberta até o fim: algumas
etapas ficam minutos sem mostrar nada novo. Se uma instalação anterior foi interrompida, ele reinstala o
pacote que ficou pela metade.

## 3. Teste rápido (recomendado antes da rodada completa)

Dê dois cliques em **`rodar_teste_rapido.bat`**. Na GPU leva de 30 a 60 minutos para os três sites.
Roda todas as etapas com 1 semente, 2 membros, 2 épocas e orçamentos pequenos e grava em
`resultados_rapido\` e `saida_artigo_rapido\`, já com tabelas, figuras e guia. Os números **não servem
para o artigo**: nas tabelas eles saem em vermelho e as figuras levam a marca d'água "TESTE RÁPIDO". O
teste só confere que tudo roda no seu computador, do TFT ao PDF.

## 4. Rodada completa

Dê dois cliques em **`rodar_experimentos.bat`** (`python executar.py tudo`). Para cada site ele roda as
10 sementes, uma de cada vez, com todas as etapas. No fim gera o relatório de cada site, junta os sites e
produz tabelas, figuras, macros e o guia em `saida_artigo\`.

- **Retomada:** cada etapa grava o que produz. Se fechar a janela, faltar luz ou o Windows reiniciar,
  rode de novo: o que já estiver pronto é pulado. Enquanto roda, o Windows não entra em suspensão.
- **Se os dados ou o config mudarem:** o arquivo `resultados\<SITE>\manifesto.json` guarda a impressão
  digital dos dados de entrada (conteúdo da série, do GFS e das partições), da série depois do QC, do
  limite físico ȳ, da tabela de pares e das seções do config que afetam os resultados. Se algo mudar (por exemplo, o GFS foi reprocessado), a
  rodada seguinte avisa no log, move os resultados antigos para `resultados\<SITE>_antigo_<data>\` (nada é
  apagado) e refaz o que depende disso. Mudanças só em `hec`, `lgbm`, `estresse` ou
  `otimizadores` movem só os arquivos desses métodos; mudanças só em `tft` mantêm os baselines; e a passagem
  para a v3 (ou mudanças em `hibrido`) refaz só o que depende do modelo proposto.
- **Por partes** (recomendado: comece com poucas sementes e olhe o guia):
  - `rodar_experimentos.bat --sementes 0 1 2` roda só essas sementes; as outras podem vir depois, e o
    relatório usa as sementes que já estiverem prontas;
  - `rodar_experimentos.bat --site GEO` roda um site só; `--etapas proposto prior` roda só essas etapas.
- **Tempo estimado por semente numa GPU de entrada (RTX 3060).** O treino dos TFTs cresce com o tamanho
  do bloco de treino: GEO tem ~23 mil horas diurnas de treino, BRA ~10 mil e YUL ~7 mil.

  | Etapa | O que roda | GEO | BRA | YUL |
  |---|---|---|---|---|
  | `proposto` | 10 TFTs, LightGBM (84 modelos), pesos por janela, PROP, MVP, ablação, camadas e o ICSO-PP do B4h | 1–2 h | 0,6–1,2 h | 0,5–1 h |
  | `prior` | 40 LSTMs (10 por horizonte) e 8 ICSO-PP (PRIOR e B4e) | 1–2 h | 0,5–1 h | 0,4–0,8 h |
  | demais etapas | estresse, TFT nativo, LightGBM + CQR, HEC-XGB | 40–80 min | 30–60 min | 30–60 min |
  | `otimizadores` | opcional na v3 (`--etapas otimizadores`): comparação de otimizadores da v2 | 50–80 min | 50–80 min | 50–80 min |

  São 8 a 17 horas por semente para os três sites, ou de 3 a 7 dias para as 10 sementes. Medido num
  notebook com RTX 3050 (6 GB), GEO, semente 0, na v1: 4,2 h (proposto 1,3 h, prior 0,5 h, otimizadores
  1,8 h, dos quais 55 min só do TPE, e demais etapas 0,6 h). Com a época de 4.000 janelas (v2), o treino
  dos 10 TFTs cai de ~67 para ~15 min (v2.1, com o peso intradiário: ~23 min); sem os otimizadores (v3), a
  semente do GEO deve ficar perto de 2 h. O tempo de cada semente
  aparece no log; a partir dele dá para estimar o resto. As etapas de calibração usam
  vários núcleos da CPU ao mesmo tempo (até 8; `processos:` no config).
- **Log:** `resultados\<SITE>\logs\experimentos.log`. `python executar.py status` mostra o que já está
  pronto em cada semente.

## 5. O que sai e como levar para o artigo

```
resultados\<SITE>\
  manifesto.json         impressão digital dos dados e do config da rodada (seção 4)
  cache\s<semente>\      modelos (.pt), saídas das redes, quantis do LightGBM, pesos do híbrido, θ* do ICSO-PP (B4h)
  previsoes\s<semente>\  intervalos e quantis de teste de cada método e variante (.npz)
  csv\results\*.csv      tabelas do site (CSV)
  csv\data\*.csv         dados das figuras do site
  csv\detalhe\           métricas por semente, IS diário, meta.json
saida_artigo\
  results\*.csv          tabelas com os três sites juntos (Holm sobre os 12 pares site–horizonte)
  data\*.csv             dados das figuras (os que o main.tex lê em pgfplots)
  tables\tab_*.tex       tabelas LaTeX: tab_data (Tab. 4), tab_main (5), tab_sites (6), tab_layers (7),
                         tab_groups (8), tab_ablation (9), tab_stress (11), tab_cost (12); sem a Tab. 10
  macros\                results_macros.tex (os \R... do texto) e wgc_reference.tex
  figuras\               fig_horizon (Fig. 6), fig_heat (7), fig_weights (nova, no lugar da 8), fig_vsn (9),
                         fig_attention (10), fig_multipliers (11), fig_ranks (12) e fig_example (nova,
                         opcional: uma semana de previsões DA por site), em PDF e PNG; fig_vsn_pgfplots.tex
  GUIA_ARTIGO.md         o que fazer com tudo isso no main.tex e o que os números confirmam
```

**Para levar ao artigo:**

1. Rode `gerar_relatorio.bat --latex ..\artigo2_3sites` (abra o `cmd` na pasta `experimentos` para passar
   argumentos). Ele gera tudo com as sementes que já terminaram na rodada completa (`resultados\`), copia
   `results\`, `data\`, `tables\`, `macros\` e `figuras\` para o projeto LaTeX e deixa lá o
   `GUIA_ARTIGO.md`. Com `--perfil rapido` ele usa o teste rápido (`resultados_rapido\`). Se ainda não houver
   resultado nenhum, ele avisa e não gera nada. Sem `--latex`, copie as pastas à mão.
2. **Não rode** o `tools/render_tables.py` nem o `build.sh` do zip de 16/10: eles regeram tabelas e
   macros com a lista fixa ASP, GTB, UTR e BRA e sobrescrevem estas. Compile com `latexmk -pdf main.tex`.
3. Siga a seção 3 do guia para as mudanças de texto que dependem dos sites (resumo, Seção V-A, Tab. 4,
   QC, Fig. 9, contagem de pares, disponibilidade de dados). A pasta `artigo2_3sites\`, entregue junto
   com este pacote, é o projeto do zip de 16/10 já com essas mudanças: dá para compilar e comparar.
4. Leia a seção 4 do guia antes de revisar a Seção VI: ela diz quais frases do rascunho os números
   confirmam e quais precisam ser reescritas.
5. Quando os números forem os finais, ponha `\showplaceholdersfalse` no preâmbulo do `main.tex`.

Se um método ficar sem resultado (uma etapa interrompida, por exemplo), as células dele saem como "--",
ele fica fora dos postos de Friedman e o guia avisa. Rode a etapa que falta depois (por exemplo,
`rodar_experimentos.bat --etapas hec`) e gere o relatório de novo.

| CSV | Tabela/figura | Como é calculado |
|---|---|---|
| `main_metrics.csv` | Tab. 5, 6, Fig. 6 e 12 | 8 métodos × 4 horizontes, média das sementes; `IS_sd` é o desvio entre sementes |
| `site_diagnostics.csv` | Tab. 6 | DM unilateral no IS diário (Newey–West, ⌊n^{1/3}⌋ defasagens), Holm sobre todos os pares site–horizonte; `merged_pct` = % das janelas com fusão de regime ou tercil |
| `group_coverage.csv` | Tab. 8 | cobertura por hora, regime, tercil, estação local e classe de céu |
| `calib_layers.csv` | Tab. 7 | L1–L7 sobre a mesma base híbrida (1 h e DA) |
| `ablation.csv` | Tab. 9 | B1–B5, B4h e B5a–B5g (1 h, 6 h e DA) |
| `stress.csv` | Tab. 11 | S0–S5 no DA, PRIOR e PROP |
| `cost.csv` | Tab. 12 | tempos medidos na sua máquina |
| `group_sizes.csv` | referência do WGC | horas de teste por grupo no DA |
| `fig_heat_mondrian.csv`, `fig_heat_cc.csv` | Fig. 7 | cobertura DA por célula regime × hora (L3 e proposto) |
| `fig_weights.csv` | figura nova (lugar da Fig. 8) | peso do TFT escolhido em cada janela, por horizonte e mês de teste, média das sementes |
| `fig_vsn_1h.csv`, `fig_vsn_DA.csv` | Fig. 9 | pesos de seleção por grupo de variáveis (colunas `site`, `code`, `feat`, `w`) |
| `fig_attention.csv` | Fig. 10 | atenção média nas 120 h do codificador, DA, por regime |
| `fig_cc_multipliers.csv` | Fig. 11 | ψ_r do limiar superior no DA, janelas de inverno e de verão |
| `fig_example.csv` | figura nova | semana de teste do DA com maior variação do índice de céu claro, por site |

## 6. Decisões de implementação que o texto do artigo precisa refletir

O script segue a especificação da Tab. 3 e das Seções III–V. Onde o texto não fixava um detalhe, ou onde
a especificação literal não funcionava, a escolha foi esta (revise as frases correspondentes):

1. **TFT em PyTorch puro, sem o PyTorch Forecasting.** É a mesma arquitetura de Lim et al. (GRN, VSN,
   LSTM codificador–decodificador, atenção interpretável, quantis). Escrever o TFT à mão evitou a
   dependência do Lightning no Windows e deu acesso direto ao que o Estágio 3 usa: a representação
   penúltima, as cabeças medianas e os pesos ponderados pelos dias do bootstrap. Ajuste a Seção V-E,
   que cita o PyTorch Forecasting.
2. **Limiar do conformal condicional calculado pela dual.** O limiar sai da derivada à esquerda do valor
   da dual da regressão quantílica aumentada: um programa linear (HiGHS) por padrão hora × regime ×
   tercil, sem bisseção. É o mesmo limiar do Algoritmo 1. Os testes (`python executar.py autoteste`)
   conferem isso contra a bisseção e contra o split e o Mondrian.
3. **Regra de fusão.** Como no texto, a contagem inclui o ponto de teste (regra simétrica nos n+1
   pontos), mas o mínimo é n_ef = max(30, ⌈τ/(1−τ)⌉ + 1): 50 com τ = 0,98 e 40 no nível 0,975 da grade
   do CRPS. Com n_min = 30, um grupo com menos de ⌈τ/(1−τ)⌉ = 49 amostras de calibração tornaria a
   regressão quantílica aumentada inviável e o limiar infinito (intervalo [0, ȳ] para o mês inteiro),
   como no Mondrian. A regra também vale para as horas: no inverno, as horas das pontas do dia têm
   poucas horas diurnas. O artigo diz "n_min = 30" e fala só de regimes e tercis.
4. **Interações (B4b e L7):** colunas regime × hora. Dentro de cada regime (fora o mais frequente), as
   horas vizinhas são fundidas pela mesma regra até cada célula ter n_ef amostras; sem isso, quase
   nenhuma célula de 12 semanas chegaria a 49 amostras e B4b sairia igual ao proposto.
5. **Escalas do ICSO-PP.** Nas cabeças, ε0 = 10⁻³ em s = ς0(|θ0| + ε0), então cada unidade de u move um
   peso ~5% do seu valor (o artigo não fixa ε0). No teste com dados simulados, ε0 = 1 (passo de ~0,05
   em todo peso) deixou o enxame derivar em direções em que o IS validado cruzado quase não muda: a
   mediana ganhou um viés de −8% de P_nom e o RMSE piorou 75%, com IS igual. Com ε0 = 10⁻³ o RMSE fica
   no nível do Adam. Para log γ (θ0 = 0, em que a regra não mexeria em γ) a escala é 0,5. Vale conferir
   na rodada real se o RMSE de B4 (Tab. 9) não fica pior que o de B3; o guia confere isso.
6. **Base do weight decay do TFT:** 10⁻⁵, o mesmo do artigo 1. A Tab. 3 não fixa esse valor, mas ele
   sofre o jitter de ±10%.
7. **CRPS de todos os métodos pela mesma decomposição em 20 quantis** (0,025; 0,075; …; 0,975). O TFT
   nativo é treinado com esses 20 níveis mais a mediana. O intervalo dele continua sendo
   [q0,025; q0,975], e é dessa grade que sai o CRPS.
8. **Pesos de seleção da Fig. 9.** O VSN dá pesos separados para o passado (codificador) e para as
   entradas futuras, incluindo o NWP (decodificador); a Fig. 9 junta os dois por horizonte. Para o
   passo-alvo j: peso do grupo = ρ_j·v_j + (1 − ρ_j)·Σ_p a_jp·v_p, em que v_p são os pesos do VSN da posição
   p somados por grupo, a_jp é a atenção de j sobre p (distribui o contexto temporal, que chega pela atenção
   e pelo LSTM) e ρ_j é a fração da representação do passo-alvo que vem das variáveis do próprio passo
   pelas conexões residuais com porta (razão das normas dos ramos em cada LayerNorm(skip + GLU(x))). Os
   grupos somam 100%. Ponderar só pela atenção, como numa versão anterior, deixava o NWP com 1–3% no DA,
   porque o NWP só entra no decodificador e chega à saída sobretudo pelas conexões residuais. Os dois
   extremos ficam salvos como diagnóstico em `cache\s<semente>\tft_saidas.npz` (`vsn_ctx_*`: só a
   atenção; `vsn_prop_*`: só o passo-alvo; `vsn_propria`: ρ médio em 1 h e no DA). Resultados de versões
   anteriores são atualizados sem retreinar. Descreva a regra na Seção III-G.
9. **Piso do DA:** p(h) com h = 24, que dá p = 7.
10. **Buffer δ = 0,01 em todos os métodos conformais** (baselines e camadas L1–L7), para que todos mirem a
    mesma cobertura.
11. **Janela de calibração do DA.** A previsão DA do dia 1 do mês m é emitida às 12:00 do último dia do
    mês anterior; por isso a janela de calibração do DA termina nessa emissão (as horas da tarde desse
    dia, ainda não observadas, ficam de fora). Nos horizontes intradiários a janela termina no início do
    mês, como no texto.
12. **Pares sem GFS.** Se a hora-alvo não tem GFS em nenhum ciclo até 24 h antes, o par sai da avaliação
    de todos os métodos (o log diz quantos). Sem isso, o NWP faltante cairia no regime "encoberto".
13. **Grupos de avaliação.** O WGC de todos os métodos usa os tercis de σ̃ do modelo proposto da mesma
    semente, com os cortes fixados na validação. Assim os 19 grupos são os mesmos em todas as linhas.
14. **PRIOR (artigo 1)** conforme a especificação do artigo 1: um Boot-LSTM por horizonte, MSE na
    potência, ICSO-PP nas cabeças com aptidão Mondrian, piso reestimado em cada janela, quantis por hora
    com o global de reserva e fator s* (bisseção com expansão). **HEC-XGB** conforme Gangwar et al.: 7
    XGBoost com bootstrap de linhas e jitter em subsample, colsample, λ e α. L3 e L4 usam a camada do
    artigo 1, com o fator s*.
15. **B4e:** o Boot-LSTM não tem cabeças de quantis, então a dispersão é só a epistêmica, e o ICSO-PP
    refina as cabeças com a aptidão condicional.
16. **Orçamento dos otimizadores: 2.040 avaliações para todos**, as mesmas do ICSO-PP (40 da população
    inicial + 40 × 50 gerações). A Seção V-E diz "2,000"; troque por 2,040 (ou use `orcamento: 2000` no
    config, e aí o ICSO-PP continua com 2.040).
17. **BatchMVP:** implementação própria do algoritmo de Jung et al. (2023), com grade de 10 faixas do
    limiar e parada quando o maior desvio ponderado fica abaixo de 0,25·q(1−q)/n (no máximo 3.000
    tentativas). Os grupos são os mesmos 19 do conformal condicional, mais o grupo "todos". Com 12 semanas
    (~1.000 amostras por janela), 100 faixas deixam células grupo × faixa de 0–2 amostras e o BatchMVP
    sobreajusta: no teste com dados simulados, a cobertura caiu para ~94% com 100 faixas e ficou em ~96%
    (o alvo com o buffer) com 10. O artigo não fixa esse número; vale citá-lo na Seção V-C (Baselines).
18. **Sem modelo de fundação (v2).** O Chronos saiu da comparação: o artigo tem sete baselines (CH-PeEn,
    LightGBM + CQR, HEC-XGB, CP-Boot-LSTM-ICSO-PP, TFT nativo, TFT + CQR e Boot-TFT + BatchMVP). Tire do
    texto o item do Chronos na Seção V-C (“Eight baselines” → “Seven baselines”), a frase sobre modelos de
    fundação na Seção I-B e a frase sobre o Chronos na Seção VI-A; o guia traz as linhas.
19. **Limite físico ȳ pelo treino.** ȳ é o maior y diurno do bloco de treino, arredondado para cima: GEO
    1,00, BRA 1,04 (a capacidade do ONS é um pouco menor que o pico; ~0,9% das horas diurnas passam de 1)
    e YUL 0,79 (normalizado pela potência DC). Com ȳ = 1 fixo, o BRA perderia cobertura nas horas claras
    de meio-dia. O texto diz "ȳ = 1 when Pnom is the AC rating"; acrescente que ȳ é o máximo do treino.
20. **QC de disponibilidade da usina.** Dias em que o máximo de y numa janela de 7 dias fica abaixo de 30%
    do p99 diurno do treino, em trechos de pelo menos 3 dias, saem do experimento (alvos e entradas). No
    YUL de 2021–2025 (período usado até 20/10/2026) isso removia 29/04–28/12/2021, 26/04–30/12/2022 e
    02–04/10/2024. Nos dois primeiros trechos a
    coluna `5_1_Active_Power` do arquivo anual do DKASC não traz a potência da usina: nesses meses os canais
    do Desert Gardens estão trocados no arquivo (a coluna de "energia" passa a seguir a irradiância no plano
    dos módulos e a de "potência" fica entre 30 e 80). Em BRA e GEO a regra não remove nada. Acrescente a
    regra à Seção V-B (o guia traz a frase).
21. **YUL: a saída do Desert Gardens é limitada pela rede isolada de Yulara (curtailment) de 2021 em diante;
    desde 21/10/2026 o YUL usa 2017–2020, com teste em 2020.** Em jan–abr/2021, nos dias claros, o meio-dia do
    Desert Gardens fica em 20–36% do pico do dia (vizinhos: 98%) e o pico do dia em 0,29–0,39 da nominal
    (vizinhos: 0,78–0,87); de mai/2021 a dez/2022 a coluna da usina vem trocada. O `verificar_yul.py` da coleta
    repete essa conta por trimestre para 2017–2020 e para a coleta se achar corte ou canal trocado. Histórico
    (2021–2025): nos arquivos brutos do DKASC, em dias de céu limpo (o
    piranômetro da própria usina e os sistemas vizinhos Laundry, Service Station e Connellan Airport
    seguindo a curva do sol), a potência do Desert Gardens cai ao meio-dia e volta no fim da tarde: o
    meio-dia fica abaixo de 80% do máximo do dia em 100% dos dias claros de abr–set de 2024 e de 2025, em
    71–87% dos de out/2024–mar/2025 e out–dez/2025, em 63–92% dos de 2023 e só em jan–mar/2024 quase não
    aparece (mediana da razão meio-dia/máximo em 2024–2025: 0,39 no Desert Gardens contra 0,98 nos vizinhos,
    que não mostram isso). É o padrão de uma usina despachada para baixo pela
    microrrede do resort, que precisa manter carga nos geradores a gás. Por isso o teto mensal do YUL fica
    em 47–78% da referência de céu claro em 8 dos 12 meses do ano de teste, e no teste rápido a cobertura de
    todos os métodos cai em out–dez/2025 (PROP 70–90%) e nos dias de sol. Nenhum previsor baseado no tempo
    resolve isso, e o texto sobre o clima desértico (Seção VI-B) ficaria apoiado num artefato. Opções: (a)
    outro sistema de Yulara, com o mesmo GFS (a coleta só reprocessa a série): Laundry (fonte 11,
    327,6 kWp, fixo) ou Service Station (fonte 10, 226,8 kWp), sem limitação, mas com os canais trocados no
    arquivo de abr/2021 a jan/2023 (a coleta precisaria identificar a coluna de potência ou começar em
    fev/2023), ou Connellan Airport (fonte 8, 105,9 kWp, telhado), cuja coluna de potência parece correta em
    todo o período; (b) outra usina de clima desértico, com novo download do GFS. A escolha final (21/10/2026)
    foi manter o Desert Gardens e usar o período anterior ao corte.
22. **Época do TFT = 4.000 janelas de treino sorteadas** (`tft: amostras_por_epoca`). Com uma época = todas as
    ~40 mil janelas do GEO, cada hora-alvo entra em 36 janelas vizinhas por época: num membro do GEO, a perda
    de treino caiu de 0,0819 para 0,0633 em 4 épocas e a de validação subiu de 0,0827 para 0,0873, e o early
    stopping sempre guardava a 1ª época (as outras 10 eram desperdício). Com 4.000 janelas por época, a
    melhor perda de validação foi 0,0814, na 10ª época, e o treino parou na 20ª, com metade do tempo de 4
    épocas completas. Na Tab. 3, escreva “at most 100 epochs of 4,000 randomly drawn windows”.

23. **Horizontes intradiários do TFT** (`tft: lags_decodificador`, `peso_intradiario`, `passos_intradiarios`;
    v2.1). Na rodada de 20/10/2026 (GEO e BRA, 3 sementes), os métodos baseados no TFT tiveram em 1 h RMSE de
    14,9% de Pnom, contra 10,5% do LightGBM e do PRIOR, e FSS de −0,21: o erro do TFT quase não mudava de 1 h
    ao DA. A perda soma os 36 passos do decodificador e os 6 intradiários são só 1/6 dela, e a informação das
    últimas horas só chega ao passo-alvo pelo estado do LSTM e pela atenção. Num membro do GEO (mesma semente
    e bootstrap; RMSE de validação em % de Pnom; persistência inteligente em 1 h: 10,0):

    | Variante | Melhor época | 1 h | 3 h | 6 h | 24 h | 36 h |
    |---|---|---|---|---|---|---|
    | TFT da rodada (0 e 1) | 7 | 11,8 | 12,0 | 12,3 | 13,4 | 13,5 |
    | só `lags_decodificador: 3` | 4 | 11,6 | 11,9 | 12,1 | 13,5 | 13,2 |
    | só `peso_intradiario: 5` | 12 | 11,5 | 11,8 | 12,1 | 13,1 | 13,1 |
    | as duas | 24 | 10,2 | 11,2 | 11,7 | 12,8 | 12,9 |

    Com as duas, o TFT chega perto da persistência em 1 h e melhora todos os horizontes; o treino fica mais
    longo (melhor época 24 em vez de 7). No texto: a tabela de entradas ganha a linha dos k da origem e a
    Seção III-B, a frase da perda ponderada (o guia traz as frases quando as opções estão ligadas).

24. **Modelo híbrido (v3).** O Estágio 3 deixa de reotimizar as cabeças medianas com o ICSO-PP e passa a combinar o
    ensemble de TFTs (cabeças do Adam) com o LightGBM quantílico (21 quantis por horizonte, as mesmas entradas
    tabulares do baseline, inclusive o k das 3 últimas horas): ŷ = w·ŷ_TFT + (1 − w)·ŷ_GBM, e as escalas de cada
    lado do mesmo jeito. O peso w (grade em `hibrido: pesos`) é escolhido em cada janela de calibração (horizonte ×
    mês de teste) pelo menor IS da camada condicional em validação cruzada pelas metades (paridade) dos dias da
    janela. Na semente 0, o peso médio do TFT ficou em 0,45 (1 h), 0,70 (3 h), 0,65 (6 h) e 0,57 (DA) no GEO e
    perto de 0,2 em 1 h no BRA. Escolher um peso fixo por horizonte no bloco de validação (3 meses) errou no BRA
    (a validação preferia o LightGBM em 3–6 h e o ano de teste, o TFT): é a ablação B5f.
25. **Escalas de cada lado (v3).** Escores E+ = (y − ŷ)+/s↑ e E− = (ŷ − y)+/s↓. No TFT, s↓ = √(σ_epi² + σ↓²) e
    s↑ = √(σ_epi² + σ↑²), com σ↓ = (q0,5 − q0,1)/1,2816 e σ↑ = (q0,9 − q0,5)/1,2816 médios entre os membros; no
    LightGBM, (q0,5 − q0,025)/1,96 e (q0,975 − q0,5)/1,96. Cada lado tem o seu piso (percentil p(h) da
    validação) e os tercis de dispersão usam a média das duas escalas. A calibração de cada lado já era separada
    (τ = 1 − (α − δ)/2 por lado); o que muda é a escala. Ganho no teste: 3–5% de IS só com o TFT (B3 → B4).
26. **LightGBM com alvo k (v3.1).** Com `lgbm: alvo: k`, cada modelo quantílico aprende o índice de céu claro
    k = y/pcs (linhas com pcs > 0,02; k limitado a [0, 2]) e as previsões voltam a y multiplicadas por pcs,
    como já fazia o TFT; as entradas e os hiperparâmetros não mudam. A escolha foi feita só na validação (dias
    em três partes: parada antecipada, calibração e avaliação): com a calibração normalizada da camada
    proposta, o IS do LightGBM caiu 3,5–11% no GEO e 0–8% no BRA (maior no DA), e em 14 de 16 comparações
    (2 sites × 4 horizontes × 2 calibrações) o alvo k ganhou. Outras ideias testadas do mesmo jeito e
    descartadas: erro recente do GFS como entrada, GFS das horas vizinhas e média de sementes do LightGBM.

## 7. Estrutura do código

```
executar.py                 comandos (verificar, rodar, relatorio, juntar, artigo, tudo, status, autoteste)
config_experimentos.yaml    especificação do artigo e parâmetros dos baselines; perfil "rapido"
exp/dados.py                série horária, P̃cs, QC de disponibilidade, entradas do TFT, pares de avaliação
exp/redes.py                TFT e LSTM do artigo 1
exp/treino.py               bootstrap por dias, jitter, treino, inferência
exp/conformal.py            escores, conformal condicional (dual), Mondrian, s*, BatchMVP, CQR, CPD
exp/fitness.py              aptidões do Estágio 3 (IS condicional e IS Mondrian, validação cruzada)
exp/otimizadores.py         ICSO-PP, ICSO, CSO, PSO, L-SHADE, CMA-ES, TPE
exp/baselines.py            CH-PeEn, LightGBM, XGBoost (HEC)
exp/metricas.py             IS, PICP, PINAW, CRPS, FSS, WGC, CCD, DM, Holm, Wilcoxon
exp/pipeline.py             etapas por semente, com cache e manifesto
exp/relatorio.py            métricas, agregação e CSVs do artigo; junção dos sites
exp/artigo.py               tabelas LaTeX, macros, referência do WGC, figuras e guia do artigo
testes/                     testes do conformal, gerador de dados de teste, teste de formato
```

## 8. Outros sites

O código não tem nada específico de um site. Os sites vêm de `sites:` no `config_experimentos.yaml`
(padrão: YUL, BRA e GEO) e os dados de cada um, do `config.yaml` da coleta. Para incluir outro (por
exemplo, ASP, UKF ou HKG do `config_5sites.yaml` da coleta), processe-o na coleta, ponha o código em
`sites:` e rode. Tabelas, figuras e macros se ajustam ao número de sites; a contagem de pares do Holm
passa a ser 4 × (nº de sites).

## 9. Problemas comuns

- **"falta …gfs_horario.parquet"** ou **"O GFS de … cobre só …":** o GFS do site ainda não terminou de
  baixar ou de ser processado (seção 1). Termine o download, rode o processamento do GFS de novo e
  depois os experimentos.
- **Apareceu uma pasta `resultados\<SITE>_antigo_<data>`:** os dados de entrada ou o config mudaram
  desde a rodada anterior (o log diz o quê), e os resultados antigos foram guardados ali antes de serem
  refeitos. Pode apagá-la quando não precisar mais.
- **"matplotlib não instalado" no `gerar_relatorio.bat`:** as tabelas e os macros saem, mas as figuras em
  PDF/PNG não. Rode o `instalar_experimentos.bat` de novo (ele reinstala os pacotes que ficaram pela metade) e
  depois o `gerar_relatorio.bat`.
- **"PyTorch sem GPU":** o driver da NVIDIA está desatualizado, ou o PyTorch instalado é o de CPU.
  Atualize o driver e rode o `instalar_experimentos.bat` de novo.
- **"CUDA error: out of memory":** rode de novo o mesmo comando; ele continua de onde parou. Cada etapa
  devolve a memória da GPU ao terminar e, em GPUs com menos de 8 GB, o XGBoost do HEC roda na CPU. Se
  ainda faltar memória, diminua `tft: batch` no `config_experimentos.yaml` (o `amp: true`, que já é o
  padrão, também economiza memória) e feche outros programas que usem a GPU.

