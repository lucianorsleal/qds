@echo off
REM Experimentos completos do artigo (padrao: YUL, BRA e GEO, 10 sementes, todas as etapas) e, no fim,
REM CSVs, tabelas LaTeX, figuras, macros e o guia do artigo (saida_artigo\GUIA_ARTIGO.md).
REM Pode fechar a janela e rodar de novo: continua de onde parou.
REM Argumentos extras vao para o "executar.py tudo" (ex.: --site GEO  ou  --sementes 0 1 2  ou  --etapas proposto).
setlocal EnableExtensions
cd /d "%~dp0"
title Experimentos CCP-Boot-TFT-ICSO-PP
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
if not exist ".venv\Scripts\python.exe" (
  echo Ambiente .venv nao encontrado. Rode primeiro o instalar_experimentos.bat
  pause
  exit /b 1
)
".venv\Scripts\python.exe" executar.py tudo %*
echo.
echo Fim. Logs em resultados\SITE\logs\experimentos.log ; tabelas, figuras e guia do artigo em saida_artigo\
pause
