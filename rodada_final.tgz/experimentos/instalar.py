"""Instala as dependências dos experimentos no ambiente .venv desta pasta.

Detecta a GPU NVIDIA pelo nvidia-smi e escolhe a versão do PyTorch:
  - capacidade de computação >= 7.5 (RTX 20xx e mais novas, inclusive RTX 50xx): CUDA 12.8 (cu128)
  - Maxwell/Pascal/Volta (GTX 9xx/10xx, Titan V): CUDA 12.6 (cu126)
  - sem GPU NVIDIA: versão para CPU (os TFTs ficam muito lentos)
Depois instala o requirements_experimentos.txt, confere se cada pacote importa (e reinstala o que ficou pela
metade, por exemplo se a instalação anterior foi interrompida) e se o PyTorch enxerga a GPU.

Mostra o andamento na janela; a saída completa do pip vai para resultados/instalacao.log.
"""

import subprocess
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent
LOG = RAIZ / "resultados" / "instalacao.log"
PACOTES = {"numpy": "numpy", "pandas": "pandas", "scipy": "scipy", "pyarrow": "pyarrow", "yaml": "pyyaml",
           "lightgbm": "lightgbm", "xgboost": "xgboost", "optuna": "optuna", "cma": "cma", "matplotlib": "matplotlib"}


def rodar(cmd, rotulo: str) -> int:
    print(f"  {rotulo} ...", flush=True)
    with open(LOG, "a", encoding="utf-8", errors="replace") as f:
        f.write("\n> " + " ".join(cmd) + "\n")
        f.flush()
        r = subprocess.call(cmd, stdout=f, stderr=subprocess.STDOUT)
    print(f"  {rotulo}: {'ok' if r == 0 else 'FALHOU (detalhes em resultados\\instalacao.log)'}", flush=True)
    return r


def importa(mod: str) -> bool:
    return subprocess.call([sys.executable, "-c", f"import {mod}"], stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL) == 0


def gpu():
    try:
        out = subprocess.check_output(["nvidia-smi", "--query-gpu=name,compute_cap", "--format=csv,noheader"],
                                      text=True, timeout=30)
        nome, cap = out.strip().splitlines()[0].rsplit(",", 1)
        return nome.strip(), float(cap)
    except Exception:  # noqa: BLE001
        return None, None


def main():
    LOG.parent.mkdir(parents=True, exist_ok=True)
    LOG.write_text("", encoding="utf-8")
    py = sys.executable
    nome, cap = gpu()
    if nome is None:
        print("Nenhuma GPU NVIDIA encontrada (nvidia-smi não respondeu). Instalando o PyTorch para CPU.")
        idx = "https://download.pytorch.org/whl/cpu"
    else:
        canal = "cu128" if cap >= 7.5 else "cu126"
        print(f"GPU: {nome} (capacidade {cap}); PyTorch com {canal}")
        idx = f"https://download.pytorch.org/whl/{canal}"
    print("Não feche esta janela: algumas etapas ficam vários minutos sem mostrar nada novo.", flush=True)
    rodar([py, "-m", "pip", "install", "--upgrade", "pip"], "atualizando o pip")
    if rodar([py, "-m", "pip", "install", "torch", "--index-url", idx], "PyTorch (o maior download)") != 0:
        print("Falha ao instalar o PyTorch pelo índice oficial; tentando o PyPI.")
        if rodar([py, "-m", "pip", "install", "torch"], "PyTorch pelo PyPI") != 0:
            return 1
    if rodar([py, "-m", "pip", "install", "-r", str(RAIZ / "requirements_experimentos.txt")],
             "demais pacotes (LightGBM, XGBoost, Optuna, cma, matplotlib, ...)") != 0:
        return 1
    # pacote que ficou pela metade (instalação interrompida): reinstala
    quebrados = [pip for mod, pip in PACOTES.items() if not importa(mod)]
    if quebrados:
        print(f"  pacotes que não importam: {', '.join(quebrados)}; reinstalando", flush=True)
        if rodar([py, "-m", "pip", "install", "--force-reinstall"] + quebrados, "reinstalação") != 0:
            return 1
        ainda = [pip for mod, pip in PACOTES.items() if not importa(mod)]
        if ainda:
            print(f"ERRO: ainda não importam: {', '.join(ainda)}. Veja resultados\\instalacao.log")
            return 1
    code = ("import torch;print('  PyTorch', torch.__version__, '| CUDA disponível:', torch.cuda.is_available(),"
            "'|', torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'sem GPU')")
    subprocess.call([py, "-c", code])
    return 0


if __name__ == "__main__":
    sys.exit(main())
