@echo off
REM Gera CSVs, tabelas LaTeX, figuras, macros e o guia do artigo com as sementes que ja terminaram
REM (pode rodar enquanto os experimentos continuam em outra janela).
REM   Rodada completa: le resultados\SITE\ e grava em saida_artigo\
REM   Teste rapido:    gerar_relatorio.bat --perfil rapido   (le resultados_rapido\ e grava em saida_artigo_rapido\)
REM Para copiar tudo para o projeto LaTeX, acrescente:  --latex ..\artigo2_3sites
setlocal EnableExtensions
cd /d "%~dp0"
title Relatorio - experimentos CCP-Boot-TFT-ICSO-PP
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
if not exist ".venv\Scripts\python.exe" (
  echo Ambiente .venv nao encontrado. Rode primeiro o instalar_experimentos.bat
  pause
  exit /b 1
)
".venv\Scripts\python.exe" executar.py relatorio %*
if errorlevel 1 goto fim
".venv\Scripts\python.exe" executar.py juntar %*
if errorlevel 1 goto fim
".venv\Scripts\python.exe" executar.py artigo %*
if errorlevel 1 goto fim
echo.
echo Pronto: tabelas, figuras, macros e guia em saida_artigo\ (ou saida_artigo_rapido\ com --perfil rapido).
echo Veja o GUIA_ARTIGO.md nessa pasta.
:fim
echo.
pause
