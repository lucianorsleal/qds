@echo off
REM Teste rapido (alguns minutos na GPU): 1 semente, 2 membros, poucas epocas e orcamentos pequenos.
REM Serve so para conferir que tudo roda no seu computador; os numeros NAO servem para o artigo.
REM Os resultados ficam em resultados_rapido\ e saida_artigo_rapido\ (separados dos experimentos completos).
REM Roda os tres sites (YUL, BRA e GEO); para um so: rodar_teste_rapido.bat --site GEO
setlocal EnableExtensions
cd /d "%~dp0"
title Teste rapido - experimentos CCP-Boot-TFT-ICSO-PP
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
if not exist ".venv\Scripts\python.exe" (
  echo Ambiente .venv nao encontrado. Rode primeiro o instalar_experimentos.bat
  pause
  exit /b 1
)
".venv\Scripts\python.exe" executar.py tudo --perfil rapido %*
echo.
echo Fim do teste rapido. Logs em resultados_rapido\SITE\logs\ ; tabelas e figuras de teste em saida_artigo_rapido\
pause
