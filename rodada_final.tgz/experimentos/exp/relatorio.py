"""Métricas por semente, agregação das sementes e CSVs no formato do artigo.

relatorio_site():  resultados/<SITE>/csv/{results,data}/*.csv com as colunas dos CSVs do projeto do artigo
                   (linhas só do site), mais arquivos de detalhe (detalhe/*.csv e meta.json) com o que é
                   preciso para juntar os sites (IS diário para o teste DM, semana de exemplo, pesos do TFT
                   por janela, períodos sem a usina).
juntar():          junta os sites que já têm resultados em saida_artigo/{results,data}/, aplicando Holm
                   sobre todos os pares site–horizonte e as médias entre sites das tabelas agregadas.
As tabelas LaTeX, os macros, as figuras e o guia saem desses CSVs pelo exp/artigo.py (comando 'artigo').
"""

from __future__ import annotations

import logging
from pathlib import Path

import numpy as np
import pandas as pd

from . import dados as dd
from . import metricas as mt
from . import otimizadores as op
from .config import HORIZONTES, METODOS, ORDEM_SITES

log = logging.getLogger("exp")

# ablação da v3: B1–B3 (TFT, como na v2), B4 (+ escalas de cada lado), B4h (+ ICSO-PP nas cabeças, artigo 1),
# B5 = proposto (+ LightGBM com peso por janela) e as variantes do proposto B5a–B5g (B5e: Boot-LSTM do artigo 1)
VARIANTES_ABL = ["B1", "B2", "B3", "B4", "B4h", "B5", "B5a", "B5b", "B5c", "B5d", "B5e", "B5f", "B5g"]
CAMADAS = ["L1", "L2", "L3", "L4", "L5", "L6", "L7"]
ARQ_DE = {"B5": "PROP", "L6": "PROP", "L7": "B5b", "B5e": "B4e"}
OTIMIZADORES = ["Adam", "ICSO-PP", "CMA-ES", "L-SHADE", "ICSO", "CSO", "PSO", "TPE"]
CENARIOS = ["S0", "S1", "S2", "S3", "S4", "S5"]


def _npz(caminho: Path):
    if not caminho.exists():
        return None
    with np.load(caminho) as z:
        return {k: z[k] for k in z.files}


def _sementes(exp) -> list:
    return sorted(int(p.name[1:]) for p in exp.pastas["prev"].glob("s*") if p.name[1:].isdigit())


def _persistencia(exp) -> np.ndarray:
    """Persistência inteligente (Seção IV): k da última hora observada (intradiário) ou o k mais recente da
    mesma hora (DA), vezes P̃cs da hora-alvo."""
    s = exp.site
    P = exp.P.iloc[exp.te]
    i, j, t = P["i"].to_numpy(), P["j"].to_numpy(), P["t"].to_numpy()
    k_ult = pd.Series(np.where(s.diurno, s.k_fill, np.nan)).ffill().fillna(0.0).to_numpy()
    dmin = np.ceil((j + 1) / 24.0).astype(int)
    k_da = s.k_fill[np.maximum(t - 24 * dmin, 0)]
    k = np.where(P["h"].to_numpy() == 3, k_da, k_ult[i - 1])
    return np.clip(k * s.pcs[t], 0, s.y_max)


def metricas_semente(exp, seed: int) -> dict:
    alpha = exp.alpha
    P = exp.P.iloc[exp.te].reset_index(drop=True)
    y = exp.y[exp.te]
    hte = exp.h[exp.te]
    ter = _npz(exp.pasta(seed) / "tercis.npz")
    terc = ter["tercil_te"] if ter is not None else None
    sp = _persistencia(exp)
    linhas, grupos, diarios = [], [], []
    nomes = METODOS + [ARQ_DE.get(v, v) for v in VARIANTES_ABL] + [ARQ_DE.get(c, c) for c in CAMADAS]
    for nome in dict.fromkeys(nomes):
        d = _npz(exp.arq_prev(None if nome == "CHPeEn" else seed, nome))
        if d is None:
            continue
        for h, hn in enumerate(HORIZONTES):
            m = (hte == h) & np.isfinite(d["L"])
            if m.sum() == 0:
                continue
            res, cob, isc = mt.resumo_intervalos(d["L"][m], d["U"][m], y[m], alpha)
            yh = d["yhat"][m]
            r = {"metodo": nome, "horizon": hn, **res, "RMSE": mt.rmse(yh, y[m]),
                 "RMSE_SP": mt.rmse(sp[m], y[m]), "n": int(m.sum())}
            r["FSS"] = 1.0 - r["RMSE"] / r["RMSE_SP"]
            if "Q" in d and np.isfinite(d["Q"][m]).all():
                r["CRPS"] = 100.0 * float(mt.crps_quantis(d["Q"][m], y[m]).mean())
            tab = mt.coberturas_grupo(cob, P[m], None if terc is None else terc[m])
            r.update(mt.wgc_ccd(tab))
            linhas.append(r)
            tab.insert(0, "horizon", hn)
            tab.insert(0, "metodo", nome)
            grupos.append(tab)
            dia = mt.is_diario(isc, P["data"].to_numpy()[m])
            diarios.append(pd.DataFrame({"metodo": nome, "horizon": hn, "data": dia.index, "IS": dia.to_numpy()}))
    out = {"metricas": pd.DataFrame(linhas), "grupos": pd.concat(grupos) if grupos else pd.DataFrame(),
           "diario": pd.concat(diarios) if diarios else pd.DataFrame()}
    out["metricas"]["seed"] = seed
    out["grupos"]["seed"] = seed
    out["diario"]["seed"] = seed
    return out


def _celulas_heat(exp, d, terc=None):
    """Cobertura DA por célula regime × hora."""
    P = exp.P.iloc[exp.te].reset_index(drop=True)
    y = exp.y[exp.te]
    m = (exp.h[exp.te] == 3) & np.isfinite(d["L"])
    cob = (y >= d["L"]) & (y <= d["U"])
    linhas = []
    for r in range(3):
        for hh in range(6, 19):
            c = m & (P["regime"].to_numpy() == r) & (P["hora"].to_numpy() == hh)
            linhas.append({"hour": hh, "reg": r, "cov": 100.0 * cob[c].mean() if c.any() else np.nan, "n": int(c.sum())})
    return pd.DataFrame(linhas)


def _multiplicadores(exp, d):
    """ψ_r = E[q+ | regime r] / E[q+] no DA, para janelas de inverno e de verão locais."""
    P = exp.P.iloc[exp.te].reset_index(drop=True)
    m = (exp.h[exp.te] == 3) & np.isfinite(d.get("qh", np.full(len(P), np.nan)))
    lat = float(exp.site.cfg_site["lat"])
    meses = P["mes"].to_numpy()
    doy15 = np.array([pd.Timestamp(2023, int(mm), 15).dayofyear for mm in meses])
    est = dd.estacoes(doy15, lat)
    out = {}
    for nome, e in (("Winter", 0), ("Summer", 2)):
        s = m & (est == e)
        q = d["qh"][s]
        reg = P["regime"].to_numpy()[s]
        base = np.mean(q) if q.size else np.nan
        out[nome] = [float(np.mean(q[reg == r]) / base) if (reg == r).any() and base > 0 else np.nan for r in range(3)]
    return out


class SemResultados(Exception):
    """O site ainda não tem previsões prontas para o relatório."""


def relatorio_site(exp) -> Path:
    sementes = _sementes(exp)
    if not sementes:
        raise SemResultados("nenhuma previsão encontrada; rode os experimentos antes do relatório")
    cod = exp.codigo
    pasta = exp.pastas["csv"]
    (pasta / "results").mkdir(parents=True, exist_ok=True)
    (pasta / "data").mkdir(parents=True, exist_ok=True)
    (pasta / "detalhe").mkdir(parents=True, exist_ok=True)
    sem_prop = [s for s in sementes if not (exp.pasta(s) / "tercis.npz").exists()]
    if sem_prop:
        # sem o proposto não há os tercis de σ̃, e o WGC dessas sementes usaria 16 grupos em vez de 19
        log.warning("  sementes sem a etapa 'proposto' ficam fora do relatório: %s", sem_prop)
        sementes = [s for s in sementes if s not in sem_prop]
        if not sementes:
            raise SemResultados("nenhuma semente com a etapa 'proposto' pronta; rode os experimentos antes do relatório")
    log.info("== Relatório de %s (%d semente%s: %s) ==", cod, len(sementes), "" if len(sementes) == 1 else "s", sementes)
    ms = [metricas_semente(exp, s) for s in sementes]
    M = pd.concat([m["metricas"] for m in ms], ignore_index=True)
    G = pd.concat([m["grupos"] for m in ms], ignore_index=True)
    D = pd.concat([m["diario"] for m in ms], ignore_index=True)
    M.to_csv(pasta / "detalhe" / "metricas_por_semente.csv", index=False)
    D.to_csv(pasta / "detalhe" / "is_diario_por_semente.csv", index=False)

    # CRPSS relativo ao CH-PeEn, por semente e horizonte
    ref = M[M["metodo"] == "CHPeEn"].set_index("horizon")["CRPS"]
    M["CRPSS"] = 1.0 - M["CRPS"] / M["horizon"].map(ref.groupby(level=0).mean())

    # ---------------------------------------------------------------- main_metrics
    cols = ["RMSE", "FSS", "PICP", "WGC", "WGC_sky", "CCD", "PINAW", "IS", "CRPS", "CRPSS"]
    main = M[M["metodo"].isin(METODOS)].groupby(["metodo", "horizon"])[cols].mean()
    main["IS_sd"] = M[M["metodo"].isin(METODOS)].groupby(["metodo", "horizon"])["IS"].std(ddof=1).fillna(0.0)
    main = main.reset_index().rename(columns={"metodo": "method"})
    main.insert(0, "site", cod)
    main["method"] = pd.Categorical(main["method"], METODOS)
    main["horizon"] = pd.Categorical(main["horizon"], HORIZONTES)
    main = main.sort_values(["horizon", "method"])[["site", "horizon", "method", "RMSE", "FSS", "PICP", "WGC", "WGC_sky",
                                                     "CCD", "PINAW", "IS", "IS_sd", "CRPS", "CRPSS"]]
    faltam = [mm for mm in METODOS if mm not in set(main["method"].astype(str))]
    if faltam:
        # linhas vazias mantêm a estrutura dos CSVs; nas tabelas do artigo esses métodos saem como '--'
        log.warning("  ATENÇÃO: métodos sem resultado: %s. As linhas deles ficam vazias no main_metrics.csv; nas "
                    "tabelas do artigo saem como '--' e ficam fora dos postos de Friedman (Fig. 12) até rodarem "
                    "(rodar_experimentos.bat --etapas ...).", ", ".join(faltam))
        vazias = pd.DataFrame([{"site": cod, "horizon": hn, "method": mm} for mm in faltam for hn in HORIZONTES])
        main = pd.concat([main.astype({"method": str, "horizon": str}), vazias], ignore_index=True)
        main["method"] = pd.Categorical(main["method"], METODOS)
        main["horizon"] = pd.Categorical(main["horizon"], HORIZONTES)
        main = main.sort_values(["horizon", "method"])
    main.to_csv(pasta / "results" / "main_metrics.csv", index=False, float_format="%.4f")

    # ---------------------------------------------------------------- group_coverage
    g = G[G["metodo"].isin(METODOS)].groupby(["metodo", "horizon", "family", "group"], sort=False).agg(
        share=("share", "mean"), PICP=("PICP", "mean")).reset_index().rename(columns={"metodo": "method"})
    g.insert(0, "site", cod)
    g.to_csv(pasta / "results" / "group_coverage.csv", index=False, float_format="%.4f")

    # ---------------------------------------------------------------- DM e fusões
    Dm = D.groupby(["metodo", "horizon", "data"])["IS"].mean().reset_index()
    diag = []
    for hn in HORIZONTES:
        def serie(nome):
            return Dm[(Dm["metodo"] == nome) & (Dm["horizon"] == hn)].set_index("data")["IS"]
        prop = serie("PROP")
        merged = []
        for s in sementes:
            arq = exp.arq_prev(s, "PROP").with_suffix(".json")
            if arq.exists():
                import json

                mg = json.loads(arq.read_text(encoding="utf-8"))["merged"]
                hi = HORIZONTES.index(hn)
                v = [x[2] for x in mg if x[0] == hi]
                if v:
                    merged.append(100.0 * np.mean(v))
        diag.append({"site": cod, "horizon": hn, "dm_raw_MVP": mt.dm_unilateral(serie("MVP"), prop) if len(prop) else np.nan,
                     "dm_raw_PRIOR": mt.dm_unilateral(serie("PRIOR"), prop) if len(prop) else np.nan,
                     "merged_pct": float(np.mean(merged)) if merged else np.nan})
    diag = pd.DataFrame(diag)
    diag.to_csv(pasta / "detalhe" / "dm_bruto.csv", index=False)
    sd = diag.assign(dm_p_vs_MVP=mt.holm(diag["dm_raw_MVP"]), dm_p_vs_PRIOR=mt.holm(diag["dm_raw_PRIOR"]))
    sd[["site", "horizon", "dm_p_vs_MVP", "dm_p_vs_PRIOR", "merged_pct"]].to_csv(
        pasta / "results" / "site_diagnostics.csv", index=False, float_format="%.4f")

    # ---------------------------------------------------------------- camadas e ablação
    def tabela(lista, horizontes, colunas):
        linhas = []
        for v in lista:
            fonte = ARQ_DE.get(v, v)
            for hn in horizontes:
                sub = M[(M["metodo"] == fonte) & (M["horizon"] == hn)]
                if len(sub):
                    linhas.append({"_v": v, "horizon": hn, **sub[colunas].mean().to_dict()})
        return pd.DataFrame(linhas)

    lay = tabela(CAMADAS, ["1h", "DA"], ["PICP", "WGC", "WGC_sky", "CCD", "IS", "PINAW"]).rename(columns={"_v": "layer"})
    lay.to_csv(pasta / "results" / "calib_layers.csv", index=False, float_format="%.4f")
    abl = tabela(VARIANTES_ABL, ["1h", "6h", "DA"], ["IS", "PICP", "WGC", "RMSE"]).rename(columns={"_v": "variant"})
    abl.to_csv(pasta / "results" / "ablation.csv", index=False, float_format="%.4f")

    # ---------------------------------------------------------------- pesos do TFT por janela (figura nova da v3)
    pw = _pesos(exp, sementes)
    if not pw.empty:
        pw.to_csv(pasta / "data" / "fig_weights.csv", index=False, float_format="%.4f")

    # ---------------------------------------------------------------- estresse
    st = _estresse(exp, sementes, M)
    st.to_csv(pasta / "results" / "stress.csv", index=False, float_format="%.4f")

    # ---------------------------------------------------------------- custo e tamanhos de grupo
    _custo(exp, sementes).to_csv(pasta / "results" / "cost.csv", index=False, float_format="%.4f")
    _tamanhos(exp, sementes).to_csv(pasta / "results" / "group_sizes.csv", index=False)

    # ---------------------------------------------------------------- figuras
    heat = {}
    for nome, fonte in (("mondrian", "L3"), ("cc", "PROP")):
        tabs = [_celulas_heat(exp, d) for s in sementes if (d := _npz(exp.arq_prev(s, fonte))) is not None]
        if tabs:
            h = pd.concat(tabs).groupby(["reg", "hour"], sort=True)["cov"].mean().reset_index()[["hour", "reg", "cov"]]
            heat[nome] = h
            h.to_csv(pasta / "data" / f"fig_heat_{nome}.csv", index=False, float_format="%.3f")
    _figuras_tft(exp, sementes, pasta / "data")
    mult = [_multiplicadores(exp, d) for s in sementes if (d := _npz(exp.arq_prev(s, "PROP"))) is not None]
    if mult:
        w = np.nanmean([m["Winter"] for m in mult], axis=0)
        su = np.nanmean([m["Summer"] for m in mult], axis=0)
        pd.DataFrame({"regime": [0, 1, 2], "label": dd.REGIMES, "Winter": w, "Summer": su}).to_csv(
            pasta / "data" / "fig_cc_multipliers.csv", index=False, float_format="%.3f")
    ex = _semana_exemplo(exp, sementes[0])
    if ex is not None:
        ex.to_csv(pasta / "data" / "fig_example.csv", index=False, float_format="%.5f")
    _meta(exp, sementes, pasta / "detalhe" / "meta.json")
    log.info("  CSVs de %s em %s", cod, pasta)
    return pasta


def _meta(exp, sementes, arq: Path) -> None:
    """Informações que as tabelas e o guia do artigo usam (sementes, ȳ, dias sem a usina, pares de teste)."""
    import json

    def iso(o):
        return str(pd.Timestamp.fromordinal(int(o)).date())

    ind = getattr(exp.site, "indisp", None)
    ind = ind if ind is not None else np.zeros((0, 3))
    meta = {"site": exp.codigo, "sementes": [int(s) for s in sementes], "n_sementes": len(sementes),
            "membros": int(exp.cfg["ensemble"]["membros"]), "perfil": exp.cfg.get("_perfil"),
            "y_max": float(exp.ymax),
            "pares_teste": {hn: int((exp.h[exp.te] == h).sum()) for h, hn in enumerate(HORIZONTES)},
            "horas_teste_DA": int((exp.h[exp.te] == 3).sum()),
            "indisp": [[iso(a), iso(b), int(n)] for a, b, n in np.asarray(ind, dtype=np.int64)],
            "indisp_dias": int(np.asarray(ind, dtype=np.int64)[:, 2].sum()) if len(ind) else 0}
    arq.write_text(json.dumps(meta, indent=1, ensure_ascii=False), encoding="utf-8")


def _semana_exemplo(exp, seed: int):
    """Uma semana de teste do DA para a figura de exemplo do artigo: entre as janelas de 7 dias seguidos
    completos, a que tem mais regimes diários do NWP diferentes e, no empate, a maior variação do índice de
    céu claro diário. Janelas com um dia de saída quase nula sob previsão de céu claro (parada ou limitação
    da usina, não tempo) ficam de fora. Devolve y, o intervalo do proposto e o do PRIOR."""
    dp, dr = _npz(exp.arq_prev(seed, "PROP")), _npz(exp.arq_prev(seed, "PRIOR"))
    if dp is None:
        return None
    P = exp.P.iloc[exp.te].reset_index(drop=True)
    m = (exp.h[exp.te] == 3) & np.isfinite(dp["L"])
    if not m.any():
        return None
    t = P["t"].to_numpy()[m]
    df = pd.DataFrame({"t": t, "data_ord": P["data"].to_numpy()[m], "hora": exp.site.hora_lst[t].astype(int),
                       "y": exp.y[exp.te][m], "pcs": exp.pcs[exp.te][m], "yhat": dp["yhat"][m], "L": dp["L"][m],
                       "U": dp["U"][m], "regime": P["regime"].to_numpy()[m]})
    if dr is not None:
        df["L_prior"], df["U_prior"] = dr["L"][m], dr["U"][m]
    g = df.groupby("data_ord").agg(ys=("y", "sum"), ps=("pcs", "sum"), n=("y", "size"),
                                   reg=("regime", lambda r: int(pd.Series(r).mode().iloc[0])))
    g["k"] = g["ys"] / g["ps"].clip(lower=1e-6)
    suspeito = (g["k"] < 0.15) & (g["reg"] == 0)       # saída quase nula com céu claro previsto
    completos = set(g.index[g["n"] >= 6].tolist())
    melhor, nota = None, (-1, -1.0)
    for filtrar in (True, False):                      # sem janela limpa, aceita dias suspeitos
        for d0 in sorted(completos):
            janela = [d0 + i for i in range(7)]
            if not all(d in completos for d in janela) or (filtrar and bool(suspeito.loc[janela].any())):
                continue
            n_reg = int(g.loc[janela, "reg"].nunique())
            s_ = (n_reg, float(g.loc[janela, "k"].std()))
            if s_ > nota:
                melhor, nota = janela, s_
        if melhor is not None:
            break
    if melhor is None:
        return None
    sel = df[df["data_ord"].isin(melhor)].copy()
    sel.insert(0, "site", exp.codigo)
    sel.insert(1, "data", [str(pd.Timestamp.fromordinal(int(o)).date()) for o in sel["data_ord"]])
    return sel.drop(columns=["t", "data_ord", "pcs"])


def _otimizadores_detalhe(exp, sementes, M):
    linhas, curvas = [], []
    da = M[M["horizon"] == "DA"]
    for s in sementes:
        ic = _npz(exp.pasta(s) / "icso.npz")
        prop = da[(da["metodo"] == "PROP") & (da["seed"] == s)]
        if ic is not None and len(prop):
            linhas.append({"seed": s, "optimizer": "ICSO-PP", "IS": float(prop["IS"].iloc[0]), "WGC": float(prop["WGC"].iloc[0]),
                           "Fval": float(ic["F"][0]), "evals": int(ic["avaliacoes"][0]), "time_min": float(ic["seg"][0]) / 60})
            curvas.append(pd.DataFrame({"seed": s, "optimizer": "ICSO-PP", "generation": np.arange(51),
                                        "F": op.curva_geracoes(ic["hist"])}))
        for nome in OTIMIZADORES:
            if nome == "ICSO-PP":
                continue
            d = _npz(exp.arq_prev(s, f"OPT_{nome}"))
            if d is None:
                continue
            m = (exp.h[exp.te] == 3) & np.isfinite(d["L"])
            res, cob, _ = mt.resumo_intervalos(d["L"][m], d["U"][m], exp.y[exp.te][m], exp.alpha)
            ter = _npz(exp.pasta(s) / "tercis.npz")
            tab = mt.coberturas_grupo(cob, exp.P.iloc[exp.te].reset_index(drop=True)[m],
                                      None if ter is None else ter["tercil_te"][m])
            linhas.append({"seed": s, "optimizer": nome, "IS": res["IS"], "WGC": mt.wgc_ccd(tab)["WGC"], "Fval": float(d["F"][0]),
                           "evals": int(d["avaliacoes"][0]), "time_min": float(d["seg"][0]) / 60})
            if nome != "Adam":
                curvas.append(pd.DataFrame({"seed": s, "optimizer": nome, "generation": np.arange(51),
                                            "F": op.curva_geracoes(d["hist"])}))
    det = pd.DataFrame(linhas)
    det.insert(0, "site", exp.codigo)
    cur = pd.concat(curvas, ignore_index=True) if curvas else pd.DataFrame(columns=["seed", "optimizer", "generation", "F"])
    cur.insert(0, "site", exp.codigo)
    return det, cur


def _tabela_otimizadores(det: pd.DataFrame) -> pd.DataFrame:
    if det.empty:
        return pd.DataFrame(columns=["optimizer", "IS_mean", "IS_sd", "WGC_mean", "WGC_sd", "Fval_mean", "Fval_sd",
                                     "p_wilcoxon", "evals", "time_min"])
    chave = ["site", "seed"]
    ref = det[det["optimizer"] == "ICSO-PP"].set_index(chave)["IS"]
    linhas = []
    for o in OTIMIZADORES:
        sub = det[det["optimizer"] == o]
        if sub.empty:
            continue
        par = sub.set_index(chave)["IS"].reindex(ref.index)
        p = np.nan if o == "ICSO-PP" else mt.wilcoxon(par.to_numpy(), ref.to_numpy())
        linhas.append({"optimizer": o, "IS_mean": sub["IS"].mean(), "IS_sd": sub["IS"].std(ddof=1) if len(sub) > 1 else 0.0,
                       "WGC_mean": sub["WGC"].mean(), "WGC_sd": sub["WGC"].std(ddof=1) if len(sub) > 1 else 0.0,
                       "Fval_mean": sub["Fval"].mean(), "Fval_sd": sub["Fval"].std(ddof=1) if len(sub) > 1 else 0.0,
                       "p_wilcoxon": p, "evals": int(round(sub["evals"].mean())), "time_min": sub["time_min"].mean()})
    return pd.DataFrame(linhas)


def _figura_convergencia(curvas: pd.DataFrame) -> pd.DataFrame:
    out = pd.DataFrame({"generation": np.arange(51)})
    for o, col in (("ICSO-PP", "ICSOPP"), ("CMA-ES", "CMAES"), ("L-SHADE", "LSHADE"), ("PSO", "PSO"), ("TPE", "TPE")):
        sub = curvas[curvas["optimizer"] == o]
        if sub.empty:
            out[col] = out[col + "_lo"] = out[col + "_hi"] = np.nan
            continue
        g = sub.groupby("generation")["F"]
        mu, sd = g.mean().reindex(out["generation"]).to_numpy(), g.std(ddof=0).reindex(out["generation"]).fillna(0).to_numpy()
        out[col], out[col + "_lo"], out[col + "_hi"] = mu, mu - sd, mu + sd
    return out


def _estresse(exp, sementes, M):
    linhas = []
    da = M[M["horizon"] == "DA"]
    y = exp.y[exp.te]
    m_da = exp.h[exp.te] == 3
    Pte = exp.P.iloc[exp.te].reset_index(drop=True)
    for s in sementes:
        for met in ("PRIOR", "PROP"):
            r0 = da[(da["metodo"] == met) & (da["seed"] == s)]
            if len(r0):
                linhas.append({"seed": s, "scenario": "S0", "method": met, "PICP": float(r0["PICP"].iloc[0]),
                               "WGC": float(r0["WGC"].iloc[0]), "IS": float(r0["IS"].iloc[0])})
            for c in CENARIOS[1:]:
                d = _npz(exp.arq_prev(s, f"STRESS_{c}_{met}"))
                if d is None:
                    continue
                m = m_da & np.isfinite(d["L"])
                res, cob, _ = mt.resumo_intervalos(d["L"][m], d["U"][m], y[m], exp.alpha)
                Pm = Pte[m].copy()
                Pm["regime"] = d["regime_te"][m]
                tab = mt.coberturas_grupo(cob, Pm, d["tercil_te"][m])
                linhas.append({"seed": s, "scenario": c, "method": met, "PICP": res["PICP"], "WGC": mt.wgc_ccd(tab)["WGC"],
                               "IS": res["IS"]})
    t = pd.DataFrame(linhas)
    if t.empty:
        return pd.DataFrame(columns=["scenario", "method", "PICP", "WGC", "IS"])
    return t.groupby(["scenario", "method"])[["PICP", "WGC", "IS"]].mean().reset_index()


def _custo(exp, sementes):
    """Tempos medidos: treino dos 10 TFTs, do LightGBM (84 modelos) e escolha dos pesos (min); calibração por
    mês (s, todos os horizontes) e inferência dos TFTs (s por dia de previsões)."""
    ens, gbm, pes, calib, inf, ntr = [], [], [], [], [], []
    for s in sementes:
        a = _npz(exp.pasta(s) / "tft_saidas.npz")
        if a is not None:
            ens.append(float(a["t_treino_min"][0]))
            inf.append(float(a["t_inf_s_dia"][0]))
            ntr.append(int(a["n_treino"][0]))
        b = _npz(exp.pasta(s) / "lgbm_quantis.npz")
        if b is not None and "t_min" in b:
            gbm.append(float(b["t_min"][0]))
        c = _npz(exp.pasta(s) / "hibrido.npz")
        if c is not None and "t_min" in c:
            pes.append(float(c["t_min"][0]))
        j = exp.arq_prev(s, "PROP").with_suffix(".json")
        if j.exists():
            import json

            calib.append(json.loads(j.read_text(encoding="utf-8")).get("t_calib_mes_s", np.nan))
    f = lambda v: float(np.nanmean(v)) if len(v) else np.nan  # noqa: E731
    return pd.DataFrame([{"site": exp.codigo, "n_train": int(np.mean(ntr)) if ntr else 0, "ensemble_min": f(ens),
                          "lgbm_min": f(gbm), "weights_min": f(pes), "calib_s": f(calib), "infer_s": f(inf)}])


def _pesos(exp, sementes) -> pd.DataFrame:
    """Peso do TFT escolhido em cada janela (horizonte × mês de teste), médio entre as sementes."""
    import json

    linhas = []
    for s in sementes:
        j = exp.arq_prev(s, "PROP").with_suffix(".json")
        if not j.exists():
            continue
        for h, m, w in json.loads(j.read_text(encoding="utf-8")).get("pesos", []):
            linhas.append({"seed": s, "horizon": HORIZONTES[int(h)], "month": int(m), "w": float(w)})
    if not linhas:
        return pd.DataFrame()
    d = pd.DataFrame(linhas).groupby(["horizon", "month"], sort=False)["w"].agg(["mean", "std"]).reset_index()
    d.insert(0, "site", exp.codigo)
    return d.rename(columns={"mean": "w", "std": "w_sd"}).fillna({"w_sd": 0.0})


def _tamanhos(exp, sementes):
    P = exp.P.iloc[exp.te].reset_index(drop=True)
    m = exp.h[exp.te] == 3
    linhas = [{"site": exp.codigo, "family": "hour", "group": f"{hh:02d}", "n_test": int((P["hora"][m] == hh).sum())}
              for hh in range(6, 19)]
    for r, nome in enumerate(["clear", "partly", "overcast"]):
        linhas.append({"site": exp.codigo, "family": "regime", "group": nome, "n_test": int((P["regime"][m] == r).sum())})
    ters = [d["tercil_te"] for s in sementes if (d := _npz(exp.pasta(s) / "tercis.npz")) is not None]
    for k, nome in enumerate(["low", "mid", "high"]):
        n = int(round(np.mean([(t[m] == k).sum() for t in ters]))) if ters else int(m.sum() // 3)
        linhas.append({"site": exp.codigo, "family": "tertile", "group": nome, "n_test": n})
    return pd.DataFrame(linhas)


def _figuras_tft(exp, sementes, pasta):
    v1, vd, att, n_att = [], [], [], []
    for s in sementes:
        if not (exp.pasta(s) / "tft_saidas.npz").exists():
            continue
        a = exp.tft_ensemble(s)     # lê o cache; refaz os pesos da Fig. 9 se vierem de uma versão anterior
        v1.append(a["vsn_1h"])
        vd.append(a["vsn_DA"])
        att.append(a["att_DA"] * a["att_n"][:, None])
        n_att.append(a["att_n"])
    if not v1:
        return
    idx = ORDEM_SITES.index(exp.codigo) if exp.codigo in ORDEM_SITES else 0
    for nome, v in (("1h", v1), ("DA", vd)):
        w = np.mean(v, axis=0)
        w = 100.0 * w / w.sum()
        pd.DataFrame({"site": idx, "code": exp.codigo, "feat": np.arange(9), "w": w}).to_csv(
            pasta / f"fig_vsn_{nome}.csv", index=False, float_format="%.2f")
    A = np.sum(att, axis=0) / np.maximum(np.sum(n_att, axis=0)[:, None], 1)
    pd.DataFrame({"lag": np.arange(-dd.ENC, 0), "Clear": A[0], "Overcast": A[2]}).to_csv(
        pasta / "fig_attention.csv", index=False, float_format="%.5f")


# ============================================================================ juntar os sites
def juntar(cfg: dict, destino: Path | None = None, sites=None) -> Path:
    base = cfg["pasta_saida"]
    destino = Path(destino) if destino else cfg["_raiz"] / "saida_artigo"
    (destino / "results").mkdir(parents=True, exist_ok=True)
    (destino / "data").mkdir(parents=True, exist_ok=True)
    # só pastas de sites do config da coleta (ignora resultados\GEO_antigo_<data> e afins)
    validos = set((cfg.get("_coleta") or {}).get("sites", {}))
    pastas = {p.name: p / "csv" for p in sorted(base.iterdir())
              if p.name in validos and (p / "csv" / "results" / "main_metrics.csv").exists()}
    if sites:
        pastas = {k: v for k, v in pastas.items() if k in sites}
    ordem = [s for s in ORDEM_SITES if s in pastas] + [s for s in pastas if s not in ORDEM_SITES]
    if not ordem:
        raise SystemExit(f"nenhum site com relatório em {base}; rode 'executar.py relatorio' antes")
    log.info("== Juntando %d site(s): %s ==", len(ordem), ", ".join(ordem))

    def ler(sub, nome):
        partes = [pd.read_csv(pastas[s] / sub / nome) for s in ordem if (pastas[s] / sub / nome).exists()]
        return pd.concat(partes, ignore_index=True) if partes else pd.DataFrame()

    R, Dd = destino / "results", destino / "data"
    main = ler("results", "main_metrics.csv")
    num = [c for c in main.columns if c not in ("site", "horizon", "method")]
    vazios = main[main[num].isna().all(axis=1)] if num else main.iloc[:0]
    if len(vazios):
        falta = vazios.groupby("site")["method"].unique()
        log.warning("  ATENÇÃO: sem resultado em %s. Nas tabelas do artigo esses métodos saem como '--' e ficam fora "
                    "dos postos de Friedman até rodarem (rodar_experimentos.bat --etapas ...).",
                    "; ".join(f"{s}: {', '.join(map(str, m))}" for s, m in falta.items()))
    main.to_csv(R / "main_metrics.csv", index=False, float_format="%.4f")
    ler("results", "group_coverage.csv").to_csv(R / "group_coverage.csv", index=False, float_format="%.4f")
    dm = ler("detalhe", "dm_bruto.csv")
    if not dm.empty:
        dm["dm_p_vs_MVP"] = mt.holm(dm["dm_raw_MVP"])
        dm["dm_p_vs_PRIOR"] = mt.holm(dm["dm_raw_PRIOR"])
        dm[["site", "horizon", "dm_p_vs_MVP", "dm_p_vs_PRIOR", "merged_pct"]].to_csv(
            R / "site_diagnostics.csv", index=False, float_format="%.4f")
    for nome, chave in (("calib_layers.csv", ["layer", "horizon"]), ("ablation.csv", ["variant", "horizon"]),
                        ("stress.csv", ["scenario", "method"])):
        t = ler("results", nome)
        if not t.empty:
            t.groupby(chave, sort=False).mean(numeric_only=True).reset_index().to_csv(R / nome, index=False,
                                                                                      float_format="%.4f")
    t = ler("data", "fig_weights.csv")
    if not t.empty:
        t.to_csv(Dd / "fig_weights.csv", index=False, float_format="%.4f")
    ler("results", "cost.csv").to_csv(R / "cost.csv", index=False, float_format="%.4f")
    ler("results", "group_sizes.csv").to_csv(R / "group_sizes.csv", index=False)
    for nome in ("fig_heat_mondrian.csv", "fig_heat_cc.csv"):
        t = ler("data", nome)
        if not t.empty:
            t.groupby(["reg", "hour"], sort=True)["cov"].mean().reset_index()[["hour", "reg", "cov"]].to_csv(
                Dd / nome, index=False, float_format="%.3f")
    for nome in ("fig_vsn_1h.csv", "fig_vsn_DA.csv"):
        t = ler("data", nome)
        if not t.empty:
            t["site"] = t["code"].map({s: i for i, s in enumerate(ordem)})
            t.sort_values(["feat", "site"]).to_csv(Dd / nome, index=False, float_format="%.2f")
    t = ler("data", "fig_attention.csv")
    if not t.empty:
        t.groupby("lag", sort=True)[["Clear", "Overcast"]].mean().reset_index().to_csv(Dd / "fig_attention.csv",
                                                                                     index=False, float_format="%.5f")
    t = ler("data", "fig_cc_multipliers.csv")
    if not t.empty:
        t.groupby(["regime", "label"], sort=True)[["Winter", "Summer"]].mean().reset_index().to_csv(
            Dd / "fig_cc_multipliers.csv", index=False, float_format="%.3f")
    t = ler("data", "fig_example.csv")
    if not t.empty:
        t.to_csv(Dd / "fig_example.csv", index=False, float_format="%.5f")
    import json

    metas = {}
    for s in ordem:
        arq = pastas[s] / "detalhe" / "meta.json"
        if arq.exists():
            metas[s] = json.loads(arq.read_text(encoding="utf-8"))
    (destino / "meta.json").write_text(json.dumps({"sites": ordem, "por_site": metas}, indent=1, ensure_ascii=False),
                                       encoding="utf-8")
    log.info("  CSVs do artigo em %s (o comando 'artigo' gera deles as tabelas, macros, figuras e o guia)", destino)
    return destino
