"""Redes em PyTorch puro: o TFT do Estágio 1 (Lim et al., 2021) e o LSTM do artigo 1 (baseline PRIOR).

TFT (Seção II-A e III-C do artigo): GRNs com GLU, redes de seleção de variáveis (VSN) separadas para o
codificador (passado observado + conhecidas) e o decodificador (futuras conhecidas + conhecidas), LSTM
codificador-decodificador de uma camada, enriquecimento, atenção multi-cabeça interpretável (projeção V
compartilhada, média das cabeças, máscara causal), GRN por posição, porta final com a saída do LSTM e
cabeças lineares de quantis. A representação penúltima ψ̃ (dimensão H = 32) é o que o Estágio 3 usa: a
cabeça mediana é o par (w, b) de uma linha da camada de saída.

As VSNs aplicam um GRN próprio a cada variável; aqui isso é feito em lote (pesos com uma dimensão de
variável e einsum), o que equivale a V GRNs independentes e é bem mais rápido na GPU.
"""

from __future__ import annotations

import math

import torch
import torch.nn as nn
import torch.nn.functional as F


class GLU(nn.Module):
    def __init__(self, d_in: int, d_out: int):
        super().__init__()
        self.fc = nn.Linear(d_in, 2 * d_out)

    def forward(self, x):
        a, b = self.fc(x).chunk(2, dim=-1)
        return torch.sigmoid(a) * b


class GRN(nn.Module):
    """GRN(a, c) = LayerNorm(skip(a) + GLU(W1 ELU(W2 a + W3 c + b2) + b1)), dropout antes do GLU."""

    def __init__(self, d_in: int, d_hid: int, d_out: int, dropout: float = 0.1, d_ctx: int | None = None):
        super().__init__()
        self.skip = nn.Linear(d_in, d_out) if d_in != d_out else None
        self.fc2 = nn.Linear(d_in, d_hid)
        self.ctx = nn.Linear(d_ctx, d_hid, bias=False) if d_ctx else None
        self.fc1 = nn.Linear(d_hid, d_hid)
        self.drop = nn.Dropout(dropout)
        self.glu = GLU(d_hid, d_out)
        self.ln = nn.LayerNorm(d_out)

    def forward(self, a, c=None):
        res = a if self.skip is None else self.skip(a)
        h = self.fc2(a)
        if self.ctx is not None and c is not None:
            h = h + self.ctx(c)
        h = self.fc1(F.elu(h))
        return self.ln(res + self.glu(self.drop(h)))


class GRNsVariaveis(nn.Module):
    """V GRNs independentes (entrada escalar → incorporação linear d → GRN d→d), em lote."""

    def __init__(self, n_var: int, d: int, dropout: float):
        super().__init__()
        self.n_var, self.d = n_var, d

        def p(*shape, escala):
            return nn.Parameter(torch.randn(*shape) * escala)

        self.emb_w, self.emb_b = p(n_var, d, escala=1.0), nn.Parameter(torch.zeros(n_var, d))
        s = 1.0 / math.sqrt(d)
        self.w2, self.b2 = p(n_var, d, d, escala=s), nn.Parameter(torch.zeros(n_var, d))
        self.w1, self.b1 = p(n_var, d, d, escala=s), nn.Parameter(torch.zeros(n_var, d))
        self.wg, self.bg = p(n_var, d, 2 * d, escala=s), nn.Parameter(torch.zeros(n_var, 2 * d))
        self.ln_g = nn.Parameter(torch.ones(n_var, d))
        self.ln_b = nn.Parameter(torch.zeros(n_var, d))
        self.drop = nn.Dropout(dropout)

    def incorporar(self, x):  # x: (B, T, V) -> (B, T, V, d)
        return x.unsqueeze(-1) * self.emb_w + self.emb_b

    def forward(self, e):  # e: (B, T, V, d)
        h = torch.einsum("btvi,vio->btvo", e, self.w2) + self.b2
        h = torch.einsum("btvi,vio->btvo", F.elu(h), self.w1) + self.b1
        g = torch.einsum("btvi,vio->btvo", self.drop(h), self.wg) + self.bg
        a, b = g.chunk(2, dim=-1)
        z = (e + torch.sigmoid(a) * b).float()          # normalização em float32 mesmo com precisão mista
        mu = z.mean(-1, keepdim=True)
        var = z.var(-1, keepdim=True, unbiased=False)
        return ((z - mu) / torch.sqrt(var + 1e-5) * self.ln_g.float() + self.ln_b.float()).to(e.dtype)


class VSN(nn.Module):
    """v_t = Softmax(GRN_v(Ξ_t)); ξ̃_t = Σ_j v_t^(j) GRN_j(ξ_t^(j))."""

    def __init__(self, n_var: int, d: int, dropout: float):
        super().__init__()
        self.vars = GRNsVariaveis(n_var, d, dropout)
        self.sel = GRN(n_var * d, d, n_var, dropout)

    def forward(self, x):  # x: (B, T, V)
        e = self.vars.incorporar(x)
        B, T, V, d = e.shape
        pesos = torch.softmax(self.sel(e.reshape(B, T, V * d)), dim=-1)  # (B, T, V)
        xt = self.vars(e)
        return (pesos.unsqueeze(-1) * xt).sum(2), pesos


class AtencaoInterpretavel(nn.Module):
    """H̃ = (1/m_H) Σ_h Softmax(Q W_Q^h (K W_K^h)ᵀ / √d_att) V W_V, seguida de W_H."""

    def __init__(self, d: int, n_cab: int, dropout: float):
        super().__init__()
        self.n_cab, self.d_att = n_cab, d // n_cab
        self.wq = nn.Linear(d, self.d_att * n_cab)
        self.wk = nn.Linear(d, self.d_att * n_cab)
        self.wv = nn.Linear(d, self.d_att)
        self.wh = nn.Linear(self.d_att, d)
        self.drop = nn.Dropout(dropout)

    def forward(self, q, kv, mascara):  # q: (B, Tq, d), kv: (B, Tk, d), mascara: (Tq, Tk) True = bloqueia
        B, Tq, _ = q.shape
        Tk = kv.shape[1]
        Q = self.wq(q).view(B, Tq, self.n_cab, self.d_att).transpose(1, 2)
        K = self.wk(kv).view(B, Tk, self.n_cab, self.d_att).transpose(1, 2)
        V = self.wv(kv)                                                   # (B, Tk, d_att)
        s = (Q @ K.transpose(-1, -2)) / math.sqrt(self.d_att)             # (B, H, Tq, Tk)
        s = s.masked_fill(mascara, float("-inf"))
        a = torch.softmax(s, dim=-1)
        a_med = self.drop(a).mean(1)                                      # (B, Tq, Tk)
        out = a_med @ V
        return self.wh(out), a.mean(1)


class PortaNorma(nn.Module):
    """LayerNorm(skip + GLU(dropout(x)))."""

    def __init__(self, d: int, dropout: float):
        super().__init__()
        self.drop = nn.Dropout(dropout)
        self.glu = GLU(d, d)
        self.ln = nn.LayerNorm(d)

    def forward(self, x, skip):
        return self.ln(skip + self.glu(self.drop(x)))


class TFT(nn.Module):
    def __init__(self, n_enc: int, n_dec: int, d: int = 32, n_cab: int = 4, dropout: float = 0.1,
                 n_quantis: int = 3, enc_len: int = 120, dec_len: int = 36):
        super().__init__()
        self.d, self.enc_len, self.dec_len = d, enc_len, dec_len
        self.vsn_enc = VSN(n_enc, d, dropout)
        self.vsn_dec = VSN(n_dec, d, dropout)
        self.lstm_enc = nn.LSTM(d, d, batch_first=True)
        self.lstm_dec = nn.LSTM(d, d, batch_first=True)
        self.porta_lstm = PortaNorma(d, dropout)
        self.enriq = GRN(d, d, d, dropout)
        self.atencao = AtencaoInterpretavel(d, n_cab, dropout)
        self.porta_att = PortaNorma(d, dropout)
        self.ff = GRN(d, d, d, dropout)
        self.porta_final = PortaNorma(d, dropout)
        self.saida = nn.Linear(d, n_quantis)
        T = enc_len + dec_len
        m = torch.ones(dec_len, T, dtype=torch.bool)
        for j in range(dec_len):
            m[j, : enc_len + j + 1] = False  # o passo j vê o codificador e os passos 0..j do decodificador
        self.register_buffer("mascara", m, persistent=False)

    def representacao(self, x_enc, x_dec, interpretar: bool = False):
        """ψ̃ (B, 36, d) e, se pedido, (pesos do VSN do codificador, do decodificador, atenção, fração própria).

        Fração própria (B, 36): parte da representação do passo-alvo que vem das variáveis do próprio passo
        (o vetor do VSN ξ_j) pelas conexões residuais com porta. Em cada porta LayerNorm(skip + GLU(x)) a parte
        de cada ramo é a razão das normas; o resto (atenção e LSTM) é o contexto temporal."""
        xi_e, v_e = self.vsn_enc(x_enc)
        xi_d, v_d = self.vsn_dec(x_dec)
        phi_e, estado = self.lstm_enc(xi_e)
        phi_d, _ = self.lstm_dec(xi_d, estado)
        xi = torch.cat([xi_e, xi_d], dim=1)
        if not interpretar:
            phi = self.porta_lstm(torch.cat([phi_e, phi_d], dim=1), xi)
            theta = self.enriq(phi)
            q = theta[:, self.enc_len:]
            att, _ = self.atencao(q, theta, self.mascara)
            delta = self.porta_att(att, q)
            psi = self.ff(delta)
            return self.porta_final(psi, phi[:, self.enc_len:])
        # mesmas contas, abrindo as três conexões residuais com porta
        g_lstm = self.porta_lstm.glu(self.porta_lstm.drop(torch.cat([phi_e, phi_d], dim=1)))
        phi = self.porta_lstm.ln(xi + g_lstm)
        theta = self.enriq(phi)
        q = theta[:, self.enc_len:]
        att, a = self.atencao(q, theta, self.mascara)
        g_att = self.porta_att.glu(self.porta_att.drop(att))
        psi = self.ff(self.porta_att.ln(q + g_att))
        skip = phi[:, self.enc_len:]
        g_psi = self.porta_final.glu(self.porta_final.drop(psi))
        z = self.porta_final.ln(skip + g_psi)

        def parte(x, y):                     # parte do ramo x em LayerNorm(x + y)
            nx, ny = x.norm(dim=-1), y.norm(dim=-1)
            return nx / (nx + ny + 1e-12)

        r_xi = parte(xi_d, g_lstm[:, self.enc_len:])          # ξ_j dentro de φ_j
        s_att = parte(g_att, q) * parte(g_psi, skip)          # ramo da atenção dentro de z_j
        propria = (1.0 - s_att) * r_xi
        return z, (v_e, v_d, a, propria)

    def forward(self, x_enc, x_dec):
        z = self.representacao(x_enc, x_dec)
        return self.saida(z), z


class LSTMPrior(nn.Module):
    """Membro do Boot-LSTM do artigo 1: LSTM de uma camada (H = 32) sobre 120 h; o último estado oculto é
    concatenado ao vetor da hora-alvo c_τ e passa por z = ReLU(W_z[h_L; c_τ] + b_z) (H_z = 32) e pela
    cabeça linear k̂ = βᵀz + b_o."""

    def __init__(self, n_seq: int, n_ctx: int, h: int = 32, hz: int = 32, dropout: float = 0.1):
        super().__init__()
        self.lstm = nn.LSTM(n_seq, h, batch_first=True)
        self.fusao = nn.Linear(h + n_ctx, hz)
        self.drop = nn.Dropout(dropout)
        self.saida = nn.Linear(hz, 1)

    def representacao(self, seq, ctx):
        _, (h, _) = self.lstm(seq)
        return self.drop(F.relu(self.fusao(torch.cat([h[-1], ctx], dim=1))))

    def forward(self, seq, ctx):
        z = self.representacao(seq, ctx)
        return self.saida(z).squeeze(-1), z
