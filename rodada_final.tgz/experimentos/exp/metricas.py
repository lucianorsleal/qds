"""Métricas da Seção IV do artigo e testes estatísticos.

Todas as métricas usam as horas diurnas do ano de teste, normalizadas por P_nom:
    IS (Winkler), PICP, PINAW, RMSE, FSS (vs. persistência inteligente), CRPS pela decomposição em
    quantis (mesma grade de 20 níveis para todos os métodos), CRPSS (vs. CH-PeEn), coberturas por grupo,
    WGC (pior cobertura nos 19 grupos de G), CCD e WGC_sky (classes de céu ex post).
Testes: Diebold–Mariano unilateral no IS diário com variância de Newey–West (⌊n^{1/3}⌋ defasagens), Holm,
Friedman/Nemenyi (no exp/artigo.py) e Wilcoxon pareado para os otimizadores.
"""

from __future__ import annotations

import math

import numpy as np
import pandas as pd
from scipy import stats

GRADE_P = (2 * np.arange(1, 21) - 1) / 40.0  # 0,025; 0,075; ...; 0,975 (regra do ponto médio)


def is_winkler(L, U, y, alpha):
    w = U - L
    return w + (2.0 / alpha) * (L - y) * (y < L) + (2.0 / alpha) * (y - U) * (y > U)


def crps_quantis(Q, y, p=GRADE_P):
    """CRPS ≈ (2/K) Σ_k QS_{p_k}(Q_k, y), com os quantis ordenados (rearranjo monótono)."""
    Q = np.sort(np.asarray(Q, dtype=float), axis=1)
    u = (y[:, None] < Q).astype(float) - p[None, :]
    qs = u * (Q - y[:, None])
    return 2.0 * qs.mean(axis=1)


def resumo_intervalos(L, U, y, alpha):
    cob = (y >= L) & (y <= U)
    isc = is_winkler(L, U, y, alpha)
    return {"PICP": 100.0 * cob.mean(), "PINAW": float(np.mean(U - L)), "IS": 100.0 * float(np.mean(isc))}, cob, isc


def coberturas_grupo(cob, P: pd.DataFrame, tercil=None) -> pd.DataFrame:
    """Cobertura e participação de cada grupo: hora, regime, tercil (em G) e estação, céu (diagnóstico)."""
    from .dados import CEU, ESTACOES, REGIMES, TERCIS

    linhas = []
    fams = [("hour", P["hora"].to_numpy(), {h: f"{h:02d}" for h in range(6, 19)}),
            ("regime", P["regime"].to_numpy(), dict(enumerate(REGIMES))),
            ("season", P["estacao"].to_numpy(), dict(enumerate(ESTACOES))),
            ("sky", P["ceu"].to_numpy(), dict(enumerate(CEU)))]
    if tercil is not None:
        fams.insert(2, ("tertile", np.asarray(tercil), dict(enumerate(TERCIS))))
    n = len(cob)
    for fam, cod, nomes in fams:
        for k, nome in nomes.items():
            m = cod == k
            linhas.append({"family": fam, "group": nome, "share": m.sum() / max(n, 1),
                           "PICP": 100.0 * cob[m].mean() if m.any() else np.nan, "n": int(m.sum())})
    return pd.DataFrame(linhas)


def wgc_ccd(tab: pd.DataFrame, nominal=95.0) -> dict:
    g = tab[tab["family"].isin(["hour", "regime", "tertile"]) & (tab["n"] > 0)]
    sky = tab[(tab["family"] == "sky") & (tab["n"] > 0)]
    return {"WGC": float(g["PICP"].min()) if len(g) else np.nan,
            "CCD": float((g["PICP"] - nominal).abs().mean()) if len(g) else np.nan,
            "WGC_sky": float(sky["PICP"].min()) if len(sky) else np.nan}


def rmse(yhat, y):
    return 100.0 * float(np.sqrt(np.mean((yhat - y) ** 2)))


def is_diario(isc, datas) -> pd.Series:
    return pd.Series(100.0 * isc).groupby(np.asarray(datas)).mean()


def dm_unilateral(perda_outro: pd.Series, perda_prop: pd.Series) -> float:
    """H1: o proposto tem perda média menor. d_t = perda_outro - perda_prop; variância de Newey–West com
    ⌊n^{1/3}⌋ defasagens (pesos de Bartlett); p = 1 - Φ(DM)."""
    d = (perda_outro - perda_prop).dropna().to_numpy(dtype=float)
    n = d.size
    if n < 10:
        return np.nan
    dm = d.mean()
    e = d - dm
    L = int(math.floor(n ** (1 / 3)))
    s = e @ e / n
    for l in range(1, L + 1):
        s += 2 * (1 - l / (L + 1)) * (e[l:] @ e[:-l]) / n
    if s <= 0:
        return 0.0 if dm > 0 else 1.0
    z = dm / math.sqrt(s / n)
    return float(1.0 - stats.norm.cdf(z))


def holm(pvals) -> np.ndarray:
    p = np.asarray(pvals, dtype=float)
    ok = np.isfinite(p)
    out = np.full_like(p, np.nan)
    idx = np.where(ok)[0]
    if idx.size == 0:
        return out
    ordem = idx[np.argsort(p[idx])]
    m = len(ordem)
    acc = 0.0
    for r, i in enumerate(ordem):
        acc = max(acc, min(1.0, (m - r) * p[i]))
        out[i] = acc
    return out


def wilcoxon(a, b) -> float:
    a, b = np.asarray(a, dtype=float), np.asarray(b, dtype=float)
    ok = np.isfinite(a) & np.isfinite(b)
    if ok.sum() < 3 or np.allclose(a[ok], b[ok]):
        return np.nan
    try:
        return float(stats.wilcoxon(a[ok], b[ok]).pvalue)
    except ValueError:
        return np.nan
