"""Configuração dos experimentos.

O config_experimentos.yaml (pasta do executar.py) traz a especificação fixa do artigo (Tabela 3) e os
parâmetros dos baselines. Os dados de cada site (fuso, período, partições) vêm do config.yaml do pacote
de coleta, para que os dois pacotes usem exatamente as mesmas definições.
"""

from __future__ import annotations

import copy
import logging
import os
import sys
from pathlib import Path

import yaml

RAIZ = Path(__file__).resolve().parent.parent
log = logging.getLogger("exp")

HORIZONTES = ["1h", "3h", "6h", "DA"]
H_PASSO = {"1h": 1, "3h": 3, "6h": 6}           # passo do decodificador (k) de cada horizonte intradiário
H_LEAD_PISO = {"1h": 1, "3h": 3, "6h": 6, "DA": 24}  # h usado em p(h) = min(7, 5 + 0,1 h) do piso
METODOS = ["CHPeEn", "LGBM_CQR", "HEC", "PRIOR", "TFT", "CQR_TFT", "MVP", "PROP"]   # v2: sem o Chronos
ORDEM_SITES = ["YUL", "BRA", "GEO", "ASP", "UKF", "HKG"]  # ordem dos sites nas tabelas e figuras (do mais seco ao mais úmido)


def _mesclar(base: dict, extra: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (extra or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _mesclar(out[k], v)
        else:
            out[k] = v
    return out


def carregar(caminho: Path | None = None, perfil: str | None = None) -> dict:
    caminho = Path(caminho) if caminho else RAIZ / "config_experimentos.yaml"
    with open(caminho, encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    if perfil:
        perfis = cfg.get("perfis", {})
        if perfil not in perfis:
            raise SystemExit(f"perfil '{perfil}' não existe no {caminho.name} (há: {', '.join(perfis)})")
        cfg = _mesclar(cfg, perfis[perfil])
        cfg["_perfil"] = perfil
    base = caminho.parent
    cfg["_raiz"] = base
    cfg["pasta_coleta"] = (base / cfg.get("pasta_coleta", "../coleta_dados")).resolve()
    cfg["pasta_saida"] = (base / cfg.get("pasta_saida", "resultados")).resolve()
    arq = cfg["pasta_coleta"] / "config.yaml"
    if not arq.exists():
        raise SystemExit(f"não achei o config.yaml da coleta em {arq}; ajuste 'pasta_coleta' no {caminho.name}")
    with open(arq, encoding="utf-8") as f:
        cfg["_coleta"] = yaml.safe_load(f)
    pd_ = cfg["_coleta"].get("pasta_dados", "dados")
    cfg["pasta_processados"] = (cfg["pasta_coleta"] / pd_ / "processados").resolve()
    return cfg


def site(cfg: dict, codigo: str) -> dict:
    s = cfg["_coleta"]["sites"].get(codigo)
    if s is None:
        raise SystemExit(f"site {codigo} não está no config.yaml da coleta")
    s = dict(s, codigo=codigo)
    v = (cfg.get("y_max_fisico") or {}).get(codigo, cfg.get("y_max_padrao", "auto"))
    s["y_max"] = "auto" if v in (None, "auto") else float(v)   # "auto": maior y do bloco de treino (dados.py)
    return s


def pastas_site(cfg: dict, codigo: str) -> dict:
    base = cfg["pasta_saida"] / codigo
    p = {"base": base, "cache": base / "cache", "prev": base / "previsoes", "csv": base / "csv",
         "logs": base / "logs", "proc": cfg["pasta_processados"] / codigo}
    for k in ("base", "cache", "prev", "csv", "logs"):
        p[k].mkdir(parents=True, exist_ok=True)
    return p


def configurar_log(pasta_logs: Path, nivel=logging.INFO) -> None:
    raiz = logging.getLogger("exp")
    raiz.setLevel(nivel)
    for h in list(raiz.handlers):
        raiz.removeHandler(h)
    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", "%Y-%m-%d %H:%M:%S")
    ch = logging.StreamHandler(sys.stdout)
    ch.setFormatter(fmt)
    raiz.addHandler(ch)
    pasta_logs.mkdir(parents=True, exist_ok=True)
    fh = logging.FileHandler(pasta_logs / "experimentos.log", encoding="utf-8")
    fh.setFormatter(fmt)
    raiz.addHandler(fh)
    raiz.propagate = False


def dispositivo(cfg: dict):
    import torch

    pedido = str(cfg.get("dispositivo", "auto")).lower()
    if pedido == "cpu":
        return torch.device("cpu")
    if torch.cuda.is_available():
        return torch.device("cuda")
    if pedido == "cuda":
        log.warning("CUDA pedida, mas o PyTorch não vê GPU; usando a CPU (veja o README, seção 1)")
    return torch.device("cpu")


def threads_cpu() -> int:
    try:
        return max(1, (os.cpu_count() or 2) - 1)
    except Exception:  # noqa: BLE001
        return 1
