"""Funções de aptidão do Estágio 3 (Seção III-E do artigo e Seção III-E do artigo 1).

θ = cabeças medianas dos M membros (w, b) e, no TFT, log γ. A busca é feita em coordenadas de
deslocamento padronizado u = (θ - θ0) ⊘ s, com s = ς0(|θ0| + ε0) nas cabeças; log γ tem escala própria
(escala_log_gama), porque o seu valor inicial é 0 e ς0·ε0 seria pequeno demais para mexer em γ.

AptidaoCondicional (proposto e B4e): D_val é dividido pela paridade do dia em A e B; numa metade,
estimam-se o piso σ_fl (percentil p(h) de σ_tot), os cortes de tercil e os limiares por regressão
quantílica linear dos escores em Φ (sem o ponto imputado); na outra, calcula-se o IS. A média dos IS
(as duas metades, todos os horizontes) é dividida pelo valor em θ0, e soma-se λ‖u‖²/d.

AptidaoMondrian (PRIOR, artigo 1): igual, mas com quantis Mondrian por hora (s = 1) no lugar da
regressão quantílica, piso de σ (só epistêmico) na metade de ajuste, um horizonte por vez.
"""

from __future__ import annotations

import numpy as np

from . import conformal as cc
from .metricas import is_winkler


class _Base:
    def __init__(self, Z, pcs, y, theta0, cfg_icso, ymax, com_gama, clip_membros):
        self.Z = np.ascontiguousarray(Z, dtype=np.float64)         # (n, M, H)
        self.pcs = np.asarray(pcs, dtype=np.float64)
        self.y = np.asarray(y, dtype=np.float64)
        self.M, self.H = self.Z.shape[1], self.Z.shape[2]
        self.theta0 = np.asarray(theta0, dtype=np.float64)
        self.com_gama = com_gama
        self.clip = clip_membros
        self.ymax = ymax
        v0, e0 = cfg_icso["varsigma0"], cfg_icso["eps0"]
        s = v0 * (np.abs(self.theta0) + e0)
        if com_gama:
            s[-1] = cfg_icso["escala_log_gama"]
        self.s = s
        self.d = self.theta0.size
        self.lam = cfg_icso["lambda"]
        self.avaliacoes = 0
        self.IS0 = None

    def theta(self, u):
        return self.theta0 + np.asarray(u, dtype=np.float64) * self.s

    def membros(self, th, idx=None):
        Z = self.Z if idx is None else self.Z[idx]
        pcs = self.pcs if idx is None else self.pcs[idx]
        W = th[: self.M * (self.H + 1)].reshape(self.M, self.H + 1)
        k = np.einsum("nmh,mh->nm", Z, W[:, :-1]) + W[:, -1]
        ym = k * pcs[:, None]
        if self.clip:
            ym = np.clip(ym, 0.0, self.ymax)
        return ym

    def __call__(self, u):
        u = np.asarray(u, dtype=np.float64)
        f = self.is_crossfit(self.theta(u)) / self.IS0 + self.lam / self.d * float(u @ u)
        self.avaliacoes += 1
        return float(f)


class AptidaoCondicional(_Base):
    def __init__(self, Z, pcs, y, sig_ale, h_id, hora, regime, paridade, theta0, cfg_icso, cfg_conf, ymax,
                 p_por_h: dict, com_gama=True, clip_membros=False, familias=("hora", "regime", "tercil")):
        super().__init__(Z, pcs, y, theta0, cfg_icso, ymax, com_gama, clip_membros)
        self.sig_ale = None if sig_ale is None else np.asarray(sig_ale, dtype=np.float64)
        self.h_id = np.asarray(h_id)
        self.hora = np.asarray(hora).astype(int) - 6
        self.regime = np.asarray(regime).astype(int)
        self.par = np.asarray(paridade).astype(int)
        self.alpha = cfg_conf["alpha"]
        self.tau = 1.0 - (cfg_conf["alpha"] - cfg_conf["delta"]) / 2.0
        self.n_min = cfg_conf["n_min"]
        self.p_por_h = p_por_h
        self.familias = familias
        self.blocos = []
        for h in np.unique(self.h_id):
            for U in (0, 1):
                iU = np.where((self.h_id == h) & (self.par == U))[0]
                iV = np.where((self.h_id == h) & (self.par == 1 - U))[0]
                if len(iU) > 20 and len(iV) > 0:
                    self.blocos.append((h, iU, iV))
        self.IS0 = 1.0
        self.IS0 = self.is_crossfit(self.theta0)

    def previsao(self, th, idx=None):
        ym = self.membros(th, idx)
        yhat = np.clip(ym.mean(axis=1), 0.0, self.ymax)
        sep2 = ym.var(axis=1)
        if self.sig_ale is not None and self.com_gama:
            ale = self.sig_ale if idx is None else self.sig_ale[idx]
            sig = np.sqrt(sep2 + np.exp(th[-1]) * ale ** 2)
        elif self.sig_ale is not None:
            ale = self.sig_ale if idx is None else self.sig_ale[idx]
            sig = np.sqrt(sep2 + ale ** 2)
        else:
            sig = np.sqrt(sep2)
        return yhat, sig

    def _fam(self, idx, tercil):
        cod = {"hora": self.hora[idx], "regime": self.regime[idx], "tercil": tercil}
        niv = {"hora": 13, "regime": 3, "tercil": 3}
        return cc.Familias({k: cod[k] for k in self.familias}, {k: niv[k] for k in self.familias})

    def is_crossfit(self, th):
        yhat, sig = self.previsao(th)
        soma, n = 0.0, 0
        for h, iU, iV in self.blocos:
            piso = np.percentile(sig[iU], self.p_por_h[h])
            sU, sV = np.maximum(sig[iU], piso), np.maximum(sig[iV], piso)
            c1, c2 = np.percentile(sU, [100 / 3, 200 / 3])
            tU, tV = np.digitize(sU, [c1, c2]), np.digitize(sV, [c1, c2])
            Ep, Em = cc.escores(self.y[iU], yhat[iU], sU)
            fU, fV = self._fam(iU, tU), self._fam(iV, tV)
            qh = cc.limiares_rq(Ep, fU, fV, self.tau, self.n_min)
            ql = cc.limiares_rq(Em, fU, fV, self.tau, self.n_min)
            L, U = cc.intervalo(yhat[iV], sV, np.maximum(ql, 0), np.maximum(qh, 0), self.ymax)
            soma += float(is_winkler(L, U, self.y[iV], self.alpha).sum())
            n += len(iV)
        return soma / max(n, 1)


class AptidaoMondrian(_Base):
    """IS cruzado com quantis Mondrian por hora (artigo 1), para as cabeças do Boot-LSTM de um horizonte."""

    def __init__(self, Z, pcs, y, hora, paridade, theta0, cfg_icso, cfg_conf, ymax, p_h: float):
        super().__init__(Z, pcs, y, theta0, cfg_icso, ymax, com_gama=False, clip_membros=True)
        self.hora = np.asarray(hora).astype(int) - 6
        self.par = np.asarray(paridade).astype(int)
        self.alpha = cfg_conf["alpha"]
        self.tau_cauda = 1.0 - cfg_conf["alpha"] / 2.0
        self.n_min = cfg_conf["n_min"]
        self.p_h = p_h
        self.IS0 = 1.0
        self.IS0 = self.is_crossfit(self.theta0)

    def previsao(self, th, idx=None):
        ym = self.membros(th, idx)
        return np.clip(ym.mean(axis=1), 0.0, self.ymax), ym.std(axis=1)

    def is_crossfit(self, th):
        yhat, sig = self.previsao(th)
        soma, n = 0.0, 0
        for U in (0, 1):
            iU, iV = np.where(self.par == U)[0], np.where(self.par == 1 - U)[0]
            if len(iU) < 20 or len(iV) == 0:
                continue
            piso = np.percentile(sig[iU], self.p_h)
            sU, sV = np.maximum(sig[iU], piso), np.maximum(sig[iV], piso)
            Ep, Em = cc.escores(self.y[iU], yhat[iU], sU)
            Qp, _ = cc.quantis_mondrian(Ep, self.hora[iU], 13, self.tau_cauda, self.n_min)
            Qm, _ = cc.quantis_mondrian(Em, self.hora[iU], 13, self.tau_cauda, self.n_min)
            L, U_ = cc.intervalo(yhat[iV], sV, Qm[self.hora[iV]], Qp[self.hora[iV]], self.ymax)
            soma += float(is_winkler(L, U_, self.y[iV], self.alpha).sum())
            n += len(iV)
        return soma / max(n, 1)
