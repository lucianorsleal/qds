"""Orquestração dos experimentos de um site, semente por semente, com cache e retomada.

Modelo proposto (v3): Estágios 1–2, ensemble de TFTs com bootstrap por dias (cabeças do Adam); Estágio 3,
combinação com o LightGBM quantílico por janela de calibração (peso do TFT escolhido pelo IS condicional em
validação cruzada na própria janela); Estágio 4, conformal condicional sobre 19 grupos com uma escala para cada
lado do intervalo. O ICSO-PP só aparece no antecessor (PRIOR) e na ablação B4h.

Cada etapa grava o que produz em resultados/<SITE>/cache/s<semente>/ (modelos, saídas das redes,
θ*) e em resultados/<SITE>/previsoes/s<semente>/<MÉTODO>.npz (L, U, ŷ e, quando há, os 20 quantis
da grade do CRPS, alinhados aos pares de teste). Se a etapa já tiver o arquivo, ela é pulada; assim a
execução pode ser interrompida e retomada a qualquer momento.
"""

from __future__ import annotations

import fnmatch
import hashlib
import json
import logging
import os
import shutil
import time
from pathlib import Path

import numpy as np
import torch

from . import baselines as bl
from . import conformal as cc
from . import dados as dd
from . import fitness as ft
from . import metricas as mt
from . import otimizadores as op
from . import treino as tr
from .config import HORIZONTES, dispositivo, pastas_site

log = logging.getLogger("exp")
Z90 = 1.2816
Z95 = 1.959964

# Manifesto dos resultados (resultados/<SITE>/manifesto.json). Se a versão do código, o conteúdo dos dados de
# entrada, a tabela de pares, a série depois do QC, o limite físico ȳ ou uma seção do config que muda tudo for
# diferente da rodada anterior, os resultados antigos são movidos para resultados/<SITE>_antigo_<data>/ e
# refeitos. Mudanças só nos baselines movem só os arquivos deles; mudanças só na seção 'tft' movem tudo o que
# depende do TFT e mantêm os baselines que não dependem dele (CH-PeEn, LightGBM, HEC-XGB, PRIOR e B4e). Itens
# que o manifesto antigo não tem (versões anteriores do pacote) não contam como mudança.
VERSAO_RESULTADOS = 2
# v3: proposto = TFT (cabeças do Adam) + LightGBM com peso por janela e escalas de cada lado, sem o ICSO-PP nas
# cabeças. Mudou o que depende do proposto; os TFTs, os quantis do LightGBM e os baselines continuam valendo.
VERSAO_PROPOSTO = 3
VSN_VERSAO = 2          # pesos de seleção da Fig. 9 com as conexões residuais do TFT (treino.inferir_tft)
SECOES_TUDO = ["tft", "ensemble", "icso", "conformal", "lstm_prior"]
SECOES_EFETIVAS = {"y_max": "o limite físico ȳ", "serie": "a série depois do QC (inclui a indisponibilidade da usina)"}
SECOES_ARQUIVOS = {"hec": ["HEC"], "lgbm": ["LGBM_CQR"], "estresse": ["STRESS_*"],
                   "otimizadores": ["OPT_*"]}
SECOES_TFT = ["tft"]
MANTER_SEM_TFT = {"cache": ["lstm_*", "prior_previsoes.npz", "lgbm_quantis.npz"],
                  "previsoes": ["CHPeEn.*", "LGBM_CQR.*", "HEC.*", "PRIOR.*", "B4e.*"]}
# o que depende do modelo proposto (refeito quando ele muda; TFTs, LightGBM e baselines ficam)
DO_PROPOSTO = {"cache": ["tercis.npz", "hibrido.npz"],
               "previsoes": ["PROP.*", "MVP.*", "B1.*", "B2.*", "B3.*", "B4.*", "B4a.*", "B4b.*", "B4c.*", "B4d.*",
                             "B4h.*", "B5*", "L1.*", "L2.*", "L3.*", "L4.*", "L5.*", "STRESS_*", "OPT_*"]}
# chave no valor padrão (ou vazia) = mesma rodada de antes de a chave existir: não muda o manifesto
PADROES_CFG = {"tft": {"lags_decodificador": 0, "peso_intradiario": 1, "passos_intradiarios": 6},
               "lgbm": {"alvo": "y"}}


def _secao_cfg(cfg: dict, s: str):
    sec = cfg.get(s)
    if isinstance(sec, dict) and s in PADROES_CFG:
        sec = {k: v for k, v in sec.items() if not (k in PADROES_CFG[s] and (v is None or v == PADROES_CFG[s][k]))}
    return sec


def _hash_obj(obj) -> str:
    return hashlib.sha1(json.dumps(obj, sort_keys=True, default=str).encode()).hexdigest()[:12]


def _hash_arquivos(arquivos) -> str:
    h = hashlib.sha1()
    for a in arquivos:
        h.update(a.name.encode())
        with open(a, "rb") as f:
            for bloco in iter(lambda: f.read(1 << 22), b""):
                h.update(bloco)
    return h.hexdigest()[:16]


def _salvar_npz(caminho: Path, **arrays):
    caminho.parent.mkdir(parents=True, exist_ok=True)
    tmp = caminho.with_name(caminho.stem + ".tmp.npz")
    np.savez_compressed(tmp, **arrays)
    tmp.replace(caminho)


def _ler_npz(caminho: Path) -> dict:
    with np.load(caminho, allow_pickle=False) as z:
        return {k: z[k] for k in z.files}


def _json(caminho: Path, obj=None):
    if obj is None:
        return json.loads(caminho.read_text(encoding="utf-8"))
    caminho.parent.mkdir(parents=True, exist_ok=True)
    caminho.write_text(json.dumps(obj, indent=1, default=float), encoding="utf-8")


class Base:
    """Base de uma camada de calibração: ŷ, escala de baixo, escala de cima e tercil da dispersão (arrays de todos os
    pares), por janela (h, m). Com pesos {(h, m): chave}, cada janela usa a variante da chave escolhida para ela."""

    def __init__(self, var: dict, pesos: dict | None = None):
        self.var, self.pesos = var, pesos

    @classmethod
    def fixa(cls, yhat, s_lo, s_hi=None, terc=None):
        return cls({0: (yhat, s_lo, s_lo if s_hi is None else s_hi, terc)})

    def __call__(self, h, m):
        if self.pesos is None:
            return next(iter(self.var.values()))
        return self.var[self.pesos[(h, m)]]


class Experimento:
    def __init__(self, cfg: dict, codigo: str):
        self.cfg, self.codigo = cfg, codigo
        self.pastas = pastas_site(cfg, codigo)
        self.site = dd.carregar_site(cfg, codigo, self.pastas)
        dd.verificar_nwp(self.site, float(cfg.get("nwp_cobertura_minima", 0.95)))
        self.dev = dispositivo(cfg)
        conf = cfg["conformal"]
        self.alpha, self.delta, self.n_min = conf["alpha"], conf["delta"], conf["n_min"]
        self.tau = 1.0 - (self.alpha - self.delta) / 2.0
        self.ymax = self.site.y_max
        self.n_lag = int(cfg["tft"].get("lags_decodificador", 0) or 0)   # k das últimas horas no decodificador
        pr = cfg.get("processos", "auto")
        self.processos = max(1, min(16, (os.cpu_count() or 2) - 1)) if pr in (None, "auto") else int(pr)
        self.P = dd.tabela_pares(self.site, limiares=tuple(conf["limiares_regime"]))
        P = self.P
        self.h = P["h"].to_numpy()
        self.val = np.where(P["bloco"].to_numpy() == 2)[0]
        self.te = np.where((P["bloco"].to_numpy() == 4) & (P["mes_teste"].to_numpy() >= 1))[0]
        self.pos_te = np.full(len(P), -1)
        self.pos_te[self.te] = np.arange(len(self.te))
        tt = self.site.t_utc[P["t"].to_numpy()]
        J = self.site.janelas
        self.meses = [int(m) for m in J.index]
        self.m_cal = {m: np.asarray((tt >= J.loc[m, "cal_ini"]) & (tt < J.loc[m, "cal_fim"])) for m in self.meses}
        mt = P["mes_teste"].to_numpy()
        self.m_te = {m: (mt == m) & (P["bloco"].to_numpy() == 4) for m in self.meses}
        self.y = P["y"].to_numpy(dtype=np.float64)
        self.pcs = P["pcs"].to_numpy(dtype=np.float64)
        self.hora = P["hora"].to_numpy().astype(int)
        self.regime = P["regime"].to_numpy().astype(int)
        self.emis = np.unique(P["i"].to_numpy())
        self.pos_emis = np.searchsorted(self.emis, P["i"].to_numpy())
        self.j = P["j"].to_numpy()
        self.t_alvo, self.i_emis = P["t"].to_numpy(), P["i"].to_numpy()
        log.info("%s: %d pares de avaliação (validação %d, teste %d); dispositivo %s", codigo, len(P), len(self.val),
                 len(self.te), self.dev)
        self._conferir_manifesto()
        for h, nome in enumerate(HORIZONTES):
            n_te = int(((self.h == h) & np.isin(np.arange(len(P)), self.te)).sum())
            n_va = int((self.h[self.val] == h).sum())
            log.info("    %s: %d pares de teste", nome, n_te)
            if n_te == 0 or n_va == 0:
                raise SystemExit(f"{codigo}: o horizonte {nome} ficou sem pares de "
                                 f"{'teste' if n_te == 0 else 'validação'}; confira particoes.csv e o QC da coleta")

    # ------------------------------------------------------------------ manifesto (invalidação do cache)
    def _manifesto(self) -> dict:
        cfg, proc = self.cfg, self.pastas["proc"]
        arqs = [proc / "potencia_horaria.parquet", proc / "gfs_horario.parquet", proc / "particoes.csv"]
        secoes = {s: _hash_obj(_secao_cfg(cfg, s)) for s in SECOES_TUDO + list(SECOES_ARQUIVOS)}
        secoes["otimizadores"] = _hash_obj({**(cfg.get("otimizadores") or {}), "orcamento": self.orcamento()})
        secoes["y_max"] = _hash_obj(round(float(self.ymax), 6))
        y = np.ascontiguousarray(np.nan_to_num(np.asarray(self.site.y, dtype=np.float64), nan=-1.0))
        secoes["serie"] = hashlib.sha1(y.tobytes() + np.asarray(self.site.valido, dtype=np.uint8).tobytes()).hexdigest()[:12]
        pares = np.ascontiguousarray(self.P[["h", "i", "j", "t"]].to_numpy(dtype=np.int64))
        return {"versao": VERSAO_RESULTADOS, "dados": _hash_arquivos(arqs),
                "pares": hashlib.sha1(pares.tobytes()).hexdigest()[:16], "secoes": secoes,
                "proposto": _hash_obj({"v": VERSAO_PROPOSTO, "hibrido": cfg.get("hibrido"),
                                       "lgbm": _secao_cfg(cfg, "lgbm")})}

    def _tem_resultados(self) -> bool:
        if any(self.pastas["prev"].rglob("*.npz")):
            return True
        return any(a.is_file() and not a.name.startswith("site_") for a in self.pastas["cache"].rglob("*"))

    def _mover_antigos(self, motivo: str, padroes=None, manter=None, mover=None) -> None:
        """Move os resultados antigos para <SITE>_antigo_<data>: todos, só previsoes/*/<padrão>.npz (padroes),
        todos menos os arquivos de cache/ e previsoes/ que casam com manter[sub] (e o cache da série) ou só os
        que casam com mover[sub] (com os CSVs do relatório, que dependem deles)."""
        base = self.pastas["base"]
        destino = base.parent / f"{base.name}_antigo_{time.strftime('%Y%m%d-%H%M%S')}"
        movidos = 0
        if mover is not None:
            for sub in ("cache", "previsoes", "csv"):
                for item in sorted(p for p in (base / sub).rglob("*") if p.is_file()):
                    if sub != "csv" and not any(fnmatch.fnmatch(item.name, pad) for pad in mover.get(sub, [])):
                        continue
                    alvo = destino / item.relative_to(base)
                    alvo.parent.mkdir(parents=True, exist_ok=True)
                    shutil.move(str(item), str(alvo))
                    movidos += 1
        elif manter is not None:
            for sub in ("cache", "previsoes", "csv"):
                for item in sorted(p for p in (base / sub).rglob("*") if p.is_file()):
                    if sub == "cache" and item.parent == base / sub and item.name.startswith("site_"):
                        continue
                    if any(fnmatch.fnmatch(item.name, pad) for pad in manter.get(sub, [])):
                        continue
                    alvo = destino / item.relative_to(base)
                    alvo.parent.mkdir(parents=True, exist_ok=True)
                    shutil.move(str(item), str(alvo))
                    movidos += 1
        elif padroes is None:
            for sub in ("cache", "previsoes", "csv"):
                for item in sorted((base / sub).glob("*")):
                    if sub == "cache" and item.name.startswith("site_"):
                        continue                      # cache da série: chaveado pela assinatura dos arquivos
                    (destino / sub).mkdir(parents=True, exist_ok=True)
                    shutil.move(str(item), str(destino / sub / item.name))
                    movidos += 1
        else:
            for pad in padroes:
                for item in sorted(self.pastas["prev"].glob(f"*/{pad}.npz")):
                    alvo = destino / "previsoes" / item.parent.name
                    alvo.mkdir(parents=True, exist_ok=True)
                    shutil.move(str(item), str(alvo / item.name))
                    movidos += 1
        if movidos:
            log.warning("%s: %s. %d item(ns) da rodada anterior foram movidos para %s e serão refeitos.",
                        self.codigo, motivo, movidos, destino)

    def _conferir_manifesto(self) -> None:
        arq = self.pastas["base"] / "manifesto.json"
        novo = self._manifesto()
        if not arq.exists():
            if self._tem_resultados():
                self._mover_antigos("há resultados sem manifesto (versão anterior do pacote)")
            _json(arq, novo)
            return
        velho = _json(arq)
        nomes = {"versao": "a versão do código", "dados": "os dados de entrada (série, GFS ou partições)",
                 "pares": "a tabela de pares de avaliação"}
        motivos = [nomes[k] for k in ("versao", "dados", "pares") if velho.get(k) != novo[k]]
        vs = velho.get("secoes", {})
        mudou = [s for s in SECOES_TUDO if s in vs and vs[s] != novo["secoes"][s]]
        motivos += [f"a seção '{s}' do config" for s in mudou]
        motivos += [nome for s, nome in SECOES_EFETIVAS.items() if s in vs and vs[s] != novo["secoes"][s]]
        so_tft = bool(mudou) and len(motivos) == len(mudou) and all(s in SECOES_TFT for s in mudou)
        if motivos and not so_tft:
            self._mover_antigos("mudou " + ", ".join(motivos) + " desde a rodada anterior")
        else:
            if so_tft:
                self._mover_antigos("mudou a seção 'tft' do config (CH-PeEn, LightGBM, HEC-XGB, PRIOR e B4e são "
                                    "mantidos)", manter=MANTER_SEM_TFT)
            for s, padroes in SECOES_ARQUIVOS.items():
                if s in vs and vs[s] != novo["secoes"][s]:
                    self._mover_antigos(f"mudou a seção '{s}' do config", padroes)
            if "lgbm" in vs and vs["lgbm"] != novo["secoes"]["lgbm"]:
                self._mover_antigos("mudou a seção 'lgbm' do config", mover={"cache": ["lgbm_quantis.npz"]})
            if velho.get("proposto") != novo["proposto"]:
                # manifestos de antes da v3 não têm a chave: o proposto da v2 era outro modelo
                self._mover_antigos("o modelo proposto mudou (pacote v3: TFT + LightGBM, sem o ICSO-PP nas cabeças; "
                                    "TFTs, LightGBM e baselines são mantidos)" if "proposto" not in velho else
                                    "mudou a seção 'hibrido' ou 'lgbm' do config", mover=DO_PROPOSTO)
        _json(arq, novo)

    # ------------------------------------------------------------------ utilidades
    def pasta(self, seed: int) -> Path:
        p = self.pastas["cache"] / f"s{seed}"
        p.mkdir(parents=True, exist_ok=True)
        return p

    def arq_prev(self, seed, nome) -> Path:
        return self.pastas["prev"] / (f"s{seed}" if seed is not None else "comum") / f"{nome}.npz"

    def p_por_h(self):
        return {h: dd.p_piso(n) for h, n in enumerate(HORIZONTES)}

    # ================================================================== Estágios 1–2: ensemble de TFTs
    def tft_ensemble(self, seed: int) -> dict:
        arq = self.pasta(seed) / "tft_saidas.npz"
        if arq.exists():
            res = _ler_npz(arq)
            if int(np.asarray(res.get("vsn_versao", [1])).ravel()[0]) < VSN_VERSAO:
                res = self._atualizar_interpretacao(seed, res, arq)
            return res
        cfg = self.cfg
        hp0 = dict(cfg["tft"])
        M = int(cfg["ensemble"]["membros"])
        quantis = list(cfg["tft"]["quantis"])
        T = self.tensores_tft()
        w_val = (self.site.valido & (self.site.bloco == 2)).astype(np.float32)
        t0 = time.time()
        modelos, infos = [], []
        for m in range(M):
            arq_m = self.pasta(seed) / f"tft_m{m}.pt"
            rng = np.random.default_rng(seed * 1000 + m)
            w_boot = tr.pesos_bootstrap(self.site, rng)
            hp = tr.jitter(hp0, rng, cfg["ensemble"]["jitter"])
            if arq_m.exists():
                ck = torch.load(arq_m, map_location=self.dev, weights_only=False)
                mod = self._novo_tft(ck["hp"], len(quantis))
                mod.load_state_dict(ck["estado"])
                infos.append(ck["info"])
            else:
                log.info("  semente %d, membro %d/%d (lr %.2e, dropout %.3f, lote %d)", seed, m + 1, M, hp["lr"],
                         hp["dropout"], hp["batch"])
                mod, info = tr.treinar_tft(self.site, T, hp, quantis, seed * 1000 + m, w_boot, w_val,
                                           rotulo=f"s{seed} m{m}: ")
                torch.save({"estado": mod.state_dict(), "hp": hp, "info": info}, arq_m)
                infos.append(info)
            modelos.append(mod)
        t_treino = 60.0 * sum(float(i.get("min", 0.0)) for i in infos)   # inclui membros de rodadas anteriores
        t1 = time.time()
        iq = quantis.index(0.5)
        Q = np.zeros((M, len(self.P), len(quantis)), dtype=np.float32)
        Z = np.zeros((M, len(self.P), int(hp0["hidden"])), dtype=np.float32)
        cab = np.zeros((M, len(quantis), int(hp0["hidden"]) + 1))
        acc = self._interp_novo()
        for m, mod in enumerate(modelos):
            out = tr.inferir_tft(mod, T, self.emis, interpretar=True, grupo_enc=dd.GRUPO_ENC,
                                 grupo_dec=dd.grupo_dec(self.n_lag))
            Q[m] = out["q"][self.pos_emis, self.j]
            Z[m] = out["z"][self.pos_emis, self.j]
            W = mod.saida.weight.detach().cpu().numpy()
            b = mod.saida.bias.detach().cpu().numpy()
            cab[m] = np.column_stack([W, b])
            self._interp_somar(acc, out, M)
            del out
        t_inf = time.time() - t1
        dias_ev = len(np.unique(self.site.data_ord[self.emis]))
        res = {"Q": Q, "Z": Z, "cabecas": cab, "iq": np.array([iq]), **self._interp_fechar(acc),
               "t_treino_min": np.array([t_treino / 60]), "t_inf_s_dia": np.array([t_inf / max(dias_ev, 1)]),
               "n_treino": np.array([infos[0].get("n_emissoes", 0) if infos else 0]),
               "epocas": np.array([i.get("epocas", 0) for i in infos])}
        _salvar_npz(arq, **res)
        log.info("  semente %d: ensemble de %d TFTs pronto (treino %.1f min)", seed, M, t_treino / 60)
        return res

    # ------------------------------------------------------------------ interpretabilidade (Figs. 9 e 10)
    def _interp_novo(self) -> dict:
        return {"vsn": {h: np.zeros(9) for h in (0, 3)}, "ctx": {h: np.zeros(9) for h in (0, 3)},
                "prop": {h: np.zeros(9) for h in (0, 3)}, "s": {h: 0.0 for h in (0, 3)},
                "att": np.zeros((3, dd.ENC)), "n_att": np.zeros(3)}

    def _interp_somar(self, acc: dict, out: dict, M: int) -> None:
        """Soma a contribuição de um membro: pesos de grupo do passo-alvo (1 h e DA, teste) e atenção do DA
        sobre o codificador por regime."""
        te_set = np.zeros(len(self.P), dtype=bool)
        te_set[self.te] = True
        wg = out["wg"][self.pos_emis, self.j].astype(np.float64)
        wc = out["wg_ctx"][self.pos_emis, self.j].astype(np.float64)
        wp = out["wg_proprio"][self.pos_emis, self.j].astype(np.float64)
        sc = out["propria"][self.pos_emis, self.j].astype(np.float64)
        for h in (0, 3):
            sel = te_set & (self.h == h)
            acc["vsn"][h] += wg[sel].mean(axis=0) / M
            acc["ctx"][h] += wc[sel].mean(axis=0) / M
            acc["prop"][h] += wp[sel].mean(axis=0) / M
            acc["s"][h] += float(sc[sel].mean()) / M
        att = out["att_enc"][self.pos_emis, self.j].astype(np.float64)
        for r in range(3):
            sel = te_set & (self.h == 3) & (self.regime == r)
            if sel.any():
                acc["att"][r] += att[sel].sum(axis=0)
                acc["n_att"][r] += sel.sum()

    def _interp_fechar(self, acc: dict) -> dict:
        return {"vsn_1h": acc["vsn"][0], "vsn_DA": acc["vsn"][3],
                "vsn_ctx_1h": acc["ctx"][0], "vsn_ctx_DA": acc["ctx"][3],        # diagnóstico: só a atenção
                "vsn_prop_1h": acc["prop"][0], "vsn_prop_DA": acc["prop"][3],    # diagnóstico: só o próprio passo
                "att_DA": acc["att"] / np.maximum(acc["n_att"][:, None], 1), "att_n": acc["n_att"],
                "vsn_propria": np.array([acc["s"][0], acc["s"][3]]), "vsn_versao": np.array([VSN_VERSAO])}

    def _atualizar_interpretacao(self, seed: int, res: dict, arq: Path) -> dict:
        """Saídas de uma versão anterior do pacote: refaz só os pesos de seleção (Fig. 9) com a regra atual,
        a partir dos TFTs salvos, sem retreinar nem mexer nas previsões."""
        M = int(self.cfg["ensemble"]["membros"])
        arqs = [self.pasta(seed) / f"tft_m{m}.pt" for m in range(M)]
        if not all(a.exists() for a in arqs):
            return res
        log.info("  semente %d: recalculando os pesos de seleção da Fig. 9 com a regra atual (sem retreinar)", seed)
        T = self.tensores_tft()
        acc = self._interp_novo()
        for a in arqs:
            ck = torch.load(a, map_location=self.dev, weights_only=False)
            mod = self._novo_tft(ck["hp"], len(self.cfg["tft"]["quantis"]))
            mod.load_state_dict(ck["estado"])
            out = tr.inferir_tft(mod, T, self.emis, interpretar=True, grupo_enc=dd.GRUPO_ENC,
                                 grupo_dec=dd.grupo_dec(self.n_lag))
            self._interp_somar(acc, out, M)
            del out
        res = {**res, **self._interp_fechar(acc)}
        _salvar_npz(arq, **res)
        return res

    def tensores_tft(self, site=None, P=None, N=None):
        return tr.TensoresTFT(self.site if site is None else site, self.dev, P=P, N=N, n_lag=self.n_lag)

    def _novo_tft(self, hp, nq):
        from .redes import TFT

        return TFT(len(dd.VARS_ENC), len(dd.VARS_DEC) + self.n_lag, hp["hidden"], hp["cabecas"], hp["dropout"], nq,
                   dd.ENC, dd.DEC).to(self.dev)

    def modelos_tft(self, seed: int) -> list:
        quantis = list(self.cfg["tft"]["quantis"])
        mods = []
        for m in range(int(self.cfg["ensemble"]["membros"])):
            ck = torch.load(self.pasta(seed) / f"tft_m{m}.pt", map_location=self.dev, weights_only=False)
            mod = self._novo_tft(ck["hp"], len(quantis))
            mod.load_state_dict(ck["estado"])
            mods.append(mod)
        return mods

    # ------------------------------------------------------------------ previsão do ensemble para um θ
    def orcamento(self) -> int:
        """Avaliações de cada otimizador: as do ICSO-PP, N·(T+1) (população inicial + T gerações), a menos
        que o config fixe outro número."""
        o = self.cfg["otimizadores"].get("orcamento", "auto")
        if o in (None, "auto"):
            return int(self.cfg["icso"]["N"]) * (int(self.cfg["icso"]["T"]) + 1)
        return int(o)

    def theta0(self, saidas) -> np.ndarray:
        iq = int(saidas["iq"][0])
        return np.concatenate([saidas["cabecas"][:, iq, :].ravel(), [0.0]])

    def sigma_ale(self, saidas, idx=None):
        quantis = list(self.cfg["tft"]["quantis"])
        a, b = quantis.index(0.1), quantis.index(0.9)
        Q = saidas["Q"] if idx is None else saidas["Q"][:, idx]
        pcs = self.pcs if idx is None else self.pcs[idx]
        return np.abs(Q[..., b] - Q[..., a]).mean(axis=0) * pcs / (2 * Z90)

    def prever_ensemble(self, saidas, theta, gama=None, idx=None):
        """ŷ e σ_tot com as cabeças medianas de θ; gama=None usa exp(θ[-1]); gama=0 dá só σ_epi."""
        Z = saidas["Z"] if idx is None else saidas["Z"][:, idx]
        pcs = self.pcs if idx is None else self.pcs[idx]
        M, n, H = Z.shape
        W = theta[: M * (H + 1)].reshape(M, H + 1)
        ym = (np.einsum("mnh,mh->mn", Z.astype(np.float64), W[:, :-1]) + W[:, -1:]) * pcs[None, :]
        yhat = np.clip(ym.mean(axis=0), 0.0, self.ymax)
        g = float(np.exp(theta[-1])) if gama is None else float(gama)
        sig = np.sqrt(ym.var(axis=0) + g * self.sigma_ale(saidas, idx) ** 2)
        return yhat, sig

    # ================================================================== Estágio 3
    def aptidao_tft(self, saidas, familias=("hora", "regime", "tercil")):
        v = self.val
        Zv = np.transpose(saidas["Z"][:, v], (1, 0, 2))
        P = self.P.iloc[v]
        return ft.AptidaoCondicional(Zv, self.pcs[v], self.y[v], self.sigma_ale(saidas, v), self.h[v], self.hora[v],
                                     self.regime[v], P["paridade"].to_numpy(), self.theta0(saidas), self.cfg["icso"],
                                     self.cfg["conformal"], self.ymax, self.p_por_h(), com_gama=True,
                                     familias=familias)

    def estagio3(self, seed: int, saidas) -> dict:
        arq = self.pasta(seed) / "icso.npz"
        if arq.exists():
            return _ler_npz(arq)
        log.info("  semente %d: Estágio 3 (ICSO-PP em %d parâmetros)", seed, len(self.theta0(saidas)))
        f = self.aptidao_tft(saidas)
        rng = np.random.default_rng(seed * 7919 + 17)
        r = op.rodar("ICSO-PP", f, f.d, rng, self.cfg["icso"], self.orcamento())
        th = f.theta(r["u"])
        res = {"theta": th, "u": r["u"], "F": np.array([r["f"]]), "hist": r["hist"], "avaliacoes": np.array([r["avaliacoes"]]),
               "seg": np.array([r["seg"]]), "gama": np.array([np.exp(th[-1])])}
        _salvar_npz(arq, **res)
        log.info("    F_IS = %.4f (Adam = 1), γ* = %.3f, %d avaliações, %.1f min", r["f"], np.exp(th[-1]), r["avaliacoes"],
                 r["seg"] / 60)
        return res

    # ================================================================== Estágio 4 e camadas
    def piso_e_cortes(self, sig):
        """Piso σ_fl (percentil p(h) na validação) e cortes de tercil de σ̃, por horizonte (fixos)."""
        piso, cortes = {}, {}
        for h, nome in enumerate(HORIZONTES):
            v = self.val[self.h[self.val] == h]
            piso[h] = float(np.percentile(sig[v], dd.p_piso(nome)))
            st = np.maximum(sig[v], piso[h])
            cortes[h] = tuple(np.percentile(st, [100 / 3, 200 / 3]))
        return piso, cortes

    def sigma_tercil(self, sig, piso, cortes):
        st = np.empty_like(sig)
        terc = np.empty(len(sig), dtype=int)
        for h in range(len(HORIZONTES)):
            m = self.h == h
            st[m] = np.maximum(sig[m], piso[h])
            terc[m] = np.digitize(st[m], cortes[h])
        return st, terc

    def _familias(self, idx, terc, familias):
        cod = {"hora": self.hora[idx] - 6, "regime": self.regime[idx], "tercil": terc[idx]}
        niv = {"hora": 13, "regime": 3, "tercil": 3}
        return cc.Familias({k: cod[k] for k in familias}, {k: niv[k] for k in familias})

    def _janelas(self, h, estatica=False):
        """(mês, calibração, teste) do horizonte h. A calibração só usa alvos já observados na primeira
        emissão de teste do mês: no DA, a primeira emissão é às 12:00 do último dia do mês anterior, então as
        horas da tarde desse dia saem da janela (nos horizontes intradiários nada muda)."""
        for m in self.meses:
            cal = (self.m_cal[self.meses[0]] if estatica else self.m_cal[m]) & (self.h == h)
            te = self.m_te[m] & (self.h == h)
            if te.any():
                cal = cal & (self.t_alvo < self.i_emis[te].min())
                yield m, np.where(cal)[0], np.where(te)[0]

    def _saida(self, yhat, grade=False):
        n = len(self.te)
        out = {"L": np.full(n, np.nan), "U": np.full(n, np.nan), "yhat": yhat[self.te].astype(np.float64)}
        if grade:
            out["Q"] = np.full((n, len(bl.GRADE_P)), np.nan)
        return out

    def camada_cc(self, base, familias=("hora", "regime", "tercil"), interacoes=False, delta=None,
                  estatica=False, grade=False, horizontes=None):
        """Conformal condicional (Estágio 4) sobre uma Base: em cada janela, os escores de cada lado usam a escala
        daquele lado e os limiares saem do LP da janela; grava também o tercil de cada par de teste."""
        tau = 1.0 - (self.alpha - (self.delta if delta is None else delta)) / 2.0
        n = len(self.te)
        out = self._saida(np.zeros(len(self.P)), grade)
        out["qh"], out["ql"] = np.full(n, np.nan), np.full(n, np.nan)
        out["tercil"] = np.full(n, -1, dtype=np.int64)
        diag = {"merged": [], "t_calib": []}
        janelas, tarefas = [], []
        for h in (range(len(HORIZONTES)) if horizontes is None else horizontes):
            for m, ic, it in self._janelas(h, estatica):
                yhat, s_lo, s_hi, terc = base(h, m)
                Ep, Em = cc.escores(self.y[ic], yhat[ic], s_lo[ic], s_hi[ic])
                fc, fte = self._familias(ic, terc, familias), self._familias(it, terc, familias)
                janelas.append((h, m, it))
                tarefas.append((Ep, Em, fc.codigos, fte.codigos, fc.niveis, tau, self.n_min, interacoes,
                                bl.GRADE_P if grade else None))
        res = cc.mapear(cc.tarefa_janela_cc, tarefas, self.processos)
        for (h, m, it), (qh, ql, f1, f2, G, t_pi) in zip(janelas, res):
            yhat, s_lo, s_hi, terc = base(h, m)
            L, U = cc.intervalo(yhat[it], s_lo[it], ql, qh, self.ymax, sig_hi=s_hi[it])
            pos = self.pos_te[it]
            out["L"][pos], out["U"][pos], out["yhat"][pos] = L, U, yhat[it]
            out["qh"][pos], out["ql"][pos] = qh, ql
            if terc is not None:
                out["tercil"][pos] = terc[it]
            diag["t_calib"].append(t_pi)
            diag["merged"].append((h, m, bool(f1.get("regime") or f2.get("regime") or f1.get("tercil")
                                              or f2.get("tercil")), bool(f1.get("hora") or f2.get("hora"))))
            if grade:
                s_ = np.where(bl.GRADE_P[None, :] > 0.5, s_hi[it][:, None], s_lo[it][:, None]) + cc.EPS_SIGMA
                Gf = np.where(np.isfinite(G), G, 1e3)
                sinal = np.where(bl.GRADE_P > 0.5, 1.0, -1.0)[None, :]
                out["Q"][pos] = np.clip(yhat[it][:, None] + sinal * Gf * s_, 0, self.ymax)
        return out, diag

    def camada_mondrian(self, yhat, sig, piso_fixo=None, celula="hora", grade=False, horizontes=None):
        """Camada do artigo 1 (e do HEC): piso (fixo da validação ou reestimado em cada janela), quantis
        Mondrian por célula em 1-α/2 com o quantil global de reserva, fator de escala s* para cobertura
        1-α+δ na calibração e, se pedido, a CPD dos resíduos normalizados assinados da célula."""
        out = self._saida(yhat, grade)
        tau_c = 1.0 - self.alpha / 2.0
        alvo = 1.0 - self.alpha + self.delta
        diag = {"s": [], "exp": [], "fallback": [], "t_calib": []}
        for h in (range(len(HORIZONTES)) if horizontes is None else horizontes):
            nome = HORIZONTES[h]
            for m, ic, it in self._janelas(h):
                t0 = time.time()
                piso = piso_fixo[h] if piso_fixo is not None else float(np.percentile(sig[ic], dd.p_piso(nome)))
                sc, ste = np.maximum(sig[ic], piso), np.maximum(sig[it], piso)
                Ep, Em = cc.escores(self.y[ic], yhat[ic], sc)
                if celula == "hora":
                    gc, gt, ng = self.hora[ic] - 6, self.hora[it] - 6, 13
                    Qp, fb1 = cc.quantis_mondrian(Ep, gc, ng, tau_c, self.n_min)
                    Qm, fb2 = cc.quantis_mondrian(Em, gc, ng, tau_c, self.n_min)
                    qpc, qmc, qpt, qmt = Qp[gc], Qm[gc], Qp[gt], Qm[gt]
                else:
                    qpc, qmc, fb1 = self._mondrian_regime_hora(Ep, Em, ic, ic, tau_c)
                    qpt, qmt, _ = self._mondrian_regime_hora(Ep, Em, ic, it, tau_c)
                    fb2 = 0
                s, e = cc.ajustar_escala(yhat[ic], sc, qmc, qpc, self.y[ic], alvo, self.ymax)
                L, U = cc.intervalo(yhat[it], ste, s * qmt, s * qpt, self.ymax)
                pos = self.pos_te[it]
                out["L"][pos], out["U"][pos] = L, U
                diag["s"].append(s)
                diag["exp"].append(e)
                diag["fallback"].append(fb1 + fb2)
                diag["t_calib"].append(time.time() - t0)
                if grade:
                    r = (self.y[ic] - yhat[ic]) / (sc + cc.EPS_SIGMA)
                    gc_, gt_ = self.hora[ic] - 6, self.hora[it] - 6
                    eq = cc.quantis_cpd(r, gc_, gt_, 13, bl.GRADE_P, self.n_min)
                    out["Q"][pos] = np.clip(yhat[it][:, None] + eq * (ste[:, None] + cc.EPS_SIGMA), 0, self.ymax)
        return out, diag

    def _mondrian_regime_hora(self, Ep, Em, ic, ialvo, tau_c):
        """Quantis por célula regime×hora com fusão: regime vizinho na mesma hora, depois a hora toda,
        depois o global (n_min); o posto acima de n_k também cai no global."""
        rc, hc = self.regime[ic], self.hora[ic]
        cache = {}
        qp, qm = np.empty(len(ialvo)), np.empty(len(ialvo))
        fb = 0
        Qgp, Qgm = cc.quantil_split(Ep, tau_c), cc.quantil_split(Em, tau_c)
        for k, i in enumerate(ialvo):
            chave = (self.regime[i], self.hora[i])
            if chave not in cache:
                r, hh = chave
                m = (rc == r) & (hc == hh)
                if m.sum() < self.n_min:
                    viz = [1] if r != 1 else [max((0, 2), key=lambda v: ((rc == v) & (hc == hh)).sum())]
                    m = m | ((rc == viz[0]) & (hc == hh))
                if m.sum() < self.n_min:
                    m = hc == hh
                nk = int(m.sum())
                if nk < self.n_min or np.ceil((nk + 1) * tau_c) > nk:
                    cache[chave] = (Qgp, Qgm, 1)
                else:
                    cache[chave] = (cc.quantil_split(Ep[m], tau_c), cc.quantil_split(Em[m], tau_c), 0)
            qp[k], qm[k], f = cache[chave]
            fb += f
        return qp, qm, fb

    def camada_mondrian_base(self, base, celula="hora", horizontes=None):
        """Mondrian (camadas L3 e L4) sobre uma Base, com a escala de cada lado (já com piso) e o fator s* da
        calibração, como na camada do artigo 1."""
        out = self._saida(np.zeros(len(self.P)))
        tau_c = 1.0 - self.alpha / 2.0
        alvo = 1.0 - self.alpha + self.delta
        for h in (range(len(HORIZONTES)) if horizontes is None else horizontes):
            for m, ic, it in self._janelas(h):
                yhat, s_lo, s_hi, _terc = base(h, m)
                Ep, Em = cc.escores(self.y[ic], yhat[ic], s_lo[ic], s_hi[ic])
                if celula == "hora":
                    gc, gt, ng = self.hora[ic] - 6, self.hora[it] - 6, 13
                    Qp, _ = cc.quantis_mondrian(Ep, gc, ng, tau_c, self.n_min)
                    Qm, _ = cc.quantis_mondrian(Em, gc, ng, tau_c, self.n_min)
                    qpc, qmc, qpt, qmt = Qp[gc], Qm[gc], Qp[gt], Qm[gt]
                else:
                    qpc, qmc, _ = self._mondrian_regime_hora(Ep, Em, ic, ic, tau_c)
                    qpt, qmt, _ = self._mondrian_regime_hora(Ep, Em, ic, it, tau_c)
                s, _ = cc.ajustar_escala(yhat[ic], s_lo[ic], qmc, qpc, self.y[ic], alvo, self.ymax, sig_hi=s_hi[ic])
                L, U = cc.intervalo(yhat[it], s_lo[it], s * qmt, s * qpt, self.ymax, sig_hi=s_hi[it])
                pos = self.pos_te[it]
                out["L"][pos], out["U"][pos], out["yhat"][pos] = L, U, yhat[it]
        return out

    def camada_split_abs(self, base, grade=False, horizontes=None):
        out = self._saida(np.zeros(len(self.P)), grade)
        for h in (range(len(HORIZONTES)) if horizontes is None else horizontes):
            for m, ic, it in self._janelas(h):
                yhat = base(h, m)[0]
                r = self.y[ic] - yhat[ic]
                L, U = cc.split_absoluto(r, yhat[it], 1 - self.alpha + self.delta, self.ymax)
                pos = self.pos_te[it]
                out["L"][pos], out["U"][pos], out["yhat"][pos] = L, U, yhat[it]
                if grade:
                    eq = cc.quantis_cpd(r, np.zeros(len(ic), int), np.zeros(len(it), int), 1, bl.GRADE_P, 1)
                    out["Q"][pos] = np.clip(yhat[it][:, None] + eq, 0, self.ymax)
        return out

    def camada_split_norm(self, base, horizontes=None):
        out = self._saida(np.zeros(len(self.P)))
        for h in (range(len(HORIZONTES)) if horizontes is None else horizontes):
            for m, ic, it in self._janelas(h):
                yhat, s_lo, s_hi, _terc = base(h, m)
                Ep, Em = cc.escores(self.y[ic], yhat[ic], s_lo[ic], s_hi[ic])
                qh, ql = cc.quantil_split(Ep, self.tau), cc.quantil_split(Em, self.tau)
                L, U = cc.intervalo(yhat[it], s_lo[it], np.full(len(it), ql), np.full(len(it), qh), self.ymax,
                                    sig_hi=s_hi[it])
                pos = self.pos_te[it]
                out["L"][pos], out["U"][pos], out["yhat"][pos] = L, U, yhat[it]
        return out

    def camada_mvp(self, base, grade=False, horizontes=None):
        out = self._saida(np.zeros(len(self.P)), grade)
        cmvp = self.cfg["conformal"]
        fams = ("hora", "regime", "tercil")
        janelas, tarefas = [], []
        for h in (range(len(HORIZONTES)) if horizontes is None else horizontes):
            for m, ic, it in self._janelas(h):
                yhat, s_lo, s_hi, terc = base(h, m)
                Ep, Em = cc.escores(self.y[ic], yhat[ic], s_lo[ic], s_hi[ic])
                Gc = cc.matriz_grupos(self._familias(ic, terc, fams))
                Gt = cc.matriz_grupos(self._familias(it, terc, fams))
                janelas.append((h, m, it))
                tarefas.append((Ep, Em, Gc, Gt, self.tau, cmvp["mvp_faixas"], cmvp["mvp_tolerancia"],
                                bl.GRADE_P if grade else None))
        res = cc.mapear(cc.tarefa_janela_mvp, tarefas, self.processos)
        for (h, m, it), (qh, ql, G) in zip(janelas, res):
            yhat, s_lo, s_hi, _terc = base(h, m)
            L, U = cc.intervalo(yhat[it], s_lo[it], ql, qh, self.ymax, sig_hi=s_hi[it])
            pos = self.pos_te[it]
            out["L"][pos], out["U"][pos], out["yhat"][pos] = L, U, yhat[it]
            if grade:
                s_ = np.where(bl.GRADE_P[None, :] > 0.5, s_hi[it][:, None], s_lo[it][:, None]) + cc.EPS_SIGMA
                Gf = np.where(np.isfinite(G), G, 1e3)
                sinal = np.where(bl.GRADE_P > 0.5, 1.0, -1.0)[None, :]
                out["Q"][pos] = np.clip(yhat[it][:, None] + sinal * Gf * s_, 0, self.ymax)
        return out

    def camada_cqr(self, Qall, idx_lo, idx_hi, grade=False):
        """CQR em (q_lo, q_hi) nas janelas móveis; com grade, cada par (p, 1-p) da grade é conformalizado
        para cobertura 1-2p. Qall: (n_pares, 21) em y."""
        yhat = Qall[:, bl.I_MEDIANA]
        out = self._saida(np.clip(yhat, 0, self.ymax), grade)
        nivel = 1 - self.alpha + self.delta
        g = list(bl.GRADE21)
        for h in range(len(HORIZONTES)):
            for m, ic, it in self._janelas(h):
                L, U = cc.cqr(Qall[ic, idx_lo], Qall[ic, idx_hi], self.y[ic], Qall[it, idx_lo], Qall[it, idx_hi], nivel,
                              self.ymax)
                pos = self.pos_te[it]
                out["L"][pos], out["U"][pos] = L, U
                if grade:
                    for c, p in enumerate(bl.GRADE_P):
                        if p > 0.5:
                            continue
                        a = int(np.argmin(np.abs(np.array(g) - p)))
                        b = int(np.argmin(np.abs(np.array(g) - (1 - p))))
                        lo, hi = cc.cqr(Qall[ic, a], Qall[ic, b], self.y[ic], Qall[it, a], Qall[it, b], 1 - 2 * p, self.ymax)
                        out["Q"][pos, c] = lo
                        out["Q"][pos, len(bl.GRADE_P) - 1 - c] = hi
        return out

    # ================================================================== Estágio 3 (v3): base híbrida TFT + LightGBM
    def grade_pesos(self) -> list:
        return [float(w) for w in (self.cfg.get("hibrido") or {}).get("pesos", [0.0, 0.2, 0.4, 0.6, 0.8, 1.0])]

    def lgbm_alvo_k(self) -> bool:
        """v3.1: o LightGBM aprende o índice de céu claro k = y/pcs (lgbm: alvo: k), como o TFT."""
        return str((self.cfg.get("lgbm") or {}).get("alvo", "y")).strip().lower() == "k"

    def quantis_lgbm(self, seed: int) -> dict:
        """21 quantis do LightGBM em todos os pares (o mesmo modelo do baseline LightGBM + CQR), em y."""
        arq = self.pasta(seed) / "lgbm_quantis.npz"
        if arq.exists():
            return _ler_npz(arq)
        X = self.tabular_todos()
        Ptr = self._tabelas_treino()
        Qall = np.zeros((len(self.P), len(bl.GRADE21)))
        t0 = time.time()
        for h, nome in enumerate(HORIZONTES):
            mtr = Ptr["h"].to_numpy() == h
            me = self.h == h
            mv = me & np.isin(np.arange(len(self.P)), self.val)
            esc = (Ptr["pcs"].to_numpy()[mtr], self.pcs[mv], self.pcs[me]) if self.lgbm_alvo_k() else None
            Q = bl.lgbm_quantis(X["tr"][mtr], Ptr["y"].to_numpy()[mtr], X["ev"][mv], self.y[mv], X["ev"][me],
                                bl.GRADE21, self.cfg["lgbm"], seed * 31 + h, escala=esc)
            Qall[me] = np.clip(np.sort(Q, axis=1), 0, self.ymax)
        t = (time.time() - t0) / 60
        log.info("  semente %d: LightGBM (%d modelos) em %.1f min", seed, 4 * len(bl.GRADE21), t)
        res = {"Qall": Qall, "t_min": np.array([t])}
        _salvar_npz(arq, **res)
        return res

    def base_tft(self, saidas, theta=None, gama=1.0):
        """ŷ do ensemble de TFTs (cabeças do Adam, ou θ) e as escalas de baixo e de cima: a dispersão entre os membros
        combinada com a metade de baixo (q0,5 − q0,1) e a de cima (q0,9 − q0,5) da faixa das cabeças de quantis."""
        th = self.theta0(saidas) if theta is None else theta
        y, sig_ep = self.prever_ensemble(saidas, th, gama=0.0)
        quantis = list(self.cfg["tft"]["quantis"])
        a, b, c = quantis.index(0.1), quantis.index(0.5), quantis.index(0.9)
        Q = saidas["Q"]
        lo = np.abs(Q[..., b] - Q[..., a]).mean(axis=0) * self.pcs / Z90
        hi = np.abs(Q[..., c] - Q[..., b]).mean(axis=0) * self.pcs / Z90
        g = float(gama)
        return y, np.sqrt(sig_ep ** 2 + g * lo ** 2), np.sqrt(sig_ep ** 2 + g * hi ** 2)

    def base_gbm(self, Qall):
        """ŷ do LightGBM (mediana) e as escalas de cada lado: as metades da faixa 2,5–97,5%, em desvios normais."""
        md, lo, hi = Qall[:, bl.I_MEDIANA], Qall[:, bl.I_LO], Qall[:, bl.I_HI]
        return md, (md - lo) / Z95, (hi - md) / Z95

    def variante(self, yT, loT, hiT, yG, loG, hiG, w):
        """(ŷ, escala de baixo, escala de cima, tercil) da combinação com peso w do TFT: pisos de cada lado e cortes
        dos tercis da dispersão média fixados na validação, por horizonte."""
        yh = np.clip(w * yT + (1 - w) * yG, 0, self.ymax)
        lo, hi = w * loT + (1 - w) * loG, w * hiT + (1 - w) * hiG
        p_lo, _ = self.piso_e_cortes(lo)
        p_hi, _ = self.piso_e_cortes(hi)
        for h in range(len(HORIZONTES)):
            m = self.h == h
            lo[m], hi[m] = np.maximum(lo[m], p_lo[h]), np.maximum(hi[m], p_hi[h])
        sm = 0.5 * (lo + hi)
        piso, cortes = self.piso_e_cortes(sm)
        _, terc = self.sigma_tercil(sm, piso, cortes)
        return yh, lo, hi, terc

    def _is_cruzado(self, var: dict, blocos: list) -> dict:
        """IS do conformal condicional cruzado: em cada bloco (chave, índices), calibra numa metade dos dias e avalia
        na outra, para cada variante. Devolve {(chave, w): soma do IS}."""
        par = self.P["paridade"].to_numpy().astype(int)
        fams = ("hora", "regime", "tercil")
        chaves, tarefas, alvos = [], [], []
        for chave, idx in blocos:
            for w, (yh, lo, hi, terc) in var.items():
                for A in (0, 1):
                    a, b = idx[par[idx] == A], idx[par[idx] != A]
                    if len(a) < 2 * self.n_min or len(b) == 0:
                        continue
                    Ep, Em = cc.escores(self.y[a], yh[a], lo[a], hi[a])
                    fa, fb = self._familias(a, terc, fams), self._familias(b, terc, fams)
                    tarefas.append((Ep, Em, fa.codigos, fb.codigos, fa.niveis, self.tau, self.n_min, False, None))
                    chaves.append((chave, w))
                    alvos.append(b)
        soma = {}
        for (chave, w), b, (qh, ql, *_r) in zip(chaves, alvos, cc.mapear(cc.tarefa_janela_cc, tarefas, self.processos)):
            yh, lo, hi, _t = var[w]
            L, U = cc.intervalo(yh[b], lo[b], ql, qh, self.ymax, sig_hi=hi[b])
            soma[(chave, w)] = soma.get((chave, w), 0.0) + float(mt.is_winkler(L, U, self.y[b], self.alpha).sum())
        return soma

    def _escolher(self, soma: dict, chaves, var: dict) -> dict:
        neutro = min(var, key=lambda w: abs(w - 0.5))
        out = {}
        for chave in chaves:
            cand = {w: soma.get((chave, w), np.inf) for w in var}
            out[chave] = min(cand, key=cand.get) if np.isfinite(min(cand.values())) else neutro
        return out

    def pesos_mensais(self, var: dict, horizontes=None) -> dict:
        """Peso do TFT em cada janela (h, m): o de menor IS na validação cruzada pelas metades dos dias da própria
        janela de calibração, com a camada condicional. A escolha é causal: nada do mês de teste entra."""
        blocos = [((h, m), ic) for h in (range(len(HORIZONTES)) if horizontes is None else horizontes)
                  for m, ic, _it in self._janelas(h)]
        return self._escolher(self._is_cruzado(var, blocos), [c for c, _i in blocos], var)

    def pesos_validacao(self, var: dict) -> dict:
        """Peso fixo por horizonte, escolhido do mesmo jeito no bloco de validação (ablação B5f)."""
        blocos = [(h, self.val[self.h[self.val] == h]) for h in range(len(HORIZONTES))]
        return self._escolher(self._is_cruzado(var, blocos), list(range(len(HORIZONTES))), var)

    def hibrido(self, seed: int, saidas) -> dict:
        """Base híbrida da semente: quantis do LightGBM, as variantes da grade de pesos e o peso de cada janela."""
        Qall = self.quantis_lgbm(seed)["Qall"]
        yT, loT, hiT = self.base_tft(saidas)
        yG, loG, hiG = self.base_gbm(Qall)
        var = {w: self.variante(yT, loT, hiT, yG, loG, hiG, w) for w in self.grade_pesos()}
        arq = self.pasta(seed) / "hibrido.npz"
        if arq.exists():
            z = _ler_npz(arq)
            pesos = {(int(h), int(m)): float(w) for h, m, w in z["pesos"]}
            pesos_val = {int(h): float(w) for h, w in z["pesos_val"]}
        else:
            t0 = time.time()
            pesos = self.pesos_mensais(var)
            pesos_val = self.pesos_validacao(var)
            t = (time.time() - t0) / 60
            _salvar_npz(arq, pesos=np.array([[h, m, w] for (h, m), w in pesos.items()], dtype=float),
                        pesos_val=np.array([[h, w] for h, w in pesos_val.items()], dtype=float), t_min=np.array([t]))
            media = {HORIZONTES[h]: round(float(np.mean([w for (hh, _m), w in pesos.items() if hh == h])), 2)
                     for h in range(len(HORIZONTES))}
            log.info("  semente %d: peso do TFT escolhido em cada janela (%.1f min); média por horizonte %s", seed, t,
                     media)
        return {"var": var, "pesos": pesos, "pesos_val": pesos_val, "Qall": Qall}

    def tercis_base(self, base) -> dict:
        """Tercil da dispersão e dispersão média de cada par de teste, como a base os usou (grupos do WGC)."""
        terc, sig = np.full(len(self.te), -1, dtype=np.int64), np.full(len(self.te), np.nan)
        for h in range(len(HORIZONTES)):
            for m, _ic, it in self._janelas(h):
                _y, lo, hi, tc = base(h, m)
                pos = self.pos_te[it]
                terc[pos], sig[pos] = tc[it], 0.5 * (lo[it] + hi[it])
        return {"tercil_te": terc, "sig_te": sig}

    # ================================================================== variantes do proposto
    VARIANTES = ("PROP", "MVP", "B1", "B2", "B3", "B4", "B4h", "B5a", "B5b", "B5c", "B5d", "B5f", "B5g",
                 "L1", "L2", "L3", "L4", "L5")

    def variantes(self, seed: int, saidas, hib) -> None:
        """PROP (B5 = L6), MVP, a ablação (B1–B4, B4h, B5a–B5g) e as camadas L1–L5, sobre a mesma base."""
        pend = [n for n in self.VARIANTES if not self.arq_prev(seed, n).exists()]
        var, pesos = hib["var"], hib["pesos"]
        b_hib = Base(var, pesos)
        if not (self.pasta(seed) / "tercis.npz").exists():
            _salvar_npz(self.pasta(seed) / "tercis.npz", **self.tercis_base(b_hib))
        if not pend:
            return
        th0 = self.theta0(saidas)
        y_0, sig_0 = self.prever_ensemble(saidas, th0, gama=1.0)
        piso_0, cortes_0 = self.piso_e_cortes(sig_0)
        st_0, terc_0 = self.sigma_tercil(sig_0, piso_0, cortes_0)
        y_e, sig_e = self.prever_ensemble(saidas, th0, gama=0.0)
        piso_e, _ = self.piso_e_cortes(sig_e)
        w1, w0 = max(var), min(var)              # só o TFT e só o LightGBM

        def grava(nome, out, diag=None):
            _salvar_npz(self.arq_prev(seed, nome), **out)
            if diag is not None:
                _json(self.arq_prev(seed, nome).with_suffix(".json"), diag)

        for nome in pend:
            t0 = time.time()
            if nome == "PROP":
                out, dg = self.camada_cc(b_hib, grade=True)
                grava(nome, out, {"merged": dg["merged"], "t_calib_mes_s": float(np.sum(dg["t_calib"]) / 12),
                                  "pesos": [[h, m, w] for (h, m), w in sorted(pesos.items())]})
            elif nome == "MVP":
                grava(nome, self.camada_mvp(b_hib, grade=True))
            elif nome == "B1":
                out, _ = self.camada_mondrian(y_e, sig_e, piso_fixo=piso_e, horizontes=[0, 2, 3])
                grava(nome, out)
            elif nome == "B2":
                out, _ = self.camada_mondrian(y_0, sig_0, piso_fixo=piso_0, horizontes=[0, 2, 3])
                grava(nome, out)
            elif nome == "B3":
                out, _ = self.camada_cc(Base.fixa(y_0, st_0, terc=terc_0), horizontes=[0, 2, 3])
                grava(nome, out)
            elif nome == "B4":
                out, _ = self.camada_cc(Base({w1: var[w1]}), horizontes=[0, 2, 3])
                grava(nome, out)
            elif nome == "B4h":
                # Estágio 3 do artigo 1: ICSO-PP nas cabeças medianas e em γ, sobre o B4 (só o TFT)
                s3 = self.estagio3(seed, saidas)
                yI, loI, hiI = self.base_tft(saidas, s3["theta"], gama=float(np.exp(s3["theta"][-1])))
                out, _ = self.camada_cc(Base({1.0: self.variante(yI, loI, hiI, yI, loI, hiI, 1.0)}), horizontes=[0, 2, 3])
                grava(nome, out)
            elif nome == "B5a":
                out, _ = self.camada_cc(b_hib, familias=("hora", "tercil"), horizontes=[0, 2, 3])
                grava(nome, out)
            elif nome == "B5b":
                out, _ = self.camada_cc(b_hib, interacoes=True, horizontes=[0, 2, 3])
                grava(nome, out)
            elif nome == "B5c":
                out, _ = self.camada_cc(b_hib, delta=0.0, horizontes=[0, 2, 3])
                grava(nome, out)
            elif nome == "B5d":
                out, _ = self.camada_cc(b_hib, estatica=True, horizontes=[0, 2, 3])
                grava(nome, out)
            elif nome == "B5f":
                fixos = {k: hib["pesos_val"][k[0]] for k in pesos}
                out, _ = self.camada_cc(Base(var, fixos), horizontes=[0, 2, 3])
                grava(nome, out)
            elif nome == "B5g":
                out, _ = self.camada_cc(Base({w0: var[w0]}), horizontes=[0, 2, 3])
                grava(nome, out)
            elif nome == "L1":
                grava(nome, self.camada_split_abs(b_hib, horizontes=[0, 3]))
            elif nome == "L2":
                grava(nome, self.camada_split_norm(b_hib, horizontes=[0, 3]))
            elif nome == "L3":
                grava(nome, self.camada_mondrian_base(b_hib, horizontes=[0, 3]))
            elif nome == "L4":
                grava(nome, self.camada_mondrian_base(b_hib, celula="regime_hora", horizontes=[0, 3]))
            elif nome == "L5":
                grava(nome, self.camada_mvp(b_hib, horizontes=[0, 3]))
            log.info("    %s pronto (%.1f s)", nome, time.time() - t0)

    # ================================================================== otimizadores (Tab. 10 da v2; etapa opcional na v3)
    def otimizadores(self, seed: int, saidas, s3) -> None:
        lista = [o for o in self.cfg["otimizadores"]["lista"] if o != "ICSO-PP"]
        orc = self.orcamento()
        f = None
        for k_op, nome in enumerate(lista):
            arq = self.arq_prev(seed, f"OPT_{nome}")
            if arq.exists():
                continue
            if f is None:
                f = self.aptidao_tft(saidas)
            log.info("  semente %d: otimizador %s (%d avaliações)", seed, nome, orc)
            f.avaliacoes = 0
            rng = np.random.default_rng(seed * 7919 + 1000 * (k_op + 1))
            r = op.rodar(nome, f, f.d, rng, self.cfg["icso"], orc)
            th = f.theta(r["u"])
            out = self._avaliar_theta_da(saidas, th)
            out.update({"F": np.array([r["f"]]), "hist": r["hist"], "avaliacoes": np.array([r["avaliacoes"]]),
                        "seg": np.array([r["seg"]])})
            _salvar_npz(arq, **out)
            log.info("    %s: F = %.4f, %.1f min", nome, r["f"], r["seg"] / 60)
        arq = self.arq_prev(seed, "OPT_Adam")
        if not arq.exists():
            out = self._avaliar_theta_da(saidas, self.theta0(saidas), gama=1.0)
            out.update({"F": np.array([1.0]), "hist": np.ones(1), "avaliacoes": np.array([0]), "seg": np.array([0.0])})
            _salvar_npz(arq, **out)

    def _avaliar_theta_da(self, saidas, theta, gama=None):
        y_, sig = self.prever_ensemble(saidas, theta, gama=gama)
        piso, cortes = self.piso_e_cortes(sig)
        st, terc = self.sigma_tercil(sig, piso, cortes)
        out, _ = self.camada_cc(Base.fixa(y_, st, terc=terc), horizontes=[3])
        return out

    # ================================================================== PRIOR (Boot-LSTM do artigo 1) e B4e
    def _tabelas_treino(self):
        if not hasattr(self, "_Ptr"):
            self._Ptr = dd.tabela_pares(self.site, blocos=(1,), limiares=tuple(self.cfg["conformal"]["limiares_regime"]))
        return self._Ptr

    def prior(self, seed: int) -> None:
        nomes = ["PRIOR", "B4e"]
        if all(self.arq_prev(seed, n).exists() for n in nomes) and (self.pasta(seed) / "lstm_saidas.npz").exists():
            return
        arq = self.pasta(seed) / "lstm_saidas.npz"
        cfgL = self.cfg["lstm_prior"]
        M = int(cfgL["membros"])
        if arq.exists():
            S = _ler_npz(arq)
        else:
            S = self._treinar_lstm_todos(seed, cfgL, M)
            _salvar_npz(arq, **S)
        # Estágio 3 de cada horizonte: Mondrian (PRIOR) e condicional (B4e)
        Z, k0 = S["Z"], S["cab0"]
        orc = self.orcamento()
        yhat_p = np.zeros(len(self.P))
        sig_p = np.zeros(len(self.P))
        yhat_b = np.zeros(len(self.P))
        sig_b = np.zeros(len(self.P))
        for h, nome in enumerate(HORIZONTES):
            sel = self.h == h
            iv = np.where(sel & np.isin(np.arange(len(self.P)), self.val))[0]
            Zv = np.transpose(Z[:, iv], (1, 0, 2)).astype(np.float64)
            th0 = k0[:, h].ravel()
            P = self.P.iloc[iv]
            arq_t = self.pasta(seed) / f"lstm_theta_h{h}.npz"
            if arq_t.exists():
                tt = _ler_npz(arq_t)
            else:
                rng = np.random.default_rng(seed * 104729 + h)
                fm = ft.AptidaoMondrian(Zv, self.pcs[iv], self.y[iv], self.hora[iv], P["paridade"].to_numpy(), th0,
                                        self.cfg["icso"], self.cfg["conformal"], self.ymax, dd.p_piso(nome))
                r1 = op.rodar("ICSO-PP", fm, fm.d, rng, self.cfg["icso"], orc)
                fc = ft.AptidaoCondicional(Zv, self.pcs[iv], self.y[iv], None, self.h[iv], self.hora[iv], self.regime[iv],
                                           P["paridade"].to_numpy(), th0, self.cfg["icso"], self.cfg["conformal"], self.ymax,
                                           self.p_por_h(), com_gama=False, clip_membros=True)
                r2 = op.rodar("ICSO-PP", fc, fc.d, rng, self.cfg["icso"], orc)
                tt = {"prior": fm.theta(r1["u"]), "b4e": fc.theta(r2["u"]), "F_prior": np.array([r1["f"]]),
                      "F_b4e": np.array([r2["f"]]), "seg": np.array([r1["seg"] + r2["seg"]])}
                _salvar_npz(arq_t, **tt)
            idx = np.where(sel)[0]
            for chave, ys, ss in (("prior", yhat_p, sig_p), ("b4e", yhat_b, sig_b)):
                W = tt[chave].reshape(M, -1)
                ym = (np.einsum("mnh,mh->mn", Z[:, idx].astype(np.float64), W[:, :-1]) + W[:, -1:]) * self.pcs[idx][None]
                ym = np.clip(ym, 0, self.ymax)
                ys[idx] = np.clip(ym.mean(0), 0, self.ymax)
                ss[idx] = ym.std(0)
        o1, dg = self.camada_mondrian(yhat_p, sig_p, piso_fixo=None, grade=True)
        _salvar_npz(self.arq_prev(seed, "PRIOR"), **o1)
        _json(self.arq_prev(seed, "PRIOR").with_suffix(".json"), {"s": dg["s"], "exp": dg["exp"], "fallback": dg["fallback"]})
        piso_b, cortes_b = self.piso_e_cortes(sig_b)
        st_b, terc_b = self.sigma_tercil(sig_b, piso_b, cortes_b)
        o2, _ = self.camada_cc(Base.fixa(yhat_b, st_b, terc=terc_b), horizontes=[0, 2, 3])
        _salvar_npz(self.arq_prev(seed, "B4e"), **o2)
        _salvar_npz(self.pasta(seed) / "prior_previsoes.npz", yhat=yhat_p, sig=sig_p)
        log.info("  semente %d: PRIOR e B4e prontos", seed)

    def _dados_lstm(self, Pp, k_fill=None, rolling=None, nwp=None):
        i, j = Pp["i"].to_numpy(), Pp["j"].to_numpy()
        return dd.contexto_lstm(self.site, i, j, k_fill, rolling, nwp)

    def _treinar_lstm_todos(self, seed, cfgL, M):
        site = self.site
        Ptr = self._tabelas_treino()
        n = site.n
        tr_rows = site.bloco[:n] == 1
        base = dd.sequencia_lstm_base(site)
        st_seq = dd._stats(base[:n], tr_rows)
        T = tr.TensoresLSTM(site, self.dev, base, st_seq)
        H = int(cfgL["Hz"])
        Z = np.zeros((M, len(self.P), H), dtype=np.float32)
        cab0 = np.zeros((M, len(HORIZONTES), H + 1))
        t0 = time.time()
        for h, nome in enumerate(HORIZONTES):
            Pt = Ptr[Ptr["h"] == h]
            Pv = self.P.iloc[self.val][self.P.iloc[self.val]["h"] == h]
            Ct = self._dados_lstm(Pt)
            st_ctx = dd._stats(Ct)
            norm = lambda X: np.nan_to_num((X - st_ctx[0]) / st_ctx[1]).astype(np.float32)  # noqa: E731
            Ct, Cv = norm(Ct), norm(self._dados_lstm(Pv))
            idx_h = np.where(self.h == h)[0]
            Ce = norm(self._dados_lstm(self.P.iloc[idx_h]))
            dias_t = Pt["data"].to_numpy()
            for m in range(M):
                rng = np.random.default_rng(seed * 2000 + 100 * h + m)
                ud = np.unique(dias_t)
                sorteio = rng.choice(ud, size=len(ud), replace=True)
                cont = dict(zip(*np.unique(sorteio, return_counts=True)))
                w = np.array([cont.get(d, 0) for d in dias_t], dtype=np.float32)
                hp = tr.jitter({k: cfgL[k] for k in ("lr", "dropout", "weight_decay")} | {"batch": cfgL["batch"]}, rng)
                hp.update({"H": cfgL["H"], "Hz": cfgL["Hz"], "paciencia": cfgL["paciencia"],
                           "max_epocas": cfgL["max_epocas"]})
                mod, info = tr.treinar_lstm(T, Ct, Pt["i"].to_numpy(), Pt["y"].to_numpy(), Pt["pcs"].to_numpy(), w,
                                            Cv, Pv["i"].to_numpy(), Pv["y"].to_numpy(), Pv["pcs"].to_numpy(), hp,
                                            seed * 2000 + 100 * h + m)
                _, z = tr.inferir_lstm(mod, T, self.P["i"].to_numpy()[idx_h], Ce)
                Z[m, idx_h] = z
                cab0[m, h] = tr.cabeca_lstm(mod)
                torch.save({"estado": mod.state_dict(), "hp": hp, "st_ctx": st_ctx, "st_seq": st_seq},
                           self.pasta(seed) / f"lstm_h{h}_m{m}.pt")
            log.info("    LSTM %s: %d membros (%.1f min até aqui)", nome, M, (time.time() - t0) / 60)
        return {"Z": Z, "cab0": cab0, "t_min": np.array([(time.time() - t0) / 60])}

    # ================================================================== TFT nativo e TFT + CQR
    def tft_nativo(self, seed: int) -> None:
        if self.arq_prev(seed, "TFT").exists() and self.arq_prev(seed, "CQR_TFT").exists():
            return
        arq = self.pasta(seed) / "tft_nativo.npz"
        if arq.exists():
            Qy = _ler_npz(arq)["Qy"]
        else:
            T = self.tensores_tft()
            w_tr = (self.site.valido & (self.site.bloco == 1)).astype(np.float32)
            w_va = (self.site.valido & (self.site.bloco == 2)).astype(np.float32)
            log.info("  semente %d: TFT nativo (21 quantis)", seed)
            mod, _ = tr.treinar_tft(self.site, T, dict(self.cfg["tft"]), list(map(float, bl.GRADE21)), seed * 1000 + 999,
                                    w_tr, w_va, rotulo=f"s{seed} nativo: ")
            out = tr.inferir_tft(mod, T, self.emis)
            Qy = np.sort(out["q"][self.pos_emis, self.j], axis=1) * self.pcs[:, None]
            Qy = np.clip(Qy, 0, self.ymax)
            _salvar_npz(arq, Qy=Qy)
        nat = {"L": Qy[self.te, bl.I_LO], "U": Qy[self.te, bl.I_HI], "yhat": Qy[self.te, bl.I_MEDIANA],
               "Q": Qy[self.te][:, bl.I_GRADE]}
        _salvar_npz(self.arq_prev(seed, "TFT"), **nat)
        _salvar_npz(self.arq_prev(seed, "CQR_TFT"), **self.camada_cqr(Qy, bl.I_LO, bl.I_HI, grade=True))

    # ================================================================== LightGBM + CQR e HEC-XGB
    def tabular_todos(self):
        if not hasattr(self, "_Xtab"):
            Ptr = self._tabelas_treino()
            self._Xtab = {"tr": dd.tabular(self.site, Ptr["i"].to_numpy(), Ptr["j"].to_numpy()),
                          "ev": dd.tabular(self.site, self.P["i"].to_numpy(), self.P["j"].to_numpy())}
        return self._Xtab

    def lgbm(self, seed: int) -> None:
        if self.arq_prev(seed, "LGBM_CQR").exists():
            return
        Qall = self.quantis_lgbm(seed)["Qall"]
        _salvar_npz(self.arq_prev(seed, "LGBM_CQR"), **self.camada_cqr(Qall, bl.I_LO, bl.I_HI, grade=True))

    def hec(self, seed: int) -> None:
        if self.arq_prev(seed, "HEC").exists():
            return
        X = self.tabular_todos()
        Ptr = self._tabelas_treino()
        yhat, sig = np.zeros(len(self.P)), np.zeros(len(self.P))
        gpu = self.dev.type == "cuda" and bool(self.cfg["hec"].get("usar_gpu", True))
        if gpu and torch.cuda.get_device_properties(0).total_memory < 7.5 * 2 ** 30:
            gpu = False       # XGBoost guarda memória da GPU até o fim do processo; com < 8 GB, sobra pouco
        self._liberar_gpu()                     # para os TFTs
        t0 = time.time()
        for h in range(len(HORIZONTES)):
            mt = Ptr["h"].to_numpy() == h
            me = self.h == h
            mv = me & np.isin(np.arange(len(self.P)), self.val)
            pr = bl.xgb_ensemble(X["tr"][mt], Ptr["y"].to_numpy()[mt], X["ev"][mv], self.y[mv], X["ev"][me], self.cfg["hec"],
                                 seed * 53 + h, int(self.cfg["hec"]["membros"]), gpu)
            yhat[me] = np.clip(pr.mean(0), 0, self.ymax)
            sig[me] = pr.std(0)
        log.info("  semente %d: HEC-XGB (%s) em %.1f min", seed, "GPU" if gpu else "CPU", (time.time() - t0) / 60)
        out, dg = self.camada_mondrian(yhat, sig, piso_fixo=None, grade=True)
        _salvar_npz(self.arq_prev(seed, "HEC"), **out)

    # ================================================================== CH-PeEn (determinístico)
    def chpeen(self) -> None:
        arq = self.arq_prev(None, "CHPeEn")
        if arq.exists():
            return
        _salvar_npz(arq, **bl.chpeen(self.site, self.P.iloc[self.te]))

    # ================================================================== testes de estresse (Tab. 11)
    def estresse(self, seed: int, saidas, hib) -> None:
        """DA com entradas degradadas (S1–S5): TFTs e LightGBM (o do DA, treinado uma vez com o histórico limpo)
        preveem com as entradas do cenário, o peso de cada janela é escolhido de novo e a camada é recalibrada."""
        cen = ["S1", "S2", "S3", "S4", "S5"]
        pend = [c for c in cen if not (self.arq_prev(seed, f"STRESS_{c}_PROP").exists()
                                        and self.arq_prev(seed, f"STRESS_{c}_PRIOR").exists())]
        if not pend:
            return
        site = self.site
        da = np.where((self.h == 3) & (self.P["bloco"].to_numpy() >= 3))[0]
        emis_da = np.unique(self.P["i"].to_numpy()[da])
        cfg_e = self.cfg["estresse"]
        rng = np.random.default_rng(seed * 4241 + 7)
        desde = int(np.where(site.bloco[:site.n] >= 3)[0].min()) - dd.ENC - 48
        entradas = {}
        for c in cen:                            # sorteios na mesma ordem de sempre, para os cenários não mudarem
            nwp, P_ = site.nwp, None
            kf, yf, R = site.k_fill, site.y_fill, site.rolling
            if c in ("S1", "S2"):
                nwp = dd.nwp_ruidoso(site, cfg_e["ruido"][0 if c == "S1" else 1], rng, emis_da)
            elif c == "S3":
                nwp = dd.nwp_atrasado(site, self.cfg, emis_da, 24)
            else:
                tirar = dd.lacunas_aleatorias(site, cfg_e["lacunas"][0 if c == "S4" else 1], rng, max(desde, dd.ENC))
                kf, yf, R = dd.passado_com_lacunas(site, tirar)
                P_ = site.passado_pad(kf, yf, R)
            entradas[c] = (nwp, kf, yf, R, P_)
        # LightGBM do DA com o histórico limpo, aplicado às entradas de cada cenário
        X = self.tabular_todos()
        Ptr = self._tabelas_treino()
        mtr = Ptr["h"].to_numpy() == 3
        mv = (self.h == 3) & np.isin(np.arange(len(self.P)), self.val)
        Pd = self.P.iloc[da]
        Xaps = [dd.tabular(site, Pd["i"].to_numpy(), Pd["j"].to_numpy(), entradas[c][1], entradas[c][3], entradas[c][0])
                for c in pend]
        esc = ((Ptr["pcs"].to_numpy()[mtr], self.pcs[mv], [self.pcs[da]] * len(Xaps)) if self.lgbm_alvo_k()
               else None)
        Qg = bl.lgbm_quantis(X["tr"][mtr], Ptr["y"].to_numpy()[mtr], X["ev"][mv], self.y[mv], Xaps, bl.GRADE21,
                             self.cfg["lgbm"], seed * 31 + 3, escala=esc)
        mods = self.modelos_tft(seed)
        pos = np.searchsorted(emis_da, self.P["i"].to_numpy()[da])
        for c, Qc in zip(pend, Qg):
            nwp, kf, yf, R, P_ = entradas[c]
            T = self.tensores_tft(site, P=P_, N=site.nwp_pad(nwp))
            Zs, Qs = [], []
            for mod in mods:
                out = tr.inferir_tft(mod, T, emis_da)
                Zs.append(out["z"][pos, self.j[da]])
                Qs.append(out["q"][pos, self.j[da]])
            sa = {"Z": saidas["Z"].copy(), "Q": saidas["Q"].copy(), "cabecas": saidas["cabecas"], "iq": saidas["iq"]}
            sa["Z"][:, da] = np.stack(Zs)
            sa["Q"][:, da] = np.stack(Qs)
            Qall = hib["Qall"].copy()
            Qall[da] = np.clip(np.sort(Qc, axis=1), 0, self.ymax)
            k_nwp = nwp[self.P["i"].to_numpy()[da], self.j[da], dd.FEAT_NWP.index("k_nwp")]
            reg_orig = self.regime.copy()
            self.regime[da] = dd.regime_de(k_nwp, tuple(self.cfg["conformal"]["limiares_regime"]))
            yT, loT, hiT = self.base_tft(sa)
            yG, loG, hiG = self.base_gbm(Qall)
            var = {w: self.variante(yT, loT, hiT, yG, loG, hiG, w) for w in self.grade_pesos()}
            base = Base(var, self.pesos_mensais(var, horizontes=[3]))
            o, _ = self.camada_cc(base, horizontes=[3])
            o["tercil_te"] = o.pop("tercil")
            o["regime_te"] = self.regime[self.te]
            _salvar_npz(self.arq_prev(seed, f"STRESS_{c}_PROP"), **o)
            o2 = self._prior_estresse(seed, da, kf, yf, R, nwp)
            o2["tercil_te"], o2["regime_te"] = o["tercil_te"], self.regime[self.te]
            _salvar_npz(self.arq_prev(seed, f"STRESS_{c}_PRIOR"), **o2)
            self.regime = reg_orig
            log.info("  semente %d: estresse %s pronto", seed, c)

    def _prior_estresse(self, seed, da, kf, yf, R, nwp):
        """Boot-LSTM do DA com as entradas degradadas; cabeças θ* do PRIOR; camada recalibrada."""
        from .redes import LSTMPrior

        site = self.site
        h = 3
        M = int(self.cfg["lstm_prior"]["membros"])
        tt = _ler_npz(self.pasta(seed) / f"lstm_theta_h{h}.npz")
        W = tt["prior"].reshape(M, -1)
        base = dd.sequencia_lstm_base(site, kf, yf)
        Pd = self.P.iloc[da]
        Craw = dd.contexto_lstm(site, Pd["i"].to_numpy(), Pd["j"].to_numpy(), kf, R, nwp)
        ym = np.zeros((M, len(da)))
        for m in range(M):
            ck = torch.load(self.pasta(seed) / f"lstm_h{h}_m{m}.pt", map_location=self.dev, weights_only=False)
            T = tr.TensoresLSTM(site, self.dev, base, ck["st_seq"])
            mod = LSTMPrior(T.S.shape[1], Craw.shape[1], ck["hp"]["H"], ck["hp"]["Hz"], ck["hp"]["dropout"]).to(self.dev)
            mod.load_state_dict(ck["estado"])
            C = np.nan_to_num((Craw - ck["st_ctx"][0]) / ck["st_ctx"][1]).astype(np.float32)
            _, z = tr.inferir_lstm(mod, T, Pd["i"].to_numpy(), C)
            ym[m] = np.clip((z @ W[m, :-1] + W[m, -1]) * self.pcs[da], 0, self.ymax)
        prev = _ler_npz(self.pasta(seed) / "prior_previsoes.npz")
        yhat, sig = prev["yhat"].copy(), prev["sig"].copy()
        yhat[da] = np.clip(ym.mean(0), 0, self.ymax)
        sig[da] = ym.std(0)
        o, _ = self.camada_mondrian(yhat, sig, piso_fixo=None, horizontes=[3])
        return o

    # ================================================================== execução de uma semente
    def rodar_semente(self, seed: int, etapas: set) -> None:
        t0 = time.time()
        log.info("== %s, semente %d ==", self.codigo, seed)
        precisa_tft = etapas & {"proposto", "otimizadores", "estresse"}

        def etapa(f, *a):                       # cada etapa devolve a memória da GPU ao terminar
            try:
                return f(*a)
            finally:
                self._liberar_gpu()

        self._liberar_gpu()
        if precisa_tft:
            saidas = etapa(self.tft_ensemble, seed)
            if etapas & {"proposto", "estresse"}:
                hib = etapa(self.hibrido, seed, saidas)
            if "proposto" in etapas:
                etapa(self.variantes, seed, saidas, hib)
        if "prior" in etapas or "estresse" in etapas:
            etapa(self.prior, seed)
        if "otimizadores" in etapas:            # comparação de otimizadores da v2 (fora das etapas padrão)
            s3 = etapa(self.estagio3, seed, saidas)
            etapa(self.otimizadores, seed, saidas, s3)
        if "estresse" in etapas:
            etapa(self.estresse, seed, saidas, hib)
        if "tft_nativo" in etapas:
            etapa(self.tft_nativo, seed)
        if "lgbm" in etapas:
            etapa(self.lgbm, seed)
        if "hec" in etapas:
            etapa(self.hec, seed)
        log.info("== %s, semente %d concluída em %.1f min ==", self.codigo, seed, (time.time() - t0) / 60)

    def _liberar_gpu(self) -> None:
        """Coleta os objetos sem referência (inclusive ciclos) e devolve ao driver a memória que o PyTorch guarda
        em cache, para a etapa seguinte (ou outra biblioteca, como o XGBoost) poder usá-la."""
        import gc

        gc.collect()
        if self.dev.type == "cuda":
            torch.cuda.empty_cache()
