"""Baselines que não usam o TFT (Seção V-C do artigo).

CH-PeEn      distribuição empírica dos índices de céu claro de treino na mesma hora, vezes P̃cs.
LightGBM+CQR regressões quantílicas (LightGBM) em α/2 e 1-α/2, conformalizadas (CQR); a distribuição
             preditiva vem dos 20 níveis da grade, conformalizados em pares (p, 1-p).
HEC-XGB      Gangwar et al. (2026): 7 XGBoost com bootstrap de linhas, jitter de ±10% em subsample,
             colsample_bytree, λ e α, sementes próprias; camada heterocedástica assimétrica com piso p(h),
             grupos Mondrian por hora, quantil global se n_k < 30 e fator de escala s* (bisseção com
             expansão) para cobertura 1-α+δ na calibração.
"""

from __future__ import annotations

import logging

import numpy as np

log = logging.getLogger("exp")

# grade de 21 quantis treinados (TFT nativo e LightGBM): os 20 níveis da grade do CRPS e a mediana
from .metricas import GRADE_P  # noqa: E402

GRADE21 = np.sort(np.concatenate([GRADE_P, [0.5]]))
I_MEDIANA = int(np.where(np.isclose(GRADE21, 0.5))[0][0])
I_GRADE = [i for i in range(len(GRADE21)) if i != I_MEDIANA]
I_LO = int(np.where(np.isclose(GRADE21, 0.025))[0][0])
I_HI = int(np.where(np.isclose(GRADE21, 0.975))[0][0])


# ============================================================================ CH-PeEn
def chpeen(site, P_te, p_pi=(0.025, 0.975)):
    n = site.n
    tr = site.valido[:n] & (site.bloco[:n] == 1)
    k = np.clip(site.y[:n] / np.maximum(site.pcs[:n], 0.02), 0, 1.5)
    hora = site.hora_lst[:n]
    t = P_te["t"].to_numpy()
    h_te = site.hora_lst[t]
    pcs = site.pcs[t]
    niveis = np.concatenate([GRADE_P, p_pi])
    Qk = np.zeros((len(t), len(niveis)))
    media = np.zeros(len(t))
    for hh in np.unique(h_te):
        v = k[tr & (hora == hh)]
        if v.size < 5:
            v = k[tr]
        m = h_te == hh
        Qk[m] = np.quantile(v, niveis)
        media[m] = v.mean()
    Q = np.clip(Qk * pcs[:, None], 0, site.y_max)
    return {"yhat": np.clip(media * pcs, 0, site.y_max), "L": Q[:, -2], "U": Q[:, -1], "Q": Q[:, :len(GRADE_P)]}


# ============================================================================ LightGBM
S_MIN_K = 0.02          # alvo k (v3.1): linhas de treino/validação com escala de céu claro abaixo disso ficam de fora
K_MAX = 2.0             # e o índice de céu claro é limitado a [0, K_MAX]


def lgbm_quantis(Xtr, ytr, Xva, yva, Xap, niveis, hp: dict, seed: int, escala=None):
    """Quantis do LightGBM (um modelo por nível). escala = (s_tr, s_va, s_ap), opcional (v3.1, lgbm: alvo: k): o modelo
    aprende o índice de céu claro k = y/s, como o TFT, e as previsões voltam a y multiplicadas por s_ap. Xap pode ser
    uma lista de matrizes (testes de estresse); nesse caso s_ap é uma lista com a escala de cada uma."""
    import inspect

    import lightgbm as lgb

    lista = isinstance(Xap, (list, tuple))           # várias matrizes de aplicação (testes de estresse)
    Xs = list(Xap) if lista else [Xap]
    if escala is not None:
        s_tr, s_va, s_ap = (np.asarray(s, dtype=np.float64) if not isinstance(s, (list, tuple)) else s for s in escala)
        s_aps = [np.asarray(s, dtype=np.float64) for s in s_ap] if isinstance(s_ap, (list, tuple)) else [s_ap] * len(Xs)
        ok_tr, ok_va = s_tr > S_MIN_K, s_va > S_MIN_K
        Xtr, ytr = Xtr[ok_tr], np.clip(np.asarray(ytr)[ok_tr] / s_tr[ok_tr], 0.0, K_MAX)
        Xva, yva = Xva[ok_va], np.clip(np.asarray(yva)[ok_va] / s_va[ok_va], 0.0, K_MAX)
    # LightGBM >= 4.7 troca eval_set por eval_X/eval_y (eval_set ainda funciona, mas avisa a cada modelo)
    if "eval_X" in inspect.signature(lgb.LGBMRegressor.fit).parameters:
        validacao = {"eval_X": (Xva,), "eval_y": (yva,)}
    else:
        validacao = {"eval_set": [(Xva, yva)]}
    outs = [np.zeros((X.shape[0], len(niveis))) for X in Xs]
    for c, q in enumerate(niveis):
        m = lgb.LGBMRegressor(objective="quantile", alpha=float(q), n_estimators=hp["n_estimators"],
                              learning_rate=hp["learning_rate"], num_leaves=hp["num_leaves"],
                              min_child_samples=hp["min_child_samples"], subsample=hp["subsample"],
                              subsample_freq=1, colsample_bytree=hp["colsample_bytree"], random_state=seed + c,
                              n_jobs=hp.get("n_jobs", -1), verbose=-1)
        m.fit(Xtr, ytr, callbacks=[lgb.early_stopping(50, verbose=False)], **validacao)
        for o, X in zip(outs, Xs):
            o[:, c] = m.predict(X)
    if escala is not None:
        outs = [o * s[:, None] for o, s in zip(outs, s_aps)]
    return outs if lista else outs[0]


# ============================================================================ XGBoost (HEC)
def xgb_ensemble(Xtr, ytr, Xva, yva, Xap, hp: dict, seed: int, membros: int = 7, gpu: bool = False):
    import xgboost as xgb

    rng = np.random.default_rng(seed)
    preds = np.zeros((membros, Xap.shape[0]))
    for m in range(membros):
        idx = rng.integers(0, len(ytr), len(ytr))  # bootstrap de linhas (Gangwar et al.)
        jit = lambda v: v * (1.0 + rng.uniform(-0.1, 0.1))  # noqa: E731
        mod = xgb.XGBRegressor(n_estimators=hp["n_estimators"], learning_rate=hp["learning_rate"],
                               max_depth=hp["max_depth"], subsample=min(1.0, jit(hp["subsample"])),
                               colsample_bytree=min(1.0, jit(hp["colsample_bytree"])),
                               reg_lambda=jit(hp["reg_lambda"]), reg_alpha=jit(hp["reg_alpha"]),
                               tree_method="hist", device="cuda" if gpu else "cpu", random_state=seed * 100 + m,
                               early_stopping_rounds=50, n_jobs=hp.get("n_jobs", -1), verbosity=0)
        try:
            mod.fit(Xtr[idx], ytr[idx], eval_set=[(Xva, yva)], verbose=False)
        except Exception as e:  # noqa: BLE001  (XGBoost sem suporte a CUDA nesta instalação)
            if not gpu:
                raise
            log.warning("    XGBoost na GPU falhou (%s); seguindo na CPU", str(e)[:120])
            gpu = False
            mod.set_params(device="cpu")
            mod.fit(Xtr[idx], ytr[idx], eval_set=[(Xva, yva)], verbose=False)
        preds[m] = mod.predict(Xap)
    return preds
