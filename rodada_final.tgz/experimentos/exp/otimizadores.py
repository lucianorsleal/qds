"""Otimizadores do Estágio 3 com o mesmo orçamento de avaliações (Seção III-E e Tab. 10 do artigo).

Todos minimizam a mesma aptidão f(u) nas coordenadas de deslocamento padronizado, partindo da solução do
Adam (u = 0), e devolvem o melhor u, o melhor valor e o histórico do melhor valor a cada avaliação.

    ICSO-PP  galos com inércia cosseno c(t) ∈ [0,3; 0,8], galinhas, pintinhos guiados pela mãe e pelo melhor,
             mutação gaussiana com probabilidade 0,2 → 0 nos primeiros 70% das gerações e o mecanismo
             presa–predador (margem ρ = 0,15, p_enc = 0,2, p_esc = 0,75, salto N(0, 0,1²) perto de um galo);
             N = 40 (12 galos, 20 galinhas das quais 8 mães, 8 pintinhos), G = 5, T = 50
    ICSO     o mesmo sem presa–predador
    CSO      o CSO original (Meng et al., 2014): galos x(1 + N(0, σ²)), pintinhos só seguem a mãe, sem mutação
    PSO      enxame global, inércia 0,7298, c1 = c2 = 1,49618
    L-SHADE  Tanabe e Fukunaga (2014): current-to-pbest/1, memória de sucesso, arquivo e redução linear da
             população
    CMA-ES   biblioteca cma (Hansen), σ0 = 1
    TPE      Optuna, u_j ∈ [-3, 3], a solução do Adam enfileirada como primeira tentativa
"""

from __future__ import annotations

import math
import time

import numpy as np


LIMITE_U = 10.0  # caixa de segurança |u_j| <= 10 (100 vezes a escala ς0 da busca) para os métodos de enxame


def _caixa(x):
    return np.clip(x, -LIMITE_U, LIMITE_U)


class _Registro:
    def __init__(self, f, orcamento):
        self.f, self.orcamento = f, orcamento
        self.hist, self.melhor_f, self.melhor_u = [], math.inf, None

    def __call__(self, u):
        v = float(self.f(u))
        if not np.isfinite(v):
            v = 1e6
        if v < self.melhor_f:
            self.melhor_f, self.melhor_u = v, np.array(u, dtype=float)
        self.hist.append(self.melhor_f)
        return v

    @property
    def n(self):
        return len(self.hist)

    def resultado(self, t0):
        return {"u": self.melhor_u, "f": self.melhor_f, "hist": np.array(self.hist), "avaliacoes": self.n,
                "seg": time.time() - t0}


def icso_pp(f, d, rng, cfg, variante="ICSO-PP"):
    t0 = time.time()
    N, nR, nH, nM, nC = cfg["N"], cfg["galos"], cfg["galinhas"], cfg["maes"], cfg["pintinhos"]
    G, T = cfg["G"], cfg["T"]
    reg = _Registro(f, None)
    X = rng.standard_normal((N, d))
    X[0] = 0.0
    F = np.array([reg(x) for x in X])
    eps = 1e-12
    papeis = None
    for t in range(1, T + 1):
        if papeis is None or (t - 1) % G == 0:
            ordem = np.argsort(F)
            galos, galinhas, pintos = ordem[:nR], ordem[nR:nR + nH], ordem[nR + nH:nR + nH + nC]
            grupo_galinha = rng.choice(galos, size=len(galinhas))
            maes = rng.choice(galinhas, size=nM, replace=False)
            mae_pinto = rng.choice(maes, size=len(pintos))
            papeis = True
        Xn = X.copy()
        ib = int(np.argmin(F))
        c_t = cfg["c_min"] + (cfg["c_max"] - cfg["c_min"]) * math.cos(math.pi * t / (2 * T))
        for i in galos:
            k = rng.choice(galos[galos != i])
            s2 = 1.0 if F[i] <= F[k] else math.exp(max(-50.0, min(50.0, (F[k] - F[i]) / (abs(F[i]) + eps))))
            ruido = rng.normal(0.0, math.sqrt(s2), d)
            if variante == "CSO":
                Xn[i] = X[i] * (1.0 + ruido)
            else:
                Xn[i] = c_t * X[i] + X[i] * ruido
        todos = np.concatenate([galos, galinhas])
        for idx, i in enumerate(galinhas):
            r1 = grupo_galinha[idx]
            cand = todos[(todos != i) & (todos != r1)]
            r2 = rng.choice(cand)
            S1 = math.exp(max(-50.0, min(50.0, (F[i] - F[r1]) / (abs(F[i]) + eps))))
            S2 = math.exp(max(-50.0, min(50.0, F[r2] - F[i])))
            Xn[i] = X[i] + S1 * rng.random(d) * (X[r1] - X[i]) + S2 * rng.random(d) * (X[r2] - X[i])
        for idx, i in enumerate(pintos):
            m = mae_pinto[idx]
            FL = rng.uniform(0.0, 2.0)
            Xn[i] = X[i] + FL * (X[m] - X[i])
            if variante != "CSO":
                BL = math.exp(max(-50.0, min(50.0, F[ib] - F[i])))
                Xn[i] = Xn[i] + BL * (X[ib] - X[i])
        if variante != "CSO":
            p_mut = cfg["p_mut"] * max(0.0, 1.0 - t / (cfg["frac_mut"] * T))
            for i in range(N):
                if i != ib and rng.random() < p_mut:
                    Xn[i] = Xn[i] + rng.normal(0.0, cfg["sigma_mut"], d)
        if variante == "ICSO-PP" and t <= cfg["frac_mut"] * T:
            fb = F.min()
            for i in range(N):
                if F[i] > (1.0 + cfg["rho"]) * fb and rng.random() < cfg["p_enc"]:
                    if rng.random() < cfg["p_esc"]:
                        e = rng.choice(galos)
                        Xn[i] = X[e] + rng.normal(0.0, cfg["sigma_esc"], d)
                    else:
                        Xn[i] = rng.standard_normal(d)
        X = _caixa(Xn)
        F = np.array([reg(x) for x in X])
    return reg.resultado(t0)


def pso(f, d, rng, cfg, orcamento):
    t0 = time.time()
    reg = _Registro(f, orcamento)
    N = cfg["N"]
    X = rng.standard_normal((N, d))
    X[0] = 0.0
    V = np.zeros((N, d))
    F = np.array([reg(x) for x in X])
    P, PF = X.copy(), F.copy()
    w, c1, c2 = 0.7298, 1.49618, 1.49618
    while reg.n + N <= orcamento:
        g = P[np.argmin(PF)]
        V = w * V + c1 * rng.random((N, d)) * (P - X) + c2 * rng.random((N, d)) * (g - X)
        X = _caixa(X + V)
        F = np.array([reg(x) for x in X])
        m = F < PF
        P[m], PF[m] = X[m], F[m]
    return reg.resultado(t0)


def lshade(f, d, rng, cfg, orcamento, N_ini=None, H=6, p_best=0.11, r_arc=2.6, N_min=4):
    t0 = time.time()
    reg = _Registro(f, orcamento)
    N_ini = int(N_ini or cfg["N"])
    X = rng.standard_normal((N_ini, d))
    X[0] = 0.0
    F = np.array([reg(x) for x in X])
    MF, MCR = np.full(H, 0.5), np.full(H, 0.5)
    k_mem = 0
    arq = np.empty((0, d))
    N = N_ini
    while reg.n < orcamento:
        S_F, S_CR, dF = [], [], []
        ordem = np.argsort(F)
        n_p = max(2, int(round(p_best * N)))
        U = np.empty_like(X)
        Fi_all, CRi_all = np.empty(N), np.empty(N)
        for i in range(N):
            r = rng.integers(H)
            CRi = 0.0 if np.isnan(MCR[r]) else float(np.clip(rng.normal(MCR[r], 0.1), 0, 1))
            Fi = -1.0
            while Fi <= 0:
                Fi = MF[r] + 0.1 * math.tan(math.pi * (rng.random() - 0.5))
            Fi = min(Fi, 1.0)
            pb = X[ordem[rng.integers(n_p)]]
            r1 = rng.choice([j for j in range(N) if j != i])
            uni = np.vstack([X, arq]) if len(arq) else X
            r2 = rng.integers(len(uni))
            while r2 == i or r2 == r1:
                r2 = rng.integers(len(uni))
            v = X[i] + Fi * (pb - X[i]) + Fi * (X[r1] - uni[r2])
            jr = rng.integers(d)
            cruz = rng.random(d) < CRi
            cruz[jr] = True
            U[i] = _caixa(np.where(cruz, v, X[i]))
            Fi_all[i], CRi_all[i] = Fi, CRi
        for i in range(N):
            if reg.n >= orcamento:
                break
            fu = reg(U[i])
            if fu <= F[i]:
                if fu < F[i]:
                    S_F.append(Fi_all[i])
                    S_CR.append(CRi_all[i])
                    dF.append(F[i] - fu)
                    arq = np.vstack([arq, X[i]]) if len(arq) else X[i][None, :]
                X[i], F[i] = U[i], fu
        if S_F:
            w = np.array(dF) / np.sum(dF)
            sf, scr = np.array(S_F), np.array(S_CR)
            MF[k_mem] = np.sum(w * sf ** 2) / np.sum(w * sf)
            MCR[k_mem] = np.nan if (np.isnan(MCR[k_mem]) or scr.max() == 0) else np.sum(w * scr ** 2) / max(np.sum(w * scr), 1e-12)
            k_mem = (k_mem + 1) % H
        N_novo = int(round((N_min - N_ini) / orcamento * reg.n + N_ini))
        if N_novo < N:
            manter = np.argsort(F)[:max(N_novo, N_min)]
            X, F = X[manter], F[manter]
            N = len(X)
        lim_arq = int(round(r_arc * N))
        if len(arq) > lim_arq:
            arq = arq[rng.choice(len(arq), lim_arq, replace=False)]
    return reg.resultado(t0)


def cmaes(f, d, rng, cfg, orcamento):
    import cma

    t0 = time.time()
    reg = _Registro(f, orcamento)
    reg(np.zeros(d))
    es = cma.CMAEvolutionStrategy(np.zeros(d), 1.0, {"seed": int(rng.integers(1, 2 ** 31 - 1)), "verbose": -9,
                                                    "maxfevals": orcamento - 1})
    while not es.stop() and reg.n < orcamento:
        sols = es.ask()
        if reg.n + len(sols) > orcamento:
            sols = sols[: orcamento - reg.n]
            if not sols:
                break
            vals = [reg(s) for s in sols]
            break
        vals = [reg(s) for s in sols]
        es.tell(sols, vals)
    return reg.resultado(t0)


def tpe(f, d, rng, cfg, orcamento, limite=3.0):
    import logging as _lg

    import optuna

    optuna.logging.set_verbosity(optuna.logging.WARNING)
    _lg.getLogger("optuna").setLevel(_lg.WARNING)
    t0 = time.time()
    reg = _Registro(f, orcamento)
    samp = optuna.samplers.TPESampler(seed=int(rng.integers(1, 2 ** 31 - 1)), n_startup_trials=cfg["N"])
    est = optuna.create_study(direction="minimize", sampler=samp)
    nomes = [f"u{j}" for j in range(d)]
    est.enqueue_trial({n: 0.0 for n in nomes})

    def obj(tr):
        u = np.array([tr.suggest_float(n, -limite, limite) for n in nomes])
        return reg(u)

    est.optimize(obj, n_trials=orcamento, show_progress_bar=False)
    return reg.resultado(t0)


def rodar(nome: str, f, d: int, rng, cfg_icso: dict, orcamento: int):
    if nome in ("ICSO-PP", "ICSO", "CSO"):
        return icso_pp(f, d, rng, cfg_icso, nome)
    if nome == "PSO":
        return pso(f, d, rng, cfg_icso, orcamento)
    if nome == "L-SHADE":
        return lshade(f, d, rng, cfg_icso, orcamento)
    if nome == "CMA-ES":
        return cmaes(f, d, rng, cfg_icso, orcamento)
    if nome == "TPE":
        return tpe(f, d, rng, cfg_icso, orcamento)
    raise ValueError(nome)


def curva_geracoes(hist: np.ndarray, por_geracao: int = 40, geracoes: int = 50) -> np.ndarray:
    """Melhor valor depois de 40·(g+1) avaliações, g = 0..50."""
    out = np.empty(geracoes + 1)
    for g in range(geracoes + 1):
        k = min(len(hist), por_geracao * (g + 1)) - 1
        out[g] = hist[k] if k >= 0 else np.nan
    return out
