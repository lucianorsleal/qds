"""Treino e inferência das redes (Estágios 1–2 e baselines neurais).

- Bootstrap por blocos diários (Seção II-B): sorteiam-se |T| dias de treino com reposição; cada par
  (emissão, hora-alvo) entra na perda com peso igual ao número de vezes que o dia da hora-alvo saiu.
- Jitter de ±10% na taxa de aprendizado, dropout, weight decay e tamanho do lote, e semente própria.
- Perda quantílica (TFT) ou erro quadrático (LSTM do artigo 1) no domínio da potência, só nas horas diurnas
  válidas; Adam, corte do gradiente e parada antecipada na validação.
"""

from __future__ import annotations

import logging
import math
import time

import numpy as np
import torch

from .dados import DEC, ENC, PAD, Site
from .redes import TFT, LSTMPrior

log = logging.getLogger("exp")


def semear(seed: int) -> None:
    import random

    random.seed(seed)
    np.random.seed(seed % (2 ** 32))
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def pesos_bootstrap(site: Site, rng: np.random.Generator, bloco: int = 1) -> np.ndarray:
    """Peso de cada hora-alvo = nº de vezes que o seu dia saiu no sorteio com reposição."""
    n = site.n
    alvo = site.valido[:n] & (site.bloco[:n] == bloco)
    dias = np.unique(site.data_ord[:n][alvo])
    sorteio = rng.choice(dias, size=len(dias), replace=True)
    cont = dict(zip(*np.unique(sorteio, return_counts=True)))
    w = np.array([cont.get(d, 0) for d in site.data_ord[:n]], dtype=np.float32) * alvo
    return np.concatenate([w, np.zeros(PAD, dtype=np.float32)])


def jitter(base: dict, rng: np.random.Generator, frac: float = 0.1) -> dict:
    out = dict(base)
    for k in ("lr", "dropout", "weight_decay", "batch"):
        out[k] = base[k] * (1.0 + rng.uniform(-frac, frac))
    out["batch"] = max(8, int(round(out["batch"])))
    return out


def _amp(dev, ativo: bool):
    """(fábrica de contexto autocast, GradScaler ou None). Precisão mista só na GPU."""
    if ativo and dev.type == "cuda":
        return (lambda: torch.autocast(device_type="cuda", dtype=torch.float16)), torch.amp.GradScaler("cuda")
    return (lambda: torch.autocast(device_type="cpu", enabled=False)), None


# ============================================================================ TFT
class TensoresTFT:
    """Entradas do TFT na GPU, indexadas pela grade horária do site.

    n_lag > 0 (tft: lags_decodificador): o k padronizado das horas i−1, …, i−n_lag, já observado na emissão i,
    entra também no decodificador, repetido nos 36 passos. No codificador essa informação só chega ao passo-alvo
    pelo estado do LSTM e pela atenção; no decodificador ela tem caminho direto pelas conexões residuais."""

    def __init__(self, site: Site, dev, P=None, N=None, n_lag: int = 0):
        self.dev = dev
        self.P = torch.as_tensor(site.passado_pad() if P is None else P, device=dev)
        self.K = torch.as_tensor(site.conhecido_pad(), device=dev)
        self.N = torch.as_tensor(site.nwp_pad() if N is None else N, device=dev)
        self.y = torch.as_tensor(np.nan_to_num(site.y, nan=0.0).astype(np.float32), device=dev)
        self.pcs = torch.as_tensor(site.pcs.astype(np.float32), device=dev)
        self.ar_e = torch.arange(-ENC, 0, device=dev)
        self.ar_d = torch.arange(0, DEC, device=dev)
        self.n_lag = int(n_lag or 0)
        self.ar_lag = torch.arange(1, self.n_lag + 1, device=dev)
        self.n_enc = self.P.shape[1] + self.K.shape[1]
        self.n_dec = self.N.shape[2] + self.K.shape[1] + self.n_lag

    def lote(self, i):
        ie = i[:, None] + self.ar_e
        idd = i[:, None] + self.ar_d
        x_enc = torch.cat([self.P[ie], self.K[ie]], dim=-1)
        x_dec = torch.cat([self.N[i], self.K[idd]], dim=-1)
        if self.n_lag:
            lag = self.P[i[:, None] - self.ar_lag, 0]                 # (B, n_lag): coluna 0 de P = k padronizado
            x_dec = torch.cat([x_dec, lag.unsqueeze(1).expand(-1, x_dec.shape[1], -1)], dim=-1)
        return x_enc, x_dec, idd


def pesos_passos(hp: dict, dev):
    """Peso de cada passo do decodificador na perda: tft: peso_intradiario nos tft: passos_intradiarios primeiros
    passos e 1 nos demais (None = todos iguais). Com 36 passos, os intradiários (1–6 h) são só 1/6 da perda e o
    TFT quase não aprende a usar as últimas observações; com peso 5 nos 6 primeiros, eles ficam com metade."""
    p = float(hp.get("peso_intradiario", 1.0) or 1.0)
    if p == 1.0:
        return None
    v = torch.ones(DEC, device=dev)
    v[: int(hp.get("passos_intradiarios", 6))] = p
    return v


def _perda_quantil(q_k, y, pcs, w, quantis):
    yq = q_k * pcs.unsqueeze(-1)                         # quantis no domínio da potência
    u = y.unsqueeze(-1) - yq
    tau = torch.as_tensor(quantis, device=q_k.device, dtype=q_k.dtype)
    l = torch.maximum(tau * u, (tau - 1.0) * u).sum(-1)  # (B, 36)
    return (l * w).sum(), w.sum()


def emissoes_com_alvo(w: np.ndarray, n: int) -> np.ndarray:
    """Emissões i >= ENC com algum alvo de peso > 0 em i..i+35."""
    cs = np.concatenate([[0.0], np.cumsum(w)])
    i = np.arange(ENC, n)
    tem = (cs[i + DEC] - cs[i]) > 0
    return i[tem]


def treinar_tft(site: Site, T: TensoresTFT, hp: dict, quantis: list, seed: int, w_treino: np.ndarray,
                w_val: np.ndarray, rotulo: str = "") -> tuple:
    dev = T.dev
    semear(seed)
    modelo = TFT(T.n_enc, T.n_dec, hp["hidden"], hp["cabecas"], hp["dropout"], len(quantis), ENC, DEC).to(dev)
    opt = torch.optim.Adam(modelo.parameters(), lr=hp["lr"], weight_decay=hp["weight_decay"])
    Wt = torch.as_tensor(w_treino, device=dev)
    Wv = torch.as_tensor(w_val, device=dev)
    it = emissoes_com_alvo(w_treino, site.n)
    iv = emissoes_com_alvo(w_val, site.n)
    lim = hp.get("amostras_por_epoca")
    pj = pesos_passos(hp, dev)           # (36,) ou None; vale no treino e na parada antecipada
    gen = torch.Generator(device="cpu").manual_seed(seed)
    ctx, scaler = _amp(dev, hp.get("amp", True))
    melhor, estado, sem_melhora = math.inf, None, 0
    t0 = time.time()
    B = int(hp["batch"])
    hist = []
    for ep in range(int(hp["max_epocas"])):
        modelo.train()
        ordem = it[torch.randperm(len(it), generator=gen).numpy()]
        if lim and len(ordem) > lim:
            ordem = ordem[:int(lim)]
        soma = peso = 0.0
        for a in range(0, len(ordem), B):
            i = torch.as_tensor(ordem[a:a + B], device=dev)
            xe, xd, idd = T.lote(i)
            with ctx():
                q, _ = modelo(xe, xd)
            l, wsum = _perda_quantil(q.float(), T.y[idd], T.pcs[idd], Wt[idd] if pj is None else Wt[idd] * pj,
                                     quantis)
            if wsum.item() <= 0:
                continue
            loss = l / wsum
            opt.zero_grad(set_to_none=True)
            if scaler is not None:
                scaler.scale(loss).backward()
                scaler.unscale_(opt)
                torch.nn.utils.clip_grad_norm_(modelo.parameters(), hp["clip_grad"])
                scaler.step(opt)
                scaler.update()
            else:
                loss.backward()
                torch.nn.utils.clip_grad_norm_(modelo.parameters(), hp["clip_grad"])
                opt.step()
            soma += l.item()
            peso += wsum.item()
        v = avaliar_perda_tft(modelo, T, iv, Wv, quantis, ctx, pj=pj)
        hist.append((ep, soma / max(peso, 1e-9), v))
        if v < melhor - 1e-7:
            melhor, sem_melhora = v, 0
            estado = {k: x.detach().clone() for k, x in modelo.state_dict().items()}
        else:
            sem_melhora += 1
        if sem_melhora >= hp["paciencia"]:
            break
    if estado is None:                   # perda de validação NaN/inf em todas as épocas
        if scaler is not None:
            log.warning("    %sperda de validação inválida com precisão mista; refazendo este membro em float32", rotulo)
            return treinar_tft(site, T, dict(hp, amp=False), quantis, seed, w_treino, w_val, rotulo)
        raise RuntimeError(f"{rotulo}o treino do TFT divergiu (perda de validação inválida em todas as épocas); "
                           "diminua 'lr' em tft no config_experimentos.yaml")
    modelo.load_state_dict(estado)
    ep_melhor = 1 + min(range(len(hist)), key=lambda k: hist[k][2] if math.isfinite(hist[k][2]) else math.inf)
    info = {"epocas": len(hist), "perda_val": melhor, "min": (time.time() - t0) / 60, "n_emissoes": int(len(it)),
            "melhor_epoca": ep_melhor, "hist": [(int(e) + 1, float(tr_), float(va)) for e, tr_, va in hist]}
    log.info("    %sTFT: %d épocas (melhor: %d), perda val %.5f, %.1f min", rotulo, info["epocas"], ep_melhor, melhor,
             info["min"])
    return modelo, info


@torch.no_grad()
def avaliar_perda_tft(modelo, T: TensoresTFT, iv, Wv, quantis, ctx, B: int = 1024, pj=None) -> float:
    modelo.eval()
    soma = peso = 0.0
    for a in range(0, len(iv), B):
        i = torch.as_tensor(iv[a:a + B], device=T.dev)
        xe, xd, idd = T.lote(i)
        with ctx():
            q, _ = modelo(xe, xd)
        l, w = _perda_quantil(q.float(), T.y[idd], T.pcs[idd], Wv[idd] if pj is None else Wv[idd] * pj, quantis)
        soma += l.item()
        peso += w.item()
    return soma / max(peso, 1e-9)


@torch.no_grad()
def inferir_tft(modelo, T: TensoresTFT, emissoes: np.ndarray, interpretar: bool = False, B: int = 512,
                grupo_enc=None, grupo_dec=None, n_grupos: int = 9) -> dict:
    """Saídas em todas as 36 horas de cada emissão: quantis de k (n, 36, nq) e ψ̃ (n, 36, d). Com
    interpretar=True, também os pesos de grupo de variáveis do passo-alvo (n, 36, 9), a fração própria
    (n, 36) e a atenção sobre as 120 posições do codificador (n, 36, 120).

    Peso de grupo do passo-alvo j: ρ_j · v_j + (1 − ρ_j) · Σ_p a_jp v_p, em que v_p são os pesos do VSN da
    posição p somados por grupo, a_jp a atenção de j sobre p (distribui o contexto temporal, que chega pela
    atenção e pelo LSTM) e ρ_j a fração própria do passo-alvo nas conexões residuais com porta (TFT.
    representacao). Ponderar só pela atenção ignoraria que as variáveis do próprio passo (o NWP só entra no
    decodificador) chegam à saída pelas conexões residuais."""
    modelo.eval()
    qs, zs, wg, ae, sc, wc, wp = [], [], [], [], [], [], []
    if interpretar:
        ge = torch.nn.functional.one_hot(torch.as_tensor(grupo_enc, device=T.dev), n_grupos).float()
        gd = torch.nn.functional.one_hot(torch.as_tensor(grupo_dec, device=T.dev), n_grupos).float()
    for a in range(0, len(emissoes), B):
        i = torch.as_tensor(emissoes[a:a + B], device=T.dev)
        xe, xd, _ = T.lote(i)
        if interpretar:
            z, (ve, vd, att, propria) = modelo.representacao(xe, xd, interpretar=True)
            vdg = vd @ gd                                         # (B, 36, 9): grupos do próprio passo
            vg = torch.cat([ve @ ge, vdg], dim=1)                 # (B, 156, 9): peso de cada grupo por posição
            ctx = torch.einsum("bjp,bpg->bjg", att, vg)
            rho = propria.unsqueeze(-1)
            wg.append((rho * vdg + (1.0 - rho) * ctx).half().cpu())
            wc.append(ctx.half().cpu())                           # só o contexto (ponderado pela atenção)
            wp.append(vdg.half().cpu())                           # só o próprio passo
            sc.append(propria.half().cpu())
            ae.append(att[:, :, :ENC].half().cpu())
        else:
            z = modelo.representacao(xe, xd)
        qs.append(modelo.saida(z).float().cpu())
        zs.append(z.float().cpu())
    out = {"q": torch.cat(qs).numpy(), "z": torch.cat(zs).numpy()}
    if interpretar:
        out["wg"] = torch.cat(wg).numpy()
        out["propria"] = torch.cat(sc).numpy()
        out["wg_ctx"] = torch.cat(wc).numpy()
        out["wg_proprio"] = torch.cat(wp).numpy()
        out["att_enc"] = torch.cat(ae).numpy()
    return out


def cabeca_mediana(modelo: TFT, iq: int) -> np.ndarray:
    """(w (d,), b) da linha da mediana da camada de saída."""
    W = modelo.saida.weight.detach().cpu().numpy()
    b = modelo.saida.bias.detach().cpu().numpy()
    return np.concatenate([W[iq], [b[iq]]]).astype(np.float64)


# ============================================================================ LSTM (artigo 1)
class TensoresLSTM:
    def __init__(self, site: Site, dev, seq_base: np.ndarray, st_seq: tuple):
        self.dev = dev
        m, s = st_seq
        self.S = torch.as_tensor(np.nan_to_num((seq_base - m) / s).astype(np.float32), device=dev)
        self.ar = torch.arange(-ENC, 0, device=dev)

    def seq(self, i):
        return self.S[i[:, None] + self.ar]


def treinar_lstm(T: TensoresLSTM, ctx_tr, i_tr, y_tr, pcs_tr, w_tr, ctx_va, i_va, y_va, pcs_va, hp: dict,
                 seed: int, rotulo: str = "") -> tuple:
    dev = T.dev
    semear(seed)
    modelo = LSTMPrior(T.S.shape[1], ctx_tr.shape[1], hp["H"], hp["Hz"], hp["dropout"]).to(dev)
    opt = torch.optim.Adam(modelo.parameters(), lr=hp["lr"], weight_decay=hp["weight_decay"])
    to = lambda x: torch.as_tensor(np.asarray(x, dtype=np.float32), device=dev)  # noqa: E731
    Ct, Yt, Pt, Wt = to(ctx_tr), to(y_tr), to(pcs_tr), to(w_tr)
    It = torch.as_tensor(i_tr, device=dev)
    Cv, Yv, Pv, Iv = to(ctx_va), to(y_va), to(pcs_va), torch.as_tensor(i_va, device=dev)
    sel = np.where(w_tr > 0)[0]
    gen = torch.Generator(device="cpu").manual_seed(seed)
    B = int(hp["batch"])
    melhor, estado, sem = math.inf, None, 0
    t0 = time.time()
    ep = 0
    for ep in range(int(hp["max_epocas"])):
        modelo.train()
        ordem = sel[torch.randperm(len(sel), generator=gen).numpy()]
        for a in range(0, len(ordem), B):
            b = torch.as_tensor(ordem[a:a + B], device=dev)
            k, _ = modelo(T.seq(It[b]), Ct[b])
            e = (k * Pt[b] - Yt[b]) ** 2
            loss = (e * Wt[b]).sum() / Wt[b].sum().clamp_min(1e-9)
            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(modelo.parameters(), hp.get("clip_grad", 1.0))
            opt.step()
        modelo.eval()
        with torch.no_grad():
            v = 0.0
            for a in range(0, len(Iv), 4096):
                k, _ = modelo(T.seq(Iv[a:a + 4096]), Cv[a:a + 4096])
                v += ((k * Pv[a:a + 4096] - Yv[a:a + 4096]) ** 2).sum().item()
            v /= max(len(Iv), 1)
        if v < melhor - 1e-9:
            melhor, sem = v, 0
            estado = {k_: x.detach().clone() for k_, x in modelo.state_dict().items()}
        else:
            sem += 1
        if sem >= hp["paciencia"]:
            break
    if estado is None:
        raise RuntimeError(f"{rotulo}o treino do LSTM divergiu (MSE de validação inválido em todas as épocas); "
                           "diminua 'lr' em lstm_prior no config_experimentos.yaml")
    modelo.load_state_dict(estado)
    log.debug("    %sLSTM: %d épocas, MSE val %.6f, %.1f min", rotulo, ep + 1, melhor, (time.time() - t0) / 60)
    return modelo, {"epocas": ep + 1, "mse_val": melhor, "min": (time.time() - t0) / 60}


@torch.no_grad()
def inferir_lstm(modelo, T: TensoresLSTM, i, ctx, B: int = 4096) -> tuple:
    modelo.eval()
    I = torch.as_tensor(np.array(i), device=T.dev)            # cópia gravável (o pandas pode devolver só leitura)
    C = torch.as_tensor(np.asarray(ctx, dtype=np.float32), device=T.dev)
    ks, zs = [], []
    for a in range(0, len(I), B):
        k, z = modelo(T.seq(I[a:a + B]), C[a:a + B])
        ks.append(k.cpu())
        zs.append(z.cpu())
    return torch.cat(ks).numpy().astype(np.float64), torch.cat(zs).numpy().astype(np.float64)


def cabeca_lstm(modelo: LSTMPrior) -> np.ndarray:
    W = modelo.saida.weight.detach().cpu().numpy()[0]
    b = modelo.saida.bias.detach().cpu().numpy()
    return np.concatenate([W, b]).astype(np.float64)
