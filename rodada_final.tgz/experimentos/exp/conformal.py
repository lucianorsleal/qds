"""Camadas de calibração (Seções II-E, II-F e III-F do artigo e camadas L1–L7 da Tab. 7).

Escores heterocedásticos assimétricos (eq. scores):
    E+ = max(r, 0) / (σ̃ + ε),   E- = max(-r, 0) / (σ̃ + ε),   r = y - ŷ
Intervalo (eq. interval):  [ŷ - q-(x)(σ̃ + ε), ŷ + q+(x)(σ̃ + ε)] ∩ [0, ȳ].

Conformal condicional (Gibbs, Cherian e Candès, 2025) com Φ = intercepto + dummies de hora, regime e
tercil. O limiar de um ponto de teste é o maior S aceito pela regressão quantílica aumentada; com a dual
dessa regressão,
    h(t) = max { Σ η_i E_i : Σ η_i Φ_i = -t Φ(x),  η_i ∈ [τ-1, τ] },
o limiar é S* = -h'(τ⁻), a derivada à esquerda em t = τ, que o HiGHS dá pelos multiplicadores das
restrições de igualdade resolvendo a dual em t = τ - ε. É o mesmo S que a bisseção do Algoritmo 1
encontra (conferido em testes/teste_conformal.py contra a bisseção e contra o split/Mondrian), mas com um
único programa linear por padrão (hora, regime, tercil) de teste, e todos os pontos de teste do mês com
o mesmo padrão compartilham o limiar.

Regra de fusão (Seção III-F): um nível com menos de n_ef amostras, contando o ponto de teste (para que a
regra seja simétrica nos n+1 pontos), é fundido com o vizinho (horas vizinhas; claro–parcial–encoberto;
tercis vizinhos). n_ef = max(n_min, ⌈τ/(1-τ)⌉ + 1): com n_c amostras de calibração no grupo do ponto de
teste, a restrição Σ_{i∈G} η_i = -τ só é viável se n_c(1-τ) ≥ τ, ou seja, n_c ≥ ⌈τ/(1-τ)⌉; abaixo disso o
limiar seria infinito (como no Mondrian, em que ⌈(n_c+1)τ⌉ > n_c). Contando o ponto de teste, isso pede
n_c + 1 ≥ ⌈τ/(1-τ)⌉ + 1 (50 com τ = 0,98; 40 com 0,975). A fusão também vale para as horas, que no
inverno podem ter poucas horas diurnas nas pontas do dia.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
from scipy.optimize import linprog

EPS_SIGMA = 1e-6
INF = np.inf


# ============================================================================ básicos
def escores(y, yhat, sig, sig_hi=None):
    """Escores de cada lado: (E+ do lado de cima, E- do lado de baixo). sig é a escala de baixo; sig_hi, a de
    cima (None = a mesma escala dos dois lados)."""
    r = y - yhat
    s_lo = sig + EPS_SIGMA
    s_hi = s_lo if sig_hi is None else sig_hi + EPS_SIGMA
    return np.maximum(r, 0.0) / s_hi, np.maximum(-r, 0.0) / s_lo


def intervalo(yhat, sig, q_lo, q_hi, ymax, sig_hi=None):
    s_lo = sig + EPS_SIGMA
    s_hi = s_lo if sig_hi is None else sig_hi + EPS_SIGMA
    L = np.where(np.isfinite(q_lo), yhat - q_lo * s_lo, 0.0)
    U = np.where(np.isfinite(q_hi), yhat + q_hi * s_hi, ymax)
    return np.clip(L, 0.0, ymax), np.clip(U, 0.0, ymax)


def quantil_split(E, tau):
    """⌈(n+1)τ⌉-ésima estatística de ordem (infinito se o posto passa de n)."""
    E = np.asarray(E, dtype=float)
    n = E.size
    if n == 0:
        return INF
    k = int(math.ceil((n + 1) * tau - 1e-12))
    if k > n:
        return INF
    return float(np.partition(E, k - 1)[k - 1])


def n_efetivo(tau, n_min):
    """Tamanho mínimo de um grupo, contando o ponto de teste: max(n_min, ⌈τ/(1-τ)⌉ + 1)."""
    return int(max(n_min, math.ceil(tau / (1.0 - tau) - 1e-9) + 1))


# ============================================================================ fusão de níveis
def fundir(contagens: np.ndarray, nivel_teste: int | None, n_ef: int) -> np.ndarray:
    """Mapa nível -> grupo fundido para uma família ordenada (níveis 0..L-1). Grupos com menos de n_ef
    amostras (mais o ponto de teste, se nivel_teste for dado) são fundidos com o vizinho de maior
    contagem, até que todos os grupos com amostras tenham pelo menos n_ef ou reste um só."""
    L = len(contagens)
    grupos = [[l] for l in range(L)]

    def ef(g):
        return contagens[g].sum() + (1 if (nivel_teste is not None and nivel_teste in g) else 0)

    while len(grupos) > 1:
        efs = [ef(g) for g in grupos]
        pequenos = [i for i, e in enumerate(efs) if 0 < e < n_ef]
        vazios = [i for i, e in enumerate(efs) if e == 0]
        if vazios:  # nível sem amostra e sem o teste: junta ao vizinho para não sobrar coluna nula
            i = vazios[0]
        elif pequenos:
            i = min(pequenos, key=lambda k: efs[k])
        else:
            break
        viz = [k for k in (i - 1, i + 1) if 0 <= k < len(grupos)]
        k = max(viz, key=lambda v: efs[v])
        a, b = min(i, k), max(i, k)
        grupos[a] = sorted(grupos[a] + grupos[b])
        del grupos[b]
    mapa = np.empty(L, dtype=int)
    for gi, g in enumerate(grupos):
        mapa[g] = gi
    return mapa


@dataclass
class Familias:
    """Códigos por amostra de cada família (0..L-1) e o número de níveis."""
    codigos: dict          # nome -> array int
    niveis: dict           # nome -> L

    def sub(self, m):
        return Familias({k: v[m] for k, v in self.codigos.items()}, self.niveis)


def matriz_phi(fam_cal: Familias, padrao: dict, n_ef: int, contar_teste: bool = True, interacoes: bool = False):
    """Φ das amostras de calibração e φ do padrão de teste, com as fusões. Devolve (Phi, phi, fundiu),
    em que fundiu[nome] diz se a família teve algum nível fundido (para merged_pct)."""
    n = len(next(iter(fam_cal.codigos.values())))
    colunas_cal = [np.ones(n)]
    colunas_te = [1.0]
    fundiu = {}
    mapas = {}
    for nome, cod in fam_cal.codigos.items():
        L = fam_cal.niveis[nome]
        cont = np.bincount(cod, minlength=L).astype(float)
        lt = padrao[nome]
        mapa = fundir(cont, lt if contar_teste else None, n_ef)
        mapas[nome] = mapa
        G = mapa.max() + 1
        fundiu[nome] = G < np.count_nonzero(cont + (np.arange(L) == lt))
        gc = mapa[cod]
        cont_g = np.bincount(gc, minlength=G)
        ref = int(np.argmax(cont_g))
        for g in range(G):
            if g == ref:
                continue
            colunas_cal.append((gc == g).astype(float))
            colunas_te.append(1.0 if mapa[lt] == g else 0.0)
    if interacoes and "regime" in mapas and "hora" in mapas:
        # Interações regime × hora (B4b, L7). Dentro de cada regime fora da referência, as horas são
        # fundidas pela mesma regra (vizinhas, até n_ef amostras contando o teste): uma célula com menos
        # de ⌈τ/(1-τ)⌉ amostras teria limiar infinito. Um bloco por regime fica de referência, para a
        # coluna não repetir a do regime.
        gr = mapas["regime"][fam_cal.codigos["regime"]]
        gh = mapas["hora"][fam_cal.codigos["hora"]]
        tr, th = mapas["regime"][padrao["regime"]], mapas["hora"][padrao["hora"]]
        n_h = int(mapas["hora"].max()) + 1
        ref_r = int(np.argmax(np.bincount(gr)))
        for r in range(int(gr.max()) + 1):
            sel = gr == r
            if r == ref_r or not sel.any():
                continue
            cont_h = np.bincount(gh[sel], minlength=n_h).astype(float)
            mapa_b = fundir(cont_h, th if (contar_teste and tr == r) else None, n_ef)
            n_b = int(mapa_b.max()) + 1
            if n_b < 2:
                continue
            gb = mapa_b[gh]
            ref_b = int(np.argmax(np.bincount(gb[sel], minlength=n_b)))
            for b in range(n_b):
                if b == ref_b:
                    continue
                colunas_cal.append((sel & (gb == b)).astype(float))
                colunas_te.append(1.0 if (tr == r and mapa_b[th] == b) else 0.0)
    Phi = np.column_stack(colunas_cal)
    phi = np.asarray(colunas_te, dtype=float)
    return Phi, phi, fundiu


# ============================================================================ programas lineares
OPCOES_HIGHS = {"primal_feasibility_tolerance": 1e-10, "dual_feasibility_tolerance": 1e-10}


def limiar_condicional(E, Phi, phi, tau, eps=1e-7):
    """Limiar exato do conformal condicional para um padrão de teste (ver o cabeçalho). As tolerâncias do
    HiGHS ficam bem abaixo de ε; com as padrão (1e-7 = ε), em pontos degenerados o HiGHS devolve um
    supergradiente em τ em vez de h'(τ⁻), o que alarga um pouco alguns limiares."""
    t = tau - eps
    try:
        res = linprog(c=-np.asarray(E, dtype=float), A_eq=Phi.T, b_eq=-t * phi, bounds=(tau - 1.0, tau),
                      method="highs", options=OPCOES_HIGHS)
    except ValueError:
        return INF
    if res.status != 0:
        return INF
    lam = np.asarray(res.eqlin.marginals, dtype=float)
    return float(-lam @ phi)


def rq_linear(E, Phi, tau):
    """Regressão quantílica linear sem o ponto imputado (aptidão do Estágio 3): devolve β."""
    try:
        res = linprog(c=-np.asarray(E, dtype=float), A_eq=Phi.T, b_eq=np.zeros(Phi.shape[1]),
                      bounds=(tau - 1.0, tau), method="highs")
    except ValueError:
        return None
    if res.status != 0:
        return None
    return -np.asarray(res.eqlin.marginals, dtype=float)


def limiares_condicionais(E_cal, fam_cal: Familias, fam_te: Familias, tau, n_min, interacoes=False):
    """Limiares q(x) de todos os pontos de teste de uma janela (um LP por padrão distinto)."""
    n_ef = n_efetivo(tau, n_min)
    nomes = list(fam_te.codigos)
    pad = np.column_stack([fam_te.codigos[k] for k in nomes])
    unicos, inv = np.unique(pad, axis=0, return_inverse=True)
    q_u = np.empty(len(unicos))
    fundiu_any = {k: False for k in nomes}
    for u, linha in enumerate(unicos):
        padrao = dict(zip(nomes, (int(v) for v in linha)))
        Phi, phi, fundiu = matriz_phi(fam_cal, padrao, n_ef, True, interacoes)
        q_u[u] = limiar_condicional(E_cal, Phi, phi, tau)
        for k, v in fundiu.items():
            fundiu_any[k] = fundiu_any[k] or bool(v)
    return q_u[np.ravel(inv)], fundiu_any


def limiares_rq(E_fit, fam_fit: Familias, fam_ap: Familias, tau, n_min):
    """Limiares de regressão quantílica simples (plug-in), estimados em fam_fit e aplicados em fam_ap."""
    n_ef = int(n_min)
    nomes = list(fam_fit.codigos)
    n = len(E_fit)
    cols_fit, cols_ap = [np.ones(n)], [np.ones(len(next(iter(fam_ap.codigos.values()))))]
    for nome in nomes:
        L = fam_fit.niveis[nome]
        cod_f, cod_a = fam_fit.codigos[nome], fam_ap.codigos[nome]
        cont = np.bincount(cod_f, minlength=L).astype(float)
        mapa = fundir(cont, None, n_ef)
        gf, ga = mapa[cod_f], mapa[cod_a]
        G = mapa.max() + 1
        ref = int(np.argmax(np.bincount(gf, minlength=G)))
        for g in range(G):
            if g != ref:
                cols_fit.append((gf == g).astype(float))
                cols_ap.append((ga == g).astype(float))
    Phi_f, Phi_a = np.column_stack(cols_fit), np.column_stack(cols_ap)
    beta = rq_linear(E_fit, Phi_f, tau)
    if beta is None:
        q = quantil_split(E_fit, tau)
        return np.full(Phi_a.shape[0], q)
    return Phi_a @ beta


# ============================================================================ Mondrian (artigos 1 e HEC)
def quantis_mondrian(E, g, n_grupos, tau, n_min=30):
    """Q_k = ⌈(n_k+1)τ⌉-ésima estatística do grupo k; usa o quantil global se n_k < n_min ou se o posto
    passa de n_k. Devolve (Q por grupo, nº de grupos que usaram o global)."""
    Qg = quantil_split(E, tau)
    Q = np.full(n_grupos, Qg)
    fallback = 0
    for k in range(n_grupos):
        e = E[g == k]
        nk = e.size
        if nk < n_min or math.ceil((nk + 1) * tau) > nk:
            fallback += int(nk > 0)
            continue
        Q[k] = quantil_split(e, tau)
    return Q, fallback


def ajustar_escala(yhat, sig, Qlo, Qhi, y, alvo, ymax, s_lo=0.9, s_hi=1.3, E_exp=6, J=30, sig_hi=None):
    """Menor s com cobertura de calibração >= alvo (bisseção com expansão do intervalo; Alg. do artigo 1).
    Devolve (s*, nº de expansões). sig_hi: escala do lado de cima, se diferente da de baixo."""

    def cob(s):
        L, U = intervalo(yhat, sig, s * Qlo, s * Qhi, ymax, sig_hi=sig_hi)
        return np.mean((y >= L) & (y <= U))

    exp = 0
    if cob(s_hi) < alvo:
        for _ in range(E_exp):
            s_hi *= 2.0
            exp += 1
            if cob(s_hi) >= alvo:
                break
    lo, hi = s_lo, s_hi
    for _ in range(J):
        mid = 0.5 * (lo + hi)
        if cob(mid) < alvo:
            lo = mid
        else:
            hi = mid
    return hi, exp


def quantis_cpd(e_cal, g_cal, g_te, n_grupos, niveis_p, n_min=30):
    """Quantis da distribuição preditiva conformal (CPD) a partir dos resíduos assinados (normalizados ou
    não) do grupo do ponto de teste; grupos com < n_min amostras usam todos. Devolve (n_te, len(p))."""
    p = np.asarray(niveis_p, dtype=float)
    out = np.empty((len(g_te), len(p)))

    def qs(e):
        e = np.sort(e)
        n = e.size
        if n == 0:                       # janela sem calibração: intervalo físico inteiro
            return np.where(p < 0.5, -INF, INF)
        k = np.clip(np.ceil(p * (n + 1)).astype(int), 1, n) - 1
        return e[k]

    glob = qs(e_cal)
    por = {}
    for k in range(n_grupos):
        e = e_cal[g_cal == k]
        por[k] = qs(e) if e.size >= n_min else glob
    for k in np.unique(g_te):
        out[g_te == k] = por.get(int(k), glob)
    return out


# ============================================================================ BatchMVP (Jung et al., 2023)
class BatchMVP:
    """Limiar multivalido calibrado por limiar sobre grupos sobrepostos.

    f(x) começa no maior limiar da grade; a cada iteração escolhe o par (grupo G, faixa de f) com o maior
    desvio ponderado (n_{G,i}/n)(q - cob_{G,i})² e troca f, nessa célula, pelo quantil conformal das suas
    amostras (posto ⌈(n_c+1)q⌉, arredondado para cima na grade de m faixas; infinito se o posto passa de
    n_c). Uma célula cuja troca não muda f fica bloqueada até a próxima troca. Para quando o maior desvio
    das células não bloqueadas fica abaixo de uma fração (tolerancia) do ruído amostral q(1-q)/n, ou após
    max_iter tentativas (trocas e bloqueios). As atualizações ficam guardadas e são repetidas, na mesma
    ordem, nos pontos de teste.

    Os desvios de todas as células (grupo × faixa) saem de um único bincount sobre os pares (amostra, grupo),
    e só são recalculados depois de uma troca: entre trocas f não muda, então as tentativas seguintes
    descem pela mesma ordenação."""

    def __init__(self, m: int = 100, max_iter: int = 3000, tolerancia: float = 0.25):
        self.m, self.max_iter, self.tol = m, max_iter, tolerancia

    def _faixa(self, f):
        fin = np.isfinite(f)
        out = np.full(f.shape, self.m + 1, dtype=int)
        out[fin] = np.minimum((f[fin] / self.escala * self.m + 1e-9).astype(int), self.m)
        return out

    def ajustar(self, E, G, q):
        E = np.asarray(E, dtype=float)
        G = np.asarray(G, dtype=bool)
        n, K = G.shape
        nb = self.m + 2
        self.vazio = n == 0
        if self.vazio:                   # janela sem calibração: limiar infinito
            self.escala, self.passos = 1.0, []
            return self
        self.escala = float(max(E.max(), 1e-9)) * (1 + 1e-9)
        grade = np.arange(self.m + 1) / self.m * self.escala
        f = np.full(n, grade[-1])
        self.passos = []
        lim = self.tol * q * (1 - q) / n
        lin, grp = np.nonzero(G)
        tentativas = 0
        while tentativas < self.max_iter:
            fx = self._faixa(f)
            cob = (E <= f + 1e-12).astype(float)
            chave = grp * nb + fx[lin]
            cont = np.bincount(chave, minlength=K * nb)
            soma = np.bincount(chave, weights=cob[lin], minlength=K * nb)
            desv = np.zeros(K * nb)
            ok = cont > 0
            desv[ok] = cont[ok] / n * (q - soma[ok] / cont[ok]) ** 2
            trocou = False
            for k in np.argsort(-desv, kind="stable"):
                if desv[k] <= lim or tentativas >= self.max_iter:
                    break
                tentativas += 1
                gi, i = divmod(int(k), nb)
                cel = G[:, gi] & (fx == i)
                e = E[cel]
                r = int(math.ceil((e.size + 1) * q - 1e-12))
                novo = INF if r > e.size else float(np.partition(e, r - 1)[r - 1])
                if np.isfinite(novo):
                    novo = float(grade[min(int(np.ceil(novo / self.escala * self.m - 1e-9)), self.m)])
                atual = f[cel]
                if (np.isfinite(novo) and np.allclose(atual, novo)) or (not np.isfinite(novo) and np.all(~np.isfinite(atual))):
                    continue                                   # bloqueada até a próxima troca
                f[cel] = novo
                self.passos.append((gi, i, novo))
                trocou = True
                break
            if not trocou:
                break
        return self

    def prever(self, G):
        if getattr(self, "vazio", False):
            return np.full(G.shape[0], INF)
        f = np.full(G.shape[0], self.escala)
        for gi, i, novo in self.passos:
            cel = G[:, gi] & (self._faixa(f) == i)
            f[cel] = novo
        return f


# ============================================================================ CQR e split absoluto
def cqr(qlo_cal, qhi_cal, y_cal, qlo_te, qhi_te, nivel, ymax):
    s = np.maximum(qlo_cal - y_cal, y_cal - qhi_cal)
    Q = quantil_split(s, nivel)
    if not np.isfinite(Q):
        return np.zeros_like(qlo_te), np.full_like(qhi_te, ymax)
    return np.clip(qlo_te - Q, 0, ymax), np.clip(qhi_te + Q, 0, ymax)


def split_absoluto(r_cal, yhat_te, nivel, ymax):
    Q = quantil_split(np.abs(r_cal), nivel)
    if not np.isfinite(Q):
        return np.zeros_like(yhat_te), np.full_like(yhat_te, ymax)
    return np.clip(yhat_te - Q, 0, ymax), np.clip(yhat_te + Q, 0, ymax)


def matriz_grupos(fam: Familias, incluir_todos: bool = True) -> np.ndarray:
    """Indicadores (n, |G|) dos grupos de cada família (+ o grupo 'todos'), para o BatchMVP."""
    cols = [np.ones(len(next(iter(fam.codigos.values()))), dtype=bool)] if incluir_todos else []
    for nome, cod in fam.codigos.items():
        for l in range(fam.niveis[nome]):
            cols.append(cod == l)
    return np.column_stack(cols)


# ============================================================================ tarefas paralelas (Estágio 4)
def tarefa_janela_cc(args):
    """Uma janela (horizonte, mês) do conformal condicional: limiares do IP e, se pedido, da grade do CRPS.
    Função de módulo para poder rodar em processos separados."""
    import time as _t

    Ep, Em, cod_c, cod_t, niveis, tau, n_min, interacoes, grade = args
    fc, ft_ = Familias(cod_c, niveis), Familias(cod_t, niveis)
    t0 = _t.time()
    qh, f1 = limiares_condicionais(Ep, fc, ft_, tau, n_min, interacoes)
    ql, f2 = limiares_condicionais(Em, fc, ft_, tau, n_min, interacoes)
    t_pi = _t.time() - t0
    G = None
    if grade is not None:
        G = np.empty((len(next(iter(cod_t.values()))), len(grade)))
        for c, p in enumerate(grade):
            if p > 0.5:
                G[:, c], _ = limiares_condicionais(Ep, fc, ft_, p, n_min, interacoes)
            else:
                G[:, c], _ = limiares_condicionais(Em, fc, ft_, 1 - p, n_min, interacoes)
    return qh, ql, f1, f2, G, t_pi


def tarefa_janela_mvp(args):
    Ep, Em, Gc, Gt, tau, faixas, tol, grade = args

    def aj(E, q):
        return BatchMVP(faixas, tolerancia=tol).ajustar(E, Gc, q).prever(Gt)

    qh, ql = aj(Ep, tau), aj(Em, tau)
    G = None
    if grade is not None:
        G = np.empty((Gt.shape[0], len(grade)))
        for c, p in enumerate(grade):
            G[:, c] = aj(Ep, p) if p > 0.5 else aj(Em, 1 - p)
    return qh, ql, G


def mapear(funcao, tarefas, processos: int):
    """Executa as tarefas em processos separados (processos > 1) ou em sequência."""
    if processos <= 1 or len(tarefas) <= 1:
        return [funcao(t) for t in tarefas]
    import multiprocessing as mp
    import sys
    from concurrent.futures import ProcessPoolExecutor

    # Linux: forkserver. O padrão (fork) copiaria o processo principal, que já tem o contexto do CUDA e as threads do
    # PyTorch; no Windows e no macOS o padrão já é spawn.
    ctx = mp.get_context("forkserver") if sys.platform.startswith("linux") else None
    with ProcessPoolExecutor(max_workers=processos, mp_context=ctx) as ex:
        return list(ex.map(funcao, tarefas, chunksize=1))
