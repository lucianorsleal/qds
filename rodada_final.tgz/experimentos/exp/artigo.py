"""Saídas prontas para o artigo: tabelas LaTeX, macros, figuras e guia de redação (artigo 2).

Lê os CSVs que o 'juntar' grava em saida_artigo/{results,data} e grava, na mesma pasta:

  tables/tab_*.tex             as tabelas do artigo, com os mesmos nomes e o mesmo formato que o main.tex inclui
                               (\\input{tables/...}), para qualquer conjunto de sites
  tables/tab_data.tex          a Tab. 4 (sites e dados), a partir do config e dos resumos da coleta
  macros/results_macros.tex    todos os números citados no texto (\\R...), com os nomes que o main.tex usa
  macros/wgc_reference.tex     a referência amostral do WGC (simulação binomial com os tamanhos dos grupos)
  data/fig_is_horizon.csv, data/fig_wgc_horizon.csv, data/fig_ranks.csv   dados derivados (figuras em pgfplots)
  figuras/fig_*.pdf e .png     as figuras de resultados em matplotlib (alternativa às do pgfplots)
  figuras/fig_vsn_pgfplots.tex o trecho em pgfplots da Fig. 9 para o número de sites desta rodada
  GUIA_ARTIGO.md               onde cada saída entra, o que muda no texto e o que os números confirmam

Faz o papel do tools/render_tables.py e do tools/wgc_reference.py do projeto LaTeX, mas sem a lista de
sites fixa (a versão do zip de 16/10 procura ASP, GTB, UTR e BRA). No perfil 'rapido' tudo sai marcado
como hipotético (valores em vermelho no PDF e figuras com marca d'água), porque não serve para o artigo.
"""

from __future__ import annotations

import json
import logging
import math
import shutil
from pathlib import Path

import numpy as np
import pandas as pd

from .config import ORDEM_SITES

log = logging.getLogger("exp")

H4 = ["1h", "3h", "6h", "DA"]
HZ = ["1h", "6h", "DA"]
HLAB = {"1h": r"$h=1$\,h", "3h": r"$h=3$\,h", "6h": r"$h=6$\,h", "DA": r"Day-ahead (DA)"}
TAG = {"1h": "One", "3h": "Three", "6h": "Six", "DA": "DA"}
EXT = {1: "one", 2: "two", 3: "three", 4: "four", 5: "five", 6: "six", 7: "seven", 8: "eight", 9: "nine",
       10: "ten", 12: "twelve", 16: "sixteen", 20: "twenty", 24: "twenty-four"}

MODELO = "CCP-Boot-TFT-GBM"     # nome provisório do modelo da v3 (macro \RModelName; troque aqui se mudar)
DISPLAY = {"CHPeEn": r"CH-PeEn~\cite{yang2019universal}",
           "LGBM_CQR": r"LightGBM + CQR~\cite{romano2019conformalized}",
           "HEC": r"HEC-XGB~\cite{gangwar2026climate}",
           "PRIOR": r"CP-Boot-LSTM-ICSO-PP~\cite{prior2026conformalized}",
           "TFT": r"TFT, native quantiles~\cite{lim2021temporal}",
           "CQR_TFT": r"TFT + CQR",
           "MVP": r"Hybrid + BatchMVP~\cite{jung2023batch}",
           "PROP": r"\textbf{" + MODELO + "}"}
SHORT = {"PRIOR": r"\cite{prior2026conformalized}", "HEC": r"\cite{gangwar2026climate}", "MVP": "MVP", "PROP": "Ours"}
GROUPS = [["CHPeEn"], ["LGBM_CQR"], ["HEC", "PRIOR"], ["TFT", "CQR_TFT", "MVP"], ["PROP"]]   # v2: sem o Chronos
ORDER = [m for g in GROUPS for m in g]
NOME = {"CHPeEn": "CH-PeEn", "LGBM_CQR": "LightGBM + CQR", "HEC": "HEC-XGB",
        "PRIOR": "CP-Boot-LSTM-ICSO-PP", "TFT": "TFT, native quantiles", "CQR_TFT": "TFT + CQR",
        "MVP": "Hybrid + BatchMVP", "PROP": MODELO + " (ours)"}
# Paleta das figuras: os tons do main.tex (cProp, cHEC, cOrig, cCQR, cEnb, cGray), com azul, roxo, verde e
# rosa ajustados para passar no teste de daltonismo (scripts/validate_palette.js da skill de dataviz).
CORES = {"PROP": "#EB6834", "MVP": "#1F6FD1", "PRIOR": "#A23E95", "HEC": "#178F63", "CQR_TFT": "#D35F94",
         "TFT": "#52514E", "LGBM_CQR": "#8C8C8C", "CHPeEn": "#C8C8C8"}
VERMELHO, BRANCO, AZUL = (178 / 255, 24 / 255, 43 / 255), (247 / 255, 247 / 255, 247 / 255), (33 / 255, 102 / 255, 172 / 255)
LARG1, LARG2 = 3.5, 7.16      # polegadas: uma e duas colunas do IEEE Access

HYP_NOTE = (r"\ifshowplaceholders\ \textcolor{hypred}{\textbf{[Quick-test values (profile \texttt{rapido})"
            r" -- not experimental results.]}}\fi")
LNAME = {"L1": r"Split CP, absolute residuals",
         "L2": r"Normalized split CP, global",
         "L3": r"Mondrian, hour~\cite{prior2026conformalized}",
         "L4": r"Mondrian, regime $\times$ hour",
         "L5": r"BatchMVP over $\mathcal{G}$~\cite{jung2023batch}",
         "L6": r"\textbf{Conditional CP over $\mathcal{G}$ (ours)}",
         "L7": r"Conditional CP, $\mathcal{G}$ + regime$\times$hour"}
FAM = [("regime", r"NWP regime$^{\ast}$", [("Clear", "Clear"), ("Partly", "Partly cloudy"), ("Overcast", "Overcast")]),
       ("tertile", r"Dispersion tertile$^{\ast}$", [("Low", r"Low $\tilde\sigma$"), ("Mid", r"Mid $\tilde\sigma$"),
                                                     ("High", r"High $\tilde\sigma$")]),
       ("season", r"Local season", [("Winter", "Winter"), ("Spring", "Spring"), ("Summer", "Summer"), ("Autumn", "Autumn")]),
       ("sky", r"Ex-post sky class", [("Sun", "Sunny"), ("LC", "Light clouds"), ("HC", "Heavy clouds")])]
GM = ["PRIOR", "HEC", "MVP", "PROP"]
AD = {"B1": r"Boot-TFT, $\sigma_{\mathrm{epi}}$, Mondrian (hour), Adam heads",
      "B2": r"+ total dispersion $\sigma_{\mathrm{tot}}$ ($\gamma=1$)",
      "B3": r"+ conditional CP over $\mathcal{G}$ (replaces Mondrian)",
      "B4": r"+ separate lower and upper scales from the quantile heads",
      "B5": r"+ LightGBM, TFT weight chosen per window (\textbf{proposed})",
      "B4h": r"B4 + ICSO-PP on median heads and $\gamma$ (Stage~3 of~\cite{prior2026conformalized})",
      "B5a": r"B5, $\Phi$ without NWP regimes",
      "B5b": r"B5, $\Phi$ + regime$\times$hour interactions",
      "B5c": r"B5, no safety buffer ($\delta=0$)",
      "B5d": r"B5, static (non-rolling) calibration",
      "B5e": r"Boot-LSTM backbone of~\cite{prior2026conformalized} instead of the hybrid",
      "B5f": r"B5, TFT weight fixed per horizon (validation block)",
      "B5g": r"B5, LightGBM only (TFT weight 0)"}
# macros da v2 que a v3 não calcula mais (Tab. 10, Fig. 8, Estágio 3 com ICSO-PP): saem como '--' para o main.tex
# antigo continuar compilando até ser reescrito
MACROS_LEGADO = ["OptGain", "OptPCMA", "OptPLSHADE", "OptPPSO", "OptPICSO", "OptPTPE", "OptTPETime", "OptICSOTime",
                 "OptFvalICSOPP", "CostICSO"]
ON = {"Adam": r"Adam heads only", "ICSO-PP": r"\textbf{ICSO-PP (ours)}", "CMA-ES": r"CMA-ES~\cite{hansen2001completely}",
      "L-SHADE": r"L-SHADE~\cite{tanabe2014improving}", "ICSO": r"ICSO (no PP)", "CSO": r"CSO~\cite{meng2014new}",
      "PSO": r"PSO", "TPE": r"TPE (Optuna)~\cite{akiba2019optuna}"}
SN = {"S0": "Nominal", "S1": r"NWP noise, 10\%", "S2": r"NWP noise, 20\%", "S3": r"NWP outage (24-h-old run)",
      "S4": r"Missing power, 10\%", "S5": r"Missing power, 30\%"}
VSN_ROTULOS = ["Past clear-sky index", "Rolling statistics", "NWP clear-sky index", "NWP GHI", "Cloud cover",
               "Temperature/RH", "Wind ($u$, $v$)", "Solar geometry", "Calendar"]
Q05_NEMENYI = {2: 1.960, 3: 2.343, 4: 2.569, 5: 2.728, 6: 2.850, 7: 2.949, 8: 3.031, 9: 3.102, 10: 3.164}
RES_NATIVA = {"dkasc": "5 min", "ons": "1 h", "pvdaq": "5 min", "nist": "1 min", "utrecht": "1 min", "ukpv": "30 min",
              "hkg": "1 min"}
CITA_FONTE = {"dkasc": r"~\cite{dkasc}", "ons": r"~\cite{ons2026geracao}", "pvdaq": r"~\cite{pvdaq9069}"}


def _finito(x) -> bool:
    try:
        return x is not None and np.isfinite(float(x))
    except (TypeError, ValueError):
        return False


def _ext(n: int) -> str:
    return EXT.get(int(n), str(int(n)))


class Artigo:
    def __init__(self, cfg: dict, destino: Path, hipotetico: bool):
        self.cfg, self.d, self.hyp = cfg, Path(destino), bool(hipotetico)
        self.res, self.dat = self.d / "results", self.d / "data"
        self.tab, self.mac_dir, self.fig = self.d / "tables", self.d / "macros", self.d / "figuras"
        for p in (self.tab, self.mac_dir, self.fig, self.dat):
            p.mkdir(parents=True, exist_ok=True)
        self.macros: dict = {}
        self.hypfig: dict = {}
        self.extra_tex: list = []
        self.checks: list = []
        self.avisos: list = []
        self.wgc_ref = {0.96: np.nan, 0.95: np.nan}

    # ================================================================== utilidades
    def fmt(self, x, nd=1, bold=False):
        if not _finito(x):
            return "--"
        s = f"{float(x):.{nd}f}"
        if bold:
            s = r"\textbf{" + s + "}"
        return r"\hyp{" + s + "}" if self.hyp else s

    def wrap(self, s: str) -> str:
        return r"\hyp{" + s + "}" if self.hyp else s

    def mac(self, nome, valor, nd=1):
        self.macros[nome] = (f"{float(valor):.{nd}f}" if _finito(valor) else "--", self.hyp)

    def mac_txt(self, nome, texto, hyp=False):
        self.macros[nome] = (texto, hyp)

    def nota(self) -> str:
        return HYP_NOTE if self.hyp else ""

    def write(self, nome: str, linhas: list) -> None:
        (self.tab / nome).write_text("% Gerado por exp/artigo.py (pacote de experimentos) -- não editar à mão.\n"
                                     + "\n".join(linhas) + "\n", encoding="utf-8")

    def check(self, secao: str, afirmacao: str, valores: str, ok) -> None:
        try:
            ok = None if ok is None else bool(ok)
        except (TypeError, ValueError):
            ok = None
        self.checks.append({"secao": secao, "afirmacao": afirmacao, "valores": valores, "ok": ok})

    def txt_sites(self) -> str:
        return "the single site" if self.n_sites == 1 else f"the {_ext(self.n_sites)} sites"

    def txt_seeds(self) -> str:
        n = self.n_seeds
        return "ten seeds" if n == 10 else (f"{_ext(n)} seed" + ("s" if n != 1 else ""))

    def lista_sites(self, conj="and") -> str:
        s = self.sites
        return s[0] if len(s) == 1 else ", ".join(s[:-1]) + f" {conj} " + s[-1]

    # ================================================================== leitura
    def carregar(self) -> None:
        def ler(nome, pasta=None):
            arq = (pasta or self.res) / nome
            return pd.read_csv(arq, comment="#") if arq.exists() else None

        self.main = ler("main_metrics.csv")
        if self.main is None or self.main.empty:
            raise SystemExit(f"falta {self.res / 'main_metrics.csv'}; rode 'executar.py relatorio' e 'juntar' antes")
        if self.main[self.main.method == "PROP"][["IS"]].isna().all().all():
            raise SystemExit("o main_metrics.csv não tem resultados do modelo proposto (PROP)")
        self.diag, self.grp, self.lay = ler("site_diagnostics.csv"), ler("group_coverage.csv"), ler("calib_layers.csv")
        self.ab, self.op, self.st = ler("ablation.csv"), ler("optimizer.csv"), ler("stress.csv")
        self.co, self.gs = ler("cost.csv"), ler("group_sizes.csv")
        self.heat_m, self.heat_c = ler("fig_heat_mondrian.csv", self.dat), ler("fig_heat_cc.csv", self.dat)
        self.conv, self.att = ler("fig_convergence.csv", self.dat), ler("fig_attention.csv", self.dat)
        self.vsn1, self.vsnd = ler("fig_vsn_1h.csv", self.dat), ler("fig_vsn_DA.csv", self.dat)
        self.mult, self.exemplo = ler("fig_cc_multipliers.csv", self.dat), ler("fig_example.csv", self.dat)
        self.pesos = ler("fig_weights.csv", self.dat)
        presentes = list(dict.fromkeys(self.main["site"].astype(str)))
        self.sites = [s for s in ORDEM_SITES if s in presentes] + [s for s in presentes if s not in ORDEM_SITES]
        self.n_sites, self.n_pares = len(self.sites), 4 * len(self.sites)
        arq_meta = self.d / "meta.json"
        self.meta = json.loads(arq_meta.read_text(encoding="utf-8")).get("por_site", {}) if arq_meta.exists() else {}
        sem = [int(m.get("n_sementes", 0)) for m in self.meta.values() if m.get("n_sementes")]
        self.n_seeds = min(sem) if sem else len(self.cfg.get("sementes", [])) or 10
        if sem and len(set(sem)) > 1:
            self.avisos.append(f"Os sites têm números de sementes diferentes ({dict((k, v.get('n_sementes')) for k, v in self.meta.items())}); "
                               "as médias usam as sementes prontas de cada site.")
        self.membros = int(self.cfg.get("ensemble", {}).get("membros", 10))
        col = (self.cfg.get("_coleta") or {}).get("sites", {})
        self.info_sites = {s: dict(col.get(s, {})) for s in self.sites}
        proc = self.cfg.get("pasta_processados")
        for s in self.sites:
            arq = Path(proc) / s / "resumo.json" if proc else None
            self.info_sites[s]["_resumo"] = (json.loads(arq.read_text(encoding="utf-8"))
                                             if arq is not None and arq.exists() else {})
            if proc and (Path(proc) / s / "particoes.csv").exists():
                from .dados import meses_teto_baixo, razao_teto

                todos, teste = meses_teto_baixo(Path(proc) / s, Path(proc) / s / "particoes.csv")
                if sum(razao_teto(x) < 0.70 for x in teste) >= 2:
                    self.avisos.append(
                        f"**{s}: a saída da usina não acompanha a irradiância em boa parte do ano de teste.** Em "
                        f"{len(todos)} meses ({len(teste)} do ano de teste: {', '.join(teste)}) o teto mensal ficou "
                        "abaixo de 80% da referência de céu claro da coleta. Os intervalos de todos os métodos perdem "
                        "cobertura nesse site e a comparação reflete a limitação da usina, não o clima. Veja o README, "
                        "seção 6, antes de usar este site no artigo.")
        aridos =[s for s in self.sites if str(self.info_sites[s].get("koppen", "")).upper().startswith("BW")]
        if aridos:
            self.arido = aridos[0]
        elif self.diag is not None and not self.diag.empty:
            self.arido = str(self.diag.groupby("site")["merged_pct"].mean().idxmax())
        else:
            self.arido = self.sites[0]
        self.avg = self.main.groupby(["horizon", "method"]).mean(numeric_only=True)
        faltam = sorted({str(m) for m in self.main.loc[self.main[["IS"]].isna().all(axis=1), "method"]})
        if faltam:
            self.avisos.append("Sem resultado ainda: " + ", ".join(faltam) + ". As células saem como '--' e esses "
                               "métodos ficam fora dos postos de Friedman.")

    def a(self, h, m, col):
        try:
            return float(self.avg.loc[(h, m), col])
        except KeyError:
            return np.nan

    # ================================================================== referência do WGC
    def wgc_reference(self, reps: int = 4000) -> None:
        rng = np.random.default_rng(2027)
        provisorio = self.gs is None or self.gs.empty
        if provisorio:
            sites = [([180, 300] + [365] * 9 + [300, 180], [0.48, 0.33, 0.19], [1 / 3] * 3)]
        else:
            sites = []
            for _, g in self.gs.groupby("site"):
                horas = g[g.family == "hour"].sort_values("group")["n_test"].astype(int).tolist()
                reg = g[g.family == "regime"]["n_test"].to_numpy(float)
                ter = g[g.family == "tertile"]["n_test"].to_numpy(float)
                sites.append((horas, (reg / max(reg.sum(), 1)).tolist(), (ter / max(ter.sum(), 1)).tolist()))

        def simula(horas, reg, ter, p):
            n = int(sum(horas))
            hid = np.repeat(np.arange(len(horas)), horas)
            mins = np.empty(reps)
            for r in range(reps):
                rg = rng.choice(len(reg), size=n, p=reg)
                tr = rng.choice(len(ter), size=n, p=ter)
                cob = rng.random(n) < p
                gr = [cob[hid == h] for h in range(len(horas))] + [cob[rg == k] for k in range(len(reg))] \
                    + [cob[tr == k] for k in range(len(ter))]
                mins[r] = min(x.mean() for x in gr if x.size)
            return 100.0 * mins.mean()

        self.wgc_ref = {p: float(np.mean([simula(h, r, t, p) for h, r, t in sites])) for p in (0.96, 0.95)}
        wrap = (lambda v: r"\tbc{" + v + "}") if provisorio else (lambda v: v)
        txt = ["% Gerado por exp/artigo.py (pacote de experimentos) -- não editar à mão.",
               f"% fonte: {'tamanhos típicos (provisório)' if provisorio else 'results/group_sizes.csv'}, reps={reps}",
               f"\\newcommand{{\\RWGCRefRaw}}{{{self.wgc_ref[0.96]:.2f}}}",
               f"\\newcommand{{\\RWGCRefSix}}{{{wrap(f'{self.wgc_ref[0.96]:.1f}')}\\xspace}}",
               f"\\newcommand{{\\RWGCRefFive}}{{{wrap(f'{self.wgc_ref[0.95]:.1f}')}\\xspace}}",
               f"\\newif\\ifwgcrefprovisional\\wgcrefprovisional{'true' if provisorio else 'false'}"]
        (self.mac_dir / "wgc_reference.tex").write_text("\n".join(txt) + "\n", encoding="utf-8")

    # ================================================================== tabelas
    def tabelas(self) -> None:
        self._tab_main()
        self._tab_sites()
        if self.lay is not None and not self.lay.empty:
            self._tab_layers()
        if self.grp is not None and not self.grp.empty:
            self._tab_groups()
        if self.ab is not None and not self.ab.empty:
            self._tab_ablation()
        for nome in MACROS_LEGADO:              # v3: sem a Tab. 10 (otimizadores) e sem o ICSO-PP no custo
            self.mac(nome, np.nan)
        icso = self.cfg.get("icso") or {}
        self.mac("OptEvals", int(icso.get("N", 40)) * (int(icso.get("T", 50)) + 1), 0)   # orçamento do ICSO-PP (B4h)
        if self.st is not None and not self.st.empty:
            self._tab_stress()
        if self.co is not None and not self.co.empty:
            self._tab_cost()
        self._tab_data()
        self._macros_figuras()

    # ------------------------------------------------------------------ Tab. 5 (principal)
    def _tab_main(self) -> None:
        avg = self.avg
        L = [r"\begin{table*}[!t]",
             r"\caption{Probabilistic performance averaged over " + self.txt_sites() + " and " + self.txt_seeds()
             + r" (nominal coverage 95\%; daylight hours). IS and PINAW are in \% of rated capacity. WGC is the "
             r"worst-group coverage over the conditioning groups $\mathcal{G}$ (hours of day, NWP weather regimes and "
             r"dispersion tertiles); CRPSS is relative to CH-PeEn. Bold: best IS, WGC and CRPSS, and PICP closest to 95\%."
             + self.nota() + "}",
             r"\label{tab:main}", r"\centering", r"\setlength{\tabcolsep}{2.4pt}",
             r"\begin{tabular}{@{}l" + "ccccc" * 3 + r"@{}}", r"\toprule",
             " & " + " & ".join(r"\multicolumn{5}{c}{" + HLAB[h] + "}" for h in HZ) + r" \\",
             r"\cmidrule(lr){2-6}\cmidrule(lr){7-11}\cmidrule(lr){12-16}",
             "Model" + r" & IS$\downarrow$ & PICP & WGC$\uparrow$ & PINAW$\downarrow$ & CRPSS$\uparrow$" * 3 + r" \\",
             r"\midrule"]
        best = {}
        for h in HZ:
            sub = avg.loc[h]
            best[(h, "IS")] = sub["IS"].idxmin() if sub["IS"].notna().any() else None
            best[(h, "PICP")] = (sub["PICP"] - 95).abs().idxmin() if sub["PICP"].notna().any() else None
            best[(h, "WGC")] = sub["WGC"].idxmax() if sub["WGC"].notna().any() else None
            c = sub.drop(index="CHPeEn", errors="ignore")["CRPSS"]
            best[(h, "CRPSS")] = c.idxmax() if c.notna().any() else None
        for gi, grp in enumerate(GROUPS):
            for m in grp:
                cells = [DISPLAY[m]]
                for h in HZ:
                    cells += [self.fmt(self.a(h, m, "IS"), 1, best[(h, "IS")] == m),
                              self.fmt(self.a(h, m, "PICP"), 1, best[(h, "PICP")] == m),
                              self.fmt(self.a(h, m, "WGC"), 1, best[(h, "WGC")] == m),
                              self.fmt(self.a(h, m, "PINAW"), 3),
                              "--" if m == "CHPeEn" else self.fmt(self.a(h, m, "CRPSS"), 3, best[(h, "CRPSS")] == m)]
                L.append(" & ".join(cells) + r" \\")
            if gi < len(GROUPS) - 1:
                L.append(r"\midrule")
        L += [r"\bottomrule", r"\end{tabular}", r"\end{table*}"]
        self.write("tab_main.tex", L)

        # macros do texto (mesmos nomes do tools/render_tables.py)
        for h in H4:
            tag = TAG[h]
            p_is = self.a(h, "PROP", "IS")
            for m, nm in [("PROP", "Prop"), ("PRIOR", "Prior"), ("MVP", "MVP"), ("HEC", "HEC"), ("CQR_TFT", "CQRTFT"),
                          ("TFT", "TFT"), ("LGBM_CQR", "LGBM")]:
                self.mac(f"IS{nm}{tag}", self.a(h, m, "IS"))
                self.mac(f"WGC{nm}{tag}", self.a(h, m, "WGC"))
                self.mac(f"PICP{nm}{tag}", self.a(h, m, "PICP"))
                if m != "PROP":
                    o = self.a(h, m, "IS")
                    self.mac(f"Red{nm}{tag}", 100 * (1 - p_is / o) if _finito(o) and o > 0 else np.nan)
            self.mac(f"RedChronos{tag}", np.nan)    # v2 sem o Chronos: '--' para o main.tex antigo compilar
            self.mac(f"CRPSSProp{tag}", self.a(h, "PROP", "CRPSS"), 3)
            self.mac(f"FSSProp{tag}", self.a(h, "PROP", "FSS"), 3)
            self.mac(f"CCDProp{tag}", self.a(h, "PROP", "CCD"), 2)
            self.mac(f"CCDPrior{tag}", self.a(h, "PRIOR", "CCD"), 2)
            self.mac(f"WGCskyProp{tag}", self.a(h, "PROP", "WGC_sky"))
            self.mac(f"WGCskyPrior{tag}", self.a(h, "PRIOR", "WGC_sky"))
        self.red = {}
        for m, nm in [("PRIOR", "Prior"), ("MVP", "MVP"), ("HEC", "HEC"), ("CQR_TFT", "CQRTFT"), ("TFT", "TFT"),
                      ("LGBM_CQR", "LGBM")]:
            red = [100 * (1 - self.a(h, "PROP", "IS") / self.a(h, m, "IS")) for h in H4 if _finito(self.a(h, m, "IS"))]
            self.red[m] = red
            self.mac(f"Red{nm}Min", min(red) if red else np.nan)
            self.mac(f"Red{nm}Max", max(red) if red else np.nan)
        for m, nm in [("PROP", "Prop"), ("PRIOR", "Prior"), ("MVP", "MVP"), ("HEC", "HEC"), ("TFT", "TFT"),
                      ("CQR_TFT", "CQRTFT")]:
            v = [self.a(h, m, "WGC") for h in H4]
            self.mac(f"WGC{nm}Min", np.nanmin(v) if np.isfinite(v).any() else np.nan)
            self.mac(f"WGC{nm}Max", np.nanmax(v) if np.isfinite(v).any() else np.nan)
            v = [self.a(h, m, "PICP") for h in H4]
            self.mac(f"PICP{nm}Min", np.nanmin(v) if np.isfinite(v).any() else np.nan)
            self.mac(f"PICP{nm}Max", np.nanmax(v) if np.isfinite(v).any() else np.nan)
        pp = self.main[self.main.method == "PROP"]
        self.mac("PICPPropSiteMin", pp.PICP.min()); self.mac("PICPPropSiteMax", pp.PICP.max())
        self.mac("WGCPropSiteMin", pp.WGC.min()); self.mac("WGCPropSiteMax", pp.WGC.max())
        pr = self.main[self.main.method == "PRIOR"]
        self.mac("WGCPriorSiteMin", pr.WGC.min())

        # dados derivados das figuras em pgfplots
        hdr = "# HYPOTHETICAL PLACEHOLDER DATA - quick-test profile (rapido), not experimental results\n" if self.hyp else ""
        self.fig_is, self.fig_wgc = None, None
        for col, fn in [("IS", "fig_is_horizon.csv"), ("WGC", "fig_wgc_horizon.csv")]:
            d = pd.DataFrame({"hidx": [1, 2, 3, 4], "hlab": H4})
            for m in ORDER:
                d[m] = [self.a(h, m, col) for h in H4]
            with open(self.dat / fn, "w", encoding="utf-8") as f:
                f.write(hdr)
                d.to_csv(f, index=False, float_format="%.3f")
            if col == "IS":
                self.fig_is = d
            else:
                self.fig_wgc = d
        self.hypfig["Horizon"] = self.hyp

        # Friedman e Nemenyi no IS, blocos site × horizonte (só métodos com todos os blocos)
        piv = self.main.pivot_table(index=["site", "horizon"], columns="method", values="IS", dropna=False)
        completos = [m for m in ORDER if m in piv.columns and piv[m].notna().all()]
        piv = piv[completos].dropna()
        self.friedman = None
        if len(completos) >= 2 and len(piv) >= 2:
            from scipy.stats import chi2 as qui2

            R = piv.rank(axis=1, method="average").mean()
            N, k = piv.shape
            chi = 12 * N / (k * (k + 1)) * (np.sum(R ** 2) - k * (k + 1) ** 2 / 4)
            p_chi = float(qui2.sf(chi, k - 1))
            cd = Q05_NEMENYI.get(k, np.nan) * math.sqrt(k * (k + 1) / (6 * N))
            rk = pd.DataFrame({"method": R.index, "rank": R.values}).sort_values("rank", ascending=False)
            rk["y"] = range(len(rk))
            with open(self.dat / "fig_ranks.csv", "w", encoding="utf-8") as f:
                f.write(hdr)
                rk.to_csv(f, index=False, float_format="%.3f")
            self.friedman = {"R": R, "N": N, "k": k, "chi2": chi, "p": p_chi, "CD": cd, "rk": rk}
            self.mac("RankProp", R.get("PROP", np.nan), 2)
            self.mac("RankMVP", R.get("MVP", np.nan), 2)
            self.mac("RankPrior", R.get("PRIOR", np.nan), 2)
            self.mac("FriedmanChi", chi)
            self.mac("CDval", cd, 2)
            self.macros["FriedmanP"] = ("<10^{-6}" if p_chi < 1e-6 else f"={p_chi:.1e}", self.hyp)
            self.macros["CDvalRaw"] = (f"{cd:.4f}", False)
            self.macros["CDvalX"] = (f"{R.get('PROP', np.nan) + cd:.4f}", False)
            self.macros["RankPropRaw"] = (f"{R.get('PROP', np.nan):.4f}", False)
            self.macros["RankPropY"] = (str(int(rk.set_index("method").loc["PROP", "y"])) if "PROP" in R else "0", False)
            rot = ",".join("{" + (NOME[m] if m != "PROP" else "Ours") + "}" for m in rk.sort_values("y")["method"])
            self.extra_tex = [r"\pgfplotsset{rankticks/.style={ytick={0,...,%d}, yticklabels={%s}}}" % (len(rk) - 1, rot)]
        self.hypfig["Ranks"] = self.hyp

    # ------------------------------------------------------------------ Tab. 6 (por site)
    def _tab_sites(self) -> None:
        main, diag = self.main, self.diag
        L = [r"\begin{table*}[!t]",
             r"\caption{Per-site results with the single fixed specification. IS is the mean over " + self.txt_seeds()
             + r" ($\pm$ one standard deviation for the proposed model). DM: $p$-values of one-sided Diebold--Mariano "
             r"tests on daily IS (H$_1$: the proposed model has a lower IS), Holm-corrected across the "
             + _ext(self.n_pares) + r" site--horizon pairs." + self.nota() + "}",
             r"\label{tab:sites}", r"\centering", r"\setlength{\tabcolsep}{3.6pt}",
             r"\begin{tabular}{@{}llcccccccc@{}}", r"\toprule",
             r" & & \multicolumn{3}{c}{IS (\% of $P_\mathrm{nom}$)$\downarrow$} & \multicolumn{1}{c}{PICP} & "
             r"\multicolumn{2}{c}{WGC$\uparrow$} & \multicolumn{2}{c}{DM $p$ vs.} \\",
             r"\cmidrule(lr){3-5}\cmidrule(lr){6-6}\cmidrule(lr){7-8}\cmidrule(lr){9-10}",
             r"Site & $h$ & Ours & MVP & \cite{prior2026conformalized} & Ours & Ours & \cite{prior2026conformalized} & "
             r"MVP & \cite{prior2026conformalized} \\",
             r"\midrule"]

        def val(sub, m, c):
            try:
                return float(sub.loc[m, c])
            except KeyError:
                return np.nan

        for si, s in enumerate(self.sites):
            for j, h in enumerate(H4):
                sub = main[(main.site == s) & (main.horizon == h)].set_index("method")
                d = diag[(diag.site == s) & (diag.horizon == h)] if diag is not None else pd.DataFrame()
                p_mvp = float(d["dm_p_vs_MVP"].iloc[0]) if len(d) else np.nan
                p_pri = float(d["dm_p_vs_PRIOR"].iloc[0]) if len(d) else np.nan
                pis, psd = val(sub, "PROP", "IS"), val(sub, "PROP", "IS_sd")
                cell = (self.wrap(r"\textbf{" + f"{pis:.1f}" + r"}$\,\pm\,$" + f"{psd:.1f}") if _finito(pis) else "--")
                L.append(" & ".join([(r"\multirow{4}{*}{" + s + "}") if j == 0 else "",
                                     {"1h": "1 h", "3h": "3 h", "6h": "6 h", "DA": "DA"}[h], cell,
                                     self.fmt(val(sub, "MVP", "IS")), self.fmt(val(sub, "PRIOR", "IS")),
                                     self.fmt(val(sub, "PROP", "PICP")), self.fmt(val(sub, "PROP", "WGC"), 1, True),
                                     self.fmt(val(sub, "PRIOR", "WGC")),
                                     self.fmt(p_mvp, 3, _finito(p_mvp) and p_mvp < 0.05),
                                     self.fmt(p_pri, 3, _finito(p_pri) and p_pri < 0.05)]) + r" \\")
            if si < self.n_sites - 1:
                L.append(r"\midrule")
        L += [r"\bottomrule", r"\end{tabular}", r"\end{table*}"]
        self.write("tab_sites.tex", L)

        if diag is not None and not diag.empty:
            ar = diag[diag.site == self.arido]
            outros = diag[diag.site != self.arido]
            # nomes antigos (ASP era o site desértico do zip de 16/10) e nomes por papel/site
            self.mac("DMASPMinMVP", ar.dm_p_vs_MVP.min() if len(ar) else np.nan, 2)
            self.mac("DMDesertMinMVP", ar.dm_p_vs_MVP.min() if len(ar) else np.nan, 2)
            self.mac("DMOtherMaxMVP", outros.dm_p_vs_MVP.max() if len(outros) else np.nan, 3)
            self.mac("DMPriorMax", diag.dm_p_vs_PRIOR.max(), 3)
            self.mac("MergedASP", ar.merged_pct.mean() if len(ar) else np.nan, 0)
            self.mac("MergedDesert", ar.merged_pct.mean() if len(ar) else np.nan, 0)
            for s in self.sites:
                ds = diag[diag.site == s]
                self.mac(f"DMMinMVP{s}", ds.dm_p_vs_MVP.min(), 3)
                self.mac(f"DMMaxMVP{s}", ds.dm_p_vs_MVP.max(), 3)
                self.mac(f"DMMaxPrior{s}", ds.dm_p_vs_PRIOR.max(), 3)
                self.mac(f"Merged{s}", ds.merged_pct.mean(), 0)
        for s in self.sites:
            for h in H4:
                sub = main[(main.site == s) & (main.horizon == h)].set_index("method")
                for m, nm in [("PROP", "Prop"), ("MVP", "MVP"), ("PRIOR", "Prior")]:
                    self.mac(f"IS{nm}{s}{TAG[h]}", val(sub, m, "IS"))
                    self.mac(f"WGC{nm}{s}{TAG[h]}", val(sub, m, "WGC"))
                self.mac(f"PICPProp{s}{TAG[h]}", val(sub, "PROP", "PICP"))

    # ------------------------------------------------------------------ Tab. 7 (camadas)
    def _tab_layers(self) -> None:
        lay = self.lay
        L = [r"\begin{table*}[!t]",
             r"\caption{Calibration layers compared on the same hybrid TFT + LightGBM base (Stages~1--3 fixed; mean over "
             r"sites). WGC: worst-group coverage over $\mathcal{G}$; WGC$_{\mathrm{sky}}$: worst coverage over ex-post sky "
             r"classes (not guaranteed by any layer); CCD: mean absolute deviation of the group coverages from 95\% "
             r"(percentage points). Bold: best value per column among layers whose PICP is at least 95\%." + self.nota() + "}",
             r"\label{tab:layers}", r"\centering", r"\setlength{\tabcolsep}{3.4pt}",
             r"\begin{tabular}{@{}l" + "ccccc" * 2 + r"@{}}", r"\toprule",
             r" & \multicolumn{5}{c}{$h=1$\,h} & \multicolumn{5}{c}{Day-ahead (DA)} \\",
             r"\cmidrule(lr){2-6}\cmidrule(lr){7-11}",
             r"Calibration layer" + r" & PICP & WGC$\uparrow$ & WGC$_{\mathrm{sky}}\uparrow$ & CCD$\downarrow$ & IS$\downarrow$" * 2
             + r" \\", r"\midrule"]

        def melhor(ok, col, fn):
            s = ok[col].dropna()
            return (s.idxmax() if fn == "max" else s.idxmin()) if len(s) else None

        for Lk in ["L1", "L2", "L3", "L4", "L5", "L6", "L7"]:
            cells = [LNAME[Lk]]
            for h in ["1h", "DA"]:
                sub = lay[lay.horizon == h].set_index("layer")
                ok = sub[sub.PICP >= 95.0]
                r = sub.loc[Lk] if Lk in sub.index else pd.Series(dtype=float)
                cells += [self.fmt(r.get("PICP")), self.fmt(r.get("WGC"), 1, Lk == melhor(ok, "WGC", "max")),
                          self.fmt(r.get("WGC_sky"), 1, Lk == melhor(ok, "WGC_sky", "max")),
                          self.fmt(r.get("CCD"), 2, Lk == melhor(ok, "CCD", "min")),
                          self.fmt(r.get("IS"), 1, Lk == melhor(ok, "IS", "min"))]
            L.append(" & ".join(cells) + r" \\")
            if Lk in ("L2", "L4"):
                L.append(r"\midrule")
        L += [r"\bottomrule", r"\end{tabular}", r"\end{table*}"]
        self.write("tab_layers.tex", L)
        li = lay.set_index(["layer", "horizon"])

        def v(k, h, c):
            try:
                return float(li.loc[(k, h), c])
            except KeyError:
                return np.nan

        for h, tag in [("1h", "One"), ("DA", "DA")]:
            cc = v("L6", h, "IS")
            self.mac(f"LayWGCMond{tag}", v("L3", h, "WGC"))
            self.mac(f"LayWGCCC{tag}", v("L6", h, "WGC"))
            self.mac(f"LayWGCRegHour{tag}", v("L4", h, "WGC"))
            self.mac(f"LayISRegHour{tag}", 100 * (v("L4", h, "IS") / cc - 1))
            self.mac(f"LayISMVP{tag}", 100 * (v("L5", h, "IS") / cc - 1))
            self.mac(f"LayISInter{tag}", 100 * (v("L7", h, "IS") / cc - 1))
            self.mac(f"LayWGCInter{tag}", v("L7", h, "WGC"))
            self.mac(f"LayWGCSplit{tag}", v("L1", h, "WGC"))
            self.mac(f"LayISSplit{tag}", 100 * (v("L1", h, "IS") / cc - 1))
            self.mac(f"LayCCDMond{tag}", v("L3", h, "CCD"), 2)
            self.mac(f"LayCCDCC{tag}", v("L6", h, "CCD"), 2)
        self.lay_v = v

    # ------------------------------------------------------------------ Tab. 8 (grupos)
    def _tab_groups(self) -> None:
        g = (self.grp[self.grp.horizon == "DA"].groupby(["family", "group", "method"])
             .agg(PICP=("PICP", "mean"), share=("share", "mean")).reset_index())
        L = [r"\begin{table}[!t]",
             r"\caption{Day-ahead coverage (\%) by group, mean over sites. $^{\ast}$Groups in $\mathcal{G}$, covered by the "
             r"conditional guarantee; seasons and ex-post sky classes are diagnostic. Bold: closest to 95\%." + self.nota() + "}",
             r"\label{tab:groups}", r"\centering", r"\setlength{\tabcolsep}{3pt}",
             r"\begin{tabular}{@{}llccccc@{}}", r"\toprule",
             r"Family & Group & Share & " + " & ".join(SHORT[m] for m in GM) + r" \\", r"\midrule"]
        for fi, (fam, flab, items) in enumerate(FAM):
            for ii, (gk, glab) in enumerate(items):
                sub = g[(g.family == fam) & (g.group == gk)].set_index("method")
                pic = sub["PICP"].reindex(GM)
                bc = (pic - 95).abs().idxmin() if pic.notna().any() else None
                share = sub["share"].iloc[0] if len(sub) else np.nan
                L.append(" & ".join([(r"\multirow{" + str(len(items)) + r"}{*}{\parbox{1.5cm}{\raggedright " + flab + "}}")
                                     if ii == 0 else "", glab, self.fmt(100 * share if _finito(share) else np.nan, 0)]
                                    + [self.fmt(pic.get(m), 1, m == bc) for m in GM]) + r" \\")
            if fi < len(FAM) - 1:
                L.append(r"\midrule")
        L += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
        self.write("tab_groups.tex", L)
        gv = g.set_index(["family", "group", "method"])["PICP"]

        def v(f, gr, m):
            try:
                return float(gv.loc[(f, gr, m)])
            except KeyError:
                return np.nan

        for nome, (f, gr) in {"Overcast": ("regime", "Overcast"), "Clear": ("regime", "Clear"),
                              "Partly": ("regime", "Partly"), "HighSig": ("tertile", "High"),
                              "LowSig": ("tertile", "Low"), "LC": ("sky", "LC"), "HC": ("sky", "HC"),
                              "Sun": ("sky", "Sun"), "Summer": ("season", "Summer"),
                              "Winter": ("season", "Winter")}.items():
            self.mac(f"{nome}Prior", v(f, gr, "PRIOR"))
            self.mac(f"{nome}Prop", v(f, gr, "PROP"))
            self.mac(f"{nome}MVP", v(f, gr, "MVP"))
        self.grp_v = v

    # ------------------------------------------------------------------ Tab. 9 (ablação)
    def _tab_ablation(self) -> None:
        ab = self.ab
        L = [r"\begin{table*}[!t]",
             r"\caption{Ablation (mean over sites and seeds). B2--B5 each add one mechanism to the row above; B4h adds the "
             r"ICSO-PP re-optimization of the median heads and of $\gamma$ (Stage~3 of~\cite{prior2026conformalized}) to "
             r"B4; B5a--B5g change one design choice of B5. Bold: lowest IS and highest WGC among variants whose PICP is "
             r"at least 95\%." + self.nota() + "}",
             r"\label{tab:ablation}", r"\centering", r"\setlength{\tabcolsep}{2.8pt}",
             r"\begin{tabular}{@{}ll" + "cccc" * 3 + r"@{}}", r"\toprule",
             r" & & " + " & ".join(r"\multicolumn{4}{c}{" + HLAB[h] + "}" for h in HZ) + r" \\",
             r"\cmidrule(lr){3-6}\cmidrule(lr){7-10}\cmidrule(lr){11-14}",
             r"ID & Configuration" + r" & IS$\downarrow$ & PICP & WGC$\uparrow$ & nRMSE" * 3 + r" \\", r"\midrule"]
        for var in ["B1", "B2", "B3", "B4", "B5", "B4h", "B5a", "B5b", "B5c", "B5d", "B5e", "B5f", "B5g"]:
            cells = [var, AD[var]]
            for h in HZ:
                sub = ab[ab.horizon == h].set_index("variant")
                ok = sub[sub.PICP >= 95.0]
                r = sub.loc[var] if var in sub.index else pd.Series(dtype=float)
                # negrito em todos os empatados na precisão mostrada (ex.: B5f = B5g quando a validação escolhe w = 0)
                bi = var in ok.index and ok["IS"].notna().any() and round(r["IS"], 1) == round(ok["IS"].min(), 1)
                bw = var in ok.index and ok["WGC"].notna().any() and round(r["WGC"], 1) == round(ok["WGC"].max(), 1)
                cells += [self.fmt(r.get("IS"), 1, bool(bi)), self.fmt(r.get("PICP")),
                          self.fmt(r.get("WGC"), 1, bool(bw)), self.fmt(r.get("RMSE"), 2)]
            L.append(" & ".join(cells) + r" \\")
            if var == "B5":
                L.append(r"\midrule")
        L += [r"\bottomrule", r"\end{tabular}", r"\end{table*}"]
        self.write("tab_ablation.tex", L)
        ai = ab.set_index(["variant", "horizon"])

        def v(k, h, c):
            try:
                return float(ai.loc[(k, h), c])
            except KeyError:
                return np.nan

        for h, tag in [("1h", "One"), ("6h", "Six"), ("DA", "DA")]:
            self.mac(f"AbTot{tag}", 100 * (1 - v("B2", h, "IS") / v("B1", h, "IS")))
            self.mac(f"AbCCwgc{tag}", v("B3", h, "WGC") - v("B2", h, "WGC"))
            self.mac(f"AbCCis{tag}", 100 * (1 - v("B3", h, "IS") / v("B2", h, "IS")))
            self.mac(f"AbAsym{tag}", 100 * (1 - v("B4", h, "IS") / v("B3", h, "IS")))
            self.mac(f"AbHyb{tag}", 100 * (1 - v("B5", h, "IS") / v("B4", h, "IS")))
            self.mac(f"AbHybrmse{tag}", 100 * (1 - v("B5", h, "RMSE") / v("B4", h, "RMSE")))
            self.mac(f"AbICSO{tag}", 100 * (1 - v("B4h", h, "IS") / v("B4", h, "IS")))
            self.mac(f"AbICSOrmse{tag}", 100 * (v("B4h", h, "RMSE") / v("B4", h, "RMSE") - 1))
            self.mac(f"AbNoReg{tag}", v("B5a", h, "WGC"))
            self.mac(f"AbInter{tag}", 100 * (v("B5b", h, "IS") / v("B5", h, "IS") - 1))
            self.mac(f"AbNoBufPICP{tag}", v("B5c", h, "PICP"))
            self.mac(f"AbNoBufWGC{tag}", v("B5c", h, "WGC"))
            self.mac(f"AbStaticPICP{tag}", v("B5d", h, "PICP"))
            self.mac(f"AbStaticWGC{tag}", v("B5d", h, "WGC"))
            self.mac(f"AbLSTMis{tag}", 100 * (v("B5e", h, "IS") / v("B5", h, "IS") - 1))
            self.mac(f"AbLSTMwgc{tag}", v("B5e", h, "WGC"))
            self.mac(f"AbFixed{tag}", 100 * (v("B5f", h, "IS") / v("B5", h, "IS") - 1))
            self.mac(f"AbGBMOnly{tag}", 100 * (v("B5g", h, "IS") / v("B5", h, "IS") - 1))
        self.ab_v = v

    # ------------------------------------------------------------------ Tab. 10 (otimizadores)
    def _tab_optimizer(self) -> None:
        op = self.op
        L = [r"\begin{table}[!t]",
             r"\caption{Stage-3 optimizers with the same budget of fitness evaluations (day-ahead; mean $\pm$ standard "
             r"deviation over " + str(self.n_sites) + r" sites $\times$ " + str(self.n_seeds) + r" seeds). "
             r"$\mathcal{F}_{\mathrm{val}}$: final validation fitness, normalized to the Adam heads; $p$: Wilcoxon "
             r"signed-rank test against ICSO-PP on the paired IS values." + self.nota() + "}",
             r"\label{tab:optimizer}", r"\centering", r"\setlength{\tabcolsep}{2.4pt}", r"\resizebox{\columnwidth}{!}{%",
             r"\begin{tabular}{@{}lccccc@{}}", r"\toprule",
             r"Optimizer & IS$_{\mathrm{DA}}$ & WGC$_{\mathrm{DA}}$ & $\mathcal{F}_{\mathrm{val}}$ & $p$ & Min. \\",
             r"\midrule"]
        for _, r in op.iterrows():
            pw = r.get("p_wilcoxon")
            pv = "--" if not _finito(pw) else (self.wrap("<0.001") if pw < 0.001 else self.fmt(pw, 3, pw < 0.05))
            L.append(" & ".join([ON.get(r.optimizer, r.optimizer),
                                 self.wrap(f"{r.IS_mean:.2f}$\\,\\pm\\,${r.IS_sd:.2f}") if _finito(r.IS_mean) else "--",
                                 self.wrap(f"{r.WGC_mean:.1f}$\\,\\pm\\,${r.WGC_sd:.2f}") if _finito(r.WGC_mean) else "--",
                                 self.wrap(f"{r.Fval_mean:.3f}$\\,\\pm\\,${r.Fval_sd:.3f}") if _finito(r.Fval_mean) else "--",
                                 pv, self.fmt(r.time_min, 1)]) + r" \\")
        L += [r"\bottomrule", r"\end{tabular}}", r"\end{table}"]
        self.write("tab_optimizer.tex", L)
        oi = op.set_index("optimizer")

        def v(k, c):
            try:
                return float(oi.loc[k, c])
            except KeyError:
                return np.nan

        self.mac("OptGain", 100 * (1 - v("ICSO-PP", "IS_mean") / v("Adam", "IS_mean")))
        self.mac("OptPCMA", v("CMA-ES", "p_wilcoxon"), 2)
        self.mac("OptPLSHADE", v("L-SHADE", "p_wilcoxon"), 2)
        self.mac("OptPPSO", v("PSO", "p_wilcoxon"), 3)
        self.mac("OptPICSO", v("ICSO", "p_wilcoxon"), 3)
        self.mac("OptPTPE", v("TPE", "p_wilcoxon"), 3)
        self.mac("OptTPETime", v("TPE", "time_min"))
        self.mac("OptICSOTime", v("ICSO-PP", "time_min"))
        self.mac("OptFvalICSOPP", 100 * (1 - v("ICSO-PP", "Fval_mean")))
        self.mac("OptEvals", v("ICSO-PP", "evals"), 0)
        self.op_v = v

    # ------------------------------------------------------------------ Tab. 11 (estresse)
    def _tab_stress(self) -> None:
        st = self.st
        L = [r"\begin{table}[!t]",
             r"\caption{Stress tests at the day-ahead horizon (mean over sites). The conformal layers are recalibrated "
             r"on data subject to the same degradation." + self.nota() + "}",
             r"\label{tab:stress}", r"\centering", r"\setlength{\tabcolsep}{3pt}",
             r"\begin{tabular}{@{}lcccccc@{}}", r"\toprule",
             r" & \multicolumn{3}{c}{Boot-LSTM~\cite{prior2026conformalized}} & \multicolumn{3}{c}{Ours} \\",
             r"\cmidrule(lr){2-4}\cmidrule(lr){5-7}",
             r"Scenario & PICP & WGC & IS & PICP & WGC & IS \\", r"\midrule"]
        si = st.set_index(["scenario", "method"])

        def v(sc, m, c):
            try:
                return float(si.loc[(sc, m), c])
            except KeyError:
                return np.nan

        for sc in ["S0", "S1", "S2", "S3", "S4", "S5"]:
            L.append(" & ".join([SN[sc]] + [self.fmt(v(sc, m, c)) for m in ["PRIOR", "PROP"] for c in ["PICP", "WGC", "IS"]])
                     + r" \\")
        L += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
        self.write("tab_stress.tex", L)
        pr = st[st.method == "PROP"]
        self.mac("StressWGCPropMin", pr.WGC.min())
        self.mac("StressWGCPriorMin", st[st.method == "PRIOR"].WGC.min())
        self.mac("StressISPropTwo", 100 * (v("S2", "PROP", "IS") / v("S0", "PROP", "IS") - 1))
        self.mac("StressPICPPropMin", pr.PICP.min())
        self.st_v = v

    # ------------------------------------------------------------------ Tab. 12 (custo)
    def _tab_cost(self) -> None:
        co = self.co.copy()
        co["_o"] = co["site"].map({s: i for i, s in enumerate(self.sites)})
        co = co.sort_values("_o")
        for c in ("lgbm_min", "weights_min"):
            if c not in co:
                co[c] = np.nan
        L = [r"\begin{table}[!t]",
             r"\caption{Computational cost per site for all horizons ($M=" + str(self.membros) + r"$ TFTs). Stages~1--2 "
             r"train the TFT ensemble; Stage~3 trains the LightGBM quantile models (84 models) and chooses the TFT weight "
             r"of every calibration window; Stage~4 is the conditional calibration of one test month. Hardware: "
             r"\tbc{[CPU/GPU model to be reported]}." + self.nota() + "}",
             r"\label{tab:cost}", r"\centering", r"\setlength{\tabcolsep}{3pt}",
             r"\begin{tabular}{@{}lcccccc@{}}", r"\toprule",
             r" & & Stages 1--2 & \multicolumn{2}{c}{Stage 3 (min)} & Stage 4 & Inference \\",
             r"\cmidrule(lr){4-5}",
             r"Site & $N_{\mathrm{tr}}$ & (min) & LightGBM & Weights & (s/month) & (s/day) \\", r"\midrule"]
        for _, r in co.iterrows():
            L.append(" & ".join([str(r.site), self.fmt(r.n_train, 0), self.fmt(r.ensemble_min, 1), self.fmt(r.lgbm_min, 1),
                                 self.fmt(r.weights_min, 1), self.fmt(r.calib_s, 0), self.fmt(r.infer_s, 2)]) + r" \\")
        L += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
        self.write("tab_cost.tex", L)
        self.mac("CostEnsemble", co.ensemble_min.mean(), 0)
        self.mac("CostLGBM", co.lgbm_min.mean())
        self.mac("CostWeights", co.weights_min.mean())
        self.mac("CostCalib", co.calib_s.mean(), 0)
        self.mac("CostInfer", co.infer_s.max(), 2)

    # ------------------------------------------------------------------ Tab. 4 (sites e dados)
    def _tab_data(self) -> None:
        def coord(lat, lon):
            return (f"{abs(lat):.2f}\\textdegree {'S' if lat < 0 else 'N'}, "
                    f"{abs(lon):.2f}\\textdegree {'W' if lon < 0 else 'E'}")

        L = [r"\begin{table*}[!t]",
             r"\caption{Public datasets and chronological splits. Each site is a single PV plant. Days removed by the "
             r"quality control of Section~\ref{sec:qc} never enter calibration or evaluation.}",
             r"\label{tab:data}", r"\centering", r"\small", r"\setlength{\tabcolsep}{3pt}",
             r"\begin{tabular}{@{}l>{\raggedright\arraybackslash}p{3.2cm}c>{\raggedright\arraybackslash}p{3.3cm}cccc@{}}",
             r"\toprule",
             r"Site & Location (latitude, longitude) & K\"oppen & System & Capacity & Native res. & Period (test year) & "
             r"Days removed \\", r"\midrule"]
        for s in self.sites:
            c, rz = self.info_sites.get(s, {}), self.info_sites.get(s, {}).get("_resumo", {})
            nome = str(rz.get("nome") or c.get("nome") or s)
            local, sistema = (nome.split(" (", 1) + [""])[:2]
            sistema = sistema.rstrip(")")
            lat = float(rz.get("lat", c.get("lat", np.nan)))
            lon = float(rz.get("lon", c.get("lon", np.nan)))
            fonte = str(c.get("fonte", rz.get("fonte", "")))
            pn = float(rz.get("pnom_kw", c.get("pnom_kw", np.nan)))
            dc = "dc" in str(rz.get("unidade_pnom", "")).lower() or "kwp" in str(rz.get("unidade_pnom", "")).lower()
            sub = r"\mathrm{p}" if dc else r"\mathrm{ac}"
            cap = (f"{pn / 1000:.0f}\\,MW$_{{{sub}}}$" if pn >= 10000
                   else f"{pn:,.0f}".replace(",", "{,}") + f"\\,kW$_{{{sub}}}$")
            ini, fim = c.get("inicio"), c.get("fim")
            if c.get("inicio_teste"):
                t0 = pd.Timestamp(str(c["inicio_teste"]))
                t1 = min(t0 + pd.DateOffset(years=1) - pd.Timedelta(days=1), pd.Timestamp(str(fim)))
                teste = f"{t0:%m/%y}--{t1:%m/%y}"
            else:
                teste = str(c.get("ano_teste", ""))
            per = f"{pd.Timestamp(str(ini)).year}--{pd.Timestamp(str(fim)).year} ({teste})" if ini and fim else "--"
            partes = [x.strip() for x in local.split(",")]
            cidade = f"{partes[0]}, {partes[-1]}" if len(partes) >= 2 else local
            rem = rz.get("qc_pct_removidos")
            ind = int(self.meta.get(s, {}).get("indisp_dias", 0) or 0)
            rem_txt = (f"{float(rem):.1f}\\%" if _finito(rem) else "--") + (f" + {ind} d$^{{\\dagger}}$" if ind else "")
            L.append(" & ".join([s, f"{cidade} ({coord(lat, lon)})" if np.isfinite(lat) else cidade,
                                 str(c.get("koppen", "--")), sistema.replace("&", r"\&") + CITA_FONTE.get(fonte, ""),
                                 cap, RES_NATIVA.get(fonte, "--"), per, rem_txt]) + r" \\")
            self.mac(f"QCRemoved{s}", float(rem) if _finito(rem) else np.nan)
            self.mac(f"IndispDays{s}", ind, 0)
            self.mac(f"Ymax{s}", self.meta.get(s, {}).get("y_max", np.nan), 2)
            self.mac(f"Pnom{s}", pn / 1000 if pn >= 10000 else pn, 0 if pn >= 10000 else 1)
        # sites do config ainda sem resultado: macros com '--', para o main.tex que cita os três sites compilar
        proc = self.cfg.get("pasta_processados")
        for s in [x for x in self.cfg.get("sites", []) if x not in self.sites]:
            c = dict(((self.cfg.get("_coleta") or {}).get("sites", {}) or {}).get(s, {}) or {})
            arq = Path(proc) / s / "resumo.json" if proc else None
            rz = json.loads(arq.read_text(encoding="utf-8")) if arq is not None and arq.exists() else {}
            rem = rz.get("qc_pct_removidos")
            pn = float(rz.get("pnom_kw", c.get("pnom_kw", np.nan)) or np.nan)
            self.mac(f"QCRemoved{s}", float(rem) if _finito(rem) else np.nan)
            self.mac(f"IndispDays{s}", np.nan, 0)
            self.mac(f"Ymax{s}", np.nan, 2)
            self.mac(f"Pnom{s}", pn / 1000 if pn >= 10000 else pn, 0 if pn >= 10000 else 1)
        nota = []
        if any(int(self.meta.get(s, {}).get("indisp_dias", 0) or 0) for s in self.sites):
            nota = [r"\par\smallskip",
                    r"\parbox{\textwidth}{\footnotesize $^{\dagger}$Days in runs of at least three days in which the "
                    r"recorded output stays far below the plant's capability (weekly maximum below 30\% of its 99th "
                    r"percentile), removed as described in Section~\ref{sec:qc}.}"]
        L += [r"\bottomrule", r"\end{tabular}"] + nota + [r"\end{table*}"]
        self.write("tab_data.tex", L)
        # macros gerais do conjunto de sites
        self.mac_txt("NSites", str(self.n_sites))
        self.mac_txt("NSitesWord", _ext(self.n_sites))
        self.mac_txt("NPairs", str(self.n_pares))
        self.mac_txt("NPairsWord", _ext(self.n_pares))
        self.mac_txt("NSeeds", str(self.n_seeds))
        self.mac_txt("NSeedsWord", _ext(self.n_seeds))
        self.mac_txt("SiteList", self.lista_sites())
        self.mac_txt("DesertSite", self.arido)
        n_out = self.n_sites - 1                 # os outros sites (mais nublados que o desértico)
        self.mac_txt("CloudierSites", "the cloudier site" if n_out == 1 else f"the {_ext(n_out)} cloudier sites")
        kop = [str(self.info_sites[s].get("koppen", "")) for s in self.sites if self.info_sites[s].get("koppen")]
        self.mac_txt("KoppenList", ", ".join(kop[:-1]) + (" and " if len(kop) > 1 else "") + (kop[-1] if kop else ""))

    # ------------------------------------------------------------------ macros das figuras
    def _macros_figuras(self) -> None:
        for nm in ("Heat", "Attention", "Multipliers", "Convergence", "VSN", "Example", "Weights"):
            self.hypfig[nm] = self.hyp
        self.mac_txt("ModelName", MODELO)
        if self.pesos is not None and not self.pesos.empty:
            pw = self.pesos
            for h in H4:
                sub = pw[pw.horizon == h]
                self.mac(f"Weight{TAG[h]}", sub.w.mean() if len(sub) else np.nan, 2)
                for s in self.sites:
                    ss = sub[sub.site == s]
                    self.mac(f"Weight{s}{TAG[h]}", ss.w.mean() if len(ss) else np.nan, 2)
        if self.heat_m is not None and self.heat_c is not None:
            self.mac("HeatMondMin", self.heat_m["cov"].min()); self.mac("HeatCCMin", self.heat_c["cov"].min())
            self.mac("HeatMondMax", self.heat_m["cov"].max()); self.mac("HeatCCMax", self.heat_c["cov"].max())
        if self.vsn1 is not None and self.vsnd is not None:
            v1 = self.vsn1.copy()
            vd = self.vsnd.copy()
            chave = "code" if "code" in v1.columns else "site"
            past1 = v1[v1.feat.isin([0, 1])].groupby(chave).w.sum()
            nwpd = vd[vd.feat.isin([2, 3, 4])].groupby(chave).w.sum()
            self.mac("VSNPastOneMin", past1.min(), 0); self.mac("VSNPastOneMax", past1.max(), 0)
            self.mac("VSNNWPDAMin", nwpd.min(), 0); self.mac("VSNNWPDAMax", nwpd.max(), 0)
            geo = vd[vd.feat.isin([7, 8])].groupby(chave).w.sum()
            self.mac("VSNGeoASPDA", geo.get(self.arido, np.nan) if chave == "code" else geo.iloc[0], 0)
            self.mac("VSNGeoDesertDA", geo.get(self.arido, np.nan) if chave == "code" else geo.iloc[0], 0)
            if chave == "code":
                for s in self.sites:
                    self.mac(f"VSNPastOne{s}", past1.get(s, np.nan), 0)
                    self.mac(f"VSNNWPDA{s}", nwpd.get(s, np.nan), 0)
                    self.mac(f"VSNGeoDA{s}", geo.get(s, np.nan), 0)
            self.vsn_res = (past1, nwpd, geo)
        if self.mult is not None and not self.mult.empty:
            ci = self.mult.set_index("label")
            for lab, nm in (("Overcast", "Overcast"), ("Clear", "Clear"), ("Partly", "Partly")):
                for est in ("Summer", "Winter"):
                    self.mac(f"Mult{nm}{est}", ci.loc[lab, est] if lab in ci.index else np.nan, 2)

    # ================================================================== macros (arquivo)
    def escrever_macros(self) -> None:
        linhas = ["% Gerado por exp/artigo.py (pacote de experimentos) -- não editar à mão.",
                  f"% sites: {self.lista_sites()}; sementes: {self.n_seeds}; "
                  + ("PERFIL RÁPIDO: valores hipotéticos, não usar no artigo" if self.hyp else "resultados experimentais")]
        crus = {"CDvalRaw", "CDvalX", "RankPropRaw", "RankPropY"}
        for k_, (v, hyp) in sorted(self.macros.items()):
            if k_ in crus:
                linhas.append(f"\\newcommand{{\\R{k_}}}{{{v}}}")
                continue
            if k_ == "FriedmanP":
                corpo = (r"\hyp{$" + v + "$}") if hyp else ("$" + v + "$")
            else:
                corpo = (r"\hyp{" + v + "}") if hyp else v
            linhas.append(f"\\newcommand{{\\R{k_}}}{{{corpo}\\xspace}}")
        for k_, hyp in self.hypfig.items():
            linhas.append(f"\\newif\\ifhypfig{k_}\\hypfig{k_}{'true' if hyp else 'false'}")
        # aviso da 1ª página do main.tex: resultados do teste rápido (true) ou da rodada experimental (false)
        linhas.append(f"\\newif\\ifhypresults\\hypresults{'true' if self.hyp else 'false'}")
        linhas.append("% rótulos do eixo y da figura de postos, em ordem de posto")
        linhas += self.extra_tex
        (self.mac_dir / "results_macros.tex").write_text("\n".join(linhas) + "\n", encoding="utf-8")

    # ================================================================== figuras
    def figuras(self) -> None:
        self._vsn_pgfplots()                  # não depende do matplotlib
        try:
            import matplotlib

            matplotlib.use("Agg")
            import matplotlib.pyplot as plt
        except Exception as e:  # noqa: BLE001
            log.warning("  matplotlib indisponível (%s): as figuras PDF/PNG não foram geradas. Rode de novo o "
                        "instalar_experimentos.bat (ou pip install matplotlib) e depois o gerar_relatorio.bat; "
                        "as tabelas, macros e dados do pgfplots já estão prontos.", e)
            self.avisos.append("O matplotlib não está instalado: as figuras PDF/PNG (pasta figuras/) não foram geradas. "
                               "Rode de novo o instalar_experimentos.bat e depois o gerar_relatorio.bat.")
            return

        estilo = {"font.family": "serif", "font.serif": ["STIXGeneral", "DejaVu Serif"], "mathtext.fontset": "stix",
                  "font.size": 8, "axes.titlesize": 8, "axes.labelsize": 8, "legend.fontsize": 7,
                  "xtick.labelsize": 7, "ytick.labelsize": 7, "axes.linewidth": 0.6, "axes.edgecolor": "#4d4d4d",
                  "xtick.major.width": 0.6, "ytick.major.width": 0.6, "xtick.major.size": 2.5, "ytick.major.size": 2.5,
                  "grid.color": "#e6e6e6", "grid.linewidth": 0.5, "axes.spines.top": False, "axes.spines.right": False,
                  "legend.frameon": False, "pdf.fonttype": 42, "ps.fonttype": 42, "savefig.dpi": 300,
                  "savefig.bbox": "tight", "savefig.pad_inches": 0.02}
        with plt.rc_context(estilo):
            for nome, f in [("fig_horizon", self._fig_horizon), ("fig_heat", self._fig_heat),
                            ("fig_weights", self._fig_weights), ("fig_vsn", self._fig_vsn),
                            ("fig_attention", self._fig_attention), ("fig_multipliers", self._fig_multipliers),
                            ("fig_ranks", self._fig_ranks), ("fig_example", self._fig_example)]:
                try:
                    fig = f(plt)
                except Exception as e:  # noqa: BLE001
                    log.warning("  figura %s não gerada (%s)", nome, e)
                    continue
                if fig is not None:
                    self._salvar(plt, fig, nome)
        if (self.fig / "fig_example.pdf").exists():
            (self.fig / "fig_example.tex").write_text(
                "% Figura nova (opcional), por exemplo no fim da Seção VI-A. Requer \\usepackage{graphicx} (já no main.tex).\n"
                "\\begin{figure*}[!t]\n\\centering\n"
                "\\includegraphics[width=\\textwidth]{figuras/fig_example.pdf}\n"
                "\\caption{Day-ahead forecasts during one test week per site. Shaded: 95\\% PI of " + MODELO + "; "
                "solid orange: its point forecast; dashed: 95\\% PI of CP-Boot-LSTM-ICSO-PP; dots: observed power. "
                "Below each date, the weather regime forecast by the NWP for most hours of that day.}\n"
                "\\label{fig:example}\n\\end{figure*}\n", encoding="utf-8")

    def _salvar(self, plt, fig, nome: str) -> None:
        if self.hyp:
            fig.text(0.5, 0.5, "TESTE RÁPIDO – NÃO USAR NO ARTIGO", transform=fig.transFigure, rotation=18,
                     ha="center", va="center", fontsize=15, color="#C8102E", alpha=0.18, fontweight="bold", zorder=100)
        fig.savefig(self.fig / f"{nome}.pdf")
        fig.savefig(self.fig / f"{nome}.png", dpi=300)
        plt.close(fig)

    def _fig_horizon(self, plt):
        if self.fig_is is None:
            return None
        fig, axs = plt.subplots(1, 2, figsize=(LARG2, 2.35))
        estilos = {"PROP": dict(marker="*", ms=8, lw=1.6, zorder=6), "MVP": dict(marker="s", ms=3.6),
                   "PRIOR": dict(marker="^", ms=4.2), "HEC": dict(marker="D", ms=3.4),
                   "CQR_TFT": dict(marker="p", ms=4.2), "TFT": dict(marker="o", ms=3.6, ls="--", mfc="white")}
        for ax, df, ylab, tit in ((axs[0], self.fig_is, r"IS (% of $P_{\mathrm{nom}}$)", "(a) Interval score"),
                                  (axs[1], self.fig_wgc, "WGC (%)", r"(b) Worst-group coverage over $\mathcal{G}$")):
            for m, e in estilos.items():
                if m in df and df[m].notna().any():
                    ax.plot(df["hidx"], df[m], color=CORES[m], label=NOME[m], lw=e.get("lw", 1.0),
                            ls=e.get("ls", "-"), marker=e["marker"], ms=e["ms"], mfc=e.get("mfc", CORES[m]),
                            mec=CORES[m], mew=0.8, zorder=e.get("zorder", 3))
            ax.set_xticks([1, 2, 3, 4], ["1 h", "3 h", "6 h", "DA"])
            ax.set_xlim(0.8, 4.2)
            ax.set_xlabel("Forecast horizon")
            ax.set_ylabel(ylab)
            ax.set_title(tit, loc="left")
            ax.grid(True, axis="y")
        axs[1].axhline(95, color="#666666", ls="--", lw=0.8, zorder=1)
        if _finito(self.wgc_ref.get(0.96)):
            axs[1].axhline(self.wgc_ref[0.96], color="#666666", ls=":", lw=1.0, zorder=1)
            axs[1].annotate("sampling reference", xy=(4.18, self.wgc_ref[0.96]), xytext=(0, -2),
                            textcoords="offset points", fontsize=6, color="#555555", ha="right", va="top")
            axs[1].annotate("target 95%", xy=(4.18, 95), xytext=(0, 2), textcoords="offset points", fontsize=6,
                            color="#555555", ha="right", va="bottom")
        h, l_ = axs[0].get_legend_handles_labels()
        fig.legend(h, l_, loc="lower center", ncol=3, bbox_to_anchor=(0.5, -0.12), handlelength=2.4, columnspacing=1.4)
        fig.tight_layout(w_pad=2.0)
        return fig

    def _fig_heat(self, plt):
        if self.heat_m is None or self.heat_c is None:
            return None
        from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm

        cmap = LinearSegmentedColormap.from_list("divcov", [VERMELHO, BRANCO, AZUL])
        cmap.set_bad("#d9d9d9")
        norm = TwoSlopeNorm(vmin=88, vcenter=95, vmax=100)
        fig, axs = plt.subplots(1, 2, figsize=(LARG2, 1.75), sharey=True)
        im = None
        for ax, df, tit in ((axs[0], self.heat_m, "(a) Mondrian by hour"),
                            (axs[1], self.heat_c, r"(b) Conditional CP over $\mathcal{G}$ (ours)")):
            M = df.pivot_table(index="reg", columns="hour", values="cov").reindex(index=[0, 1, 2], columns=range(6, 19))
            im = ax.imshow(np.clip(M.to_numpy(dtype=float), 88, 100), cmap=cmap, norm=norm, aspect="auto",
                           origin="lower", extent=(5.5, 18.5, -0.5, 2.5), interpolation="nearest")
            ax.set_xticks(range(6, 19, 2))
            ax.set_yticks([0, 1, 2], ["Clear", "Partly", "Overcast"])
            ax.set_xticks(np.arange(5.5, 19.0, 1.0), minor=True)
            ax.set_yticks([0.5, 1.5], minor=True)
            ax.grid(True, which="minor", color="white", lw=1.2)
            ax.grid(False, which="major")
            ax.set_xlabel("Hour of day")
            ax.set_title(tit, loc="left")
            for sp in ax.spines.values():
                sp.set_visible(False)
            ax.tick_params(length=0, which="both")
        cb = fig.colorbar(im, ax=axs, fraction=0.025, pad=0.015, ticks=[88, 91, 95, 100])
        cb.set_label("PICP (%)", fontsize=7)
        cb.outline.set_visible(False)
        return fig

    def _fig_weights(self, plt):
        """Peso do TFT escolhido em cada mês de teste, por horizonte (um painel por site; média das sementes)."""
        if self.pesos is None or self.pesos.empty:
            return None
        pw = self.pesos
        sites = [s for s in self.sites if s in set(pw.site)]
        cores = {"1h": CORES["PROP"], "3h": CORES["MVP"], "6h": CORES["PRIOR"], "DA": CORES["HEC"]}
        fig, axs = plt.subplots(1, len(sites), figsize=(LARG2 if len(sites) > 1 else LARG1, 2.0), sharey=True,
                                squeeze=False)
        for ax, s in zip(axs[0], sites):
            for h in H4:
                d = pw[(pw.site == s) & (pw.horizon == h)].sort_values("month")
                if d.empty:
                    continue
                x = np.arange(1, len(d) + 1)
                ax.plot(x, d.w, color=cores[h], lw=1.4, marker="o", ms=3, label={"DA": "DA"}.get(h, h.replace("h", " h")))
            ax.set_xticks(range(1, 13, 2))
            ax.set_xlim(0.6, 12.4)
            ax.set_ylim(-0.04, 1.04)
            ax.set_xlabel("Test month")
            ax.set_title(s, loc="left")
            ax.grid(True, axis="y")
        axs[0][0].set_ylabel("TFT weight $w$ (LightGBM: $1-w$)")
        h_, l_ = axs[0][0].get_legend_handles_labels()
        fig.legend(h_, l_, loc="lower center", ncol=4, bbox_to_anchor=(0.5, -0.1), handlelength=2.0, columnspacing=1.4)
        fig.tight_layout(w_pad=1.5)
        return fig

    def _fig_vsn(self, plt):
        if self.vsn1 is None or self.vsnd is None:
            return None
        from matplotlib.colors import LinearSegmentedColormap

        cmap = LinearSegmentedColormap.from_list("seqblue", [(246 / 255, 248 / 255, 252 / 255), AZUL])
        mats = []
        for df in (self.vsn1, self.vsnd):
            chave = "code" if "code" in df.columns else "site"
            M = df.pivot_table(index="feat", columns=chave, values="w").reindex(index=range(9))
            if chave == "code":
                M = M.reindex(columns=[s for s in self.sites if s in M.columns])
            mats.append(M)
        vmax = max(45.0, float(np.nanmax([m.to_numpy(dtype=float) for m in mats])))
        larg = max(LARG1, min(LARG2, 2.4 + 0.55 * 2 * mats[0].shape[1]))
        fig, axs = plt.subplots(1, 2, figsize=(larg, 2.7), sharey=True)
        im = None
        for ax, M, tit in zip(axs, mats, (r"(a) $h=1$ h", "(b) Day-ahead")):
            A = M.to_numpy(dtype=float)
            im = ax.imshow(A, cmap=cmap, vmin=0, vmax=vmax, aspect="auto", interpolation="nearest")
            ax.set_xticks(range(A.shape[1]), [str(c) for c in M.columns])
            ax.set_yticks(range(9), VSN_ROTULOS)
            ax.set_title(tit, loc="left")
            ax.tick_params(length=0)
            for sp in ax.spines.values():
                sp.set_visible(False)
            for i in range(A.shape[0]):
                for j in range(A.shape[1]):
                    if np.isfinite(A[i, j]):
                        ax.text(j, i, f"{A[i, j]:.0f}", ha="center", va="center", fontsize=6,
                                color="white" if A[i, j] > 0.6 * vmax else "#222222")
        cb = fig.colorbar(im, ax=axs, fraction=0.04, pad=0.02)
        cb.set_label("weight (%)", fontsize=7)
        cb.outline.set_visible(False)
        return fig

    def _fig_attention(self, plt):
        if self.att is None or self.att.empty:
            return None
        a = self.att
        fig, ax = plt.subplots(figsize=(LARG1, 1.9))
        for x in range(-120, 0, 24):
            ax.axvline(x, color="#eeeeee", lw=0.6, zorder=0)
        ax.plot(a["lag"], a["Clear"], color=CORES["MVP"], lw=1.0, label="clear regime")
        ax.plot(a["lag"], a["Overcast"], color=CORES["PROP"], lw=1.3, label="overcast regime")
        ax.set_xlim(-120, -1)
        ax.set_xticks([-120, -96, -72, -48, -24, -1])
        ax.set_xlabel("Encoder lag (h)")
        ax.set_ylabel("Attention weight")
        ax.legend(ncol=2, loc="upper left")
        return fig

    def _fig_multipliers(self, plt):
        if self.mult is None or self.mult.empty:
            return None
        m = self.mult.sort_values("regime")
        x = np.arange(len(m))
        w = 0.36
        fig, ax = plt.subplots(figsize=(LARG1, 2.0))
        for k, (col, cor, lab) in enumerate((("Winter", CORES["MVP"], "winter windows"),
                                             ("Summer", CORES["PROP"], "summer windows"))):
            vals = m[col].to_numpy(dtype=float)
            bars = ax.bar(x + (k - 0.5) * (w + 0.02), vals, width=w, color=cor, label=lab, zorder=3)
            for b_, v in zip(bars, vals):
                if np.isfinite(v):
                    ax.text(b_.get_x() + b_.get_width() / 2, v + 0.02, f"{v:.2f}", ha="center", va="bottom", fontsize=6)
        ax.axhline(1.0, color="#666666", ls="--", lw=0.8, zorder=2)
        ax.set_xticks(x, ["Clear", "Partly cloudy", "Overcast"][:len(m)])
        ax.set_ylabel(r"Inflation factor $\psi_r$")
        ax.set_ylim(0, max(1.6, float(np.nanmax(m[["Winter", "Summer"]].to_numpy())) * 1.18))
        ax.grid(True, axis="y")
        ax.legend(ncol=2, loc="upper left")
        return fig

    def _fig_ranks(self, plt):
        if not self.friedman:
            return None
        rk = self.friedman["rk"].sort_values("y")
        cd = self.friedman["CD"]
        k = self.friedman["k"]
        fig, ax = plt.subplots(figsize=(LARG1 * 0.95, 0.30 * k + 0.7))
        for _, r in rk.iterrows():
            prop = r["method"] == "PROP"
            ax.plot(r["rank"], r["y"], marker="*" if prop else "o", ms=9 if prop else 4.5,
                    color=CORES["PROP"] if prop else CORES["TFT"], zorder=4)
        rp = float(rk.set_index("method").loc["PROP", "rank"]) if "PROP" in set(rk["method"]) else np.nan
        if np.isfinite(rp) and np.isfinite(cd):
            yb = k - 0.35
            ax.plot([rp, rp + cd], [yb, yb], color=CORES["PROP"], lw=1.6, solid_capstyle="butt")
            for xx in (rp, rp + cd):
                ax.plot([xx, xx], [yb - 0.15, yb + 0.15], color=CORES["PROP"], lw=1.2)
            ax.text(rp + cd + 0.12, yb, f"Nemenyi CD = {cd:.2f}", va="center", fontsize=6)
        ax.set_yticks(rk["y"], [NOME[m] if m != "PROP" else "Ours" for m in rk["method"]])
        ax.set_xlim(0.5, k + 0.5)
        ax.set_ylim(-0.7, k + 0.2)
        ax.set_xlabel(f"Average rank of IS ({self.friedman['N']} site–horizon pairs)")
        ax.grid(True, axis="x")
        return fig

    def _fig_example(self, plt):
        ex = self.exemplo
        if ex is None or ex.empty:
            return None
        sites = [s for s in self.sites if s in set(ex["site"])]
        fig, axs = plt.subplots(len(sites), 1, figsize=(LARG2, 1.45 * len(sites) + 0.35), squeeze=False)
        for ax, s in zip(axs[:, 0], sites):
            d = ex[ex["site"] == s].copy()
            dias = sorted(d["data"].unique())
            ordem = {dd_: i for i, dd_ in enumerate(dias)}
            d["x"] = d["data"].map(ordem) + d["hora"] / 24.0
            d = d.sort_values("x")
            # quebra a linha entre dias (as noites não entram nos pares)
            blocos = (d["x"].diff() > 0.2).cumsum()
            primeiro = True
            for _, b in d.groupby(blocos):
                ax.fill_between(b["x"], 100 * b["L"], 100 * b["U"], color=CORES["PROP"], alpha=0.28, lw=0,
                                label="Ours, 95% interval" if primeiro else None)
                if "L_prior" in b:
                    ax.plot(b["x"], 100 * b["L_prior"], color=CORES["PRIOR"], ls="--", lw=0.8,
                            label="CP-Boot-LSTM-ICSO-PP, 95% interval" if primeiro else None)
                    ax.plot(b["x"], 100 * b["U_prior"], color=CORES["PRIOR"], ls="--", lw=0.8)
                ax.plot(b["x"], 100 * b["yhat"], color=CORES["PROP"], lw=0.9, label="Ours, point forecast" if primeiro else None)
                ax.plot(b["x"], 100 * b["y"], color="#111111", lw=0.9, marker="o", ms=1.6,
                        label="Observed" if primeiro else None)
                primeiro = False
            ax.set_xlim(0, len(dias))
            # abaixo da data, o regime do NWP mais frequente nas horas do dia
            nomes_reg = {0: "clear", 1: "partly cloudy", 2: "overcast"}
            reg_dia = d.groupby("data")["regime"].agg(lambda r: int(pd.Series(r).mode().iloc[0]))
            ax.set_xticks([i + 0.5 for i in range(len(dias))],
                          [f"{pd.Timestamp(x):%d %b}\n{nomes_reg.get(int(reg_dia.get(x, -1)), '')}" for x in dias])
            ax.tick_params(axis="x", length=0)
            for lab in ax.get_xticklabels():
                lab.set_linespacing(1.0)
            for i in range(1, len(dias)):
                ax.axvline(i, color="#eeeeee", lw=0.6, zorder=0)
            ax.set_ylabel(r"% of $P_{\mathrm{nom}}$")
            ax.set_title(f"{s} — day-ahead, {pd.Timestamp(dias[0]):%d %b %Y} to {pd.Timestamp(dias[-1]):%d %b %Y}", loc="left")
            ax.set_ylim(bottom=0)
        h, l_ = axs[0, 0].get_legend_handles_labels()
        fig.legend(h, l_, loc="upper center", ncol=4, bbox_to_anchor=(0.5, 1.02))
        fig.tight_layout(rect=(0, 0, 1, 0.95), h_pad=0.8)
        return fig

    def _vsn_pgfplots(self) -> None:
        n = self.n_sites
        ticks = ",".join(self.sites)
        vals = [float(v.w.max()) for v in (self.vsn1, self.vsnd) if v is not None and not v.empty]
        vmax = max(10, int(math.ceil(max(vals) / 5.0)) * 5) if vals else 45
        txt = rf"""% Fig. 9 em pgfplots para {n} sites (substitui o bloco de \label{{fig:vsn}} no main.tex)
\begin{{figure*}}[!t]
\centering
\begin{{tikzpicture}}
\begin{{groupplot}}[group style={{group size=2 by 1, horizontal sep=0.35cm}},
  width=0.36\textwidth, height=5.4cm, view={{0}}{{90}}, enlargelimits=false,
  colormap name=seqblue, point meta min=0, point meta max={vmax},
  xtick={{0,...,{n - 1}}}, xticklabels={{{ticks}}},
  ytick={{0,...,8}}, tick label style={{font=\scriptsize}}, title style={{font=\footnotesize, yshift=-3pt}},
  y dir=reverse, axis on top]
\nextgroupplot[title={{(a) $h=1$\,h}},
  yticklabels={{Past clear-sky index, Rolling statistics, NWP clear-sky index, NWP GHI, Cloud cover, Temperature/RH, {{Wind ($u$, $v$)}}, Solar geometry, Calendar}}]
\addplot[matrix plot*, mesh/cols={n}, point meta=explicit] table[csv, x=site, y=feat, meta=w] {{data/fig_vsn_1h.csv}};
\ifhypfigVSN\hypwatermark\fi
\nextgroupplot[title={{(b) Day-ahead}}, yticklabels={{}}, colorbar,
  colorbar style={{width=2.5mm, y dir=normal, yticklabel style={{font=\tiny}}, title={{\tiny weight (\%)}}}}]
\addplot[matrix plot*, mesh/cols={n}, point meta=explicit] table[csv, x=site, y=feat, meta=w] {{data/fig_vsn_DA.csv}};
\ifhypfigVSN\hypwatermark\fi
\end{{groupplot}}
\end{{tikzpicture}}
\caption{{Mean TFT variable-selection weights by site at (a) 1\,h and (b) the day-ahead horizon, averaged over members, seeds and test samples.}}
\label{{fig:vsn}}
\end{{figure*}}
"""
        (self.fig / "fig_vsn_pgfplots.tex").write_text(txt, encoding="utf-8")

    # ================================================================== conferência das frases do texto
    def verificacoes(self) -> None:
        a = self.a
        okb = lambda c: bool(c)  # noqa: E731
        metodos = [m for m in ORDER if any(_finito(a(h, m, "IS")) for h in H4)]

        def faixa(vs, nd=1):
            vs = [v for v in vs if _finito(v)]
            if not vs:
                return "--"
            a, b = f"{min(vs):.{nd}f}", f"{max(vs):.{nd}f}"
            return a if a == b else f"{a}–{b}"

        def reducao(m):
            """Redução do IS do proposto em relação a m; por horizonte quando há sinal trocado."""
            d = {h: 100 * (1 - a(h, "PROP", "IS") / a(h, m, "IS")) for h in H4 if _finito(a(h, m, "IS"))}
            if not d:
                return "--"
            if min(d.values()) >= 0:
                return f"redução de {faixa(list(d.values()))}%"
            return ("redução por horizonte: " + ", ".join(f"{h} {v:+.1f}%" for h, v in d.items())
                    + " (negativo = IS do proposto maior)")

        # Visão geral (Tab. 5, Fig. 6)
        melhor_is = {h: min(metodos, key=lambda m: a(h, m, "IS") if _finito(a(h, m, "IS")) else np.inf) for h in H4}
        melhor_w = {h: max(metodos, key=lambda m: a(h, m, "WGC") if _finito(a(h, m, "WGC")) else -np.inf) for h in H4}
        self.check("VI-A Visão geral", "O proposto tem o menor IS em todos os horizontes",
                   "; ".join(f"{h}: {NOME[melhor_is[h]]}" for h in H4), all(melhor_is[h] == "PROP" for h in H4))
        self.check("VI-A Visão geral", "O proposto tem o maior WGC em todos os horizontes",
                   "; ".join(f"{h}: {NOME[melhor_w[h]]} ({a(h, melhor_w[h], 'WGC'):.1f})" for h in H4),
                   all(melhor_w[h] == "PROP" for h in H4))
        validos = [m for m in metodos if m not in ("CHPeEn",)]
        cond = {h: [m for m in validos if _finito(a(h, m, "WGC")) and a(h, m, "WGC") >= self.wgc_ref.get(0.96, 94) - 1.5]
                for h in H4}
        self.check("VI-A Visão geral", "Entre os métodos com WGC perto da referência, o proposto tem o menor IS",
                   "; ".join(f"{h}: " + (NOME[min(cond[h], key=lambda m: a(h, m, 'IS'))] if cond[h] else "--") for h in H4),
                   all(cond[h] and min(cond[h], key=lambda m: a(h, m, "IS")) == "PROP" for h in H4))
        rp = self.red.get("PRIOR", [])
        self.check("VI-A Visão geral", "O IS cai em relação ao antecessor (PRIOR)", reducao("PRIOR"),
                   okb(rp and min(rp) > 0))
        self.check("VI-A Visão geral", "O WGC sobe do antecessor para o proposto",
                   f"PRIOR {faixa([a(h, 'PRIOR', 'WGC') for h in H4])}% → proposto {faixa([a(h, 'PROP', 'WGC') for h in H4])}%",
                   all(a(h, "PROP", "WGC") > a(h, "PRIOR", "WGC") for h in H4 if _finito(a(h, "PRIOR", "WGC"))))
        ref = self.wgc_ref.get(0.96, np.nan)
        self.check("VI-A Visão geral", "O antecessor é marginalmente válido, mas o pior grupo fica bem abaixo da referência",
                   f"PICP {faixa([a(h, 'PRIOR', 'PICP') for h in H4])}%; WGC {faixa([a(h, 'PRIOR', 'WGC') for h in H4])}% "
                   f"(referência {ref:.1f}%)",
                   all(a(h, "PRIOR", "WGC") < ref - 1 for h in H4 if _finito(a(h, "PRIOR", "WGC"))))
        self.check("VI-A Visão geral", "O proposto fica perto da referência amostral do WGC (±2 pontos)",
                   f"WGC {faixa([a(h, 'PROP', 'WGC') for h in H4])}% (referência {ref:.1f}%)",
                   all(abs(a(h, "PROP", "WGC") - ref) <= 2 for h in H4))
        self.check("VI-A Visão geral", "O BatchMVP chega a um WGC parecido (±2 pontos)",
                   f"MVP {faixa([a(h, 'MVP', 'WGC') for h in H4])}% vs proposto {faixa([a(h, 'PROP', 'WGC') for h in H4])}%",
                   all(abs(a(h, "MVP", "WGC") - a(h, "PROP", "WGC")) <= 2 for h in H4 if _finito(a(h, "MVP", "WGC"))))
        rm = self.red.get("MVP", [])
        self.check("VI-A Visão geral", "Os intervalos do BatchMVP são mais largos (o proposto reduz o IS do MVP)",
                   reducao("MVP"), okb(rm and min(rm) > 0))
        pt = [a(h, "TFT", "PICP") for h in H4 if _finito(a(h, "TFT", "PICP"))]
        self.check("VI-A Visão geral", "Os quantis nativos do TFT subcobrem (PICP < 95%) e o WGC desce bastante",
                   f"PICP {faixa(pt)}%; WGC mín. {np.nanmin([a(h, 'TFT', 'WGC') for h in H4]):.1f}%",
                   (max(pt) < 95) if pt else None)
        self.check("VI-A Visão geral", "O CQR leva o PICP do TFT perto do alvo, mas o WGC fica baixo",
                   f"PICP {faixa([a(h, 'CQR_TFT', 'PICP') for h in H4])}%; WGC {faixa([a(h, 'CQR_TFT', 'WGC') for h in H4])}%",
                   all(abs(a(h, "CQR_TFT", "PICP") - 95.5) <= 1.5 and a(h, "CQR_TFT", "WGC") < a(h, "PROP", "WGC")
                       for h in H4 if _finito(a(h, "CQR_TFT", "PICP"))))
        self.check("VI-A Visão geral", "FSS e CRPSS do proposto (valores do texto)",
                   f"FSS 1 h {a('1h', 'PROP', 'FSS'):.3f}, DA {a('DA', 'PROP', 'FSS'):.3f}; CRPSS 1 h "
                   f"{a('1h', 'PROP', 'CRPSS'):.3f}, DA {a('DA', 'PROP', 'CRPSS'):.3f}",
                   a("1h", "PROP", "FSS") > 0 and a("DA", "PROP", "CRPSS") > 0)

        # Sites (Tab. 6)
        main = self.main
        n_ok, n_tot, perdas = 0, 0, []
        for s in self.sites:
            for h in H4:
                sub = main[(main.site == s) & (main.horizon == h)].set_index("method")["IS"].dropna()
                if len(sub):
                    n_tot += 1
                    if sub.idxmin() == "PROP":
                        n_ok += 1
                    else:
                        perdas.append(f"{s} {h} ({NOME[sub.idxmin()]})")
        self.check("VI-B Sites", f"O proposto tem o menor IS em todos os {n_tot} pares site–horizonte",
                   f"{n_ok} de {n_tot}" + (f"; perde em: {', '.join(perdas)}" if perdas else ""), n_ok == n_tot)
        if self.diag is not None and not self.diag.empty:
            d = self.diag
            self.check("VI-B Sites", "A melhora sobre o antecessor é significativa em todos os pares (Holm, p < 0,05)",
                       f"maior p = {d.dm_p_vs_PRIOR.max():.3f}", d.dm_p_vs_PRIOR.max() < 0.05)
            outros = d[d.site != self.arido]
            ar = d[d.site == self.arido]
            self.check("VI-B Sites", f"A melhora sobre o BatchMVP é significativa fora do site desértico ({self.arido})",
                       f"maior p fora de {self.arido} = {outros.dm_p_vs_MVP.max():.3f}" if len(outros) else "--",
                       (outros.dm_p_vs_MVP.max() < 0.05) if len(outros) else None)
            self.check("VI-B Sites", f"No site desértico ({self.arido}) a diferença para o BatchMVP não é significativa",
                       f"menor p em {self.arido} = {ar.dm_p_vs_MVP.min():.3f}; regime fundido em "
                       f"{ar.merged_pct.mean():.0f}% das janelas" if len(ar) else "--",
                       (ar.dm_p_vs_MVP.min() >= 0.05) if len(ar) else None)
        pp = main[main.method == "PROP"]
        self.check("VI-B Sites", "O WGC do proposto fica perto da referência em todos os sites",
                   f"WGC por site e horizonte {pp.WGC.min():.1f}–{pp.WGC.max():.1f}% (referência {ref:.1f}%); "
                   f"PRIOR desce a {main[main.method == 'PRIOR'].WGC.min():.1f}%", pp.WGC.min() >= ref - 3)

        # Camadas (Tab. 7, Fig. 7)
        if hasattr(self, "lay_v"):
            v = self.lay_v
            self.check("VI-C Camadas", "O Mondrian por hora (L3) tem WGC baixo no DA; o condicional (L6) sobe",
                       f"L3 {v('L3', 'DA', 'WGC'):.1f}% vs L6 {v('L6', 'DA', 'WGC'):.1f}%",
                       v("L6", "DA", "WGC") > v("L3", "DA", "WGC"))
            self.check("VI-C Camadas", "Mondrian regime × hora (L4) sobe o WGC, mas custa IS em relação ao L6",
                       f"WGC L4 {v('L4', 'DA', 'WGC'):.1f}%; IS L4/L6 − 1 = {100 * (v('L4', 'DA', 'IS') / v('L6', 'DA', 'IS') - 1):.1f}%",
                       v("L4", "DA", "IS") > v("L6", "DA", "IS"))
            self.check("VI-C Camadas", "O condicional é mais estreito que o BatchMVP (L5)",
                       f"IS L5/L6 − 1 = {100 * (v('L5', 'DA', 'IS') / v('L6', 'DA', 'IS') - 1):.1f}%",
                       v("L5", "DA", "IS") > v("L6", "DA", "IS"))
            self.check("VI-C Camadas", "O CCD do condicional é menos da metade do CCD do Mondrian por hora",
                       f"CCD L6 {v('L6', 'DA', 'CCD'):.2f} vs L3 {v('L3', 'DA', 'CCD'):.2f}",
                       v("L6", "DA", "CCD") < 0.5 * v("L3", "DA", "CCD"))
            self.check("VI-C Camadas", "As interações (L7) ganham pouco WGC e custam IS",
                       f"WGC L7 {v('L7', 'DA', 'WGC'):.1f}% vs L6 {v('L6', 'DA', 'WGC'):.1f}%; IS +"
                       f"{100 * (v('L7', 'DA', 'IS') / v('L6', 'DA', 'IS') - 1):.1f}%",
                       v("L7", "DA", "IS") >= v("L6", "DA", "IS"))
        # Grupos (Tab. 8)
        if hasattr(self, "grp_v"):
            g = self.grp_v
            self.check("VI-D Grupos", "No antecessor o regime encoberto subcobre e o claro sobrecobre; o proposto aproxima os dois de 95%",
                       f"encoberto PRIOR {g('regime', 'Overcast', 'PRIOR'):.1f}% → {g('regime', 'Overcast', 'PROP'):.1f}%; "
                       f"claro PRIOR {g('regime', 'Clear', 'PRIOR'):.1f}% → {g('regime', 'Clear', 'PROP'):.1f}%",
                       abs(g("regime", "Overcast", "PROP") - 95) < abs(g("regime", "Overcast", "PRIOR") - 95))
            self.check("VI-D Grupos", "O tercil de alta dispersão sobe",
                       f"{g('tertile', 'High', 'PRIOR'):.1f}% → {g('tertile', 'High', 'PROP'):.1f}%",
                       g("tertile", "High", "PROP") > g("tertile", "High", "PRIOR"))
            self.check("VI-D Grupos", "Dias de nuvens leves (diagnóstico) e o verão sobem",
                       f"LC {g('sky', 'LC', 'PRIOR'):.1f}% → {g('sky', 'LC', 'PROP'):.1f}%; verão "
                       f"{g('season', 'Summer', 'PRIOR'):.1f}% → {g('season', 'Summer', 'PROP'):.1f}%",
                       g("sky", "LC", "PROP") > g("sky", "LC", "PRIOR") and g("season", "Summer", "PROP") > g("season", "Summer", "PRIOR"))
        # Ablação (Tab. 9)
        if hasattr(self, "ab_v"):
            v = self.ab_v
            ganho = lambda x, y, h="DA": 100 * (1 - v(x, h, "IS") / v(y, h, "IS"))  # noqa: E731
            self.check("VI-E Ablação", "B1→B2 (dispersão total) reduz o IS", f"DA: {ganho('B2', 'B1'):.1f}%", ganho("B2", "B1") > 0)
            self.check("VI-E Ablação", "B2→B3 (camada condicional) sobe o WGC e reduz o IS",
                       f"DA: WGC +{v('B3', 'DA', 'WGC') - v('B2', 'DA', 'WGC'):.1f} pontos, IS {ganho('B3', 'B2'):.1f}%",
                       v("B3", "DA", "WGC") > v("B2", "DA", "WGC") and ganho("B3", "B2") > 0)
            self.check("VI-E Ablação", "B3→B4 (escalas de cada lado) reduz o IS em todos os horizontes",
                       "; ".join(f"{h}: {ganho('B4', 'B3', h):.1f}%" for h in HZ),
                       all(v("B4", h, "IS") < v("B3", h, "IS") for h in HZ))
            self.check("VI-E Ablação", "B4→B5 (LightGBM com peso por janela) reduz o IS, sobretudo em 1 h",
                       "; ".join(f"{h}: {ganho('B5', 'B4', h):.1f}%" for h in HZ),
                       all(v("B5", h, "IS") <= v("B4", h, "IS") for h in HZ) and ganho("B5", "B4", "1h") >= ganho("B5", "B4", "DA"))
            self.check("VI-E Ablação", "O ICSO-PP nas cabeças (B4h) não reduz o IS do B4 no teste",
                       "; ".join(f"{h}: {ganho('B4h', 'B4', h):+.1f}%" for h in HZ),
                       all(v("B4h", h, "IS") >= v("B4", h, "IS") for h in HZ))
            self.check("VI-E Ablação", "Sem os regimes do NWP (B5a) o WGC do DA cai",
                       f"{v('B5a', 'DA', 'WGC'):.1f}% vs B5 {v('B5', 'DA', 'WGC'):.1f}%", v("B5a", "DA", "WGC") < v("B5", "DA", "WGC"))
            self.check("VI-E Ablação", "As interações (B5b) custam IS",
                       f"DA: {100 * (v('B5b', 'DA', 'IS') / v('B5', 'DA', 'IS') - 1):+.1f}%", v("B5b", "DA", "IS") > v("B5", "DA", "IS"))
            self.check("VI-E Ablação", "Sem o buffer (B5c) o PICP e o WGC caem",
                       f"PICP {v('B5c', 'DA', 'PICP'):.1f}% (B5 {v('B5', 'DA', 'PICP'):.1f}%), WGC {v('B5c', 'DA', 'WGC'):.1f}% "
                       f"(B5 {v('B5', 'DA', 'WGC'):.1f}%)",
                       v("B5c", "DA", "PICP") < v("B5", "DA", "PICP") and v("B5c", "DA", "WGC") < v("B5", "DA", "WGC"))
            self.check("VI-E Ablação", "Sem a recalibração mensal (B5d) o WGC cai",
                       f"PICP {v('B5d', 'DA', 'PICP'):.1f}%, WGC {v('B5d', 'DA', 'WGC'):.1f}%",
                       v("B5d", "DA", "WGC") < v("B5", "DA", "WGC"))
            self.check("VI-E Ablação", "Com o Boot-LSTM do artigo 1 (B5e) o IS é maior",
                       "; ".join(f"{h}: {100 * (v('B5e', h, 'IS') / v('B5', h, 'IS') - 1):+.1f}%" for h in HZ),
                       all(v("B5e", h, "IS") > v("B5", h, "IS") for h in HZ))
            self.check("VI-E Ablação", "O peso escolhido mês a mês (B5) supera o peso fixo da validação (B5f)",
                       "; ".join(f"{h}: {100 * (v('B5f', h, 'IS') / v('B5', h, 'IS') - 1):+.1f}%" for h in HZ),
                       all(v("B5f", h, "IS") >= v("B5", h, "IS") for h in HZ))
            self.check("VI-E Ablação", "Só o LightGBM (B5g) perde do híbrido, sobretudo no DA",
                       "; ".join(f"{h}: {100 * (v('B5g', h, 'IS') / v('B5', h, 'IS') - 1):+.1f}%" for h in HZ),
                       all(v("B5g", h, "IS") >= v("B5", h, "IS") for h in HZ))
        # Pesos da combinação (figura nova)
        if self.pesos is not None and not self.pesos.empty:
            med = {h: float(self.pesos[self.pesos.horizon == h].w.mean()) for h in H4}
            self.check("VI-F Combinação", "O peso do TFT cresce com o horizonte (o LightGBM pesa mais em 1 h)",
                       ", ".join(f"{h}: {w:.2f}" for h, w in med.items()),
                       med["1h"] < med["DA"] and med["1h"] <= med["3h"] + 0.05)
        # Interpretabilidade (Figs. 9–11)
        if hasattr(self, "vsn_res"):
            past1, nwpd, geo = self.vsn_res
            self.check("VI-G Interpretabilidade", "Em 1 h o passado (k e estatísticas móveis) domina a seleção",
                       f"{faixa(list(past1), 0)}%", past1.min() > 40)
            self.check("VI-G Interpretabilidade", "No DA o NWP (k, GHI, nuvens) domina a seleção",
                       f"{faixa(list(nwpd), 0)}%", nwpd.min() > 30)
        if self.mult is not None and not self.mult.empty:
            ci = self.mult.set_index("label")
            self.check("VI-G Interpretabilidade", "O regime encoberto infla o limiar superior (ψ > 1) e o claro o encolhe (ψ < 1)",
                       f"encoberto inverno {ci.loc['Overcast', 'Winter']:.2f}, verão {ci.loc['Overcast', 'Summer']:.2f}; "
                       f"claro inverno {ci.loc['Clear', 'Winter']:.2f}, verão {ci.loc['Clear', 'Summer']:.2f}",
                       ci.loc["Overcast"].min() > 1 and ci.loc["Clear"].max() < 1)
        # Robustez (Fig. 12, Tab. 11)
        if self.friedman:
            R, cd = self.friedman["R"], self.friedman["CD"]
            self.check("VI-H Robustez", "O Friedman rejeita desempenho igual",
                       f"χ² = {self.friedman['chi2']:.1f}, p = {self.friedman['p']:.1e}; posto do proposto {R.get('PROP', np.nan):.2f}",
                       self.friedman["p"] < 0.05)
            self.check("VI-H Robustez", "O Nemenyi não separa o proposto do BatchMVP e do antecessor",
                       f"CD = {cd:.2f}; diferença de posto MVP {R.get('MVP', np.nan) - R.get('PROP', np.nan):.2f}, "
                       f"PRIOR {R.get('PRIOR', np.nan) - R.get('PROP', np.nan):.2f}",
                       (R.get("MVP", np.inf) - R.get("PROP", 0) < cd) and (R.get("PRIOR", np.inf) - R.get("PROP", 0) < cd))
        if self.st is not None and not self.st.empty:
            p = self.st[self.st.method == "PROP"]
            q = self.st[self.st.method == "PRIOR"]
            self.check("VI-H Robustez", "Sob as 5 degradações o proposto mantém PICP e WGC; o WGC do antecessor cai",
                       f"proposto: PICP ≥ {p.PICP.min():.1f}%, WGC ≥ {p.WGC.min():.1f}%; PRIOR: WGC ≥ {q.WGC.min():.1f}%",
                       p.PICP.min() >= 95 and p.WGC.min() > q.WGC.min())

    # ================================================================== guia
    def guia(self) -> None:
        self.verificacoes()
        n = self.n_sites
        L = ["# Guia para levar os resultados ao artigo", ""]
        if self.hyp:
            L += ["> **Perfil `rapido` (teste de fumaça):** os números desta pasta NÃO são resultados do artigo. "
                  "Nas tabelas e macros eles saem em vermelho (`\\hyp{}`) e as figuras têm marca d'água. Rode "
                  "`rodar_experimentos.bat` (perfil completo) e gere de novo.", ""]
        from . import __version__ as versao

        L += [f"Pacote de experimentos v{versao}.", ""]
        L += [f"Sites: **{self.lista_sites('e')}** ({n} sites, {self.n_pares} pares site–horizonte); sementes: "
              f"**{self.n_seeds}**; membros do ensemble: **{self.membros}**. Site desértico (o papel que o ASP tinha no "
              f"texto): **{self.arido}**.", ""]
        if self.avisos:
            L += ["**Avisos**", ""] + [f"- {x}" for x in self.avisos] + [""]
        L += ["## 1. O que tem nesta pasta", "",
              "| Arquivo | Onde entra no artigo |", "|---|---|",
              "| `tables/tab_data.tex` | Tab. 4 (sites e dados): troque a tabela escrita à mão por `\\input{tables/tab_data}` |",
              "| `tables/tab_main.tex` | Tab. 5 (comparação geral), `\\input{tables/tab_main}` |",
              "| `tables/tab_sites.tex` | Tab. 6 (por site, DM com Holm) |",
              "| `tables/tab_layers.tex` | Tab. 7 (camadas de calibração) |",
              "| `tables/tab_groups.tex` | Tab. 8 (cobertura por grupo no DA) |",
              "| `tables/tab_ablation.tex` | Tab. 9 (ablação B1–B5, B4h e B5a–B5g; a linha B4h faz o papel da antiga Tab. 10) |",
              "| `tables/tab_stress.tex` | Tab. 11 (estresse S0–S5) |",
              "| `tables/tab_cost.tex` | Tab. 12 (custo computacional) |",
              "| `macros/results_macros.tex` | todos os números do texto (`\\R...`), com os mesmos nomes do `main.tex` |",
              "| `macros/wgc_reference.tex` | referência amostral do WGC (Seção IV e Fig. 6b) |",
              "| `data/*.csv` | dados das figuras em pgfplots (Figs. 6–12) |",
              "| `figuras/fig_*.pdf` (e `.png`) | as mesmas figuras em matplotlib, para `\\includegraphics` |",
              "| `figuras/fig_vsn_pgfplots.tex` | Fig. 9 em pgfplots para estes sites (a do `main.tex` tem 4 colunas fixas) |",
              "| `figuras/fig_example.pdf` | figura nova (opcional): uma semana de previsões DA por site, proposto × antecessor |",
              "| `figuras/fig_weights.pdf` | figura nova da v3: peso do TFT escolhido em cada mês de teste, por horizonte e site "
              "(substitui a Fig. 8, de convergência dos otimizadores; dados em `data/fig_weights.csv`) |",
              "| `results/*.csv` | as tabelas em CSV (o que gerou tudo acima) |", "",
              "## 2. Como levar para o projeto LaTeX", "",
              "1. Copie `tables/`, `macros/`, `data/` e `figuras/` para a pasta do artigo (ou rode "
              "`python executar.py artigo --latex <pasta do artigo>`, que copia tudo).",
              "2. **Não rode** `tools/render_tables.py` nem o `build.sh` do zip de 16/10: eles regeram tabelas e macros "
              "com a lista fixa ASP, GTB, UTR e BRA e sobrescrevem estas. Compile direto: `latexmk -pdf main.tex`.",
              "3. No `main.tex`: troque a Tab. 4 por `\\input{tables/tab_data}` e o bloco da Fig. 9 por "
              "`\\input{figuras/fig_vsn_pgfplots}` (assim ela acompanha o número de sites de cada rodada). As outras "
              "figuras em pgfplots já leem `data/*.csv` e não dependem do número de sites. Se preferir as versões em "
              "matplotlib, use por exemplo "
              "`\\includegraphics[width=\\textwidth]{figuras/fig_horizon.pdf}` no lugar do `tikzpicture`.",
              "4. Figura nova: `figuras/fig_example.pdf` não existe no artigo; se quiser usá-la (bloco pronto, com legenda, "
              "em `figuras/fig_example.tex`: `\\input{figuras/fig_example}`), ela cabe na Seção VI-A "
              "(mostra os intervalos acompanhando os regimes).",
              "5. Quando os números forem os finais, ponha `\\showplaceholdersfalse` no preâmbulo.", "",
              "A pasta `artigo2_3sites`, entregue com o pacote, é o projeto do zip de 16/10 já com os passos 2–3 e as "
              "mudanças da seção 3 abaixo. Para pôr nela os números de uma rodada nova: "
              "`gerar_relatorio.bat --latex ..\\artigo2_3sites` e compile.", "",
              "## 3. O que muda no texto (modelo da v3 e sites)", ""]
        L += self._mudancas_texto()
        L += ["", "## 4. O que os números dizem sobre cada frase dos resultados", "",
              "A Seção VI do rascunho foi escrita para o modelo da v2 (com o ICSO-PP), com valores hipotéticos (blocos "
              "em laranja). Na v3, as frases abaixo são as que o texto novo deve sustentar, com os números desta "
              "rodada. ✅ confirma, ❌ não confirma (reescreva a frase), ➖ não dá para decidir com estes dados.", "",
              "| Seção | Afirmação do texto | Números | |", "|---|---|---|---|"]
        for c in self.checks:
            simb = "➖" if c["ok"] is None else ("✅" if c["ok"] else "❌")
            L.append(f"| {c['secao']} | {c['afirmacao']} | {c['valores']} | {simb} |")
        n_ok = sum(1 for c in self.checks if c["ok"] is True)
        n_no = sum(1 for c in self.checks if c["ok"] is False)
        L += ["", f"Resumo: {n_ok} confirmadas, {n_no} não confirmadas, "
                  f"{len(self.checks) - n_ok - n_no} indefinidas.", "",
              "## 5. Números principais (para o resumo e a conclusão)", ""]
        L += self._numeros_principais()
        L += ["", "## 6. Decisões de implementação que o texto precisa refletir", "",
              "Veja a seção 6 do README do pacote de experimentos (TFT em PyTorch puro, regra de fusão com "
              "n_ef = max(30, ⌈τ/(1−τ)⌉ + 1), interações por blocos de horas, BatchMVP com 10 faixas, janela de "
              "calibração do DA causal, pares sem GFS excluídos, QC de disponibilidade da usina, ȳ pelo treino, pesos da "
              "Fig. 9 com as conexões residuais do TFT, época do TFT de 4.000 janelas sorteadas, k recentes e peso "
              "intradiário no TFT, e o modelo híbrido da v3: itens 23 a 25)."]
        (self.d / "GUIA_ARTIGO.md").write_text("\n".join(L) + "\n", encoding="utf-8")

    def _mudancas_texto(self) -> list:
        n, sites = self.n_sites, self.sites
        kop = [str(self.info_sites[s].get("koppen", "?")) for s in sites]
        lat = {s: float(self.info_sites[s].get("_resumo", {}).get("lat", self.info_sites[s].get("lat", 0)) or 0) for s in sites}
        sul = [s for s in sites if lat[s] < 0]
        norte = [s for s in sites if lat[s] >= 0]
        hemis = ("both hemispheres (" + ", ".join(sul) + " in the south, " + ", ".join(norte) + " in the north)"
                 if sul and norte else ("the southern hemisphere" if sul else "the northern hemisphere"))
        L = [f"Linhas do `main.tex` do zip de 16/10 (as linhas podem ter mudado na sua versão). Os macros "
             f"`\\RNSites` ({n}), `\\RNSitesWord` ({_ext(n)}), `\\RNPairs` ({self.n_pares}), `\\RSiteList` "
             f"({self.lista_sites()}), `\\RKoppenList` e `\\RDesertSite` ({self.arido}) já estão em "
             "`results_macros.tex`.", "",
             f"- **Resumo (l. 143), contribuições (l. 266) e conclusão (l. 1026):** “four public datasets that span both "
             f"hemispheres and four Köppen climates (BWh, Cfa, Cfb and BSh)” → “" +
             (f"a single PV plant in {hemis}, with a {kop[0]} Köppen climate”." if n == 1 else
              f"{_ext(n)} single PV plants that span {hemis} and {_ext(len(set(kop)))} Köppen climates "
              f"({', '.join(kop)})”."),
             f"- **Seção V-A, Sites and Data (l. 713–720):** troque os quatro itens (ASP, GTB, UTR, BRA) por "
             f"{n} {'item' if n == 1 else 'itens'}:"]
        g = self.cfg.get("hibrido") or {}
        grade = ", ".join(f"{w:g}" for w in g.get("pesos", [0, 0.2, 0.4, 0.6, 0.8, 1]))
        lg = self.cfg.get("lgbm") or {}
        v3 = ["**Modelo da v3 (TFT + LightGBM, sem o ICSO-PP nas cabeças).** Estas mudanças valem para o texto todo; "
              "as seguintes são as de sites.", "",
              f"- **Nome:** “CCP-Boot-TFT-ICSO-PP” → `\\RModelName` (provisório: {MODELO}; troque a constante MODELO "
              "em exp/artigo.py se escolher outro). O ICSO-PP continua só no antecessor (CP-Boot-LSTM-ICSO-PP) e na "
              "ablação B4h.",
              "- **Resumo, contribuições e conclusão:** a contribuição do Estágio 3 com ICSO-PP sai. Entram: (i) a "
              "combinação, por horizonte, do ensemble de TFTs com modelos quantílicos de gradient boosting, com o peso "
              "escolhido em cada janela de calibração pelo IS condicional em validação cruzada; (ii) escalas separadas "
              "para os lados de baixo e de cima na camada condicional, tiradas dos quantis de cada modelo.",
              "- **Fig. 1 (pipeline):** a caixa do Estágio 3 (ICSO-PP) vira “LightGBM quantiles + per-window "
              "combination”; a do Estágio 4, “conditional CP with lower/upper scales”. A cabeça mediana deixa de ter o "
              "rótulo ICSO-PP.",
              "- **Seção III (Estágio 3, antes ICSO-PP):** texto sugerido: “LightGBM quantile models (21 levels, one set "
              "per horizon) are fitted on the tabular inputs, including the clear-sky indices of the last three hours" +
              (", with the clear-sky index as the target, like the TFT; their quantiles are multiplied back by the "
               "clear-sky power. " if str(lg.get("alvo", "y")).lower() == "k" else ". ") +
              "The TFT and LightGBM medians are combined as $\\hat y = w\\,\\hat y_{\\mathrm{TFT}} + (1-w)\\,\\hat "
              "y_{\\mathrm{GBM}}$, and their lower and upper scales likewise. The weight $w\\in\\{" + grade + "\\}$ "
              "is chosen in every calibration window (horizon $\\times$ test month) as the one with the lowest "
              "conditional interval score, cross-fitted over the two halves of the window's days; nothing from the test "
              "month enters the choice.”",
              "- **Seção III (Estágio 4):** os escores passam a ter uma escala por lado: $E^{+}=(y-\\hat "
              "y)^{+}/s^{\\uparrow}$ e $E^{-}=(\\hat y-y)^{+}/s^{\\downarrow}$. No TFT, $s^{\\downarrow}$ e "
              "$s^{\\uparrow}$ combinam a dispersão entre os membros com as metades de baixo ($q_{0.5}-q_{0.1}$) e de "
              "cima ($q_{0.9}-q_{0.5}$) da faixa das cabeças; no LightGBM, as metades da faixa 2,5–97,5%. Os tercis de "
              "dispersão usam a média das duas escalas.",
              f"- **Tab. 3 (hiperparâmetros):** acrescente a linha do LightGBM ("
              f"{'alvo: índice de céu claro k, como o TFT; ' if str(lg.get('alvo', 'y')).lower() == 'k' else ''}"
              f"até {lg.get('n_estimators', 500)} "
              f"árvores, taxa {str(lg.get('learning_rate', 0.05)).replace('.', ',')}, {lg.get('num_leaves', 63)} "
              f"folhas, mínimo de {lg.get('min_child_samples', 20)} amostras por folha, subamostragem de "
              f"{str(lg.get('subsample', 0.8)).replace('.', ',')} das linhas e "
              f"{str(lg.get('colsample_bytree', 0.8)).replace('.', ',')} das colunas, parada antecipada de 50 rodadas "
              f"na validação, 21 quantis por horizonte) e a grade do peso ({grade}); os hiperparâmetros do ICSO-PP vão "
              "para a descrição do antecessor e da ablação B4h.",
              "- **Seção V-C (baselines):** “Boot-TFT + BatchMVP” → “Hybrid + BatchMVP”: o BatchMVP é aplicado à mesma "
              "base híbrida, para isolar a camada de calibração.",
              "- **Tab. 10 e Fig. 8 (otimizadores):** saem. A linha B4h da Tab. 9 mostra o efeito do ICSO-PP nas cabeças "
              "(macros `\\RAbICSO<h>`). A Seção VI-F passa a discutir os pesos da combinação (figura "
              "`figuras/fig_weights.pdf`, macros `\\RWeight<h>` e `\\RWeight<SITE><h>`).",
              "- **Tab. 9 (ablação):** B1–B3 como antes; B4 = escalas de cada lado; B5 = proposto (+ LightGBM com peso por "
              "janela); B4h = B4 + ICSO-PP; B5a–B5d = as variantes antigas B4a–B4d, agora sobre B5; B5e = Boot-LSTM do "
              "artigo 1; B5f = peso fixo por horizonte (validação); B5g = só o LightGBM. Macros novos: `\\RAbAsym<h>`, "
              "`\\RAbHyb<h>`, `\\RAbFixed<h>`, `\\RAbGBMOnly<h>`.",
              "- **Tab. 12 (custo):** colunas novas (LightGBM e escolha dos pesos no Estágio 3); macros `\\RCostLGBM` e "
              "`\\RCostWeights` no lugar de `\\RCostICSO`.", "",
              "**Mudanças de sites:**", ""]
        L = v3 + L
        for s in sites:
            c, rz = self.info_sites.get(s, {}), self.info_sites.get(s, {}).get("_resumo", {})
            fonte = str(c.get("fonte", ""))
            txt = {"dkasc": (f"*{s} ({str(rz.get('nome', '')).split(' (')[0]}).* The Desert Gardens ground-mounted plant "
                             f"({float(rz.get('pnom_kw', 0)):.0f}\\,kW$_\\mathrm{{p}}$, fixed tilt, 2016) of the Desert "
                             "Knowledge Australia Solar Centre (DKASC) in a hot desert climate, with 5-min data for "
                             f"{str(c.get('inicio', ''))[:4]}–{str(c.get('fim', ''))[:4]}, before the plant was curtailed "
                             "by the resort microgrid~\\cite{dkasc}."),
                   "ons": (f"*{s} (Northeast Brazil).* The {c.get('nome_ons', 'ONS')} utility-scale complex "
                           f"({float(rz.get('pnom_kw', 0)) / 1000:.0f}\\,MW$_\\mathrm{{ac}}$, seven 28-MW plants) in the "
                           "semi-arid interior of Bahia, with hourly verified generation published by the system "
                           "operator ONS under a CC-BY license~\\cite{ons2026geracao}, before the large-scale "
                           "constrained-off of 2024–2025."),
                   "pvdaq": (f"*{s} (Georgia, USA).* The Simon Solar Farm "
                             f"({float(rz.get('pnom_kw', 0)) / 1000:.0f}\\,MW$_\\mathrm{{ac}}$, 40 inverters) of the NREL "
                             "PVDAQ archive (system 9069, 2023 DOE Solar Data Prize) in a humid subtropical climate, "
                             "with 5-min inverter data~\\cite{pvdaq9069}.")}.get(fonte, f"*{s}.* (descreva a usina)")
            L.append(f"    - {txt}")
        L += ["- **Tab. 4 (l. 722–735):** `\\input{tables/tab_data}` (gerada com os dados da coleta).",
              "- **Seção V-B, QC (l. 741):** as porcentagens de dias removidos por site estão em `\\RQCRemoved<SITE>` "
              "(" + ", ".join(f"{s} {self.info_sites[s].get('_resumo', {}).get('qc_pct_removidos', '?')}%" for s in sites)
              + "). Acrescente a regra de disponibilidade: “Periods in which the recorded output stays far below the "
              "plant's capability for days at a time (the weekly maximum below 30% of its 99th percentile for at "
              "least three days, which flags outages and corrupted records) are also removed.”" + self._texto_indisp(),
              f"- **Significância (l. 706) e Fig. 12:** “16 site–horizon pairs” → “{_ext(self.n_pares)} site–horizon "
              "pairs” (`\\RNPairsWord`).",
              f"- **Resultados por site (l. 821):** “all 16 site–horizon pairs” → `\\RNPairsWord` ({self.n_pares}); "
              f"“the three cloudier sites” → `\\RCloudierSites` (“{self.macros['CloudierSites'][0]}”); “the desert "
              f"climate of ASP” → “the desert climate of `\\RDesertSite`” ({self.arido}); `\\RDMASPMinMVP` e "
              f"`\\RMergedASP` já trazem os valores de {self.arido} (há também `\\RDMDesertMinMVP` e `\\RMergedDesert`).",
              f"- **Interpretabilidade (l. 981):** “At ASP, solar geometry…” → “At `\\RDesertSite`, …” "
              f"(`\\RVSNGeoASPDA` já é de {self.arido}). Fig. 9: troque o bloco por `\\input{{figuras/fig_vsn_pgfplots}}` "
              f"({n} {'coluna' if n == 1 else 'colunas'} nesta rodada). A legenda gerada não traz a frase “Past power dominates at 1 h and NWP "
              "inputs dominate the day-ahead horizon”: confira na seção 4 se os pesos a confirmam antes de pô-la de volta.",
              "- **Implementação (l. 763):** “PyTorch, PyTorch Forecasting” → “PyTorch, LightGBM”; a frase das “2,000 "
              "fitness evaluations” passa a valer só para o ICSO-PP da ablação B4h (se ficar, “2,040”, `\\ROptEvals`).",
              "- **Tab. 3 (l. 651):** “at most 100 epochs” → “at most 100 epochs of 4,000 randomly drawn windows” "
              "(`tft: amostras_por_epoca` do config; item 22 da seção 6 do README).",
              "- **Sem modelo de fundação (pacote v2):** tire o item “Chronos + CP” da lista de baselines (l. 749) e troque "
              "“Eight baselines” por “Seven baselines” (l. 745); apague a frase sobre modelos de fundação na revisão da "
              "literatura (l. 226, “Pretrained time-series foundation models now offer zero-shot forecasts…”) e a frase "
              "sobre o Chronos na Seção VI-A (l. 774, “The zero-shot foundation model sees no NWP…”). A Tab. 5 e a Fig. 12 "
              "já saem sem ele.",
              "- **Limitações (l. 1018):** “at the desert site” continua valendo; confira com a Tab. 6.",
              "- **Disponibilidade de dados (l. 1030–1033):** troque Alice Springs/NIST/Utrecht por DKASC Yulara, ONS e "
              "NREL PVDAQ. Os termos do DKASC não permitem redistribuir os dados processados de YUL: publique só os "
              "scripts que baixam da fonte.",
              "- **Bibliografia:** acrescente a entrada do PVDAQ e generalize a do DKASC (o título atual cita Alice "
              "Springs):", "",
              "```bibtex",
              "@misc{pvdaq9069,",
              "  author       = {{National Renewable Energy Laboratory (NREL)}},",
              "  title        = {Photovoltaic Data Acquisition ({PVDAQ}) Public Datasets: System 9069 (2023 {DOE} Solar Data Prize)},",
              "  howpublished = {[Online]. Available: \\url{https://data.openei.org/submissions/4568}},",
              "  note         = {License CC-BY 4.0},",
              "  year         = {2023}",
              "}",
              "```"]
        tft = self.cfg.get("tft") or {}
        nl = int(tft.get("lags_decodificador", 0) or 0)
        pw = float(tft.get("peso_intradiario", 1) or 1)
        npw = int(tft.get("passos_intradiarios", 6) or 6)
        i3 = next((i for i, x in enumerate(L) if x.startswith("- **Tab. 3 (l. 651)")), len(L) - 1)
        if pw != 1:
            frac = npw * pw / (npw * pw + 36 - npw)
            parte = "half" if abs(frac - 0.5) < 1e-9 else f"{100 * frac:.0f}\\%"
            L.insert(i3 + 1, f"- **Perda do TFT (Seção III-B, depois da frase das três cabeças de quantis, e Tab. 3):** "
                             f"com `tft: peso_intradiario: {pw:g}`, os {npw} primeiros passos do decodificador "
                             f"pesam {pw:g} vezes mais na perda quantílica e na parada antecipada. Texto sugerido: "
                             f"“The quantile loss weights the first {_ext(npw)} decoder steps by {pw:g}, so that the "
                             f"intraday horizons, {_ext(npw)} of the 36 steps, receive {parte} of the training "
                             "signal; with uniform weights the TFT barely uses the latest observations.” Na Tab. 3, "
                             f"acrescente “intraday loss weight {pw:g} (first {npw} steps)” (item 23 da seção 6 do "
                             "README).")
        if nl:
            ks = ", ".join(["$k_{t_0}$"] + [f"$k_{{t_0-{d}}}$" for d in range(1, nl)])
            L.insert(i3 + 1, f"- **Entradas do TFT (tabela de entradas, l. 442–445, e Seção III-B, l. 452):** com "
                             f"`tft: lags_decodificador: {nl}` o decodificador recebe também os {nl} últimos "
                             f"índices de céu claro observados ({ks}), repetidos nos 36 passos, como o LightGBM e o "
                             "HEC-XGB. Na tabela, acrescente antes da linha “Static” a linha “At origin (decoder, "
                             f"36\\,h) & last {_ext(nl)} observed clear-sky indices {ks}, repeated at every step \\\\”; "
                             "na l. 452, “and the decoder reads the known inputs of the next 36\\,h” → “and the "
                             f"decoder reads the known inputs of the next 36\\,h together with the last {_ext(nl)} "
                             "observed clear-sky indices” (item 23 da seção 6 do README).")
        return L

    def _texto_indisp(self) -> str:
        partes = []
        for s in self.sites:
            ind = self.meta.get(s, {}).get("indisp", [])
            if ind:
                partes.append(f"{s}: " + "; ".join(f"{a} a {b} ({n} dias)" for a, b, n in ind))
        return (" Nesta rodada, a regra removeu " + " | ".join(partes) + ".") if partes else ""

    def _numeros_principais(self) -> list:
        a = self.a
        L = ["| Horizonte | IS proposto | IS antecessor | IS BatchMVP | PICP proposto | WGC proposto | WGC antecessor | CRPSS proposto |",
             "|---|---|---|---|---|---|---|---|"]
        for h in H4:
            L.append(f"| {h} | {a(h, 'PROP', 'IS'):.1f} | {a(h, 'PRIOR', 'IS'):.1f} | {a(h, 'MVP', 'IS'):.1f} | "
                     f"{a(h, 'PROP', 'PICP'):.1f} | {a(h, 'PROP', 'WGC'):.1f} | {a(h, 'PRIOR', 'WGC'):.1f} | "
                     f"{a(h, 'PROP', 'CRPSS'):.3f} |")
        L += ["", f"Referência amostral do WGC: {self.wgc_ref.get(0.96, np.nan):.1f}% (grupos a 96%) e "
                  f"{self.wgc_ref.get(0.95, np.nan):.1f}% (a 95%)."]
        return L

    # ================================================================== cópia para o projeto LaTeX
    def copiar_para(self, latex: Path) -> None:
        latex = Path(latex)
        if not (latex / "main.tex").exists():
            raise SystemExit(f"{latex} não parece o projeto do artigo (falta main.tex)")
        for sub in ("results", "data", "tables", "macros", "figuras"):
            orig = self.d / sub
            if not orig.exists():
                continue
            (latex / sub).mkdir(parents=True, exist_ok=True)
            for arq in orig.iterdir():
                if arq.is_file():
                    shutil.copy2(arq, latex / sub / arq.name)
        shutil.copy2(self.d / "GUIA_ARTIGO.md", latex / "GUIA_ARTIGO.md")
        log.info("  tabelas, macros, dados e figuras copiados para %s (compile com 'latexmk -pdf main.tex'; "
                 "não rode o tools/render_tables.py antigo)", latex)


def gerar(cfg: dict, destino: Path, hipotetico: bool | None = None, latex: Path | None = None) -> Path:
    """Gera tabelas, macros, figuras e o guia na pasta 'destino' (a saída do 'juntar')."""
    destino = Path(destino)
    if latex and not (Path(latex) / "main.tex").exists():
        raise SystemExit(f"--latex: {Path(latex).resolve()} {'não tem main.tex' if Path(latex).exists() else 'não existe'}. "
                         "Confira o nome da pasta do artigo (o projeto adaptado é ..\\artigo2_3sites).")
    if hipotetico is None:
        hipotetico = bool(cfg.get("_perfil"))
    art = Artigo(cfg, destino, hipotetico)
    art.carregar()
    log.info("== Saídas do artigo (%s; %d semente%s%s) ==", art.lista_sites(), art.n_seeds, "" if art.n_seeds == 1 else "s",
             "; perfil rápido: valores marcados como hipotéticos" if hipotetico else "")
    art.wgc_reference()
    art.tabelas()
    art.escrever_macros()
    art.figuras()
    art.guia()
    if latex:
        art.copiar_para(Path(latex))
    log.info("  tabelas em %s, figuras em %s, guia em %s", art.tab, art.fig, destino / "GUIA_ARTIGO.md")
    return destino
