#!/usr/bin/env python3
"""Experimentos do artigo CCP-Boot-TFT-ICSO-PP (artigo 2), pacote v2.

Uso:
    python executar.py verificar                    # dados, GPU e pacotes
    python executar.py rodar                        # todas as etapas, todas as sementes do config
    python executar.py rodar --sementes 0 1         # só algumas sementes
    python executar.py rodar --etapas proposto      # só algumas etapas
    python executar.py relatorio                    # CSVs do site (resultados/<SITE>/csv)
    python executar.py juntar                       # CSVs do artigo com todos os sites prontos (saida_artigo/)
    python executar.py artigo                       # tabelas LaTeX, macros, figuras e guia (saida_artigo/)
    python executar.py artigo --latex PASTA         # ... e copia tudo para o projeto LaTeX do artigo
    python executar.py tudo                         # rodar + relatorio + juntar + artigo
    python executar.py status                       # o que já foi feito
    python executar.py autoteste                    # testes do conformal condicional
    (acrescente --perfil rapido para um teste de fumaça de poucos minutos; --site GEO para escolher o site)

Etapas (rodar --etapas ...): proposto (Estágios 1–4, MVP, ablação, camadas), prior (Boot-LSTM do artigo 1
e B4e), otimizadores, estresse, tft_nativo (TFT e TFT+CQR), lgbm, hec. CH-PeEn sempre roda.
Tudo é retomável: interrompa com Ctrl+C e rode de novo.
"""

from __future__ import annotations

import argparse
import logging
import sys
import time
from pathlib import Path

RAIZ = Path(__file__).resolve().parent
sys.path.insert(0, str(RAIZ))

from exp import __version__ as VERSAO  # noqa: E402
from exp import config as C  # noqa: E402

ETAPAS = ["proposto", "prior", "otimizadores", "estresse", "tft_nativo", "lgbm", "hec"]
# v3: a comparação de otimizadores (Tab. 10 da v2) não faz parte do modelo; roda só com --etapas otimizadores
ETAPAS_PADRAO = [e for e in ETAPAS if e != "otimizadores"]
log = logging.getLogger("exp")


def _sites(cfg, args):
    return args.site or cfg["sites"]


def _preparar_console_windows():
    """No Windows: impede a suspensão automática enquanto os experimentos rodam e desliga o 'modo de edição
    rápida' do console (um clique na janela pausaria o programa). Vale só para este processo."""
    if sys.platform != "win32":
        return
    try:
        import ctypes

        k32 = ctypes.windll.kernel32
        k32.SetThreadExecutionState(0x80000000 | 0x00000001)  # ES_CONTINUOUS | ES_SYSTEM_REQUIRED
        h = k32.GetStdHandle(-10)
        modo = ctypes.c_uint32()
        if k32.GetConsoleMode(h, ctypes.byref(modo)):
            k32.SetConsoleMode(h, (modo.value | 0x0080) & ~0x0040)
    except Exception:  # noqa: BLE001
        pass


def cmd_verificar(cfg, args):
    import importlib

    ok = True
    for mod in ("numpy", "pandas", "scipy", "torch", "lightgbm", "xgboost", "optuna", "cma", "pyarrow", "yaml",
                "matplotlib"):
        try:
            m = importlib.import_module(mod)
            print(f"  ok   {mod} {getattr(m, '__version__', '')}")
        except Exception as e:  # noqa: BLE001
            ok = False
            print(f"  FALTA {mod}: {e}")
    import torch

    if torch.cuda.is_available():
        print(f"  ok   GPU: {torch.cuda.get_device_name(0)} (CUDA {torch.version.cuda})")
    else:
        print("  aviso PyTorch sem GPU: os TFTs vão treinar na CPU (muito mais lento). Veja o README, seção 1.")
    for cod in _sites(cfg, args):
        p = cfg["pasta_processados"] / cod
        for nome in ("potencia_horaria.parquet", "particoes.csv", "gfs_horario.parquet"):
            arq = p / nome
            print(f"  {'ok  ' if arq.exists() else 'FALTA'} {cod}: {arq}")
            ok = ok and arq.exists()
        arq = p / "gfs_horario.parquet"
        if arq.exists():
            try:
                import pandas as pd

                ciclos = pd.to_datetime(pd.read_parquet(arq, columns=["ciclo_utc"])["ciclo_utc"], utc=True)
                fim = pd.Timestamp(str(C.site(cfg, cod)["fim"])).tz_localize("UTC")
                completo = ciclos.max() >= fim - pd.Timedelta(days=2)
                print(f"  {'ok  ' if completo else 'AVISO'} {cod}: GFS de {ciclos.min():%Y-%m-%d} a {ciclos.max():%Y-%m-%d}"
                      + ("" if completo else f" (os dados vão até {fim:%Y-%m-%d}: o download do GFS terminou?)"))
                ok = ok and bool(completo)
            except Exception as e:  # noqa: BLE001
                print(f"  aviso não consegui ler o período do GFS de {cod} ({e})")
    return 0 if ok else 1


def cmd_rodar(cfg, args):
    from exp.pipeline import Experimento

    etapas = set(args.etapas or ETAPAS_PADRAO)
    sementes = args.sementes if args.sementes is not None else cfg["sementes"]
    for cod in _sites(cfg, args):
        C.configurar_log(C.pastas_site(cfg, cod)["logs"])
        log.info("Experimentos de %s (pacote v%s); sementes %s; etapas %s%s", cod, VERSAO, sementes, sorted(etapas),
                 f"; perfil {cfg['_perfil']}" if cfg.get("_perfil") else "")
        exp = Experimento(cfg, cod)
        exp.chpeen()
        t0 = time.time()
        for s in sementes:
            exp.rodar_semente(int(s), etapas)
        log.info("%s: sementes %s concluídas em %.1f h", cod, sementes, (time.time() - t0) / 3600)
    return 0


def cmd_relatorio(cfg, args):
    from exp.pipeline import Experimento
    from exp.relatorio import SemResultados, relatorio_site

    feitos, sem = [], []
    for cod in _sites(cfg, args):
        if not any((cfg["pasta_saida"] / cod / "previsoes").glob("s*/*.npz")):
            sem.append(cod)                      # nada rodou ainda: não carrega os dados à toa
            continue
        C.configurar_log(C.pastas_site(cfg, cod)["logs"])
        try:
            relatorio_site(Experimento(cfg, cod))
            feitos.append(cod)
        except SemResultados as e:
            log.warning("%s: %s", cod, e)
            sem.append(cod)
    if sem:
        print(f"\nAinda sem resultados em {cfg['pasta_saida']}: {', '.join(sem)}.")
    if not feitos:
        rapido = cfg.get("_perfil") == "rapido"
        print("Nada para relatar ainda." + (
            " Rode antes o rodar_teste_rapido.bat." if rapido else
            "\n  - Rodada completa: rode antes o rodar_experimentos.bat (por exemplo, --site GEO BRA). O relatório pode ser"
            "\n    gerado com as sementes que já terminaram, enquanto as outras rodam."
            "\n  - Teste rápido: gerar_relatorio.bat --perfil rapido (lê resultados_rapido e grava em saida_artigo_rapido)."))
        return 1
    return 0


def cmd_juntar(cfg, args):
    from exp.relatorio import juntar

    C.configurar_log(cfg["pasta_saida"] / "_logs")
    juntar(cfg, _destino(cfg, args), args.site)
    return 0


def _destino(cfg, args):
    return Path(args.destino) if args.destino else (cfg["_raiz"] / (f"saida_artigo_{cfg['_perfil']}" if cfg.get("_perfil")
                                                                    else "saida_artigo"))


def cmd_artigo(cfg, args):
    from exp.artigo import gerar

    C.configurar_log(cfg["pasta_saida"] / "_logs")
    gerar(cfg, _destino(cfg, args), latex=Path(args.latex) if args.latex else None)
    return 0


def cmd_tudo(cfg, args):
    for f in (cmd_rodar, cmd_relatorio, cmd_juntar, cmd_artigo):
        r = f(cfg, args)
        if r:
            return r
    return 0


def cmd_status(cfg, args):
    for cod in _sites(cfg, args):
        base = cfg["pasta_saida"] / cod
        print(f"== {cod} ({base})")
        for s in cfg["sementes"]:
            c = base / "cache" / f"s{s}"
            pv = base / "previsoes" / f"s{s}"
            membros = len(list(c.glob("tft_m*.pt"))) if c.exists() else 0
            prev = sorted(p.stem for p in pv.glob("*.npz")) if pv.exists() else []
            print(f"  semente {s}: {membros} TFTs treinados; previsões: {', '.join(prev) if prev else '—'}")
    return 0


def cmd_autoteste(cfg, args):
    import runpy

    runpy.run_path(str(RAIZ / "testes" / "teste_conformal.py"), run_name="__main__")
    return 0


def main():
    for fluxo in (sys.stdout, sys.stderr):   # saída redirecionada no Windows (cp1252): troca γ, θ etc. por '?'
        try:
            fluxo.reconfigure(errors="replace")
        except Exception:  # noqa: BLE001
            pass
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("comando", choices=["verificar", "rodar", "relatorio", "juntar", "artigo", "tudo", "status",
                                        "autoteste"])
    ap.add_argument("--config", default=str(RAIZ / "config_experimentos.yaml"))
    ap.add_argument("--perfil", help="perfil do config (ex.: rapido)")
    ap.add_argument("--site", nargs="+", help="sites (padrão: os do config)")
    ap.add_argument("--sementes", nargs="+", type=int, help="sementes (padrão: as do config)")
    ap.add_argument("--etapas", nargs="+", choices=ETAPAS, help="etapas (padrão: todas menos otimizadores)")
    ap.add_argument("--destino", help="pasta de saída do 'juntar' e do 'artigo' (padrão: saida_artigo)")
    ap.add_argument("--latex", help="pasta do projeto LaTeX do artigo: o comando 'artigo' copia para lá tabelas, "
                                    "macros, dados e figuras")
    args = ap.parse_args()
    if args.comando == "autoteste":          # não depende dos dados nem do config
        return cmd_autoteste(None, args)
    cfg = C.carregar(Path(args.config), args.perfil)
    if args.perfil:
        cfg["pasta_saida"] = cfg["pasta_saida"].parent / (cfg["pasta_saida"].name + f"_{args.perfil}")
    import torch

    torch.set_num_threads(C.threads_cpu())
    if args.comando in ("rodar", "tudo"):
        _preparar_console_windows()
    cmds = {"verificar": cmd_verificar, "rodar": cmd_rodar, "relatorio": cmd_relatorio, "juntar": cmd_juntar,
            "artigo": cmd_artigo, "tudo": cmd_tudo, "status": cmd_status, "autoteste": cmd_autoteste}
    try:
        return cmds[args.comando](cfg, args)
    except KeyboardInterrupt:
        log.warning("interrompido; o que já foi feito fica salvo. Rode de novo para continuar.")
        return 130


if __name__ == "__main__":
    sys.exit(main())
