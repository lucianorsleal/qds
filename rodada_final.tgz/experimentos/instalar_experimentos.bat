@echo off
REM Instala o ambiente dos experimentos do artigo CCP-Boot-TFT-ICSO-PP (Windows).
REM Cria a pasta .venv aqui, instala o PyTorch com CUDA (detecta a GPU NVIDIA) e os demais pacotes,
REM e confere os dados de YUL, BRA e GEO. Detalhes em resultados\instalacao.log
setlocal EnableExtensions
cd /d "%~dp0"
title Instalacao - experimentos CCP-Boot-TFT-ICSO-PP
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
if not exist resultados mkdir resultados

set "PYEXE="
for /f "delims=" %%P in ('py -3 -c "import sys;print(sys.executable)" 2^>nul') do set "PYEXE=%%P"
if defined PYEXE if not exist "%PYEXE%" set "PYEXE="
if not defined PYEXE for /f "delims=" %%P in ('python -c "import sys;print(sys.executable)" 2^>nul') do set "PYEXE=%%P"
if defined PYEXE if not exist "%PYEXE%" set "PYEXE="
if not defined PYEXE for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do if exist "%%D\python.exe" set "PYEXE=%%D\python.exe"
if not defined PYEXE (
  echo Python nao encontrado. Instale o Python 3.10 ou mais novo em https://www.python.org/downloads/
  pause
  exit /b 1
)
echo Python encontrado: %PYEXE%
if not exist ".venv\Scripts\python.exe" (
  echo Criando o ambiente virtual .venv ...
  "%PYEXE%" -m venv .venv
  if errorlevel 1 (
    echo Falha ao criar o ambiente virtual.
    pause
    exit /b 1
  )
)
set "VPY=%~dp0.venv\Scripts\python.exe"
echo Instalando o PyTorch e os pacotes (alguns GB; pode levar varios minutos) ...
"%VPY%" instalar.py
if errorlevel 1 (
  echo Falha na instalacao. Veja resultados\instalacao.log
  pause
  exit /b 1
)
echo.
"%VPY%" executar.py verificar
echo.
echo Instalacao concluida. Para um teste rapido (minutos): rodar_teste_rapido.bat
echo Para os experimentos completos (YUL, BRA e GEO): rodar_experimentos.bat
echo Se a instalacao ja existia, ela so foi completada (ex.: matplotlib para as figuras do artigo).
pause
