# Rodada final no Linux (GPU NVIDIA) — pacote v3.1

Roteiro para rodar os experimentos do artigo do zero numa máquina Linux com GPU NVIDIA:

- **Sites:** GEO, BRA e YUL. O YUL passa a usar 2017–2020, com teste em 2020.
- **Sementes:** 10, que é o que o artigo diz.
- **Modelo:** v3.1.

No fim saem as tabelas, figuras, macros e o guia do artigo.

**Tempo:** a coleta do YUL (sobretudo o GFS) leva ~1 dia. Os experimentos de GEO e BRA rodam ao mesmo tempo, em
~4–8 h. O YUL leva mais ~1–3 h depois que a coleta terminar. Os passos 4 e 5 são independentes: comece os dois
no mesmo dia.

## 0. O que a máquina precisa

- **GPU:** Linux com GPU NVIDIA e driver instalado (`nvidia-smi` mostra a placa).
- **Python:** 3.10, 3.11 ou 3.12, com `venv`. No Ubuntu: `sudo apt install python3-venv tmux`.
- **Disco e rede:** ~30 GB livres e internet para o pip, o DKASC e o THREDDS do NCAR.
- **tmux**, para deixar as rodadas andando com o terminal fechado. O básico:
  - `tmux new -s nome` cria a sessão;
  - `Ctrl+B` e depois `D` sai dela sem parar nada;
  - `tmux attach -t nome` volta.

## 1. Levar as pastas do PC

No PC, abra o PowerShell na pasta `C:\Users\Luciano\Downloads\novo_artigo` e gere um arquivo único:

```powershell
tar -czf rodada_final.tgz --exclude=experimentos/.venv --exclude=coleta_dados/.venv --exclude=__pycache__ `
  --exclude=experimentos/resultados `
  --exclude=experimentos/resultados_rapido --exclude=experimentos/saida_artigo `
  --exclude=experimentos/saida_artigo_rapido --exclude=experimentos/versao1 --exclude=experimentos/versao2 `
  --exclude=experimentos/versao3 `
  --exclude=coleta_dados/dados/brutos --exclude=coleta_dados/dados/processados/YUL `
  --exclude=coleta_dados/gdex_token.txt --exclude=coleta_dados/hf_token.txt `
  experimentos coleta_dados artigo2_3sites
```

O arquivo fica com alguns centos de MB. O comando deixa de fora:
- **Resultados antigos:** a rodada final é do zero na máquina nova, com o mesmo hardware em todas as sementes.
- **Dados brutos da coleta e o YUL processado (2021–2025):** GEO e BRA já estão processados, e o YUL vai ser
  baixado e processado de novo (assim o YUL antigo não tem como entrar na rodada por engano).
- **Arquivos de token:** a coleta pelo THREDDS não usa login.

Copie o `rodada_final.tgz` para a máquina Linux (scp, WinSCP ou pendrive) e extraia:

```bash
mkdir -p ~/novo_artigo && tar -xzf rodada_final.tgz -C ~/novo_artigo && cd ~/novo_artigo && ls
# experimentos  coleta_dados  artigo2_3sites
```

As três pastas precisam ficar lado a lado, porque o `config_experimentos.yaml` procura a coleta em
`../coleta_dados`.

## 2. Instalar (uma vez)

```bash
cd ~/novo_artigo/experimentos
bash linux/instalar.sh
```

O script:
- cria o `.venv`;
- instala o PyTorch com CUDA para a placa e as dependências;
- roda o autoteste da camada conformal;
- mostra a GPU e o número de núcleos. A linha que começa com "PyTorch" deve citar a sua placa, não
  "nenhuma (CPU)".

## 3. Teste rápido (10–15 min, recomendado)

```bash
bash linux/rodar.sh --perfil rapido --site BRA
```

O teste roda todas as etapas com 1 semente, 2 membros e 2 épocas. Os números não servem para o artigo; ele só
confere que a GPU, o LightGBM, o XGBoost e os processos paralelos funcionam na máquina. Grava em
`resultados_rapido/` e `saida_artigo_rapido/`, separado da rodada final. Deve terminar com o log
"Saídas do artigo".

## 4. Coleta do YUL 2017–2020 (sessão tmux própria)

```bash
cd ~/novo_artigo/coleta_dados
tmux new -s yul
bash linux_yul.sh
```

Ao rodar, você aceita os termos de uso do DKASC, como na coleta anterior. O script:

1. Baixa os arquivos anuais do DKASC de Yulara de 2017 a 2020.
2. **Confere o Desert Gardens** (`verificar_yul.py`). Ele compara a usina com três vizinhos de Yulara nos dias
   claros de cada trimestre.
   - **Se aparecer "ATENÇÃO"**, o script para. Não processe o YUL; mande a tabela impressa para eu analisar.
   - Em 2021 a conferência acusa todos os trimestres, que é o motivo da troca de período.
3. Processa a potência e baixa o GFS do YUL, ~108 mil pedidos ao THREDDS do NCAR. Leva ~17 h a ~1,8 pedido/s,
   mais se o servidor estiver lento. Se o terminal cair ou você interromper com `Ctrl+C`, rode
   `bash linux_yul.sh` de novo: ele continua de onde parou.
4. Processa o YUL com o GFS. Confira `dados/processados/relatorio_coleta.md`.

Para acompanhar sem entrar no tmux: `tail -f ~/novo_artigo/coleta_dados/dados/logs/coleta.log`.

## 5. Experimentos de GEO e BRA, 10 sementes (outra sessão tmux, junto com o passo 4)

```bash
cd ~/novo_artigo/experimentos
tmux new -s exp
bash linux/rodar.sh --site GEO BRA
```

- **Retomada:** se parar (queda de energia, terminal fechado), rode o mesmo comando; o que já está pronto é pulado.
- **Andamento:** `tail -f resultados/GEO/logs/experimentos.log`. O tempo de cada semente aparece no log.
- **Resumo:** `.venv/bin/python executar.py status --site GEO BRA` mostra o que já ficou pronto.
- **Velocidade:** com mais de 17 núcleos, dá para pôr `processos: 24` (ou núcleos − 2) no
  `config_experimentos.yaml` antes de começar. Só muda a velocidade, não os resultados.

## 6. Experimentos do YUL (quando o passo 4 terminar)

```bash
cd ~/novo_artigo/experimentos
.venv/bin/python executar.py verificar --site YUL      # dados do YUL e cobertura do GFS: tudo "ok"
bash linux/rodar.sh --site YUL
```

## 7. Relatório final e artigo

Com os três sites prontos:

```bash
bash linux/rodar.sh --latex ../artigo2_3sites
```

O comando:
- confere que não falta nada (o que já está pronto é pulado);
- gera o relatório de cada site e junta os três;
- produz tabelas, macros, figuras e o guia em `saida_artigo/`;
- copia tudo para o projeto LaTeX.

Se a máquina tiver LaTeX: `cd ../artigo2_3sites && latexmk -pdf main.tex`.

## 8. Trazer de volta

```bash
cd ~/novo_artigo/experimentos
bash linux/empacotar_resultados.sh
```

O script cria `~/novo_artigo/resultados_final.tgz` com:
- CSVs, logs e manifestos de cada site;
- `saida_artigo/` e o projeto LaTeX;
- `resultados/hardware.txt`, com o modelo da CPU e da GPU e as versões, que vão para a Tab. 12.

Copie esse arquivo para `C:\Users\Luciano\Downloads\novo_artigo` no PC (não precisa extrair) e me avise: eu
confiro os resultados e adapto o texto do artigo à v3.1 com os números finais. As previsões e os caches ficam na
máquina Linux (vários GB); não apague até o artigo fechar.

## Problemas comuns

| Sintoma | O que fazer |
|---|---|
| `nvidia-smi` não existe ou o instalar mostra "nenhuma (CPU)" | instale o driver da NVIDIA da distribuição e rode `bash linux/instalar.sh` de novo |
| `nvidia-smi` mostra "CUDA Version: 11.x" e o PyTorch não vê a GPU | driver antigo para o PyTorch com CUDA 12.8: atualize o driver ou, com o `.venv` ativo, `pip install --force-reinstall torch --index-url https://download.pytorch.org/whl/cu118` |
| `CUDA out of memory` | outra coisa está usando a GPU (`nvidia-smi`); feche e rode de novo. O TFT usa pouca memória |
| `verificar_yul.py` termina com "ATENÇÃO" | não processe o YUL; mande a tabela. GEO e BRA seguem normalmente |
| o GFS fica parado ou o log mostra 429/503 | o servidor do NCAR está cheio; a coleta faz pausas de 5–60 min sozinha. Se insistir, use `--trabalhadores 16` no `linux_yul.sh` |
| `executar.py verificar` acusa GFS incompleto no YUL | rode `bash linux_yul.sh` de novo (repete os pedidos que falharam) |
| "No space left on device" | as previsões ocupam ~2 GB por site; libere espaço e rode de novo |
| quer recomeçar um site do zero | apague `experimentos/resultados/<SITE>` e rode de novo |
