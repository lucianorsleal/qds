"""Monta uma pasta de coleta de teste: a potência real do GEO e um GFS sintético no formato do
gfs_horario.parquet da coleta (para testar o pacote antes de o GFS real terminar de baixar).

O NWP sintético parte do índice de céu claro observado, com erro que cresce com a antecedência,
nebulosidade correlacionada, temperatura e umidade sazonais e vento aleatório.

Uso: python testes/gerar_dados_teste.py <pasta_coleta_real> <pasta_destino> [--inicio AAAA-MM-DD]
"""
import argparse
import shutil
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

ap = argparse.ArgumentParser()
ap.add_argument("coleta")
ap.add_argument("destino")
ap.add_argument("--site", default="GEO")
ap.add_argument("--inicio", default=None, help="corta a série antes desta data (teste mais rápido)")
a = ap.parse_args()
src, dst = Path(a.coleta), Path(a.destino)
cod = a.site
(dst / "dados" / "processados" / cod).mkdir(parents=True, exist_ok=True)
cfg = yaml.safe_load(open(src / "config.yaml", encoding="utf-8"))
if a.inicio:
    cfg["sites"][cod]["inicio"] = a.inicio
yaml.safe_dump(cfg, open(dst / "config.yaml", "w", encoding="utf-8"), allow_unicode=True, sort_keys=False)
p = pd.read_parquet(src / "dados" / "processados" / cod / "potencia_horaria.parquet")
p["tempo_utc"] = pd.to_datetime(p["tempo_utc"], utc=True)
if a.inicio:
    ini = pd.Timestamp(a.inicio).tz_localize(cfg["sites"][cod]["fuso_lst"]).tz_convert("UTC")
    p = p[p["tempo_utc"] >= ini]
    p.loc[p["bloco"] == "fora", "bloco"] = "treino"
p.to_parquet(dst / "dados" / "processados" / cod / "potencia_horaria.parquet", index=False)
shutil.copy(src / "dados" / "processados" / cod / "particoes.csv", dst / "dados" / "processados" / cod / "particoes.csv")

rng = np.random.default_rng(42)
t = pd.DatetimeIndex(p["tempo_utc"])
ghi_cs = p["ghi_cs"].to_numpy(dtype=float)
cs_rel = ghi_cs / max(ghi_cs.max(), 1)
y = p["y"].to_numpy(dtype=float)
k_obs = np.where(cs_rel > 0.05, np.clip(y / np.maximum(0.85 * cs_rel, 0.05), 0, 1.3), np.nan)
k_obs = pd.Series(k_obs).interpolate(limit=6).fillna(0.6).to_numpy()
serie = pd.Series(np.arange(len(t)), index=t)
c0, c1 = t.min().floor("6h"), t.max().floor("6h")
ciclos = pd.date_range(c0, c1, freq="6h")
linhas = []
doy = t.dayofyear.to_numpy()
for c in ciclos:
    validos = c + pd.to_timedelta(np.arange(3, 75), unit="h")
    idx = serie.reindex(validos).to_numpy()
    ok = np.isfinite(idx)
    if not ok.any():
        continue
    ii = idx[ok].astype(int)
    lead = (np.arange(3, 75)[ok] + 1).astype(np.float32)
    erro = rng.normal(0, 0.12 + 0.004 * lead)
    k = np.clip(k_obs[ii] + erro, 0, 1.2)
    k = np.where(ghi_cs[ii] > 1, k, 0.0)
    tcc = np.clip(1 - k + rng.normal(0, 0.1, len(ii)), 0, 1)
    t2m = 17 + 10 * np.sin(2 * np.pi * (doy[ii] - 110) / 365) + 5 * cs_rel[ii] + rng.normal(0, 1.5, len(ii))
    rh = np.clip(70 - 20 * cs_rel[ii] + 15 * tcc + rng.normal(0, 5, len(ii)), 5, 100)
    linhas.append(pd.DataFrame({"ciclo_utc": c, "valido_utc": validos[ok], "lead_h": lead,
                                "ghi_nwp": (k * ghi_cs[ii]).astype(np.float32), "ghi_cs": ghi_cs[ii].astype(np.float32),
                                "k_nwp": k.astype(np.float32), "tcc": tcc.astype(np.float32), "t2m": t2m.astype(np.float32),
                                "rh2m": rh.astype(np.float32), "u10": rng.normal(1, 2, len(ii)).astype(np.float32),
                                "v10": rng.normal(0, 2, len(ii)).astype(np.float32)}))
g = pd.concat(linhas, ignore_index=True)
g["t2m_x_rh2m"] = (g["t2m"] * g["rh2m"]).astype(np.float32)
g.to_parquet(dst / "dados" / "processados" / cod / "gfs_horario.parquet", index=False)
print(f"{cod}: {len(p)} horas de potência, {len(g)} linhas de GFS sintético em {dst}")
