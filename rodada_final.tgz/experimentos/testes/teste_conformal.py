"""Testes do conformal condicional (exp/conformal.py).

1. Só intercepto: o limiar é a ⌈(n+1)τ⌉-ésima estatística de ordem (split conformal).
2. Dummies disjuntas: o limiar é o quantil Mondrian do grupo do ponto de teste.
3. Grupos sobrepostos (hora + regime + tercil): o limiar pela dual coincide com a bisseção do Algoritmo 1
   sobre a regressão quantílica aumentada resolvida no primal.
4. Simulação: a cobertura de cada grupo sobreposto fica >= τ em média.
5. BatchMVP: cobertura por grupo perto de q.
6. Regra de fusão no limite (contando o ponto de teste, n_ef = ⌈τ/(1-τ)⌉ + 1 = 50 com τ = 0,98): o grupo
   do ponto de teste com 48 amostras de calibração é fundido e com 49 não é; os dois dão limiar finito.
   Com interações regime × hora, os limiares também ficam finitos.
"""
import sys
from pathlib import Path

import numpy as np
from scipy.optimize import linprog

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from exp import conformal as cc  # noqa: E402

rng = np.random.default_rng(0)


def primal_aceita(E, Phi, phi, S, tau):
    n, d = Phi.shape
    A = np.vstack([Phi, phi[None, :]])
    b = np.concatenate([E, [S]])
    m = n + 1
    # variáveis: beta (d, livre), u+ (m), u- (m)
    c = np.concatenate([np.zeros(d), tau * np.ones(m), (1 - tau) * np.ones(m)])
    A_eq = np.hstack([A, np.eye(m), -np.eye(m)])
    bounds = [(None, None)] * d + [(0, None)] * (2 * m)
    r = linprog(c, A_eq=A_eq, b_eq=b, bounds=bounds, method="highs")
    beta = r.x[:d]
    return S <= phi @ beta + 1e-8


def bissecao(E, Phi, phi, tau, tol=1e-6):
    lo, hi = 0.0, max(1.0, E.max())
    while primal_aceita(E, Phi, phi, hi, tau):
        hi *= 2
        if hi > 1e6:
            return np.inf
    while hi - lo > tol:
        mid = 0.5 * (lo + hi)
        if primal_aceita(E, Phi, phi, mid, tau):
            lo = mid
        else:
            hi = mid
    return lo


# 1 -------------------------------------------------------------------------
for n, tau in [(99, 0.95), (100, 0.95), (199, 0.975), (1000, 0.98), (49, 0.98), (48, 0.98)]:
    E = rng.exponential(size=n)
    q = cc.limiar_condicional(E, np.ones((n, 1)), np.ones(1), tau)
    ref = cc.quantil_split(E, tau)
    assert (np.isinf(q) and np.isinf(ref)) or abs(q - ref) < 1e-9, (n, tau, q, ref)
print("1. intercepto = split conformal: ok")

# 2 -------------------------------------------------------------------------
n = 600
g = rng.integers(0, 3, n)
E = rng.exponential(size=n) * (1 + g)
for gt in range(3):
    Phi = np.column_stack([np.ones(n), g == 1, g == 2]).astype(float)
    phi = np.array([1.0, gt == 1, gt == 2], dtype=float)
    q = cc.limiar_condicional(E, Phi, phi, 0.95)
    ref = cc.quantil_split(E[g == gt], 0.95)
    assert abs(q - ref) < 1e-9, (gt, q, ref)
print("2. dummies disjuntas = Mondrian: ok")

# 3 -------------------------------------------------------------------------
n = 300
fam = cc.Familias({"hora": rng.integers(0, 4, n), "regime": rng.integers(0, 3, n), "tercil": rng.integers(0, 3, n)},
                  {"hora": 4, "regime": 3, "tercil": 3})
E = rng.exponential(size=n) * (1 + 0.5 * fam.codigos["regime"]) * (1 + 0.3 * fam.codigos["hora"])
difs = []
for padrao in [{"hora": 0, "regime": 0, "tercil": 0}, {"hora": 3, "regime": 2, "tercil": 1},
               {"hora": 1, "regime": 1, "tercil": 2}]:
    for tau in (0.9, 0.95):
        Phi, phi, _ = cc.matriz_phi(fam, padrao, cc.n_efetivo(tau, 10))
        q = cc.limiar_condicional(E, Phi, phi, tau)
        qb = bissecao(E, Phi, phi, tau)
        difs.append(abs(q - qb))
        assert abs(q - qb) < 1e-4, (padrao, tau, q, qb)
print(f"3. dual = bisseção do Algoritmo 1 (dif. máx {max(difs):.2e}): ok")

# 4 -------------------------------------------------------------------------
tau, reps, n, m = 0.9, 300, 400, 200
cob = {("hora", l): [] for l in range(4)}
cob.update({("regime", l): [] for l in range(3)})
for r in range(reps):
    def amostra(k):
        h, rg, t = rng.integers(0, 4, k), rng.choice(3, k, p=[0.6, 0.3, 0.1]), rng.integers(0, 3, k)
        e = rng.exponential(size=k) * (1 + rg) * (1 + 0.4 * h)
        return cc.Familias({"hora": h, "regime": rg, "tercil": t}, {"hora": 4, "regime": 3, "tercil": 3}), e
    fc, Ec = amostra(n)
    ft, Et = amostra(m)
    q, _ = cc.limiares_condicionais(Ec, fc, ft, tau, n_min=10)
    ok = Et <= q
    for l in range(4):
        cob[("hora", l)].append(ok[ft.codigos["hora"] == l].mean())
    for l in range(3):
        s = ft.codigos["regime"] == l
        if s.any():
            cob[("regime", l)].append(ok[s].mean())
medias = {k: float(np.mean(v)) for k, v in cob.items()}
print("4. cobertura média por grupo (alvo 0,90):", {f"{k[0]}{k[1]}": round(v, 3) for k, v in medias.items()})
assert min(medias.values()) > tau - 0.01

# 5 -------------------------------------------------------------------------
n = 3000
fam = cc.Familias({"hora": rng.integers(0, 6, n), "regime": rng.choice(3, n, p=[0.5, 0.3, 0.2])},
                  {"hora": 6, "regime": 3})
E = rng.exponential(size=n) * (1 + fam.codigos["regime"]) * (1 + 0.3 * fam.codigos["hora"])
G = cc.matriz_grupos(fam)
mvp = cc.BatchMVP().ajustar(E, G, 0.9)
fam_t = cc.Familias({"hora": rng.integers(0, 6, n), "regime": rng.choice(3, n, p=[0.5, 0.3, 0.2])},
                    {"hora": 6, "regime": 3})
Et = rng.exponential(size=n) * (1 + fam_t.codigos["regime"]) * (1 + 0.3 * fam_t.codigos["hora"])
f = mvp.prever(cc.matriz_grupos(fam_t))
covs = [np.mean(Et[g] <= f[g]) for g in cc.matriz_grupos(fam_t).T]
print(f"5. BatchMVP: {len(mvp.passos)} atualizações; cobertura por grupo de {min(covs):.3f} a {max(covs):.3f} (alvo 0,90)")
assert min(covs) > 0.86

# 6 -------------------------------------------------------------------------
for n_peq, deve_fundir in ((48, True), (49, False)):
    # n_ef = ⌈0,98/0,02⌉ + 1 = 50 contando o ponto de teste: 48 + 1 funde, 49 + 1 não funde
    reg = np.r_[np.zeros(500, int), np.ones(n_peq, int)]
    fam = cc.Familias({"hora": rng.integers(0, 3, reg.size), "regime": reg}, {"hora": 3, "regime": 3})
    _, _, fundiu = cc.matriz_phi(fam, {"hora": 0, "regime": 1}, cc.n_efetivo(0.98, 30))
    assert fundiu["regime"] == deve_fundir, (n_peq, fundiu)
    fam_t = cc.Familias({"hora": np.array([0, 1, 2]), "regime": np.array([1, 1, 0])}, {"hora": 3, "regime": 3})
    q, _ = cc.limiares_condicionais(np.abs(rng.standard_normal(reg.size)), fam, fam_t, 0.98, 30)
    assert np.isfinite(q).all(), (n_peq, q)
n = 1500
fam = cc.Familias({"hora": rng.integers(0, 8, n), "regime": rng.choice(3, n, p=[0.6, 0.3, 0.1]),
                   "tercil": rng.integers(0, 3, n)}, {"hora": 8, "regime": 3, "tercil": 3})
pad = np.array([[h, r, t] for h in range(8) for r in range(3) for t in range(3)])
fam_t = cc.Familias({"hora": pad[:, 0], "regime": pad[:, 1], "tercil": pad[:, 2]}, {"hora": 8, "regime": 3, "tercil": 3})
E = np.abs(rng.standard_normal(n))
q0, _ = cc.limiares_condicionais(E, fam, fam_t, 0.98, 30)
q1, _ = cc.limiares_condicionais(E, fam, fam_t, 0.98, 30, interacoes=True)
Phi0 = cc.matriz_phi(fam, {"hora": 0, "regime": 1, "tercil": 0}, cc.n_efetivo(0.98, 30))[0]
Phi1 = cc.matriz_phi(fam, {"hora": 0, "regime": 1, "tercil": 0}, cc.n_efetivo(0.98, 30), interacoes=True)[0]
assert np.isfinite(q1).all() and Phi1.shape[1] > Phi0.shape[1] and np.linalg.matrix_rank(Phi1) == Phi1.shape[1]
print(f"6. fusão no limite (48 → funde, 49 → não) e interações ({Phi1.shape[1] - Phi0.shape[1]} colunas a mais): ok")
print("conformal OK")
