"""(Obsoleto desde a v2) Conferia que os CSVs eram lidos pelo tools/render_tables.py e pelo
tools/wgc_reference.py do zip de 16/10, que esperam 9 métodos (com o Chronos, retirado na v2). As tabelas,
macros e figuras do artigo saem do exp/artigo.py (comando 'artigo').

Copia o projeto do artigo para uma pasta temporária, troca results/ e data/ pelos CSVs gerados e roda os dois
scripts. Como o render_tables.py da versão de 4 sites procura ASP, GTB, UTR e BRA na Tab. 6, as linhas do
site testado são replicadas com esses quatro nomes (só para o teste de formato).

Uso: python testes/teste_render_artigo.py <pasta_do_projeto_latex> <pasta_saida_artigo>
"""
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import pandas as pd

proj, saida = Path(sys.argv[1]), Path(sys.argv[2])
tmp = Path(tempfile.mkdtemp(prefix="artigo_teste_"))
dst = tmp / "artigo"
shutil.copytree(proj, dst)
NOMES = ["ASP", "GTB", "UTR", "BRA"]
for sub in ("results", "data"):
    for arq in (saida / sub).glob("*.csv"):
        df = pd.read_csv(arq)
        if arq.name == "main_metrics.csv":
            # método sem resultado: o render_tables.py antigo precisa das
            # 9 linhas para os postos; só neste teste de formato, copia os números do LGBM_CQR
            num = [c for c in df.columns if c not in ("site", "horizon", "method")]
            for mm in df.loc[df[num].isna().all(axis=1), "method"].unique():
                print(f"(teste) {mm} sem resultado; copiando LGBM_CQR só para conferir o formato")
                for hz in df["horizon"].unique():
                    src = df[(df["method"] == "LGBM_CQR") & (df["horizon"] == hz)][num].to_numpy()
                    df.loc[(df["method"] == mm) & (df["horizon"] == hz), num] = src
        if "site" in df.columns and not pd.api.types.is_numeric_dtype(df["site"]):
            df = pd.concat([df.assign(site=n) for n in NOMES], ignore_index=True)
        elif arq.name.startswith("fig_vsn"):
            df = pd.concat([df.assign(site=i, code=n) for i, n in enumerate(NOMES)], ignore_index=True)
            df = df.sort_values(["feat", "site"])
        df.to_csv(dst / sub / arq.name, index=False)
for script in ("tools/render_tables.py", "tools/wgc_reference.py"):
    r = subprocess.run([sys.executable, script], cwd=dst, capture_output=True, text=True)
    print(f"== {script}: código {r.returncode}")
    print((r.stdout + r.stderr)[-2500:])
    if r.returncode != 0:
        sys.exit(1)
hyp = [p.name for p in (dst / "results").glob("*.csv") if p.read_text().startswith("# HYPOTHETICAL")]
print("CSVs ainda hipotéticos:", hyp or "nenhum")
print(open(dst / "macros" / "results_macros.tex").read()[:1500])
print("tabelas:", sorted(p.name for p in (dst / "tables").glob("*.tex")))
print(open(dst / "tables" / "tab_main.tex").read()[:2500])
print("render OK em", dst)
