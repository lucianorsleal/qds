#!/usr/bin/env bash
# Roda os experimentos no Linux: python executar.py tudo <opções> (rodar + relatório + junção + saídas do artigo),
# no ambiente .venv. Retomável: o que já estiver pronto é pulado. Exemplos (de dentro da pasta experimentos):
#   bash linux/rodar.sh --perfil rapido --site BRA      # teste rápido (~10 min; grava em resultados_rapido)
#   bash linux/rodar.sh --site GEO BRA                  # 10 sementes do config
#   bash linux/rodar.sh --site YUL                      # depois que a coleta do YUL terminar
#   bash linux/rodar.sh --latex ../artigo2_3sites       # relatório final dos três sites e cópia para o LaTeX
# Rode dentro do tmux (tmux new -s exp) para poder fechar o terminal; a saída também vai para linux/rodar.log.
set -euo pipefail
cd "$(dirname "$0")/.."
# shellcheck disable=SC1091
source .venv/bin/activate
export PYTHONUNBUFFERED=1
python executar.py tudo "$@" 2>&1 | tee -a linux/rodar.log
exit "${PIPESTATUS[0]}"
