#!/usr/bin/env bash
# Junta num arquivo só o que precisa voltar para o PC: CSVs, logs e manifestos de cada site, as saídas do artigo,
# o projeto LaTeX (se estiver ao lado) e o hardware usado (Tab. 12). As previsões e os caches (vários GB) ficam na
# máquina. Uso, de dentro da pasta experimentos:   bash linux/empacotar_resultados.sh   -> ../resultados_final.tgz
set -euo pipefail
cd "$(dirname "$0")/.."
PASTA="$(basename "$PWD")"
{
  echo "data: $(date -Iseconds)"
  echo "cpu: $(lscpu 2>/dev/null | sed -n 's/^Model name:[[:space:]]*//p' | head -1) ($(nproc) núcleos)"
  nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv,noheader 2>/dev/null | sed 's/^/gpu: /' || true
  # shellcheck disable=SC1091
  source .venv/bin/activate
  python -c "import torch, lightgbm, xgboost; print('torch', torch.__version__, '| lightgbm', lightgbm.__version__, '| xgboost', xgboost.__version__)"
} > resultados/hardware.txt
itens=("$PASTA/resultados/hardware.txt")
for x in resultados/_logs saida_artigo linux/rodar.log; do [ -e "$x" ] && itens+=("$PASTA/$x"); done
for s in resultados/*/; do
  s="${s%/}"
  case "$s" in *_antigo_*|resultados/_logs) continue ;; esac
  for x in csv logs manifesto.json; do [ -e "$s/$x" ] && itens+=("$PASTA/$s/$x"); done
done
cd ..
[ -d artigo2_3sites ] && itens+=(artigo2_3sites)
[ -f coleta_dados/dados/processados/relatorio_coleta.md ] && itens+=(coleta_dados/dados/processados/relatorio_coleta.md)
tar -czf resultados_final.tgz "${itens[@]}"
echo "Criado $(pwd)/resultados_final.tgz ($(du -h resultados_final.tgz | cut -f1)). Leve este arquivo para o PC."
