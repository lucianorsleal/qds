#!/usr/bin/env bash
# Instala o ambiente dos experimentos no Linux (uma vez): cria o .venv, instala o PyTorch com CUDA para a GPU
# (o instalar.py escolhe a versão pelo nvidia-smi), instala o requirements_experimentos.txt, roda o autoteste e
# mostra a GPU. Uso, de dentro da pasta experimentos:   bash linux/instalar.sh
set -euo pipefail
cd "$(dirname "$0")/.."
PY="${PYTHON:-python3}"
"$PY" -c 'import sys; assert sys.version_info >= (3, 10), "precisa de Python 3.10 ou mais novo"'
if ! command -v nvidia-smi >/dev/null 2>&1; then
  echo "AVISO: nvidia-smi não encontrado; sem o driver da NVIDIA os TFTs rodam na CPU (muito mais lento)."
fi
[ -d .venv ] || "$PY" -m venv .venv
# shellcheck disable=SC1091
source .venv/bin/activate
python -m pip install --upgrade pip wheel
python instalar.py
python executar.py autoteste
python - <<'PYEOF'
import os
import torch
gpu = torch.cuda.get_device_name(0) if torch.cuda.is_available() else "nenhuma (CPU)"
print(f"PyTorch {torch.__version__} | GPU: {gpu} | núcleos da CPU: {os.cpu_count()}")
PYEOF
echo "Instalação concluída."
