@echo off
REM GFS pelos pedidos de subset do GDEX (veja o README, secao "GFS pelo subset do GDEX").
REM Baixa os arquivos dos pedidos ja prontos na sua conta, grava nos mesmos arquivos do THREDDS
REM (dados\brutos\gfs) e mostra quantos pedidos ao THREDDS ainda faltariam. Pode rodar de novo
REM quando outro pedido ficar pronto: o que ja foi importado nao e baixado outra vez.
REM Antes: copie o "API Token" de https://gdex.ucar.edu/accounts/profile/ para gdex_token.txt,
REM nesta pasta. Feche antes qualquer outra janela da coleta.
setlocal EnableExtensions
cd /d "%~dp0"
title GFS do GDEX - CCP-Boot-TFT-ICSO-PP
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
if not exist ".venv\Scripts\python.exe" (
  echo Ambiente .venv nao encontrado. Rode primeiro o rodar_coleta.bat
  pause
  exit /b 1
)
".venv\Scripts\python.exe" coletar.py gdex %*
echo.
echo Fim. Detalhes em dados\logs\coleta.log
pause
