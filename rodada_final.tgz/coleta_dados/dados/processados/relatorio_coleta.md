# Relatório da coleta de dados — CCP-Boot-TFT-ICSO-PP

Gerado em 2026-10-19 06:32.

## Valores para a Tabela 4 e para os itens em roxo do artigo

| Site | Local (lat, lon) | Köppen | Sistema | Pnom | Período (teste) | Dias removidos no QC |
|---|---|---|---|---|---|---|
| YUL | -25.2400, 130.9900 | BWh | Yulara, NT, AU (Desert Gardens, DKASC) | 1058.4 kW (kWp: potência nominal DC da usina informada pelo DKASC) | 2021-01-01 a 2025-12-31 (2025) | 12.21% |
| BRA | -12.5831, -44.1067 | BSh | Conj. Ituverava | 196.0 MW (kW_ac (capacidade instalada informada pelo ONS)) | 2019-07-01 a 2023-06-30 (jul/2022–jun/2023) | 5.13% |
| GEO | 33.6762, -83.6760 | Cfa | Social Circle, GA, US (Simon Solar Farm, PVDAQ 9069) — 40 unidades | 33.0 MW (kW_ac instalados (40 inversores de 825 kW); y = potência AC dos inversores com dado / capacidade deles) | 2016-03-01 a 2023-11-30 (dez/2022–nov/2023) | 8.16% |

## YUL — Yulara, NT, AU (Desert Gardens, DKASC)

- Horas diurnas com dado: 94.88% (primeira 2020-12-31 20:30:00+00:00, última 2025-12-31 08:30:00+00:00 UTC)
- Percentil 99,9 de y nas horas diurnas: 0.7276 (limite físico ȳ)
- QC: 223 de 1826 dias removidos (faltantes 9.2%, saída zero 0.93%, curtailment 2.35%, clipping 0.22%)
- Checagem de fuso: defasagem mediana 0.097 h; meses com |defasagem| > 0,5 h: 2
- Teto mensal (p99 de y nas horas diurnas): de 0.054 a 0.752; meses com teto < 80% do usual (já descontado o céu claro do mês no plano 15° / azimute 0°): 39 — 2021-02 (0.62), 2021-03 (0.66), 2021-05 (0.11), 2021-06 (0.10), 2021-07 (0.10), 2021-08 (0.10), 2021-09 (0.10), 2021-10 (0.10), 2021-11 (0.10), 2021-12 (0.10), 2022-05 (0.10), 2022-06 (0.11), 2022-07 (0.10), 2022-08 (0.10), 2022-09 (0.10), 2022-10 (0.10), 2022-11 (0.10), 2022-12 (0.10), 2023-08 (0.76), 2023-09 (0.65), 2023-10 (0.70), 2023-11 (0.68), 2024-04 (0.57), 2024-05 (0.51) ... (quedas longas indicam capacidade indisponível; veja checagem_teto_mensal.csv)
- GFS: 7313 ciclos; arquivos ok 131581, ausentes no arquivo do NCAR 275, falhas 0; GHI faltante 0.0%
- p_max_observado_kw: 832.5
- qc_pct_dias_com_restricao_ons: 0.0

## BRA — Tabocas do Brejo Velho, BA, BR (Conj. Ituverava, ONS)

- Horas diurnas com dado: 100.0% (primeira 2019-07-01 10:00:00+00:00, última 2023-06-30 19:00:00+00:00 UTC)
- Percentil 99,9 de y nas horas diurnas: 1.0103 (limite físico ȳ)
- QC: 75 de 1461 dias removidos (faltantes 0.0%, saída zero 1.64%, curtailment 1.1%, clipping 2.4%)
- Checagem de fuso: defasagem mediana -0.068 h; meses com |defasagem| > 0,5 h: 2
- Teto mensal (p99 de y nas horas diurnas): de 0.822 a 1.02; meses com teto < 80% do usual (já descontado o céu claro do mês no plano 13° / azimute 0°): nenhum (quedas longas indicam capacidade indisponível; veja checagem_teto_mensal.csv)
- GFS: 5853 ciclos; arquivos ok 108322, ausentes no arquivo do NCAR 142, falhas 0; GHI faltante 0.0%
- soma_potencia_efetiva_mw: 196.0
- qc_pct_dias_com_restricao_ons: 0.0

## GEO — Social Circle, GA, US (Simon Solar Farm, PVDAQ 9069)

- Horas diurnas com dado: 93.49% (primeira 2016-03-01 13:00:00+00:00, última 2023-11-28 21:00:00+00:00 UTC)
- Percentil 99,9 de y nas horas diurnas: 0.9989 (limite físico ȳ)
- QC: 231 de 2831 dias removidos (faltantes 6.92%, saída zero 1.24%, curtailment 0.0%, clipping 0.0%)
- Checagem de fuso: defasagem mediana -0.014 h; meses com |defasagem| > 0,5 h: 0
- Teto mensal (p99 de y nas horas diurnas): de 0.754 a 1.0; meses com teto < 80% do usual (já descontado o céu claro do mês no plano 20° / azimute 180°): 8 — 2021-06 (0.80), 2021-07 (0.78), 2021-08 (0.79), 2022-07 (0.80), 2023-06 (0.78), 2023-07 (0.76), 2023-08 (0.78), 2023-09 (0.79) (quedas longas indicam capacidade indisponível; veja checagem_teto_mensal.csv)
- GFS: 11333 ciclos; arquivos ok 195928, ausentes no arquivo do NCAR 216, falhas 0; GHI faltante 0.0%
- disponibilidade_frota_diurna_media: 0.8709
- qc_pct_dias_com_restricao_ons: 0.0
- system_id: 9069
- canais_potencia: inversores (40 x potência AC); medidor 1: 2016-02-17 a 2019-04-04; medidor 2: 2020-03-26 a 2023-11-29
