@echo off
REM Igual ao rodar_coleta.bat, mas ja registra o aceite dos termos do DKASC
REM (https://dkasolarcentre.com.au/download/terms-conditions), sem perguntar.
call "%~dp0rodar_coleta.bat" --aceito-termos-dkasc
