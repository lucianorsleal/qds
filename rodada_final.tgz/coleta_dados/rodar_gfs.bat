@echo off
REM 1) Reprocessa as series de potencia (rapido, ~5 min) com o codigo atual.
REM 2) Retoma a etapa do GFS de onde parou e refaz pedidos que falharam.
REM 3) Reprocessa tudo, agora com o GFS.
REM Use depois que o rodar_coleta.bat ja tiver criado o ambiente .venv.
REM Feche antes qualquer outra janela da coleta: so pode haver uma rodando.
setlocal EnableExtensions
cd /d "%~dp0"
title Coleta do GFS - CCP-Boot-TFT-ICSO-PP
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
if not exist ".venv\Scripts\python.exe" (
  echo Ambiente .venv nao encontrado. Rode primeiro o rodar_coleta.bat
  pause
  exit /b 1
)
echo == 1/3 Reprocessando as series de potencia ==
".venv\Scripts\python.exe" coletar.py processar --sem-gfs
echo.
echo == 2/3 Baixando o GFS (retoma de onde parou; pode fechar e rodar de novo) ==
".venv\Scripts\python.exe" coletar.py baixar --fontes gfs --refazer-falhas %*
echo.
echo == 3/3 Processando tudo com o GFS ==
".venv\Scripts\python.exe" coletar.py processar
echo.
echo Fim. O resumo esta em dados\processados\relatorio_coleta.md
pause
