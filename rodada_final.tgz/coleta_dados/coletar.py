#!/usr/bin/env python3
"""Coleta dos dados do artigo CCP-Boot-TFT-ICSO-PP.

Uso (na pasta deste arquivo):
    python coletar.py verificar                 # testa o acesso a todas as fontes (1-2 min)
    python coletar.py baixar --aceito-termos-dkasc          # potência de todos os sites do config.yaml
    python coletar.py baixar --fontes gfs       # GFS: demorado (1-2 dias), pode interromper e retomar
    python coletar.py processar                 # gera dados/processados/<SITE>/...
    python coletar.py status                    # o que já foi baixado
    python coletar.py tudo --aceito-termos-dkasc
    python coletar.py gdex                      # GFS dos pedidos de subset prontos no GDEX (token)
    python coletar.py importar-gfs PASTA        # GFS de arquivos de subset já baixados

Fontes de potência (campo 'fonte' de cada site no config.yaml): dkasc (YUL), ons (BRA) e pvdaq (GEO);
ukpv e hkg servem ao conjunto antigo de 5 sites (config_5sites.yaml) e nist e utrecht ao do artigo 1
(config_artigo1.yaml). A fonte 'gfs' serve a todos os sites.
"""

from __future__ import annotations

import argparse
import logging
import sys
import time

from coleta import __version__
from coleta import gfs as gfs_mod
from coleta.fontes import dkasc
from coleta.processamento import FONTES, escrever_relatorio, processar_site
from coleta.util import carregar_config, configurar_log, pastas

log = logging.getLogger("coleta")


def aplicar_coordenadas(cfg, P) -> None:
    """Sites cujo ponto é definido pelos dados (ex.: subestação coletora do BRA) gravam
    brutos/<SITE>/coordenadas.json; o GFS e o processamento usam esse ponto."""
    import json

    for cod, s in cfg["sites"].items():
        arq = P.brutos / cod / "coordenadas.json"
        if arq.exists():
            try:
                c = json.loads(arq.read_text(encoding="utf-8"))
                if c.get("id_ons") and str(c["id_ons"]) != str(s.get("id_ons", "")).strip():
                    log.info("%s: %s é de outra usina (%s); vale o ponto do config.yaml", cod, arq.name, c["id_ons"])
                    continue
                if (round(s["lat"], 4), round(s["lon"], 4)) != (round(c["lat"], 4), round(c["lon"], 4)):
                    log.info("%s: ponto do site = (%.4f, %.4f), de %s", cod, c["lat"], c["lon"], arq.name)
                s["lat"], s["lon"] = float(c["lat"]), float(c["lon"])
            except Exception as e:  # noqa: BLE001
                log.warning("%s: não consegui ler %s: %s", cod, arq, e)


def _sites(cfg, codigos):
    todos = cfg["sites"]
    codigos = codigos or list(todos)
    faltam = [c for c in codigos if c not in todos]
    if faltam:
        sys.exit(f"site(s) desconhecido(s): {faltam}; use {list(todos)}")
    return [todos[c] for c in codigos]


def _confirmar_termos_dkasc(args) -> bool:
    if args.aceito_termos_dkasc:
        return True
    print("\n" + dkasc.TERMOS + "\n")
    try:
        r = input("Você leu e aceita os termos do DKASC? [s/N] ").strip().lower()
    except EOFError:
        r = ""
    return r in ("s", "sim", "y", "yes")


def cmd_baixar(cfg, P, args):
    sites_sel = _sites(cfg, args.sites)
    fontes = args.fontes or sorted({s["fonte"] for s in sites_sel}) + ["gfs"]
    erros = []
    for s in sites_sel:
        f, cod = s["fonte"], s["codigo"]
        if f not in fontes:
            continue
        log.info("== Baixando %s (%s) ==", f.upper(), cod)
        try:
            if f == "dkasc":
                ok = _confirmar_termos_dkasc(args)
                if not ok:
                    log.warning("  DKASC pulado: termos não aceitos")
                    continue
                FONTES[f].baixar(s, cfg, P, aceito_termos=True)
            elif f == "ons":
                FONTES[f].baixar(s, cfg, P, fator_capacidade=args.ons_fator_capacidade)
            else:
                FONTES[f].baixar(s, cfg, P)
        except Exception as e:  # noqa: BLE001
            log.exception("  falha em %s (%s): %s", f, cod, e)
            erros.append(cod)
    if "gfs" in fontes:
        log.info("== Baixando GFS 0,25° (NCAR GDEX d084001) ==")
        try:
            gfs_mod.baixar(cfg, P, _sites(cfg, args.sites), inicio=args.gfs_inicio, fim=args.gfs_fim,
                           trabalhadores=args.trabalhadores, refazer_falhas=args.refazer_falhas,
                           apenas_estimar=args.estimar)
        except KeyboardInterrupt:
            raise
        except Exception as e:  # noqa: BLE001
            log.error("  falha no GFS: %s", e)
            erros.append("gfs")
    if erros:
        log.error("Terminou com falhas em: %s (veja dados/logs/coleta.log)", ", ".join(erros))
        return 1
    log.info("Downloads concluídos.")
    return 0


def cmd_processar(cfg, P, args):
    resumos = []
    erros = []
    for s in _sites(cfg, args.sites):
        try:
            resumos.append(processar_site(s, cfg, P, com_gfs=not args.sem_gfs))
        except Exception as e:  # noqa: BLE001
            log.exception("  falha ao processar %s: %s", s["codigo"], e)
            erros.append(s["codigo"])
    # junta com resumos anteriores de sites não processados agora
    import json
    feitos = {r["site"] for r in resumos}
    for cod in cfg["sites"]:
        arq = P.processados / cod / "resumo.json"
        if cod not in feitos and arq.exists():
            resumos.append(json.loads(arq.read_text(encoding="utf-8")))
    ordem = list(cfg["sites"])
    resumos.sort(key=lambda r: ordem.index(r["site"]))
    escrever_relatorio(resumos, P)
    if not args.sem_gfs:
        try:
            from coleta.grupos import tamanhos
            tamanhos(cfg, P)
        except Exception as e:  # noqa: BLE001
            log.warning("  não consegui calcular os tamanhos dos grupos: %s", e)
    return 1 if erros else 0


def cmd_gdex(cfg, P, args):
    from coleta import gfs_subset

    try:
        gfs_subset.importar(cfg, P, _sites(cfg, args.sites), origem=None, trabalhadores=args.trabalhadores or 8,
                            pedidos=args.pedidos)
    except RuntimeError as e:
        log.error("  %s", e)
        return 1
    gfs_mod.baixar(cfg, P, _sites(cfg, args.sites), apenas_estimar=True)
    return 0


def cmd_importar_gfs(cfg, P, args):
    from pathlib import Path

    from coleta import gfs_subset

    origem = Path(args.origem)
    if not origem.exists():
        log.error("  %s não existe", origem)
        return 1
    gfs_subset.importar(cfg, P, _sites(cfg, args.sites), origem=origem)
    gfs_mod.baixar(cfg, P, _sites(cfg, args.sites), apenas_estimar=True)
    return 0


def cmd_status(cfg, P, args):
    print(f"Pasta de dados: {P.raiz}")
    for s in _sites(cfg, args.sites):
        cod = s["codigo"]
        pasta = P.bruto(cod)
        arqs = [a for a in sorted(pasta.iterdir()) if a.is_file()]
        tam = sum(a.stat().st_size for a in arqs) / 1e6
        print(f"\n{cod} ({s['fonte']}): {len(arqs)} arquivo(s) brutos, {tam:.0f} MB")
        for a in arqs:
            print(f"   {a.name:55s} {a.stat().st_size / 1e6:10.1f} MB")
        plano = gfs_mod.planejar([s], cfg["gfs"])
        cob = gfs_mod.cobertura(P.gfs(cod), s["lat"], s["lon"])
        print(f"   GFS: {cob['dias']} de {len(plano)} dias gravados; arquivos ok {cob.get('ok', 0)}, "
              f"ausentes {cob.get('ausentes_no_arquivo', 0)}, falhas {cob.get('falhas', 0)}")
        proc = P.processados / cod
        if (proc / "potencia_horaria.parquet").exists():
            print(f"   processado: {', '.join(sorted(p.name for p in proc.iterdir()))}")
    return 0


def cmd_verificar(cfg, P, args):
    """Testa o acesso a cada fonte usada no config.yaml (alguns segundos cada)."""
    import numpy as np
    import pandas as pd

    from coleta.util import nova_sessao

    sess = nova_sessao()
    resultados = []

    def teste(nome, fn):
        t0 = time.time()
        try:
            info = fn()
            resultados.append((nome, "OK", f"{time.time() - t0:.1f} s", info))
        except Exception as e:  # noqa: BLE001
            resultados.append((nome, "FALHOU", f"{time.time() - t0:.1f} s", str(e)[:300]))

    vistos = set()
    for s in _sites(cfg, args.sites):
        mod = FONTES[s["fonte"]]
        chave = (s["fonte"], s.get("id_ons"), s.get("system_id"))
        if chave in vistos or not hasattr(mod, "verificar"):
            continue
        vistos.add(chave)
        teste(f"{s['fonte']} ({s['codigo']})", lambda m=mod, st=s: m.verificar(st, cfg, sess))

    def t_gfs():
        s = _sites(cfg, args.sites)[0]
        cx = gfs_mod.caixa(s["lat"], s["lon"])
        c = pd.Timestamp("2023-03-10 12:00", tz="UTC")
        url = gfs_mod.url_arquivo(cfg["gfs"]["servidor_ncss"].rstrip("/"), c, 15)
        params = [("var", n) for n in gfs_mod.nomes_variaveis(15)] + [
            ("north", f"{cx['north']:.3f}"), ("south", f"{cx['south']:.3f}"),
            ("west", f"{cx['west']:.3f}"), ("east", f"{cx['east']:.3f}"), ("accept", "netcdf3")]
        r = sess.get(url, params=params, timeout=90)
        if r.status_code >= 500:
            raise IOError(f"HTTP {r.status_code}: servidor THREDDS do NCAR fora do ar no momento "
                          "(a coleta do GFS espera ele voltar sozinha)")
        r.raise_for_status()
        d, t0, t1 = gfs_mod.ler_nc(r.content, cx, c)
        return f"caixa 4x4 ok, T2m média {np.nanmean(d[2]) - 273.15:.1f} °C, janela de média [{t0:.0f}, {t1:.0f}] h"

    log.info("Testando o acesso às fontes...")
    teste("NCAR GDEX THREDDS (GFS)", t_gfs)
    for nome, st, dt, info in resultados:
        (log.info if st == "OK" else log.warning)("  [%s] %s (%s): %s", st, nome, dt, info)
    return 0 if all(r[1] == "OK" for r in resultados) else 1


def _preparar_console_windows():
    """No Windows: impede a suspensão automática enquanto a coleta roda e desliga o 'modo de
    edição rápida' do console (um clique na janela pausaria o programa até apertar Enter).
    Vale só para este processo/janela; nada é alterado nas configurações do sistema."""
    if sys.platform != "win32":
        return
    try:
        import ctypes

        k32 = ctypes.windll.kernel32
        k32.SetThreadExecutionState(0x80000000 | 0x00000001)  # ES_CONTINUOUS | ES_SYSTEM_REQUIRED
        h = k32.GetStdHandle(-10)  # STD_INPUT_HANDLE
        modo = ctypes.c_uint32()
        if k32.GetConsoleMode(h, ctypes.byref(modo)):
            k32.SetConsoleMode(h, (modo.value | 0x0080) & ~0x0040)  # EXTENDED_FLAGS, sem QUICK_EDIT
        log.info("Windows: suspensão automática bloqueada enquanto a coleta roda")
    except Exception as e:  # noqa: BLE001
        log.debug("não consegui ajustar o console: %s", e)


def cmd_tudo(cfg, P, args):
    rc = 0
    if args.sem_dkasc:
        fora = [c for c, s in cfg["sites"].items() if s["fonte"] == "dkasc"]
        args.sites = [c for c in (args.sites or list(cfg["sites"])) if c not in fora]
        log.info("%s (DKASC) fora desta execução (--sem-dkasc)", ", ".join(fora) or "nenhum site")
    args.fontes = sorted({s["fonte"] for s in _sites(cfg, args.sites)})
    rc |= cmd_baixar(cfg, P, args)
    aplicar_coordenadas(cfg, P)
    args.sem_gfs = True
    rc |= cmd_processar(cfg, P, args)
    if args.so_potencia:
        log.info("Séries de potência prontas (--so-potencia: o GFS fica para o rodar_gfs.bat).")
        return rc
    log.info("Séries de potência prontas. Começando o GFS (etapa longa; pode interromper com Ctrl+C e retomar).")
    args.fontes = ["gfs"]
    rc |= cmd_baixar(cfg, P, args)
    args.sem_gfs = False
    rc |= cmd_processar(cfg, P, args)
    return rc


def main(argv=None):
    p = argparse.ArgumentParser(description="Coleta de dados do artigo CCP-Boot-TFT-ICSO-PP")
    p.add_argument("--config", default=None, help="caminho do config.yaml")
    p.add_argument("-v", "--verboso", action="store_true")
    sub = p.add_subparsers(dest="cmd", required=True)

    def comuns(sp):
        sp.add_argument("--sites", nargs="+", help="códigos do config.yaml, ex.: YUL BRA (padrão: todos)")

    sp = sub.add_parser("verificar", help="testa o acesso às fontes")
    sp = sub.add_parser("baixar", help="baixa os dados brutos")
    comuns(sp)
    sp.add_argument("--fontes", nargs="+", choices=sorted(FONTES) + ["gfs"])
    sp.add_argument("--aceito-termos-dkasc", action="store_true")
    sp.add_argument("--ons-fator-capacidade", action="store_true",
                    help="também filtra o dataset 'Fator de Capacidade' do ONS (~1,2 GB em fluxo)")
    sp.add_argument("--gfs-inicio", help="AAAA-MM-DD (só para testes)")
    sp.add_argument("--gfs-fim", help="AAAA-MM-DD (só para testes)")
    sp.add_argument("--trabalhadores", type=int, help="pedidos simultâneos ao servidor do GFS (padrão 8)")
    sp.add_argument("--refazer-falhas", action="store_true", help="refaz dias do GFS com pedidos que falharam")
    sp.add_argument("--estimar", action="store_true", help="só mostra quantos pedidos do GFS faltam")
    sp = sub.add_parser("processar", help="gera as séries horárias, o QC e o relatório")
    comuns(sp)
    sp.add_argument("--sem-gfs", action="store_true")
    sp = sub.add_parser("status", help="mostra o que já foi baixado")
    comuns(sp)
    sp = sub.add_parser("gdex", help="baixa e importa o GFS dos pedidos de subset prontos no GDEX")
    comuns(sp)
    sp.add_argument("--pedidos", nargs="+", help="só estes pedidos (números do GDEX)")
    sp.add_argument("--trabalhadores", type=int, help="downloads simultâneos (padrão 8)")
    sp = sub.add_parser("importar-gfs", help="importa o GFS de arquivos de subset já baixados")
    comuns(sp)
    sp.add_argument("origem", help="pasta ou arquivo (.nc, .tar, .zip)")
    sp = sub.add_parser("tudo", help="baixa tudo e processa (potência primeiro, GFS depois)")
    comuns(sp)
    sp.add_argument("--aceito-termos-dkasc", action="store_true")
    sp.add_argument("--sem-dkasc", action="store_true", help="não baixa nem processa os sites do DKASC")
    sp.add_argument("--so-potencia", action="store_true", help="baixa e processa só a potência (sem GFS)")
    sp.add_argument("--trabalhadores", type=int)
    a = p.parse_args(argv)
    for k, v in {"sites": None, "ons_fator_capacidade": False, "gfs_inicio": None, "gfs_fim": None,
                 "trabalhadores": None, "refazer_falhas": False, "estimar": False, "sem_gfs": False,
                 "aceito_termos_dkasc": False, "fontes": None, "sem_dkasc": False, "so_potencia": False}.items():
        if not hasattr(a, k):
            setattr(a, k, v)

    cfg = carregar_config(a.config)
    P = pastas(cfg)
    configurar_log(P.logs, a.verboso)
    log.info("coleta v%s | dados em %s | sites: %s", __version__, P.raiz, ", ".join(cfg["sites"]))
    aplicar_coordenadas(cfg, P)
    if a.cmd in ("baixar", "tudo", "gdex", "importar-gfs"):
        _preparar_console_windows()
    cmds = {"baixar": cmd_baixar, "processar": cmd_processar, "status": cmd_status,
            "verificar": cmd_verificar, "tudo": cmd_tudo, "gdex": cmd_gdex, "importar-gfs": cmd_importar_gfs}
    try:
        return cmds[a.cmd](cfg, P, a)
    except KeyboardInterrupt:
        log.warning("Interrompido. Rode o mesmo comando de novo para continuar de onde parou.")
        return 130


if __name__ == "__main__":
    sys.exit(main())
