@echo off
REM Coleta do YUL 2017-2020 (Desert Gardens antes do corte de potencia), no Windows:
REM   1) baixa a potencia do DKASC de Yulara 2017-2020 (aceite dos termos do DKASC, como na coleta anterior)
REM   2) confere corte de potencia e canais trocados (verificar_yul.py); se der ATENCAO, para aqui
REM   3) processa a potencia do YUL
REM   4) baixa o GFS do YUL (~108 mil pedidos, ~17 h; pode fechar e rodar de novo para retomar)
REM   5) processa o YUL com o GFS
REM Use depois que o rodar_coleta.bat ja tiver criado o ambiente .venv. So pode haver uma janela da coleta aberta.
setlocal EnableExtensions
cd /d "%~dp0"
title Coleta do YUL 2017-2020
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
if not exist ".venv\Scripts\python.exe" (
  echo Ambiente .venv nao encontrado. Rode primeiro o rodar_coleta.bat
  pause
  exit /b 1
)
echo == 1/5 Potencia do DKASC (Yulara 2017-2020) ==
".venv\Scripts\python.exe" coletar.py baixar --sites YUL --fontes dkasc --aceito-termos-dkasc
if errorlevel 1 goto erro
echo.
echo == 2/5 Conferindo o Desert Gardens (corte de potencia e canais) ==
".venv\Scripts\python.exe" verificar_yul.py
if errorlevel 1 goto atencao
echo.
echo == 3/5 Processando a potencia do YUL ==
".venv\Scripts\python.exe" coletar.py processar --sites YUL --sem-gfs
if errorlevel 1 goto erro
echo.
echo == 4/5 GFS do YUL (longo; pode fechar e rodar de novo para retomar) ==
".venv\Scripts\python.exe" coletar.py baixar --sites YUL --fontes gfs --trabalhadores 32 --refazer-falhas
if errorlevel 1 goto erro
echo.
echo == 5/5 Processando o YUL com o GFS ==
".venv\Scripts\python.exe" coletar.py processar --sites YUL
if errorlevel 1 goto erro
echo.
echo Fim. Confira dados\processados\relatorio_coleta.md e a pasta dados\processados\YUL
pause
exit /b 0
:atencao
echo.
echo O Desert Gardens mostrou corte de potencia ou canal trocado (tabela acima). NAO processe o YUL:
echo mande a tabela para analise. GEO e BRA seguem normalmente.
pause
exit /b 1
:erro
echo.
echo Algo falhou (detalhes em dados\logs\coleta.log). Rode de novo: o que ja foi baixado fica salvo.
pause
exit /b 1
