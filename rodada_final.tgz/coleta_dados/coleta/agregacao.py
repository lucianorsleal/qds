"""Agregação de séries sub-horárias em médias horárias e montagem de portfólios."""

from __future__ import annotations

import pandas as pd


def hora_de_inicio(t_utc: pd.DatetimeIndex, rotulo: str, passo: pd.Timedelta,
                   fuso_lst: str = "UTC") -> pd.DatetimeIndex:
    """Hora de relógio local [t, t+1h) a que pertence cada amostra (devolvida em UTC).

    rotulo='fim'   : amostra em t representa [t-passo, t)  -> hora = floor(t - passo)
    rotulo='inicio': amostra em t representa [t, t+passo)  -> hora = floor(t)
    O arredondamento é feito na hora padrão local, o que importa em fusos com meia hora
    (Alice Springs, UTC+09:30): lá as horas locais começam em hh:30 UTC.
    """
    t_utc = pd.DatetimeIndex(t_utc)
    if rotulo == "fim":
        t = t_utc - passo
    elif rotulo == "inicio":
        t = t_utc
    else:
        raise ValueError(f"rotulo_intervalo inválido: {rotulo!r} (use 'inicio' ou 'fim')")
    return t.tz_convert(fuso_lst).floor("h").tz_convert("UTC")


def fracao_fuso_h(fuso_lst: str) -> float:
    """Parte fracionária do deslocamento do fuso local em horas (0,5 para UTC+09:30)."""
    off = pd.Timestamp("2020-01-01", tz=fuso_lst).utcoffset().total_seconds() / 3600.0
    return off % 1.0


class AcumuladorHorario:
    """Acumula somas e contagens horárias por coluna, em blocos (para arquivos grandes)."""

    def __init__(self):
        self.soma = None
        self.cont = None

    def adicionar(self, dados: pd.DataFrame, horas: pd.DatetimeIndex) -> None:
        dados = dados.astype("float64")
        g = dados.groupby(horas)
        s = g.sum(min_count=1)
        c = g.count()
        if self.soma is None:
            self.soma, self.cont = s, c
        else:
            self.soma = self.soma.add(s, fill_value=0)
            self.cont = self.cont.add(c, fill_value=0)

    def resultado(self, amostras_por_hora: float):
        """(media, disponibilidade) por hora e coluna."""
        if self.soma is None:
            return pd.DataFrame(), pd.DataFrame()
        soma = self.soma.sort_index()
        cont = self.cont.reindex_like(soma).fillna(0)
        media = soma / cont.where(cont > 0)
        disp = (cont / amostras_por_hora).clip(upper=1.0)
        return media, disp


def mascarar_unidades_paradas(media: pd.DataFrame, disp: pd.DataFrame, capacidade: pd.Series,
                              y_mediana_min: float = 0.2, y_unidade_max: float = 0.02):
    """Marca como faltante a hora em que uma unidade está parada (inversor desligado) enquanto
    as demais produzem: y_i <= y_unidade_max com mediana dos y_j >= y_mediana_min.
    Zeros de falha não aparecem como 'faltante' nos arquivos, por isso este filtro."""
    cols = [c for c in media.columns if c in capacidade.index and capacidade[c] > 0]
    if len(cols) < 3:
        return media, disp, pd.Series(0, index=media.columns)
    y = media[cols].div(capacidade[cols].astype(float), axis=1)
    med = y.median(axis=1, skipna=True)
    parada = y.le(y_unidade_max) & med.ge(y_mediana_min).to_numpy()[:, None]
    media = media.copy()
    disp = disp.copy()
    media[cols] = media[cols].mask(parada)
    disp[cols] = disp[cols].mask(parada, 0.0)
    return media, disp, parada.sum().reindex(media.columns, fill_value=0)


def disponibilidade_diurna(disp: pd.DataFrame, diurno: pd.Series) -> pd.Series:
    """Fração de amostras válidas nas horas diurnas, por coluna (0..1)."""
    d = disp.reindex(diurno.index)
    d = d[diurno.to_numpy()]
    return d.fillna(0).mean()


def portfolio(media: pd.DataFrame, disp: pd.DataFrame, capacidade: pd.Series,
              disp_min_hora: float, frac_cap_min: float) -> pd.DataFrame:
    """Potência normalizada de um conjunto de unidades ponderada pela capacidade disponível.

    y(t) = sum_{i disponível} P_i(t) / sum_{i disponível} C_i
    Uma hora é válida se a capacidade disponível for >= frac_cap_min da capacidade total.
    """
    cols = [c for c in capacidade.index if c in media.columns]
    media = media[cols]
    disp = disp[cols].reindex(media.index).fillna(0)
    cap = capacidade[cols].astype(float)
    ok = (disp >= disp_min_hora) & media.notna()
    p = media.where(ok, 0.0).sum(axis=1)
    c_ok = ok.mul(cap, axis=1).sum(axis=1)
    frac = c_ok / cap.sum()
    y = (p / c_ok.where(c_ok > 0)).where(frac >= frac_cap_min)
    return pd.DataFrame({"y": y, "frac_capacidade": frac, "n_unidades": ok.sum(axis=1)})
