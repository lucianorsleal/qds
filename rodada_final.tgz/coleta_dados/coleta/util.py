"""Funções comuns: configuração, caminhos, log e download com retomada."""

from __future__ import annotations

import hashlib
import logging
import os
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import requests
import yaml

RAIZ = Path(__file__).resolve().parent.parent
USER_AGENT = "Mozilla/5.0 (coleta-dados-ccp-boot-tft; pesquisa academica)"

log = logging.getLogger("coleta")


# ---------------------------------------------------------------------------
# Configuração e caminhos
# ---------------------------------------------------------------------------
def carregar_config(caminho: Optional[Path] = None) -> dict:
    caminho = Path(caminho) if caminho else RAIZ / "config.yaml"
    with open(caminho, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    pasta = Path(cfg.get("pasta_dados", "dados"))
    if not pasta.is_absolute():
        pasta = RAIZ / pasta
    cfg["_pasta_dados"] = pasta
    for nome, s in cfg["sites"].items():
        s["codigo"] = nome
    return cfg


@dataclass
class Pastas:
    raiz: Path

    @property
    def brutos(self) -> Path:
        return self.raiz / "brutos"

    @property
    def processados(self) -> Path:
        return self.raiz / "processados"

    @property
    def logs(self) -> Path:
        return self.raiz / "logs"

    def bruto(self, site: str) -> Path:
        p = self.brutos / site
        p.mkdir(parents=True, exist_ok=True)
        return p

    def gfs(self, site: str) -> Path:
        p = self.brutos / "gfs" / site
        p.mkdir(parents=True, exist_ok=True)
        return p

    def processado(self, site: str) -> Path:
        p = self.processados / site
        p.mkdir(parents=True, exist_ok=True)
        return p


def pastas(cfg: dict) -> Pastas:
    p = Pastas(cfg["_pasta_dados"])
    for d in (p.brutos, p.processados, p.logs):
        d.mkdir(parents=True, exist_ok=True)
    return p


def configurar_log(pasta_logs: Path, verboso: bool = False) -> None:
    pasta_logs.mkdir(parents=True, exist_ok=True)
    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", "%Y-%m-%d %H:%M:%S")
    raiz = logging.getLogger("coleta")
    raiz.setLevel(logging.DEBUG)
    if raiz.handlers:
        return
    console = logging.StreamHandler(sys.stdout)
    console.setLevel(logging.DEBUG if verboso else logging.INFO)
    console.setFormatter(fmt)
    arquivo = logging.FileHandler(pasta_logs / "coleta.log", encoding="utf-8")
    arquivo.setLevel(logging.DEBUG)
    arquivo.setFormatter(fmt)
    raiz.addHandler(console)
    raiz.addHandler(arquivo)


# ---------------------------------------------------------------------------
# Download com retomada (HTTP Range), verificação de tamanho e MD5
# ---------------------------------------------------------------------------
def nova_sessao() -> requests.Session:
    s = requests.Session()
    s.headers.update({"User-Agent": USER_AGENT})
    return s


def md5_arquivo(caminho: Path, bloco: int = 8 << 20) -> str:
    h = hashlib.md5()
    with open(caminho, "rb") as f:
        while True:
            b = f.read(bloco)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def _fmt_bytes(n: float) -> str:
    for u in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1024:
            return f"{n:.1f} {u}"
        n /= 1024
    return f"{n:.1f} PB"


def baixar_arquivo(
    url: str,
    destino: Path,
    tamanho_esperado: Optional[int] = None,
    md5: Optional[str] = None,
    sessao: Optional[requests.Session] = None,
    tentativas: int = 6,
    timeout: int = 60,
    descricao: Optional[str] = None,
) -> Path:
    """Baixa `url` para `destino` com retomada. Pula se o arquivo já está completo."""
    destino = Path(destino)
    destino.parent.mkdir(parents=True, exist_ok=True)
    nome = descricao or destino.name
    if destino.exists():
        ok_tamanho = tamanho_esperado is None or destino.stat().st_size == tamanho_esperado
        if ok_tamanho and (md5 is None or md5_arquivo(destino) == md5):
            log.info("  já existe: %s (%s)", nome, _fmt_bytes(destino.stat().st_size))
            return destino
        log.warning("  arquivo existente incompleto ou corrompido, baixando de novo: %s", nome)
        destino.unlink()

    parcial = destino.with_name(destino.name + ".part")
    sessao = sessao or nova_sessao()
    espera = 5
    for tentativa in range(1, tentativas + 1):
        try:
            ja = parcial.stat().st_size if parcial.exists() else 0
            headers = {"Range": f"bytes={ja}-"} if ja else {}
            with sessao.get(url, headers=headers, stream=True, timeout=timeout) as r:
                if r.status_code == 416 and ja:  # já completo
                    break
                if r.status_code not in (200, 206):
                    r.raise_for_status()
                    raise IOError(f"HTTP {r.status_code}")
                if ja and r.status_code == 200:  # servidor ignorou o Range
                    ja = 0
                    modo = "wb"
                else:
                    modo = "ab" if ja else "wb"
                total = r.headers.get("Content-Length")
                total = int(total) + ja if total is not None else tamanho_esperado
                baixado = ja
                t0 = time.time()
                ultimo = 0.0
                with open(parcial, modo) as f:
                    for bloco in r.iter_content(chunk_size=1 << 20):
                        if not bloco:
                            continue
                        f.write(bloco)
                        baixado += len(bloco)
                        agora = time.time()
                        if agora - ultimo > 10:
                            ultimo = agora
                            vel = (baixado - ja) / max(agora - t0, 1e-6)
                            pct = f"{100 * baixado / total:.1f}%" if total else "?"
                            log.info("  %s: %s de %s (%s, %s/s)", nome, _fmt_bytes(baixado),
                                     _fmt_bytes(total) if total else "?", pct, _fmt_bytes(vel))
            if tamanho_esperado is not None and parcial.stat().st_size < tamanho_esperado:
                raise IOError(
                    f"download interrompido ({parcial.stat().st_size} de {tamanho_esperado} bytes)")
            break
        except Exception as e:  # noqa: BLE001
            if tentativa == tentativas:
                raise
            log.warning("  falha ao baixar %s (tentativa %d/%d): %s; nova tentativa em %ds",
                        nome, tentativa, tentativas, e, espera)
            time.sleep(espera)
            espera = min(espera * 2, 120)

    if tamanho_esperado is not None and parcial.stat().st_size != tamanho_esperado:
        raise IOError(f"tamanho inesperado para {nome}: {parcial.stat().st_size} != {tamanho_esperado}")
    if md5 is not None:
        calc = md5_arquivo(parcial)
        if calc != md5:
            parcial.unlink()
            raise IOError(f"MD5 não confere para {nome}: {calc} != {md5}")
    os.replace(parcial, destino)
    log.info("  ok: %s (%s)", nome, _fmt_bytes(destino.stat().st_size))
    return destino


def tamanho_remoto(url: str, sessao: Optional[requests.Session] = None, timeout: int = 30) -> Optional[int]:
    sessao = sessao or nova_sessao()
    try:
        r = sessao.head(url, allow_redirects=True, timeout=timeout)
        if r.status_code == 200 and r.headers.get("Content-Length"):
            return int(r.headers["Content-Length"])
    except Exception:  # noqa: BLE001
        pass
    return None
