"""GFS 0,25° arquivado (NCAR GDEX d084001 = RDA ds084.1), via THREDDS NetCDF Subset Service.

Para cada ciclo (00/06/12/18 UTC) e hora de previsão (f003..f048 sempre; f051..f072 só na
janela de calibração+teste, usada no teste de estresse S3), pede ao servidor apenas uma
caixa 4x4 de pontos de grade em volta do site (~8 KB por pedido) com seis variáveis:
    DSWRF médio na superfície (W/m²), nebulosidade total média (%), T2m (K), UR2m (%), u10 e v10 (m/s).
Os brutos ficam em dados/brutos/gfs/<SITE>/<AAAA>/<AAAAMMDD>.npz (um arquivo por dia de ciclo),
o que permite retomar a coleta e reinterpolar para outro ponto sem baixar de novo.

O processamento converte as médias do GFS (janelas 0-3 h / 0-6 h que reiniciam a cada 6 h)
em médias de 3 h, interpola para horas cheias e grava dados/processados/<SITE>/gfs_horario.parquet.
"""

from __future__ import annotations

import io
import logging
import math
import os
import re
import threading
import time
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
import requests

from .util import USER_AGENT

log = logging.getLogger("coleta")

VARS = ["dswrf", "tcc", "t2m", "rh2m", "u10", "v10"]
_PADROES = {
    "dswrf": re.compile(r"^Downward_Short-Wave_Radiation_Flux_surface_(\d+)_Hour_Average$"),
    "tcc": re.compile(r"^Total_cloud_cover_entire_atmosphere_(\d+)_Hour_Average$"),
    "t2m": re.compile(r"^Temperature_height_above_ground$"),
    "rh2m": re.compile(r"^Relative_humidity_height_above_ground$"),
    "u10": re.compile(r"^u-component_of_wind_height_above_ground$"),
    "v10": re.compile(r"^v-component_of_wind_height_above_ground$"),
}
_NIVEL = {"t2m": 2.0, "rh2m": 2.0, "u10": 10.0, "v10": 10.0}
ST_OK, ST_AUSENTE, ST_ERRO = 1, 0, -1


def nomes_variaveis(fh: int) -> list:
    suf = "3_Hour_Average" if fh % 6 == 3 else "6_Hour_Average"
    return [f"Downward_Short-Wave_Radiation_Flux_surface_{suf}",
            f"Total_cloud_cover_entire_atmosphere_{suf}",
            "Temperature_height_above_ground", "Relative_humidity_height_above_ground",
            "u-component_of_wind_height_above_ground", "v-component_of_wind_height_above_ground"]


# ---------------------------------------------------------------------------
# Planejamento
# ---------------------------------------------------------------------------
def caixa(lat: float, lon: float) -> dict:
    """Caixa 4x4 de pontos da grade 0,25° em volta do ponto (lon em -180..180).
    lats em ordem decrescente (como o GFS), lons crescentes."""
    la0 = math.floor(lat / 0.25) * 0.25
    lo0 = math.floor(lon / 0.25) * 0.25
    lats = np.array([la0 + 0.5, la0 + 0.25, la0, la0 - 0.25])
    lons = np.array([lo0 - 0.25, lo0, lo0 + 0.25, lo0 + 0.5])
    return {"lats": lats, "lons": lons, "north": lats[0] + 0.01, "south": lats[-1] - 0.01,
            "west": lons[0] - 0.01, "east": lons[-1] + 0.01}


def _faixa(a) -> list:
    ini, fim, passo = (int(x) for x in a)
    return list(range(ini, fim + 1, passo))


def janela_estresse(site: dict, cfg_gfs: dict) -> pd.Timestamp:
    from .particoes import inicio_teste
    t = inicio_teste(site).tz_localize(site["fuso_lst"]).tz_convert("UTC")
    return t - pd.Timedelta(weeks=int(cfg_gfs.get("semanas_antes_teste_estresse", 14)))


def _utc(x) -> pd.Timestamp:
    t = pd.Timestamp(x)
    return t.tz_localize("UTC") if t.tzinfo is None else t.tz_convert("UTC")


def ciclos_site(site: dict, cfg_gfs: dict, inicio=None, fim=None) -> pd.DatetimeIndex:
    ini = pd.Timestamp(site["inicio"]).tz_localize(site["fuso_lst"]).tz_convert("UTC") - pd.Timedelta(days=2)
    fi = (pd.Timestamp(site["fim"]) + pd.Timedelta(days=1)).tz_localize(site["fuso_lst"]).tz_convert("UTC")
    ini = max(ini.floor("D"), _utc(cfg_gfs["inicio_arquivo"]))
    if inicio is not None:
        ini = max(ini, _utc(inicio))
    if fim is not None:
        fi = min(fi, _utc(fim) + pd.Timedelta(days=1))
    horas = [int(h) for h in cfg_gfs.get("ciclos", [0, 6, 12, 18])]
    dias = pd.date_range(ini.floor("D"), fi.floor("D"), freq="D")
    c = [d + pd.Timedelta(hours=h) for d in dias for h in horas]
    return pd.DatetimeIndex([x for x in c if ini <= x < fi])


def horas_previsao(site: dict, cfg_gfs: dict, ciclo: pd.Timestamp) -> list:
    base = _faixa(cfg_gfs["horas_previsao_base"])
    if ciclo >= janela_estresse(site, cfg_gfs):
        base = base + _faixa(cfg_gfs["horas_previsao_estresse"])
    return base


def planejar(sites: list, cfg_gfs: dict, inicio=None, fim=None) -> dict:
    """{dia AAAAMMDD: {(ciclo, fh): [códigos de site]}}"""
    plano: dict = {}
    for s in sites:
        for c in ciclos_site(s, cfg_gfs, inicio, fim):
            dia = c.strftime("%Y%m%d")
            for fh in horas_previsao(s, cfg_gfs, c):
                plano.setdefault(dia, {}).setdefault((c, fh), []).append(s["codigo"])
    return dict(sorted(plano.items()))


def arquivo_dia(pasta_site: Path, dia: str) -> Path:
    return pasta_site / dia[:4] / f"{dia}.npz"


# ---------------------------------------------------------------------------
# Pedido NCSS e leitura do NetCDF
# ---------------------------------------------------------------------------
_local = threading.local()


def _sessao() -> requests.Session:
    if not hasattr(_local, "s"):
        s = requests.Session()
        s.headers.update({"User-Agent": USER_AGENT})
        ad = requests.adapters.HTTPAdapter(pool_connections=2, pool_maxsize=2)
        s.mount("https://", ad)
        _local.s = s
    return _local.s


def url_arquivo(servidor: str, ciclo: pd.Timestamp, fh: int) -> str:
    return f"{servidor}/{ciclo:%Y}/{ciclo:%Y%m%d}/gfs.0p25.{ciclo:%Y%m%d%H}.f{fh:03d}.grib2"


_nomes_alternativos: dict = {}
_trava_nomes = threading.Lock()


def _descobrir_nomes(url: str, timeout: int) -> list:
    """Se os nomes padrão falharem, lê o dataset.xml do arquivo e escolhe as variáveis."""
    r = _sessao().get(url + "/dataset.xml", timeout=timeout)
    r.raise_for_status()
    nomes = re.findall(r'<grid name="([^"]+)"', r.text)
    escolhidos = []
    for v in VARS:
        cand = [n for n in nomes if _PADROES[v].match(n)]
        if not cand:
            raise KeyError(f"variável {v} não encontrada em {url}")
        if v in ("dswrf", "tcc"):
            cand.sort(key=lambda n: int(_PADROES[v].match(n).group(1)))
        escolhidos.append(cand[0])
    return escolhidos


def _txt(x) -> str:
    return x.decode() if isinstance(x, bytes) else str(x)


def ler_nc(conteudo: bytes, cx: dict, ciclo: pd.Timestamp):
    """Extrai a caixa 4x4 das seis variáveis e os limites (h) da janela de média do DSWRF."""
    from scipy.io import netcdf_file

    with netcdf_file(io.BytesIO(conteudo), "r", mmap=False) as nc:
        V = nc.variables
        lat = np.asarray(V["latitude"].data, dtype=float)
        lon = np.asarray(V["longitude"].data, dtype=float) % 360.0

        def achar(alvo, grade):
            dif = np.abs(grade - alvo)
            return int(np.argmin(dif)) if dif.min() < 0.01 else -1

        ilat = [achar(la, lat) for la in cx["lats"]]
        ilon = [achar(lo % 360.0, lon) for lo in cx["lons"]]
        dados = np.full((len(VARS), 4, 4), np.nan, dtype=np.float32)
        t0 = t1 = np.nan
        for k, v in enumerate(VARS):
            nome = next((n for n in V if _PADROES[v].match(n)), None)
            if nome is None:
                continue
            var = V[nome]
            arr = np.array(var.data, dtype=np.float64)
            for att in ("_FillValue", "missing_value"):
                if hasattr(var, att):
                    arr[arr == float(np.ravel(getattr(var, att))[0])] = np.nan
            dims = list(var.dimensions)
            sel = []
            for d in dims:
                if d.startswith("height_above_ground"):
                    niveis = np.asarray(V[d].data, dtype=float)
                    i = np.where(np.isclose(niveis, _NIVEL[v]))[0]
                    sel.append(int(i[0]) if len(i) else None)
                elif d in ("latitude", "longitude"):
                    sel.append(slice(None))
                else:
                    sel.append(0)
            if any(s is None for s in sel):
                continue
            campo = arr[tuple(sel)]
            for a, ia in enumerate(ilat):
                for b, ib in enumerate(ilon):
                    if ia >= 0 and ib >= 0:
                        dados[k, a, b] = campo[ia, ib]
            if v == "dswrf":
                tdim = dims[0]
                bnd = _txt(getattr(V[tdim], "bounds", b""))
                if bnd and bnd in V:
                    unid = _txt(V[tdim].units)
                    base = _utc(unid.split("since", 1)[1].strip())
                    desloc = (base - ciclo).total_seconds() / 3600.0
                    b0, b1 = np.ravel(V[bnd].data)[:2]
                    t0, t1 = float(b0) + desloc, float(b1) + desloc
    return dados, t0, t1


class ServidorIndisponivel(IOError):
    """HTTP 5xx, 429, tempo esgotado ou conexão recusada: problema do servidor, não do pedido."""


class Disjuntor:
    """Pausa todos os trabalhadores quando o servidor do NCAR para de responder.

    Depois de `limiar` falhas seguidas de servidor, todos esperam `pausa` (5 min, dobrando até
    60 min) antes de tentar de novo. Assim uma queda do THREDDS não vira milhares de pedidos
    marcados como falha: a coleta só fica parada e continua sozinha quando o servidor volta.
    """

    def __init__(self, limiar: int = 12, pausa_inicial_s: float = 300, pausa_max_s: float = 3600):
        self.limiar, self.p0, self.pmax = limiar, pausa_inicial_s, pausa_max_s
        self.trava = threading.Lock()
        self.seguidas = 0
        self.pausa = pausa_inicial_s
        self.aberto_ate = 0.0

    def aguardar(self) -> None:
        while True:
            with self.trava:
                resta = self.aberto_ate - time.time()
            if resta <= 0:
                return
            time.sleep(min(resta, 30))

    def falha(self, motivo: str) -> None:
        with self.trava:
            self.seguidas += 1
            if self.seguidas >= self.limiar and time.time() >= self.aberto_ate:
                self.aberto_ate = time.time() + self.pausa
                log.warning("GFS: servidor do NCAR indisponível (%s); pausa de %.0f min e nova tentativa",
                            motivo[:80], self.pausa / 60)
                self.pausa = min(self.pausa * 2, self.pmax)
                self.seguidas = 0

    def sucesso(self) -> None:
        with self.trava:
            if self.pausa > self.p0 and self.seguidas == 0:
                log.info("GFS: servidor do NCAR voltou a responder")
            self.seguidas = 0
            self.pausa = self.p0


disjuntor = Disjuntor()


def requisitar(servidor: str, ciclo: pd.Timestamp, fh: int, cx: dict, timeout: int, tentativas: int,
               max_falhas_servidor: int = 400):
    """Faz um pedido NCSS. Retorna (status, dados[6,4,4] ou None, t0, t1).

    Erros do pedido (resposta inválida etc.) usam até `tentativas`. Quedas do servidor não
    gastam tentativas: o disjuntor pausa a coleta até o servidor voltar.
    """
    url = url_arquivo(servidor, ciclo, fh)
    nomes = _nomes_alternativos.get(fh % 6) or nomes_variaveis(fh)
    espera = 5
    trocou_nomes = False
    tentativa = 0
    falhas_servidor = 0
    while tentativa < tentativas:
        disjuntor.aguardar()
        try:
            params = [("var", n) for n in nomes] + [
                ("north", f"{cx['north']:.3f}"), ("south", f"{cx['south']:.3f}"),
                ("west", f"{cx['west']:.3f}"), ("east", f"{cx['east']:.3f}"), ("accept", "netcdf3")]
            try:
                r = _sessao().get(url, params=params, timeout=timeout)
            except (requests.ConnectionError, requests.Timeout) as e:
                raise ServidorIndisponivel(type(e).__name__) from e
            if r.status_code == 404:
                disjuntor.sucesso()
                return ST_AUSENTE, None, np.nan, np.nan
            if r.status_code in (429, 500, 502, 503, 504):
                raise ServidorIndisponivel(f"HTTP {r.status_code}")
            if r.status_code == 400:
                disjuntor.sucesso()
                if trocou_nomes:
                    # mesmo com os nomes lidos do próprio arquivo: arquivo ilegível no servidor
                    log.debug("  GFS: %s f%03d ilegível no servidor (HTTP 400); tratado como ausente", ciclo, fh)
                    return ST_AUSENTE, None, np.nan, np.nan
                trocou_nomes = True
                try:
                    nomes_arq = _descobrir_nomes(url, timeout)
                except Exception as e:  # noqa: BLE001
                    log.debug("  GFS: %s f%03d sem catálogo legível (%s); tratado como ausente", ciclo, fh, e)
                    return ST_AUSENTE, None, np.nan, np.nan
                if nomes_arq == nomes:
                    log.debug("  GFS: %s f%03d ilegível no servidor (HTTP 400); tratado como ausente", ciclo, fh)
                    return ST_AUSENTE, None, np.nan, np.nan
                nomes = nomes_arq
                continue
            r.raise_for_status()
            if not r.content.startswith(b"CDF"):
                raise IOError("resposta não é NetCDF")
            dados, t0, t1 = ler_nc(r.content, cx, ciclo)
            disjuntor.sucesso()
            if trocou_nomes and nomes != nomes_variaveis(fh):
                with _trava_nomes:
                    if _nomes_alternativos.get(fh % 6) != nomes:
                        _nomes_alternativos[fh % 6] = nomes
                        log.info("  GFS: nomes alternativos de variáveis para f%03d: %s", fh, nomes[:2])
            return ST_OK, dados, t0, t1
        except ServidorIndisponivel as e:
            disjuntor.falha(str(e))
            falhas_servidor += 1
            if falhas_servidor >= max_falhas_servidor:
                log.debug("  GFS desistiu de %s f%03d após %d quedas do servidor", ciclo, fh, falhas_servidor)
                return ST_ERRO, None, np.nan, np.nan
            time.sleep(espera)
            espera = min(espera * 2, 60)
        except Exception as e:  # noqa: BLE001
            tentativa += 1
            if tentativa >= tentativas:
                log.debug("  GFS falhou %s f%03d: %s", ciclo, fh, e)
                return ST_ERRO, None, np.nan, np.nan
            time.sleep(espera)
            espera = min(espera * 2, 120)
    return ST_ERRO, None, np.nan, np.nan


# ---------------------------------------------------------------------------
# Coleta (paralela e retomável)
# ---------------------------------------------------------------------------
def gravar_dia(caminho: Path, linhas: list, cx: dict) -> None:
    """linhas: [(ciclo, fh, status, dados|None, t0, t1)]"""
    linhas = sorted(linhas, key=lambda x: (x[0], x[1]))
    n = len(linhas)
    dados = np.full((n, len(VARS), 4, 4), np.nan, dtype=np.float32)
    for i, linha in enumerate(linhas):
        if linha[3] is not None:
            dados[i] = linha[3]
    caminho.parent.mkdir(parents=True, exist_ok=True)
    tmp = caminho.with_name(caminho.stem + ".tmp.npz")
    with open(tmp, "wb") as f:
        np.savez_compressed(
            f,
            ciclo=np.array([int(x[0].timestamp()) for x in linhas], dtype=np.int64),
            fh=np.array([x[1] for x in linhas], dtype=np.int16),
            status=np.array([x[2] for x in linhas], dtype=np.int8),
            t0=np.array([x[4] for x in linhas], dtype=np.float32),
            t1=np.array([x[5] for x in linhas], dtype=np.float32),
            dados=dados, lats=np.asarray(cx["lats"], dtype=np.float32),
            lons=np.asarray(cx["lons"], dtype=np.float32))
        f.flush()
        os.fsync(f.fileno())  # garante o conteúdo no disco antes da troca (queda de energia)
    tmp.replace(caminho)


def _ler_dia(caminho: Path) -> list:
    with np.load(caminho) as z:
        ciclo, fh, status = z["ciclo"], z["fh"], z["status"]
        dados, t0, t1 = z["dados"], z["t0"], z["t1"]
    out = []
    for i in range(len(ciclo)):
        st = int(status[i])
        out.append((pd.Timestamp(int(ciclo[i]), unit="s", tz="UTC"), int(fh[i]), st,
                    dados[i] if st == ST_OK else None, float(t0[i]), float(t1[i])))
    return out


def _mesma_caixa(z, cx: dict) -> bool:
    return (np.allclose(np.asarray(z["lats"], dtype=float), cx["lats"], atol=1e-4)
            and np.allclose(np.asarray(z["lons"], dtype=float) % 360.0, np.asarray(cx["lons"]) % 360.0, atol=1e-4))


def _contem_ponto(z, lat: float, lon: float) -> bool:
    la = np.asarray(z["lats"], dtype=float)
    lo = np.asarray(z["lons"], dtype=float) % 360.0
    return bool(la.min() <= lat <= la.max() and lo.min() <= lon % 360.0 <= lo.max())


def _chaves_feitas(caminho: Path, refazer_falhas: bool, cx: Optional[dict] = None) -> set:
    """(ciclo, fh) já resolvidos no arquivo do dia (ok ou ausente no arquivo do NCAR).
    Se o arquivo é de outra caixa (o ponto do site mudou no config.yaml), nada conta como feito."""
    if not caminho.exists():
        return set()
    try:
        with np.load(caminho) as z:
            if cx is not None and not _mesma_caixa(z, cx):
                return set()
            ciclo, fh, status = z["ciclo"], z["fh"], z["status"]
        ok = status != ST_ERRO if refazer_falhas else np.ones(len(status), dtype=bool)
        return {(int(c), int(f)) for c, f, o in zip(ciclo, fh, ok) if o}
    except Exception:  # noqa: BLE001
        return set()


def baixar(cfg: dict, pastas, sites: list, inicio=None, fim=None, trabalhadores=None,
           refazer_falhas: bool = False, apenas_estimar: bool = False) -> None:
    g = cfg["gfs"]
    servidor = g["servidor_ncss"].rstrip("/")
    timeout, tentativas = int(g.get("timeout_s", 120)), int(g.get("tentativas", 6))
    n_trab = int(trabalhadores or g.get("trabalhadores", 8))
    caixas = {s["codigo"]: caixa(s["lat"], s["lon"]) for s in sites}
    plano = planejar(sites, g, inicio, fim)

    pend: dict = {}
    for dia, tarefas in plano.items():
        cods_dia = {cod for v in tarefas.values() for cod in v}
        feitas = {cod: _chaves_feitas(arquivo_dia(pastas.gfs(cod), dia), refazer_falhas, caixas[cod])
                  for cod in cods_dia}
        t = {}
        for (c, fh), cods in tarefas.items():
            falta = [cod for cod in cods if (int(c.timestamp()), fh) not in feitas[cod]]
            if falta:
                t[(c, fh)] = falta
        if t:
            pend[dia] = t
    n_arq = sum(len(t) for t in pend.values())
    n_ped = sum(len(v) for t in pend.values() for v in t.values())
    log.info("GFS: %d dias no plano, %d com pendências; faltam %d arquivos GRIB (%d pedidos NCSS) "
             "com %d trabalhadores", len(plano), len(pend), n_arq, n_ped, n_trab)
    if n_trab > 64:
        log.warning("GFS: %d trabalhadores nunca foram testados (32 funcionou bem). Com pedidos demais o servidor "
                    "do NCAR tende a responder 429/503 ou estourar o tempo, e a coleta faz pausas de 5–60 min; "
                    "se isso aparecer no log, volte 'trabalhadores' do config.yaml para 32.", n_trab)
    if n_ped:
        # medido em out/2026 nos arquivos de 2019+ (GFS v15): ~0,4 pedido/s com 8 trabalhadores e ~1,8 com 32;
        # acima de 32 não há medida, então a estimativa não cresce além disso
        taxa = min(0.055 * n_trab, 1.8)
        log.info("GFS: estimativa grosseira: %.0f h a ~%.1f pedido/s (depende da carga do servidor do NCAR)",
                 n_ped / taxa / 3600, taxa)
    if apenas_estimar or not pend:
        return

    t_ini = time.time()
    cont = {"feitos": 0, "falhas": 0}

    def tarefa(c, fh, cods):
        res = {}
        for cod in cods:  # em sequência: o 2º site aproveita o arquivo já aberto no servidor
            res[cod] = requisitar(servidor, c, fh, caixas[cod], timeout, tentativas)
        return c, fh, res

    def finalizar(dia, futs):
        por_site: dict = {}
        for f in futs:
            c, fh, res = f.result()
            for cod, (st, d, t0, t1) in res.items():
                por_site.setdefault(cod, []).append((c, fh, st, d, t0, t1))
                cont["feitos"] += 1
                cont["falhas"] += int(st == ST_ERRO)
        for cod, linhas in por_site.items():
            cam = arquivo_dia(pastas.gfs(cod), dia)
            antigas = []
            if cam.exists():
                try:
                    with np.load(cam) as z:
                        mesma = _mesma_caixa(z, caixas[cod])
                    antigas = _ler_dia(cam) if mesma else []
                except Exception as e:  # noqa: BLE001
                    log.warning("  GFS: %s ilegível (%s); será regravado", cam.name, e)
            if antigas:
                novas = {(x[0], x[1]) for x in linhas}
                linhas = [x for x in antigas if (x[0], x[1]) not in novas] + linhas
            gravar_dia(cam, linhas, caixas[cod])
        dec = time.time() - t_ini
        taxa = cont["feitos"] / max(dec, 1e-6)
        resta = (n_ped - cont["feitos"]) / max(taxa, 1e-6)
        log.info("GFS %s ok | %d/%d pedidos (%.1f%%) | %.2f pedidos/s | falhas %d | faltam ~%.1f h",
                 dia, cont["feitos"], n_ped, 100.0 * cont["feitos"] / n_ped, taxa, cont["falhas"], resta / 3600)

    janela = max(2, n_trab // 8 + 2)
    dias = list(pend.keys())
    em_voo: dict = {}
    ex = ThreadPoolExecutor(max_workers=n_trab)
    interrompido = False
    try:
        i = 0
        while i < len(dias) or em_voo:
            while i < len(dias) and len(em_voo) < janela:
                dia = dias[i]
                em_voo[dia] = [ex.submit(tarefa, c, fh, cods) for (c, fh), cods in pend[dia].items()]
                i += 1
            nao_feitos = [f for fs in em_voo.values() for f in fs if not f.done()]
            if nao_feitos:
                wait(nao_feitos, return_when=FIRST_COMPLETED, timeout=60)
            for dia in [d for d, fs in em_voo.items() if all(f.done() for f in fs)]:
                finalizar(dia, em_voo.pop(dia))
    except KeyboardInterrupt:
        interrompido = True
        log.warning("GFS: interrompido; os dias já gravados ficam salvos. Rode de novo para continuar.")
        raise
    finally:
        ex.shutdown(wait=not interrompido, cancel_futures=True)
    if cont["falhas"]:
        log.warning("GFS: %d pedidos falharam após %d tentativas; rode de novo com --refazer-falhas",
                    cont["falhas"], tentativas)


# ---------------------------------------------------------------------------
# Processamento: médias de 3 h e interpolação horária
# ---------------------------------------------------------------------------
def pesos_bilineares(lats, lons, lat, lon) -> np.ndarray:
    """Pesos (4x4) da interpolação bilinear do ponto dentro da caixa (lats decrescentes)."""
    lon = lon % 360.0
    lons = np.asarray(lons, dtype=float) % 360.0
    lats = np.asarray(lats, dtype=float)
    W = np.zeros((4, 4))
    ia = int(np.clip(np.searchsorted(-lats, -lat) - 1, 0, 2))
    ib = int(np.clip(np.searchsorted(lons, lon) - 1, 0, 2))
    fa = float(np.clip((lats[ia] - lat) / (lats[ia] - lats[ia + 1]), 0, 1))
    fb = float(np.clip((lon - lons[ib]) / (lons[ib + 1] - lons[ib]), 0, 1))
    W[ia, ib] = (1 - fa) * (1 - fb)
    W[ia + 1, ib] = fa * (1 - fb)
    W[ia, ib + 1] = (1 - fa) * fb
    W[ia + 1, ib + 1] = fa * fb
    return W


def carregar_brutos(pasta_site: Path, lat: float, lon: float) -> pd.DataFrame:
    arquivos = [a for a in sorted(pasta_site.glob("*/*.npz")) if not a.name.endswith(".tmp.npz")]
    if not arquivos:
        raise FileNotFoundError(f"nenhum bruto do GFS em {pasta_site}; rode 'python coletar.py baixar --fontes gfs'")
    partes = []
    fora = 0
    ilegiveis = 0
    for a in arquivos:
        try:
            with np.load(a) as z:
                z = {k: z[k] for k in ("lats", "lons", "dados", "ciclo", "fh", "status", "t0", "t1")}
        except Exception:  # noqa: BLE001
            ilegiveis += 1
            continue
        if not _contem_ponto(z, lat, lon):
            fora += 1  # arquivo de uma caixa antiga (o ponto do site mudou): ignora
            continue
        W = pesos_bilineares(z["lats"], z["lons"], lat, lon)
        d = z["dados"].astype(np.float64)  # (n, 6, 4, 4)
        valido = np.isfinite(d)
        num = np.sum(np.where(valido, d, 0.0) * W, axis=(2, 3))
        den = np.sum(valido * W, axis=(2, 3))
        vals = np.where(den > 0.5, num / np.where(den > 0, den, 1.0), np.nan)
        df = pd.DataFrame(vals, columns=VARS)
        df["ciclo"] = pd.to_datetime(z["ciclo"], unit="s", utc=True)
        df["fh"] = z["fh"].astype(int)
        df["status"] = z["status"].astype(int)
        df["t0"] = z["t0"].astype(float)
        df["t1"] = z["t1"].astype(float)
        partes.append(df)
    if ilegiveis:
        log.warning("  GFS: %d arquivo(s) diário(s) de %s ilegíveis foram ignorados; rode 'python coletar.py "
                    "baixar --fontes gfs' para baixá-los de novo", ilegiveis, pasta_site.name)
    if fora:
        log.warning("  GFS: %d arquivo(s) diário(s) de %s são de outra caixa (o ponto do site mudou?) e foram "
                    "ignorados; rode 'python coletar.py baixar --fontes gfs' para baixá-los de novo",
                    fora, pasta_site.name)
    if not partes:
        raise FileNotFoundError(f"nenhum bruto do GFS em {pasta_site} cobre o ponto ({lat:.4f}, {lon:.4f})")
    df = pd.concat(partes, ignore_index=True)
    df = df.drop_duplicates(["ciclo", "fh"], keep="last").sort_values(["ciclo", "fh"]).reset_index(drop=True)
    df.loc[df["status"] != ST_OK, VARS] = np.nan
    return df


def _largura_padrao(fh: int) -> float:
    return 3.0 if fh % 6 == 3 else 6.0


def medias_3h(df: pd.DataFrame, var: str, fhs: list) -> pd.DataFrame:
    """Médias de 3 h terminando em cada fh (ciclo x fh), a partir das janelas do GFS:
    fh com fh%6==3 traz a média de 3 h; fh com fh%6==0 traz a média de 6 h, e
    média[fh-3, fh] = 2*média6[fh-6, fh] - média3[fh-6, fh-3]."""
    base = df.set_index(["ciclo", "fh"])
    vals = base[var].unstack("fh").reindex(columns=fhs)
    larg = (base["t1"] - base["t0"]).round().unstack("fh").reindex(columns=fhs)
    out = pd.DataFrame(np.nan, index=vals.index, columns=fhs)
    for fh in fhs:
        w = larg[fh].fillna(_largura_padrao(fh))
        r3 = vals[fh].where(w == 3)
        if fh - 3 in fhs:
            ant = vals[fh - 3].where(larg[fh - 3].fillna(_largura_padrao(fh - 3)) == 3)
            r6 = (2.0 * vals[fh] - ant).where(w == 6)
        else:
            r6 = pd.Series(np.nan, index=vals.index)
        out[fh] = r3.where(w == 3, r6)
    return out


def _interp(x_alvo: np.ndarray, x: np.ndarray, y: np.ndarray) -> np.ndarray:
    ok = np.isfinite(y)
    if ok.sum() == 0:
        return np.full(x_alvo.shape, np.nan)
    if ok.sum() == 1:
        return np.full(x_alvo.shape, float(y[ok][0]))
    return np.interp(x_alvo, x[ok], y[ok])  # constante fora do intervalo


def processar(site: dict, cfg: dict, pastas, ceu) -> pd.DataFrame:
    """Tabela horária por ciclo: ciclo_utc, valido_utc (início da hora-alvo), lead_h e variáveis.

    As horas-alvo seguem o relógio padrão local do site (em YUL, UTC+09:30, começam em hh:30 UTC).
    lead_h = horas entre o ciclo e o FIM da hora-alvo (a hora [c+5h, c+6h) tem lead_h = 6).
    """
    from .agregacao import fracao_fuso_h

    frac = fracao_fuso_h(site["fuso_lst"])
    modo = cfg["gfs"].get("interpolacao_ghi", "k_linear")
    df = carregar_brutos(pastas.gfs(site["codigo"]), site["lat"], site["lon"])
    fhs = sorted(int(x) for x in df["fh"].unique())
    fh_arr = np.array(fhs, dtype=float)
    m_ghi = medias_3h(df, "dswrf", fhs).clip(lower=0)
    m_tcc = medias_3h(df, "tcc", fhs).clip(0, 100)
    base = df.set_index(["ciclo", "fh"])
    inst = {v: base[v].unstack("fh").reindex(columns=fhs) for v in ("t2m", "rh2m", "u10", "v10")}

    partes = []
    for c in m_ghi.index:
        g3 = m_ghi.loc[c].to_numpy(dtype=float)
        t2 = inst["t2m"].loc[c].to_numpy(dtype=float)
        tem = np.isfinite(g3) | np.isfinite(t2)
        if not tem.any():
            continue
        # inícios das horas-alvo (h após o ciclo), com a hora inteira coberta pelos dados
        hh = np.arange(3.0 + frac, fh_arr[tem].max() - 1.0 + 1e-9, 1.0)
        if hh.size == 0:
            continue
        mm = hh + 0.5
        ini_h = c + pd.to_timedelta(hh, unit="h")
        cs_1h = ceu.media(ini_h, ini_h + pd.Timedelta(hours=1))
        ini3 = c + pd.to_timedelta(fh_arr - 3, unit="h")
        cs_3h = ceu.media(ini3, ini3 + pd.Timedelta(hours=3))
        k3 = np.where(cs_3h >= 20.0, g3 / np.maximum(cs_3h, 1e-6), np.nan)
        k3 = np.clip(k3, 0.0, 1.5)
        if modo == "k_constante":
            idx = np.clip(np.searchsorted(fh_arr, hh, side="right"), 0, len(fh_arr) - 1)
            k_h = k3[idx]
            k_h = np.where(np.isfinite(k_h), k_h, _interp(mm, fh_arr - 1.5, k3))
        else:
            k_h = _interp(mm, fh_arr - 1.5, k3)
        dia = cs_1h >= 1.0
        reg = {
            "ciclo_utc": c, "valido_utc": ini_h, "lead_h": (hh + 1.0).astype(np.float32),
            "ghi_nwp": np.where(dia, k_h * cs_1h, 0.0), "ghi_cs": cs_1h,
            "k_nwp": np.where(dia, k_h, 0.0),
            "tcc": _interp(mm, fh_arr - 1.5, m_tcc.loc[c].to_numpy(dtype=float)) / 100.0,
        }
        for v in ("t2m", "rh2m", "u10", "v10"):
            reg[v] = _interp(mm, fh_arr, inst[v].loc[c].to_numpy(dtype=float))
        partes.append(pd.DataFrame(reg))
    if not partes:
        raise RuntimeError(f"GFS de {site['codigo']}: nenhum ciclo com dados")
    out = pd.concat(partes, ignore_index=True)
    out["t2m"] = out["t2m"] - 273.15
    out["rh2m"] = out["rh2m"].clip(0, 100)
    out["tcc"] = out["tcc"].clip(0, 1)
    out["t2m_x_rh2m"] = out["t2m"] * out["rh2m"]
    num = ["ghi_nwp", "ghi_cs", "k_nwp", "tcc", "t2m", "rh2m", "u10", "v10", "t2m_x_rh2m"]
    out[num] = out[num].astype("float32")
    return out


def cobertura(pasta_site: Path, lat: Optional[float] = None, lon: Optional[float] = None) -> dict:
    st = []
    for a in sorted(pasta_site.glob("*/*.npz")):
        if a.name.endswith(".tmp.npz"):
            continue
        try:
            with np.load(a) as z:
                if lat is not None and lon is not None and not _contem_ponto(z, lat, lon):
                    continue
                st.append(z["status"])
        except Exception:  # noqa: BLE001
            continue
    if not st:
        return {"dias": 0, "arquivos": 0, "ok": 0, "ausentes_no_arquivo": 0, "falhas": 0}
    s = np.concatenate(st)
    return {"dias": len(st), "arquivos": int(s.size), "ok": int((s == ST_OK).sum()),
            "ausentes_no_arquivo": int((s == ST_AUSENTE).sum()), "falhas": int((s == ST_ERRO).sum())}
