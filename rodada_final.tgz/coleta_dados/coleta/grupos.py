"""Tamanho dos grupos de condicionamento no ano de teste (entrada de tools/wgc_reference.py do artigo).

Grupos (Seção III-A): 13 horas de relógio local (06..18; horas diurnas antes das 06 ou depois das
18 entram no primeiro ou no último grupo), 3 regimes do NWP pelo índice de céu claro do GFS
(claro k >= 0,8; parcialmente nublado 0,4 <= k < 0,8; encoberto k < 0,4) e 3 tercis da dispersão
(tamanhos iguais por construção). Conta só horas diurnas de teste com dado e dia mantido no QC.
"""

from __future__ import annotations

import logging

import numpy as np
import pandas as pd

from .nwp_selecao import _juntar, ciclo_disponivel

log = logging.getLogger("coleta")

HORIZONTES = {"1h": 1, "3h": 3, "6h": 6, "DA": None}
REGIMES = [("clear", 0.8, np.inf), ("partly", 0.4, 0.8), ("overcast", -np.inf, 0.4)]


def _k_nwp_intradiario(gfs: pd.DataFrame, alvos_utc: pd.DatetimeIndex, h: int, latencia_h: float) -> np.ndarray:
    t0 = alvos_utc - pd.Timedelta(hours=h - 1)
    a = pd.DataFrame({"ciclo_utc": ciclo_disponivel(t0, latencia_h), "valido_utc": alvos_utc})
    return _juntar(a, gfs)["k_nwp"].to_numpy(dtype=float)


def tamanhos(cfg: dict, pastas) -> tuple:
    linhas = []
    for cod, site in cfg["sites"].items():
        pasta = pastas.processados / cod
        arq_p, arq_g = pasta / "potencia_horaria.parquet", pasta / "gfs_horario.parquet"
        if not (arq_p.exists() and arq_g.exists()):
            log.warning("  %s: falta potencia_horaria ou gfs_horario; rode 'processar' antes", cod)
            continue
        p = pd.read_parquet(arq_p)
        t = p[(p["bloco"] == "teste") & p["diurno"] & p["manter_dia"] & p["y"].notna()].copy()
        hora = t["hora_lst"].clip(6, 18)
        g = pd.read_parquet(arq_g)
        da = pd.read_parquet(pasta / "gfs_dia_seguinte.parquet") if (pasta / "gfs_dia_seguinte.parquet").exists() else None
        for nome_h, h in HORIZONTES.items():
            for hh, n in hora.value_counts().sort_index().items():
                linhas.append({"site": cod, "horizonte": nome_h, "family": "hour", "group": f"{int(hh):02d}",
                               "n_test": int(n)})
            if h is None:
                if da is None:
                    continue
                k = da.set_index("valido_utc")["k_nwp"].reindex(t["tempo_utc"]).to_numpy(dtype=float)
            else:
                k = _k_nwp_intradiario(g, pd.DatetimeIndex(t["tempo_utc"]), h, cfg["gfs"].get("latencia_h", 5))
            for nome, lo, hi in REGIMES:
                linhas.append({"site": cod, "horizonte": nome_h, "family": "regime", "group": nome,
                               "n_test": int(np.sum((k >= lo) & (k < hi)))})
            n = len(t)
            for i, nome in enumerate(["low", "mid", "high"]):
                linhas.append({"site": cod, "horizonte": nome_h, "family": "tertile", "group": nome,
                               "n_test": int(n // 3 + (1 if i < n % 3 else 0))})
    det = pd.DataFrame(linhas)
    if det.empty:
        return det, det
    det.to_csv(pastas.processados / "group_sizes_por_horizonte.csv", index=False)
    da = det[det["horizonte"] == "DA"].drop(columns="horizonte")
    da.to_csv(pastas.processados / "group_sizes.csv", index=False)
    log.info("Tamanhos dos grupos: %s (copie para results/group_sizes.csv do artigo)",
             pastas.processados / "group_sizes.csv")
    return det, da
