"""Desert Knowledge Australia Solar Centre (DKASC): Alice Springs e Yulara.

Fonte: https://dkasolarcentre.com.au/download?location=yulara (ou location=alice-springs)
Arquivos anuais "All Individual Technologies (yearly data set with weather data)",
resolução de 5 min, carimbo em hora local (ACST, UTC+09:30), potência ativa em kW.

Dois modos, conforme o config.yaml:
  * usina única ('id_fonte'): a série de um sistema só. É o YUL: Desert Gardens, em Yulara
    (1.058,4 kWp, 3.360 módulos de 315 W, solo, inclinação fixa de 15° para o norte, desde mar/2016);
  * portfólio (sem 'id_fonte'): soma dos arranjos fixos de Alice Springs com disponibilidade mínima
    (o ASP do conjunto do artigo 1, config_artigo1.yaml).
"""

from __future__ import annotations

import logging
import re

import numpy as np
import pandas as pd

from ..agregacao import (AcumuladorHorario, disponibilidade_diurna, hora_de_inicio,
                         mascarar_unidades_paradas, portfolio)
from ..util import baixar_arquivo, nova_sessao

log = logging.getLogger("coleta")

URL_ANUAL = "https://solarcentre.spinifexvalley.com.au/yearly_export/{prefixo}_{ano}.csv"
TAMANHO_APROX_MB = {2019: 192.54, 2020: 198.03, 2021: 187.99, 2022: 189.34, 2023: 184.6, 2024: 206.5,
                    2025: 212.6}

TERMOS = """\
Termos de uso do DKASC (https://dkasolarcentre.com.au/download/terms-conditions), em resumo:
  * os dados são protegidos por copyright (Desert Knowledge Australia / Ekistica);
  * sem consentimento formal, só é permitido exibir/reproduzir/distribuir até 5.000 células de dados;
  * publicações devem citar a fonte e trazer o aviso de isenção de responsabilidade do DKA;
  * ao baixar você declara concordar com os termos e com as 'notes on the data'.
Isso impede publicar os dados processados do DKASC no repositório do artigo sem autorização."""

# id da fonte em Yulara (prefixo das colunas; é o número no início dos arquivos de exportação do site)
# -> (rótulo do DKASC, kW nominal, montagem)
YULARA = {
    5: ("1 Desert Gardens, 1058.4kW, poly-Si, Fixed (solo), 2016", 1058.4, "fixo"),
    10: ("2 Service Station, 226.8kW, poly-Si, Fixed, 2016", 226.8, "fixo"),
    7: ("3-A Sails in the Desert 1, 22.6kW, mono-Si, Roof, 2016", 22.6, "fixo"),
    9: ("3-B Sails in the Desert 2, 38.3kW, mono-Si, Roof, 2016", 38.3, "fixo"),
    6: ("3-C Sails in the Desert 3, 45.8kW, mono-Si, Roof, 2016", 45.8, "fixo"),
    11: ("4 Laundry, 327.6kW, poly-Si, Fixed, 2016", 327.6, "fixo"),
    8: ("5 Connellan Airport, 105.9kW, mono-Si, Roof, 2016", 105.9, "fixo"),
    3051: ("3 Sails in the Desert (soma dos três telhados), 106.6kW", 106.6, "medidor"),
    3050: ("Total dos sites de Yulara, 1820kW", 1820.0, "medidor"),
}

# id da fonte (prefixo das colunas) -> (rótulo do site DKASC, kW nominal, montagem)
# montagem: fixo | rastreador | medidor
ARRANJOS = {
    91: ("1A Trina, 10.5kW, mono-Si, Dual, 2009", 10.5, "rastreador"),
    87: ("1B Trina, 23.4kW, mono-Si, Dual, 2009", 23.4, "rastreador"),
    78: ("2 eco-Kinetics, 26.5kW, mono-Si, Dual, 2010", 26.5, "rastreador"),
    70: ("3 BP Solar, 5.0kW, poly-Si, Fixed, 2008, Roof Mounted", 5.0, "fixo"),
    86: ("4 Kyocera, 2.2kW, poly-Si, Dual, 2008", 2.2, "rastreador"),
    89: ("5 Kyocera, 5.4kW, poly-Si, Single, 2008", 5.4, "rastreador"),
    95: ("6 Kyocera, 5.4kW, poly-Si, Dual, 2008", 5.4, "rastreador"),
    79: ("7 First Solar, 7.0kW, CdTe, Fixed, 2008", 7.0, "fixo"),
    93: ("8 Kaneka, 6.0kW, Amorphous Silicon, Fixed, 2008", 6.0, "fixo"),
    218: ("9A Solibro, 5.2kW, CIGS, Fixed, 2017", 5.2, "fixo"),
    85: ("10 SunPower, 5.8kW, mono-Si, Fixed, 2009, 215W", 5.8, "fixo"),
    106: ("11 BP Solar, 5.0kW, poly-Si, Fixed, 2008", 5.0, "fixo"),
    84: ("12 BP Solar, 5.1kW, mono-Si, Fixed, 2008", 5.1, "fixo"),
    92: ("13 Trina, 5.3kW, mono-Si, Fixed, 2009", 5.3, "fixo"),
    90: ("14 Kyocera, 5.4kW, poly-Si, Fixed, 2008", 5.4, "fixo"),
    100: ("16A BP Solar, 2.0kW, poly-Si, Fixed, 2008, North", 2.0, "fixo"),
    103: ("16B BP Solar, 2.0kW, poly-Si, Fixed, 2008, Flat", 2.0, "fixo"),
    105: ("16C BP Solar, 2.0kW, poly-Si, Fixed, 2008, East", 2.0, "fixo"),
    81: ("16D BP Solar, 2.0kW, poly-Si, Fixed, 2008, West", 2.0, "fixo"),
    69: ("17 Sanyo, 6.3kW, HIT Hybrid Silicon, Fixed, 2010", 6.3, "fixo"),
    71: ("18 SunPower, 5.2kW, mono-Si, Fixed, 2011", 5.2, "fixo"),
    98: ("19 Sungrid, 5.0kW, mono-Si, Fixed, 2010", 5.0, "fixo"),
    68: ("20 Sungrid, 5.0kW, poly-Si, Fixed, 2010", 5.0, "fixo"),
    67: ("21 Evergreen Solar, 4.9kW, poly-Si, Fixed, 2010", 4.9, "fixo"),
    97: ("22 SolFocus, 16.8kW, CPV, Dual, 2010", 16.8, "rastreador"),
    61: ("23 Calyxo, 5.4kW, CdTe, Fixed, 2010", 5.4, "fixo"),
    213: ("24 Q CELLS, 6.1kW, poly-Si, Fixed, 2016", 6.1, "fixo"),
    212: ("25 Hanwha Solar, 5.8kW, poly-Si, Fixed, 2016", 5.8, "fixo"),
    72: ("26 Q CELLS, 5.5kW, poly-Si, Fixed, 2013", 5.5, "fixo"),
    55: ("29 CSUN, 6.0kW, poly-Si, Fixed, 2013", 6.0, "fixo"),
    56: ("30 Q CELLS, 5.6kW, poly-Si, Fixed, 2013", 5.6, "fixo"),
    74: ("31 TDG, 5.0kW, mono-Si, Fixed, 2013", 5.0, "fixo"),
    214: ("32 Canadian Solar, 5.3kW, poly-Si, Fixed, 2016", 5.3, "fixo"),
    52: ("33 REC, 5.5kW, poly-Si, Fixed, 2012", 5.5, "fixo"),
    63: ("34 Winaico, 5.3kW, poly-Si, Fixed, 2012", 5.3, "fixo"),
    73: ("35 Elkem, 5.5kW, poly-Si, Fixed, 2014", 5.5, "fixo"),
    58: ("36 NovoPolymers, 5.2kW, poly-Si, Fixed, 2016", 5.2, "fixo"),
    64: ("37 Tindo, 5.5kW, poly-Si, Fixed, 2016", 5.5, "fixo"),
    59: ("38 Q CELLS, 5.9kW, mono-Si, Fixed, 2017", 5.9, "fixo"),
    102: ("31.5kW, Dual, Large Scale Trackers (desativado 07/2013)", 31.5, "rastreador"),
    77: ("Canadian Solar, 5.5kW, poly-Si, Fixed, 2013 (desativado 11/2016)", 5.5, "fixo"),
    205: ("Q CELLS, 5.9kW, UMG, Fixed (desativado 10/2013)", 5.9, "fixo"),
    99: ("Solco, 5.8kW, CIGS, Fixed, 2009 (desativado 10/2017)", 5.8, "fixo"),
    54: ("Q CELLS, 5.6kW, poly-Si, Fixed (desativado 09/2015)", 5.6, "fixo"),
    57: ("Q CELLS, 5.6kW, mono-Si, Fixed (desativado 11/2014)", 5.6, "fixo"),
    66: ("Hanergy, 5.6kW, CIGS, Fixed, 2010 (desativado 06/2018)", 5.6, "fixo"),
    60: ("First Solar, 5.6kW, CdTe, Fixed, 2013 (desativado 05/2020)", 5.6, "fixo"),
    96: ("MasterMeter1 (total do site)", 263.0, "medidor"),
    62: ("MasterMeter2", 0.0, "medidor"),
}

_RE_POT = re.compile(r"^(\d+)_.*Active_Power$")

# local do DKASC (campo 'local_dkasc' do config.yaml) -> prefixo dos arquivos anuais e tabela de sistemas
LOCAIS = {
    "alice-springs": {"prefixo": "Alice_Springs", "nome": "DKASC Alice Springs", "sistemas": ARRANJOS,
                      "tamanho_mb": TAMANHO_APROX_MB},
    "yulara": {"prefixo": "Yulara", "nome": "DKASC Yulara", "sistemas": YULARA, "tamanho_mb": {}},
}


def _local(site: dict) -> tuple:
    chave = str(site.get("local_dkasc", "alice-springs")).strip().lower()
    if chave not in LOCAIS:
        raise ValueError(f"local_dkasc desconhecido: {chave!r}; use {sorted(LOCAIS)}")
    return chave, LOCAIS[chave]


def anos(site: dict) -> list:
    return list(range(pd.Timestamp(site["inicio"]).year, pd.Timestamp(site["fim"]).year + 1))


def arquivos(site: dict, pastas) -> dict:
    _, loc = _local(site)
    return {a: pastas.bruto(site["codigo"]) / f"{loc['prefixo']}_{a}.csv" for a in anos(site)}


def url_anual(site: dict, ano: int) -> str:
    return URL_ANUAL.format(prefixo=_local(site)[1]["prefixo"], ano=ano)


def verificar(site: dict, cfg: dict, sess) -> str:
    ano = pd.Timestamp(site["fim"]).year
    r = sess.get(url_anual(site, ano), headers={"Range": "bytes=0-2047"}, timeout=60)
    r.raise_for_status()
    return f"arquivo de {ano}: HTTP {r.status_code}, cabeçalho começa com {r.text[:30]!r}"


def baixar(site: dict, cfg: dict, pastas, aceito_termos: bool = False, **_) -> None:
    if not aceito_termos:
        raise PermissionError("é preciso aceitar os termos do DKASC (--aceito-termos-dkasc)")
    chave, loc = _local(site)
    sess = nova_sessao()
    sess.headers["Referer"] = f"https://dkasolarcentre.com.au/download?location={chave}"
    for ano, destino in arquivos(site, pastas).items():
        tam = loc["tamanho_mb"].get(ano)
        baixar_arquivo(url_anual(site, ano), destino, sessao=sess,
                       descricao=f"{loc['nome']} {ano}" + (f" (~{tam} MB)" if tam else ""))


def _ler_ano(caminho, ids=None) -> pd.DataFrame:
    """Potência ativa (kW) das fontes do arquivo anual; com `ids`, só as dessas fontes."""
    cab = pd.read_csv(caminho, nrows=0).columns
    cols = [c for c in cab if _RE_POT.match(c)]
    if ids is not None:
        achadas = {int(_RE_POT.match(c).group(1)): c for c in cols}
        faltam = [i for i in ids if i not in achadas]
        if faltam:
            raise KeyError(f"{caminho.name}: não achei a potência da(s) fonte(s) {faltam}. Colunas de potência "
                           f"no arquivo: {', '.join(cols[:40]) or 'nenhuma'}")
        cols = [achadas[i] for i in ids]
    df = pd.read_csv(caminho, usecols=["timestamp"] + cols, low_memory=False)
    for c in cols:
        df[c] = pd.to_numeric(df[c], errors="coerce").astype("float32")
    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
    if getattr(df["timestamp"].dt, "tz", None) is not None:
        raise ValueError("carimbo do DKASC com fuso explícito: ajuste 'fuso_dados' no config.yaml")
    df = df.dropna(subset=["timestamp"]).drop_duplicates("timestamp").set_index("timestamp").sort_index()
    df.columns = [int(_RE_POT.match(c).group(1)) for c in df.columns]
    return df


def horario(site: dict, cfg: dict, pastas, atributos_fn) -> tuple:
    """Série horária do site. Retorna (df_horario, metadados)."""
    if site.get("id_fonte") is not None:
        return _horario_usina(site, cfg, pastas, atributos_fn)
    return _horario_portfolio(site, cfg, pastas, atributos_fn)


def _periodo_horas(site: dict) -> pd.DatetimeIndex:
    ini = pd.Timestamp(site["inicio"]).tz_localize(site["fuso_lst"]).tz_convert("UTC")
    fim = (pd.Timestamp(site["fim"]) + pd.Timedelta(days=1)).tz_localize(site["fuso_lst"]).tz_convert("UTC")
    return pd.date_range(ini, fim, freq="h", inclusive="left")


def _horario_usina(site: dict, cfg: dict, pastas, atributos_fn) -> tuple:
    """Série horária de uma usina só (id_fonte): média das amostras de 5 min de cada hora.

    A hora vale se tiver >= disponibilidade_min_hora das 12 amostras. Leituras acima de 120% da
    potência nominal são descartadas (picos de medição); paradas da usina com sol ficam para o QC
    diário (regra de saída zero)."""
    chave, loc = _local(site)
    sid = int(site["id_fonte"])
    rot, kw_tab, mont = loc["sistemas"].get(sid, (f"fonte {sid}", float("nan"), "desconhecida"))
    pnom = float(site.get("pnom_kw") or kw_tab)
    if not np.isfinite(pnom) or pnom <= 0:
        raise ValueError(f"{site['codigo']}: informe pnom_kw no config.yaml (fonte {sid} sem potência na tabela)")
    acc = AcumuladorHorario()
    passo = pd.Timedelta(minutes=5)
    n_amostras = n_altas = 0
    for ano, caminho in arquivos(site, pastas).items():
        if not caminho.exists():
            raise FileNotFoundError(f"falta {caminho.name}; rode 'python coletar.py baixar --fontes dkasc'")
        log.info("  lendo %s", caminho.name)
        s = _ler_ano(caminho, ids=[sid])[sid].astype("float64")
        q = s.quantile(0.999) if s.notna().any() else np.nan
        if np.isfinite(q) and q > 50 * pnom:
            log.warning("  %s %d: potência parece estar em W (p99,9 = %.0f); convertida para kW", site["codigo"],
                        ano, q)
            s = s / 1000.0
        altas = s > 1.2 * pnom
        n_altas += int(altas.sum())
        s = s.mask(altas)
        n_amostras += int(s.notna().sum())
        t_utc = s.index.tz_localize(site["fuso_dados"]).tz_convert("UTC")
        horas = hora_de_inicio(t_utc, site.get("rotulo_intervalo", "fim"), passo, site["fuso_lst"])
        acc.adicionar(s.to_frame(sid), horas)
    media, disp = acc.resultado(amostras_por_hora=12)
    horas = _periodo_horas(site)
    p = media.reindex(horas)[sid] if sid in media.columns else pd.Series(np.nan, index=horas)
    d = disp.reindex(horas)[sid].fillna(0.0) if sid in disp.columns else pd.Series(0.0, index=horas)
    diurno = atributos_fn(horas)["zenite"] < cfg["qc"]["zenite_max_graus"]
    ok = (d >= cfg["qc"]["disponibilidade_min_hora"]) & p.notna()
    p = p.where(ok)
    out = pd.DataFrame(index=horas)
    out["y"] = p / pnom
    out["p_kw"] = p
    out["disponibilidade"] = d
    out["n_unidades"] = ok.astype("int16")
    disp_d = float(d[diurno.to_numpy()].mean()) if diurno.any() else 0.0
    tab = pd.DataFrame([{"id_fonte": sid, "sistema": rot, "kw": pnom, "montagem": mont,
                         "disponibilidade_diurna": round(disp_d, 4), "amostras_5min": n_amostras,
                         "amostras_acima_120pct_descartadas": n_altas, "selecionado": True}])
    meta = {
        "pnom_kw": round(pnom, 3),
        "unidade_pnom": "kWp: potência nominal DC da usina informada pelo DKASC",
        "n_unidades": 1,
        "tabela_unidades": tab,
        "lat": site["lat"], "lon": site["lon"],
        "p_max_observado_kw": round(float(p.max()), 1) if p.notna().any() else None,
    }
    log.info("  %s: %s (%s, fonte %d), Pnom = %.1f kWp, %.1f%% das amostras diurnas presentes%s",
             site["codigo"], loc["nome"], rot.split(",")[0], sid, pnom, 100 * disp_d,
             f"; {n_altas} leituras acima de 120% da nominal descartadas" if n_altas else "")
    return out, meta


def _horario_portfolio(site: dict, cfg: dict, pastas, atributos_fn) -> tuple:
    """Série horária do 'virtual plant' de Alice Springs (soma dos arranjos fixos selecionados)."""
    tabela = _local(site)[1]["sistemas"]
    acc = AcumuladorHorario()
    passo = pd.Timedelta(minutes=5)
    for ano, caminho in arquivos(site, pastas).items():
        if not caminho.exists():
            raise FileNotFoundError(f"falta {caminho.name}; rode 'python coletar.py baixar --fontes dkasc'")
        log.info("  lendo %s", caminho.name)
        df = _ler_ano(caminho)
        t_utc = df.index.tz_localize(site["fuso_dados"]).tz_convert("UTC")
        horas = hora_de_inicio(t_utc, site.get("rotulo_intervalo", "fim"), passo, site["fuso_lst"])
        acc.adicionar(df, horas)
    media, disp = acc.resultado(amostras_por_hora=12)

    horas = _periodo_horas(site)
    media = media.reindex(horas)
    disp = disp.reindex(horas).fillna(0)
    attrs = atributos_fn(horas)
    diurno = attrs["zenite"] < cfg["qc"]["zenite_max_graus"]

    # horas em que um arranjo está parado enquanto os outros geram contam como faltantes
    cap_todos = pd.Series({sid: tabela[sid][1] for sid in media.columns
                           if sid in tabela and tabela[sid][2] in ("fixo", "rastreador")})
    media, disp, n_paradas = mascarar_unidades_paradas(media, disp, cap_todos)
    disp_arr = disponibilidade_diurna(disp, diurno)
    linhas = []
    for sid in media.columns:
        rot, kw, mont = tabela.get(sid, (f"fonte {sid} (desconhecida)", float("nan"), "desconhecida"))
        linhas.append({"id_fonte": sid, "arranjo": rot, "kw": kw, "montagem": mont,
                       "horas_paradas": int(n_paradas.get(sid, 0)),
                       "disponibilidade_diurna": round(float(disp_arr.get(sid, 0.0)), 4)})
    tab = pd.DataFrame(linhas).sort_values("id_fonte")
    montagens = {"fixo"} | ({"rastreador"} if site.get("incluir_rastreadores") else set())
    lim = site.get("disponibilidade_min_arranjo", 0.95)
    tab["selecionado"] = tab["montagem"].isin(montagens) & (tab["disponibilidade_diurna"] >= lim) & (tab["kw"] > 0)
    sel = tab[tab["selecionado"]]
    if sel.empty:
        raise RuntimeError(f"nenhum arranjo de {site['codigo']} atingiu a disponibilidade mínima")
    cap = pd.Series(sel["kw"].to_numpy(), index=sel["id_fonte"].to_numpy())
    pf = portfolio(media, disp, cap, cfg["qc"]["disponibilidade_min_hora"], cfg["qc"]["frac_capacidade_min"])
    pnom = float(cap.sum())
    out = pd.DataFrame(index=horas)
    out["y"] = pf["y"]
    out["p_kw"] = pf["y"] * pnom
    out["disponibilidade"] = pf["frac_capacidade"]
    out["n_unidades"] = pf["n_unidades"]
    meta = {
        "pnom_kw": round(pnom, 3),
        "unidade_pnom": "kW (soma das potências nominais dos arranjos fixos selecionados)",
        "n_unidades": int(len(sel)),
        "tabela_unidades": tab,
        "lat": site["lat"], "lon": site["lon"],
    }
    log.info("  %s: %d arranjos fixos selecionados (>= %.0f%% de disponibilidade), Pnom = %.1f kW",
             site["codigo"], len(sel), 100 * lim, pnom)
    return out, meta
