"""BRA: complexo fotovoltaico do Nordeste, geração horária verificada do ONS.

Fontes: ONS Dados Abertos (CC-BY 4.0)
  'Geração por Usina em Base Horária'  https://dados.ons.org.br/dataset/geracao-usina-2
      arquivos anuais até 2021 e mensais a partir de 2022, em Parquet (menores) ou CSV;
      val_geracao em MWmed (média horária em MW); din_instante em horário de Brasília, com o horário
      de verão enquanto ele existiu (até 16/02/2019): por isso fuso_dados = America/Sao_Paulo.
  'Restrição de operação por constrained-off de usinas fotovoltaicas, detalhamento por usina'
      https://dados.ons.org.br/dataset/restricao_coff_fotovoltaica_detail  (desde abr/2024)
      uma linha por usina e semi-hora; flg_geracaorestrita = 1 quando a geração foi limitada pelo ONS.
      As horas com alguma semi-hora limitada em alguma usina do conjunto saem da série (y = NaN) e
      ficam marcadas na coluna 'restrita'.
"""

from __future__ import annotations

import json
import logging

import numpy as np
import pandas as pd

from ..util import baixar_arquivo, nova_sessao

log = logging.getLogger("coleta")

BASE = "https://ons-aws-prod-opendata.s3.amazonaws.com/dataset/"
URL_GERACAO = BASE + "geracao_usina_2_ho/{nome}"
URL_CAPACIDADE = BASE + "capacidade-geracao/CAPACIDADE_GERACAO.csv"
URL_FATOR_CAP = BASE + "fator_capacidade_2_di/{nome}"
URL_COFF = BASE + "restricao_coff_fotovoltaica_detail_tm/{nome}"
INICIO_COFF = pd.Timestamp("2024-04-01")  # primeiro mês publicado do detalhamento por usina
COLS_COFF = ["din_instante", "id_ons", "nom_usina", "id_ons_conjuntousina", "nom_conjuntousina",
             "flg_geracaorestrita", "val_geracaoverificada", "val_geracaoestimada"]


def _nomes_coff(site: dict, ext: str = "parquet") -> list:
    ini = max(pd.Timestamp(site["inicio"]).replace(day=1), INICIO_COFF)
    fim = pd.Timestamp(site["fim"])
    if ini > fim:
        return []
    return [f"RESTRICAO_COFF_FOTOVOLTAICA_DETAIL_{p.year}_{p.month:02d}.{ext}"
            for p in pd.period_range(ini, fim, freq="M")]


def _nomes_geracao(site: dict, ext: str = "parquet") -> list:
    ini, fim = pd.Timestamp(site["inicio"]), pd.Timestamp(site["fim"])
    nomes = []
    for ano in range(ini.year, fim.year + 1):
        if ano <= 2021:
            nomes.append(f"GERACAO_USINA-2_{ano}.{ext}")
        else:
            for mes in range(1, 13):
                m0 = pd.Timestamp(year=ano, month=mes, day=1)
                if ini.replace(day=1) <= m0 <= fim:
                    nomes.append(f"GERACAO_USINA-2_{ano}_{mes:02d}.{ext}")
    return nomes


def baixar(site: dict, cfg: dict, pastas, fator_capacidade: bool = False, **_) -> None:
    sess = nova_sessao()
    pasta = pastas.bruto(site["codigo"])
    for nome in _nomes_geracao(site, "parquet"):
        destino = pasta / nome
        try:
            baixar_arquivo(URL_GERACAO.format(nome=nome), destino, sessao=sess, descricao=f"ONS {nome}")
        except Exception as e:  # noqa: BLE001
            log.warning("  parquet indisponível (%s); tentando CSV", e)
            nome_csv = nome.replace(".parquet", ".csv")
            baixar_arquivo(URL_GERACAO.format(nome=nome_csv), pasta / nome_csv, sessao=sess,
                           descricao=f"ONS {nome_csv}")
    baixar_arquivo(URL_CAPACIDADE, pasta / "CAPACIDADE_GERACAO.csv", sessao=sess,
                   descricao="ONS capacidade instalada (cadastro de usinas)")
    if site.get("restricao_ons", True):
        for nome in _nomes_coff(site, "parquet"):
            try:
                baixar_arquivo(URL_COFF.format(nome=nome), pasta / nome, sessao=sess, descricao=f"ONS {nome}")
            except Exception as e:  # noqa: BLE001
                log.warning("  parquet indisponível (%s); tentando CSV", e)
                nome_csv = nome.replace(".parquet", ".csv")
                baixar_arquivo(URL_COFF.format(nome=nome_csv), pasta / nome_csv, sessao=sess,
                               descricao=f"ONS {nome_csv}")
    if fator_capacidade:
        _baixar_fator_capacidade_filtrado(site, pasta, sess)
    _coordenadas_ons(site, pasta, sess)


def _coordenadas_ons(site: dict, pasta, sess) -> None:
    """Grava brutos/BRA/coordenadas.json com a subestação coletora do conjunto, tirada do dataset
    'Fator de Capacidade' do ONS (um dos últimos meses do período). O GFS e o processamento passam a
    usar esse ponto. Se não der, fica o lat/lon do config.yaml."""
    destino = pasta / "coordenadas.json"
    id_ons = str(site["id_ons"]).strip()
    if destino.exists():
        try:
            if json.loads(destino.read_text(encoding="utf-8")).get("id_ons") == id_ons:
                return
        except Exception:  # noqa: BLE001
            pass
    fim = pd.Timestamp(site["fim"]).to_period("M")
    meses = [p for p in (fim - k for k in range(3)) if p.year >= 2022]  # os anuais são grandes demais
    for p in meses:
        nome = f"FATOR_CAPACIDADE-2_{p.year}_{p.month:02d}.parquet"
        tmp = pasta / f"_coordenadas_{nome}"
        try:
            baixar_arquivo(URL_FATOR_CAP.format(nome=nome), tmp, sessao=sess,
                           descricao=f"ONS {nome} (coordenadas do conjunto)")
            df = pd.read_parquet(tmp)
        except Exception as e:  # noqa: BLE001
            log.warning("  coordenadas do ONS: %s indisponível (%s)", nome, e)
            continue
        finally:
            tmp.unlink(missing_ok=True)
        df.columns = [str(c).strip().lower() for c in df.columns]
        sel = None
        for col in ("id_ons", "id_ons_conjuntousina", "ceg"):
            if col in df.columns:
                m = df[col].astype(str).str.strip() == id_ons
                if m.any():
                    sel = df[m]
                    break
        if sel is None:
            log.warning("  coordenadas do ONS: %s não aparece em %s", id_ons, nome)
            continue
        for la, lo in (("val_latitudesecoletora", "val_longitudesecoletora"),
                       ("val_latitudepontoconexao", "val_longitudepontoconexao")):
            if la in sel.columns and lo in sel.columns:
                lat = pd.to_numeric(sel[la], errors="coerce").median()
                lon = pd.to_numeric(sel[lo], errors="coerce").median()
                if pd.notna(lat) and pd.notna(lon) and -35 < lat < 6 and -75 < lon < -30:
                    destino.write_text(json.dumps({"lat": round(float(lat), 6), "lon": round(float(lon), 6),
                                                   "id_ons": id_ons, "fonte": f"ONS {nome}, {la}/{lo}"}),
                                       encoding="utf-8")
                    log.info("  %s: coordenadas do ONS (%s) = (%.5f, %.5f)", site["codigo"],
                             la.replace("val_latitude", ""), lat, lon)
                    return
        log.warning("  coordenadas do ONS: %s sem latitude/longitude em %s", id_ons, nome)
    log.warning("  %s: mantidas as coordenadas do config.yaml (%.4f, %.4f)", site["codigo"], site["lat"], site["lon"])


def verificar(site: dict, cfg: dict, sess) -> str:
    ultimo = _nomes_geracao(site, "parquet")[-1]
    r = sess.head(URL_GERACAO.format(nome=ultimo), timeout=60)
    r.raise_for_status()
    txt = f"{ultimo}: {int(r.headers.get('Content-Length', 0)) / 1e6:.1f} MB"
    coff = _nomes_coff(site, "parquet")
    if coff and site.get("restricao_ons", True):
        r = sess.head(URL_COFF.format(nome=coff[-1]), timeout=60)
        r.raise_for_status()
        txt += f"; {coff[-1]}: {int(r.headers.get('Content-Length', 0)) / 1e6:.1f} MB"
    return txt


def _ler_coff(caminho) -> pd.DataFrame:
    if caminho.suffix == ".parquet":
        df = pd.read_parquet(caminho)
    else:
        df = pd.read_csv(caminho, sep=";", dtype=str)
    df.columns = [str(c).strip().lower() for c in df.columns]
    for c in COLS_COFF:
        if c not in df.columns:
            df[c] = None
    return df[COLS_COFF]


def restricoes(site: dict, pasta) -> tuple:
    """(Série horária UTC 'restrita', início, fim da cobertura) para o conjunto do site, ou None.

    Hora restrita = alguma semi-hora com flg_geracaorestrita = 1 em alguma usina do conjunto."""
    arqs = {}
    for nome in _nomes_coff(site, "parquet"):
        a = pasta / nome
        alt = pasta / nome.replace(".parquet", ".csv")
        if a.exists():
            arqs[nome] = a
        elif alt.exists():
            arqs[nome] = alt
    if not arqs:
        return None
    id_ons = str(site["id_ons"]).strip()
    base = str(site.get("nome_ons", "")).replace("Conj. ", "").strip().upper()
    partes = []
    for a in arqs.values():
        df = _ler_coff(a)
        ids = df["id_ons"].astype(str).str.strip()
        ids_cj = df["id_ons_conjuntousina"].astype(str).str.strip()
        nomes_cj = df["nom_conjuntousina"].astype(str).str.upper()
        sel = (ids == id_ons) | (ids_cj == id_ons)
        if not sel.any() and base:
            sel = nomes_cj.str.contains(base, regex=False, na=False)
        partes.append(df[sel])
    d = pd.concat(partes, ignore_index=True)
    if d.empty:
        log.warning("  %s: nenhuma linha de constrained-off para %s nos arquivos do ONS", site["codigo"], id_ons)
        return None
    d["din_instante"] = pd.to_datetime(d["din_instante"], errors="coerce")
    d["flg"] = pd.to_numeric(d["flg_geracaorestrita"], errors="coerce").fillna(0) > 0
    d = d.dropna(subset=["din_instante"])
    t = pd.DatetimeIndex(d["din_instante"]).tz_localize(site["fuso_dados"], ambiguous="NaT", nonexistent="NaT")
    ok = ~t.isna()
    t = t[ok].tz_convert("UTC")
    hora = t.tz_convert(site["fuso_lst"]).floor("h").tz_convert("UTC")  # semi-hora [t, t+30 min)
    r = pd.Series(d.loc[ok, "flg"].to_numpy(), index=hora).groupby(level=0).max()
    n_usinas = d["nom_usina"].nunique()
    log.info("  %s: constrained-off de %d usina(s) do conjunto, %s a %s; %d hora(s) com restrição",
             site["codigo"], n_usinas, r.index.min(), r.index.max(), int(r.sum()))
    return r, r.index.min(), r.index.max()


def _baixar_fator_capacidade_filtrado(site: dict, pasta, sess) -> None:
    """Opcional: lê em fluxo o 'Fator de Capacidade' (tem coordenadas e capacidade hora a hora)
    e guarda só as linhas do conjunto escolhido (evita gravar ~1,2 GB em disco)."""
    destino = pasta / f"fator_capacidade_{site['id_ons']}.csv"
    if destino.exists():
        log.info("  já existe: %s", destino.name)
        return
    ini, fim = pd.Timestamp(site["inicio"]), pd.Timestamp(site["fim"])
    nomes = []
    for ano in range(ini.year, fim.year + 1):
        if ano <= 2021:
            nomes.append(f"FATOR_CAPACIDADE_{ano}.csv")
        else:
            nomes += [f"FATOR_CAPACIDADE-2_{ano}_{m:02d}.csv" for m in range(1, 13)]
    cab = None
    linhas = []
    for nome in nomes:
        log.info("  filtrando %s em fluxo", nome)
        with sess.get(URL_FATOR_CAP.format(nome=nome), stream=True, timeout=120) as r:
            r.raise_for_status()
            for i, ln in enumerate(r.iter_lines(decode_unicode=False)):
                txt = ln.decode("utf-8", errors="replace")
                if i == 0:
                    cab = cab or txt
                    continue
                if f";{site['id_ons']};" in txt:
                    linhas.append(txt)
    tmp = destino.with_suffix(".part")
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(cab + "\n" + "\n".join(linhas) + "\n")
    tmp.replace(destino)
    log.info("  ok: %s (%d linhas)", destino.name, len(linhas))


def _ler_geracao(caminho, id_ons: str, nome_ons: str) -> pd.DataFrame:
    if caminho.suffix == ".parquet":
        df = pd.read_parquet(caminho)
    else:
        df = pd.read_csv(caminho, sep=";", dtype=str)
    df.columns = [str(c).strip().lower() for c in df.columns]
    if "id_ons" in df.columns:
        sel = df[df["id_ons"].astype(str).str.strip() == id_ons]
    else:
        sel = df.iloc[0:0]
    if sel.empty and "nom_usina" in df.columns:
        sel = df[df["nom_usina"].astype(str).str.strip() == nome_ons]
    sel = sel.copy()
    sel["din_instante"] = pd.to_datetime(sel["din_instante"], errors="coerce")
    sel["val_geracao"] = pd.to_numeric(sel["val_geracao"], errors="coerce")
    if "id_estado" not in sel.columns:
        sel["id_estado"] = None
    return sel[["din_instante", "val_geracao", "id_estado"]].dropna(subset=["din_instante"])


def horario(site: dict, cfg: dict, pastas, atributos_fn) -> tuple:
    pasta = pastas.bruto(site["codigo"])
    partes = []
    for nome in _nomes_geracao(site, "parquet"):
        caminho = pasta / nome
        if not caminho.exists():
            alt = pasta / nome.replace(".parquet", ".csv")
            if alt.exists():
                caminho = alt
            else:
                raise FileNotFoundError(f"falta {nome}; rode 'python coletar.py baixar --fontes ons'")
        partes.append(_ler_geracao(caminho, site["id_ons"], site.get("nome_ons", "")))
    df = pd.concat(partes, ignore_index=True)
    if df.empty:
        raise RuntimeError(f"nenhuma linha do ONS para {site['id_ons']} / {site.get('nome_ons')}")
    uf = df["id_estado"].dropna().astype(str).str.strip()
    uf = site.get("uf") or (uf.mode().iloc[0] if len(uf) else None)
    df = df.groupby("din_instante", as_index=False)["val_geracao"].mean()
    # Horário de Brasília com horário de verão (America/Sao_Paulo): a hora repetida no fim do
    # verão (16/02/2019 23:00) e a hora inexistente no início dele não têm instante UTC único;
    # viram NaT e são descartadas (são horas noturnas).
    t = pd.DatetimeIndex(df["din_instante"]).tz_localize(site["fuso_dados"], ambiguous="NaT",
                                                         nonexistent="NaT")
    validos = ~t.isna()
    if (~validos).any():
        log.info("  BRA: %d hora(s) ambígua(s)/inexistente(s) na troca do horário de verão descartada(s): %s",
                 int((~validos).sum()), ", ".join(str(x) for x in df.loc[~validos, "din_instante"].head(4)))
    t = t[validos].tz_convert("UTC")
    if site.get("rotulo_intervalo", "inicio") == "fim":
        t = t - pd.Timedelta(hours=1)
    serie = pd.Series(df.loc[validos, "val_geracao"].to_numpy(), index=t).sort_index()
    serie = serie[~serie.index.duplicated()]

    ini = pd.Timestamp(site["inicio"]).tz_localize(site["fuso_lst"]).tz_convert("UTC")
    fim = (pd.Timestamp(site["fim"]) + pd.Timedelta(days=1)).tz_localize(site["fuso_lst"]).tz_convert("UTC")
    horas = pd.date_range(ini, fim, freq="h", inclusive="left")
    mw = serie.reindex(horas)
    pnom_kw = float(site["pnom_kw"])
    out = pd.DataFrame(index=horas)
    out["p_kw"] = (mw * 1000.0).clip(lower=0)
    out["y"] = out["p_kw"] / pnom_kw
    out["disponibilidade"] = mw.notna().astype(float)
    res_coff = restricoes(site, pasta) if site.get("restricao_ons", True) else None
    if res_coff is not None:
        r, ini_c, fim_c = res_coff
        out["restrita"] = r.astype(bool).reindex(horas, fill_value=False).to_numpy(dtype=bool)
        out.loc[out["restrita"], ["p_kw", "y"]] = np.nan
        cobre = (out.index >= ini_c) & (out.index <= fim_c)

    meta = {
        "pnom_kw": pnom_kw,
        "unidade_pnom": "kW_ac (capacidade instalada informada pelo ONS)",
        "id_ons": site["id_ons"],
        "nome_ons": site.get("nome_ons"),
        "lat": site["lat"], "lon": site["lon"],
    }
    if res_coff is not None:
        dia = (mw > 0.01 * pnom_kw / 1000.0).to_numpy()  # horas com geração (proxy de horas diurnas)
        base_h = cobre & dia
        meta["restricao_ons_periodo"] = (f"{ini_c.tz_convert(site['fuso_lst']):%Y-%m-%d} a "
                                         f"{fim_c.tz_convert(site['fuso_lst']):%Y-%m-%d}")
        meta["pct_horas_com_geracao_restritas"] = round(
            100.0 * float(out.loc[base_h | (cobre & out["restrita"].to_numpy()), "restrita"].mean()), 2)
    cad = pasta / "CAPACIDADE_GERACAO.csv"
    if cad.exists():
        try:
            c = pd.read_csv(cad, sep=";", dtype=str)
            nome_base = str(site.get("nome_ons", "")).replace("Conj. ", "").upper()
            cad_uf = c[c["nom_tipousina"].str.contains("FOTOV", na=False)]
            if uf:
                cad_uf = cad_uf[cad_uf["id_estado"] == uf]
            if nome_base:
                cad_uf = cad_uf[cad_uf["nom_usina"].str.upper().str.contains(nome_base, na=False)]
            cad_uf = cad_uf.assign(mw=pd.to_numeric(cad_uf["val_potenciaefetiva"].str.replace(",", "."),
                                                    errors="coerce"))
            comp = cad_uf.groupby(["nom_usina", "ceg", "dat_entradaoperacao"], as_index=False)["mw"].sum()
            meta["composicao_cadastro_ons"] = comp
            meta["soma_potencia_efetiva_mw"] = round(float(comp["mw"].sum()), 3)
        except Exception as e:  # noqa: BLE001
            log.warning("  não consegui ler o cadastro de capacidade do ONS: %s", e)
    fc = pasta / f"fator_capacidade_{site['id_ons']}.csv"
    if fc.exists():
        f = pd.read_csv(fc, sep=";", dtype=str)
        for c in ("val_capacidadeinstalada", "val_latitudesecoletora", "val_longitudesecoletora"):
            f[c] = pd.to_numeric(f[c], errors="coerce")
        meta["capacidade_instalada_mw_min_max"] = (float(f["val_capacidadeinstalada"].min()),
                                                   float(f["val_capacidadeinstalada"].max()))
    log.info("  BRA: %s (%s), Pnom = %.1f MW, %d horas com dado",
             site.get("nome_ons"), site["id_ons"], pnom_kw / 1000, int(mw.notna().sum()))
    return out, meta
