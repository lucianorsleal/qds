"""HKG: 60 sistemas FV de telhado no campus da HKUST (Clear Water Bay, Hong Kong), Lin et al. (2025).

Fonte: Dryad, doi:10.5061/dryad.m37pvmd99 (CC0) — artigo: Scientific Data 12 (2025), s41597-025-04397-y
  Dataset.zip (296 MB):
    PV stations with panel level optimizer/Site level dataset/*.csv     37 estações, 15 min
    PV stations without panel level optimizer/Site level dataset/*.csv  23 estações, 1 h
    Metadata/PV generation system metadata.ttl   (Brick) potência nominal de cada estação
  Colunas: Time (hora local HKT), generation(kWh) no intervalo, power(W).
O Dryad protege os downloads com um desafio anti-robô, então o Dataset.zip é baixado pelo navegador
(https://datadryad.org/dataset/doi:10.5061/dryad.m37pvmd99) e salvo na pasta do coletar.py ou em
dados/brutos/HKG/; a coleta o move para dados/brutos/HKG/Dataset.zip.

Decisões (conferidas nos dados):
- Potência média do intervalo = generation(kWh) / duração; power(W) das estações de 15 min é uma leitura
  pontual (~3% abaixo da média) e não é usada.
- Rótulo: nas estações de 15 min (SolarEdge) o carimbo marca o INÍCIO do intervalo; nas de 1 h (SMA),
  o FIM. Com esses rótulos o centro da curva diária bate com o do céu claro (mediana +0,01 h e +0,04 h).
- As coordenadas do .ttl são aproximadas e espalhadas por Hong Kong, embora todas as estações fiquem no
  campus da HKUST; vale o ponto do config.yaml.
- Fora da carteira: estações cuja potência mudou no período (o .ttl só dá a final: Zone A2, ampliada
  em 2023, e Zone D), as "Flexible PV" (módulos flexíveis experimentais, saída irregular) e as com
  carimbos repetidos com valores diferentes em mais de 2% das linhas.
- Carteira: razão de somas sobre as estações com dado (y = soma da potência / soma da potência nominal
  delas), com as horas e os dias de estação parada mascarados, como no UKF.
"""

from __future__ import annotations

import logging
import re
import zipfile
from difflib import get_close_matches

import numpy as np
import pandas as pd

from ..agregacao import hora_de_inicio

log = logging.getLogger("coleta")

PAGINA = "https://datadryad.org/dataset/doi:10.5061/dryad.m37pvmd99"
URL_ZIP = "https://datadryad.org/downloads/file_stream/3462931"
TAMANHO_ZIP = 296120633
SHA256_ZIP = "737e63d1f4d2753c1122fc902102dcfc8b6c22055ef037ce44f18fdecd988c31"
_PASTA_SITES = "Site level dataset/"
_TTL = "PV generation system metadata.ttl"
EXCLUIR_PADRAO = ("Zone A2", "Zone D")


def _zip_ok(caminho) -> bool:
    return caminho.exists() and caminho.stat().st_size == TAMANHO_ZIP


def _achar_zip(pasta):
    """Dataset.zip em dados/brutos/HKG ou na pasta do coletar.py (qualquer .zip com o tamanho certo)."""
    from ..util import RAIZ

    if _zip_ok(pasta / "Dataset.zip"):
        return pasta / "Dataset.zip"
    for lugar in (pasta, RAIZ):
        for a in sorted(lugar.glob("*.zip")):
            if _zip_ok(a):
                return a
    return None


def verificar(site: dict, cfg: dict, sess) -> str:
    from ..util import RAIZ, Pastas

    pasta = Pastas(cfg["_pasta_dados"]).bruto(site["codigo"])
    a = _achar_zip(pasta)
    if a is not None:
        return f"{a.name} presente ({a.parent})"
    raise RuntimeError(f"falta o Dataset.zip (296 MB): baixe em {PAGINA} e salve em {RAIZ}")


def baixar(site: dict, cfg: dict, pastas, **_) -> None:
    from ..util import RAIZ

    pasta = pastas.bruto(site["codigo"])
    pasta.mkdir(parents=True, exist_ok=True)
    destino = pasta / "Dataset.zip"
    a = _achar_zip(pasta)
    if a is None:
        raise RuntimeError(
            "o Dryad bloqueia downloads automáticos. Abra " + PAGINA + " no navegador, clique em "
            f"'Dataset.zip' (296 MB) e salve o arquivo em {RAIZ}")
    if a != destino:
        a.replace(destino)
        log.info("  %s movido para %s", a.name, destino)
    else:
        log.info("  já existe: Dataset.zip (%.1f MB)", destino.stat().st_size / 1e6)


# ---------------------------------------------------------------------------
# Leitura
# ---------------------------------------------------------------------------
def _norm(nome: str) -> str:
    s = nome.lower().replace("centre", "center").replace("sports", "sport").replace("phrase", "phase")
    return re.sub(r"[^a-z0-9]", "", s)


def ler_ttl(texto: str) -> pd.DataFrame:
    """Uma linha por PV_Generation_System: nome, kWp, data de conexão, inclinação e azimute (texto)."""
    linhas = []
    for bloco in re.split(r"\n(?=pvsystem:)", texto):
        m = re.match(r"pvsystem:(\S+) a brick:PV_Generation_System", bloco)
        if not m:
            continue

        def campo(padrao):
            x = re.search(padrao, bloco, re.S)
            return x.group(1) if x else None

        kw = campo(r"ext:ratedPowerOutput\s*\[\s*brick:hasUnit unit:KW\s*;\s*brick:value\s+([-\d.]+)")
        linhas.append({"nome_ttl": m.group(1), "kwp": float(kw) if kw else np.nan,
                       "conexao": campo(r"ext:connectionDate\s*\[\s*brick:value\s+\"([^\"]+)\""),
                       "inclinacao": campo(r"ext:tiltAngle\s*\[\s*brick:value\s+\"([^\"]+)\""),
                       "azimute": campo(r"ext:azimuth\s*\[\s*brick:value\s+\"([^\"]+)\"")})
    return pd.DataFrame(linhas)


def _casar(nomes_arquivo: list, ttl: pd.DataFrame) -> dict:
    chaves = {_norm(n): n for n in ttl["nome_ttl"]}
    out = {}
    for n in nomes_arquivo:
        k = _norm(n)
        if k in chaves:
            out[n] = chaves[k]
            continue
        c = get_close_matches(k, list(chaves), n=1, cutoff=0.85)
        out[n] = chaves[c[0]] if c else None
    return out


def _ler_estacao(z: zipfile.ZipFile, membro: str) -> tuple:
    """(série de potência média em W indexada pelo carimbo local, passo em min, nº de carimbos repetidos
    com valores diferentes, nº de linhas)."""
    with z.open(membro) as f:
        d = pd.read_csv(f)
    d.columns = [str(c).strip() for c in d.columns]
    t = pd.to_datetime(d["Time"], format="mixed", errors="coerce")
    g = pd.to_numeric(d["generation(kWh)"], errors="coerce")
    s = pd.DataFrame({"t": t, "g": g}).dropna(subset=["t"])
    passo = s["t"].sort_values().diff().dropna().dt.total_seconds().div(60).round()
    passo = float(passo.mode().iloc[0]) if len(passo) else 60.0
    dup = s[s["t"].duplicated(keep=False)]
    conflito = dup.groupby("t")["g"].agg(lambda x: x.max() - x.min() > 1e-9) if not dup.empty else pd.Series(dtype=bool)
    ruins = set(conflito[conflito].index)
    s = s[~s["t"].isin(ruins)].drop_duplicates("t").set_index("t").sort_index()
    w = s["g"].where(s["g"] >= 0) * 1000.0 * 60.0 / passo  # kWh no intervalo -> W médio
    return w, passo, len(ruins), len(d)


def _rotulo(site: dict, passo: float) -> str:
    return str(site.get("rotulo_15min", "inicio")) if passo < 60 else str(site.get("rotulo_60min", "fim"))


def horario(site: dict, cfg: dict, pastas, atributos_fn) -> tuple:
    pasta = pastas.bruto(site["codigo"])
    arq = _achar_zip(pasta)
    if arq is None:
        raise FileNotFoundError(f"falta o Dataset.zip de Hong Kong; baixe em {PAGINA}")
    excluir = {_norm(x) for x in site.get("excluir_estacoes", EXCLUIR_PADRAO)}
    sem_flexiveis = bool(site.get("excluir_flexiveis", True))
    fuso_dados, fuso_lst = site.get("fuso_dados", "Etc/GMT-8"), site["fuso_lst"]
    ini = pd.Timestamp(site["inicio"]).tz_localize(fuso_lst).tz_convert("UTC")
    fim = (pd.Timestamp(site["fim"]) + pd.Timedelta(days=1)).tz_localize(fuso_lst).tz_convert("UTC")
    horas = pd.date_range(ini, fim, freq="h", inclusive="left")

    with zipfile.ZipFile(arq) as z:
        membros = [m for m in z.namelist() if _PASTA_SITES in m and m.lower().endswith(".csv")]
        ttl_m = next((m for m in z.namelist() if m.endswith(_TTL)), None)
        ttl = ler_ttl(z.read(ttl_m).decode("utf-8")) if ttl_m else pd.DataFrame(columns=["nome_ttl", "kwp"])
        nomes = {m: m.rsplit("/", 1)[-1][:-4].strip() for m in membros}
        casamento = _casar(list(nomes.values()), ttl)
        kwp_ttl = ttl.set_index("nome_ttl")["kwp"] if not ttl.empty else pd.Series(dtype=float)

        soma, cont, info = {}, {}, []
        for m in sorted(membros):
            nome = nomes[m]
            otimizador = "without panel" not in m
            reg = {"estacao": nome, "otimizador": otimizador, "nome_metadado": casamento.get(nome)}
            kwp = float(kwp_ttl.get(casamento.get(nome), np.nan)) if casamento.get(nome) else np.nan
            reg["kwp"] = kwp
            motivo = None
            if _norm(nome) in excluir:
                motivo = "potência mudou no período (o metadado só dá a final)"
            elif sem_flexiveis and "flexible" in nome.lower():
                motivo = "módulos flexíveis experimentais"
            elif not np.isfinite(kwp) or kwp <= 0:
                motivo = "sem potência nominal no metadado"
            w, passo, n_conf, n_lin = _ler_estacao(z, m)
            reg.update({"passo_min": passo, "rotulo": _rotulo(site, passo), "carimbos_conflitantes": n_conf})
            if motivo is None and n_conf > 0.02 * n_lin:
                motivo = f"{n_conf} carimbos repetidos com valores diferentes"
            w = w.where(w <= 1.25 * kwp * 1000.0)  # picos impossíveis
            reg["primeiro"] = w.first_valid_index()
            reg["ultimo"] = w.last_valid_index()
            reg["excluida"] = motivo or ""
            info.append(reg)
            if motivo:
                continue
            t = pd.DatetimeIndex(w.index).tz_localize(fuso_dados, ambiguous="NaT", nonexistent="NaT")
            ok = ~t.isna()
            t_utc = t[ok].tz_convert("UTC")
            h = hora_de_inicio(t_utc, reg["rotulo"], pd.Timedelta(minutes=passo), fuso_lst)
            serie = pd.Series(w.to_numpy()[ok], index=t_utc)
            g = serie.groupby(h)
            soma[nome] = g.sum(min_count=1)
            cont[nome] = g.count() * (passo / 60.0)  # fração da hora coberta
    tab = pd.DataFrame(info)
    usadas = tab.loc[tab["excluida"] == "", "estacao"].tolist()
    if not usadas:
        raise RuntimeError("HKG: nenhuma estação utilizável no Dataset.zip")
    for _, r in tab[tab["excluida"] != ""].iterrows():
        log.info("  HKG: fora da carteira: %s (%s)", r["estacao"], r["excluida"])

    cap = tab.set_index("estacao").loc[usadas, "kwp"].astype(float) * 1000.0  # W
    S = pd.DataFrame(soma).reindex(index=horas, columns=usadas)
    C = pd.DataFrame(cont).reindex(index=horas, columns=usadas).fillna(0.0)  # fração da hora com dado
    # média de W nas amostras = soma / nº de amostras; nº de amostras = cobertura * 60 / passo
    passos = tab.set_index("estacao").loc[usadas, "passo_min"].astype(float)
    n_am = C.mul(60.0 / passos, axis=1)
    media = S / n_am.where(n_am > 0)

    # estação parada: hora em ~0 enquanto a mediana das outras >= 0,2; dia com <= 5% da energia mediana
    y_i = media.div(cap, axis=1)
    med = y_i.median(axis=1, skipna=True)
    parada_h = y_i.le(0.02) & med.ge(0.2).to_numpy()[:, None]
    dia = horas.tz_convert(fuso_lst).floor("D")
    e_dia = (y_i * C).groupby(dia).sum(min_count=1)
    med_dia = e_dia.median(axis=1, skipna=True)
    parada_d = e_dia.le(0.05 * med_dia.to_numpy()[:, None]) & med_dia.ge(0.5).to_numpy()[:, None]
    parada = parada_h.to_numpy() | parada_d.reindex(dia).to_numpy(dtype=bool)
    media = media.mask(parada)
    C = C.mask(parada, 0.0).where(media.notna(), 0.0)

    c_w = cap.to_numpy()
    num = (media.fillna(0.0).to_numpy() * C.to_numpy()).sum(axis=1)  # W x fração de hora
    den = (C.to_numpy() * c_w[None, :]).sum(axis=1)                   # Wp x fração de hora
    primeiro = pd.to_datetime(tab.set_index("estacao").loc[usadas, "primeiro"])
    ultimo = pd.to_datetime(tab.set_index("estacao").loc[usadas, "ultimo"])
    p_ini = pd.DatetimeIndex(primeiro).tz_localize(fuso_dados).tz_convert("UTC") - pd.Timedelta(hours=1)
    p_fim = pd.DatetimeIndex(ultimo).tz_localize(fuso_dados).tz_convert("UTC")
    servico = (horas.to_numpy()[:, None] >= p_ini.to_numpy()[None, :]) & \
              (horas.to_numpy()[:, None] <= p_fim.to_numpy()[None, :])
    cap_serv = (servico * c_w[None, :]).sum(axis=1)
    with np.errstate(invalid="ignore", divide="ignore"):
        y = np.where(den > 0, num / den, np.nan)
        disp = np.where(cap_serv > 0, den / cap_serv, 0.0)
    disp = np.clip(disp, 0.0, 1.0)
    lim = float(site.get("disponibilidade_min_frota", 0.5))
    y = np.where(disp >= lim, y, np.nan)

    attrs = atributos_fn(horas)
    diurno = (attrs["zenite"] < cfg["qc"]["zenite_max_graus"]).to_numpy()
    serv_d = servico & diurno[:, None]
    n_serv = serv_d.sum(axis=0)
    cov = C.to_numpy()
    tab = tab.set_index("estacao")
    tab["disponibilidade_diurna_em_servico"] = np.nan
    tab.loc[usadas, "disponibilidade_diurna_em_servico"] = np.round(
        np.where(n_serv > 0, (cov * serv_d).sum(axis=0) / np.maximum(n_serv, 1), np.nan), 4)
    tab["horas_paradas_mascaradas"] = 0
    tab.loc[usadas, "horas_paradas_mascaradas"] = (parada & diurno[:, None]).sum(axis=0)
    for c in ("primeiro", "ultimo"):
        tab[c] = pd.to_datetime(tab[c]).dt.strftime("%Y-%m-%d %H:%M")
    tab_out = tab.reset_index()

    out = pd.DataFrame(index=horas)
    out["y"] = y
    out["capacidade_kw"] = den / 1000.0
    out["p_kw"] = out["y"] * out["capacidade_kw"]
    out["disponibilidade"] = disp
    out["n_unidades"] = np.round(cov.sum(axis=1), 1)
    pos = cap_serv[diurno & (cap_serv > 0)]
    meta = {
        "pnom_kw": round(float(np.mean(pos)) / 1000.0, 2) if pos.size else float(c_w.sum() / 1000.0),
        "unidade_pnom": "kWp (potência nominal média das estações em serviço; y = potência / kWp das estações com dado)",
        "n_unidades": len(usadas), "n_sistemas": len(usadas),
        "tabela_unidades": tab_out,
        "lat": site["lat"], "lon": site["lon"],
        "capacidade_total_kwp": round(float(c_w.sum() / 1000.0), 2),
        "disponibilidade_frota_diurna_media": round(float(np.mean(disp[diurno])), 4),
        "estacoes_excluidas": "; ".join(f"{i} ({r})" for i, r in tab.loc[tab["excluida"] != "", "excluida"].items()),
    }
    log.info("  HKG: %d estações na carteira (%.0f kWp), %d fora; disponibilidade diurna média %.1f%%",
             len(usadas), c_w.sum() / 1000.0, int((tab["excluida"] != "").sum()),
             100 * meta["disponibilidade_frota_diurna_media"])
    return out, meta
