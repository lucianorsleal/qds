"""UKF: frota residencial de uma região da Grã-Bretanha (UK PV, Open Climate Fix / Sheffield Solar).

Fonte: https://huggingface.co/datasets/openclimatefix/uk_pv  (CC-BY 4.0)
O acesso exige login no Hugging Face: aceitar as condições na página do dataset e criar um token de
leitura, salvo em 'hf_token.txt' na pasta do coletar.py (ou na variável de ambiente HF_TOKEN).

Arquivos usados:
  metadata.csv   ss_id, start/end_datetime_GMT (1ª e última leitura de 30 min), latitude_rounded,
                 longitude_rounded (~1 km), orientation, tilt, kWp
  bad_data.csv   ss_id, start/end_datetime_GMT (vazio = até o fim), reason
  30_minutely/year=AAAA/month=MM/data.parquet   ss_id, datetime_GMT (FIM do intervalo, UTC),
                 generation_Wh (energia no intervalo)

Região: por padrão, o círculo de raio 'raio_km' com mais sistemas residenciais ativos em todo o
período (centro escolhido entre as próprias posições dos sistemas). Para fixar o centro, use
'centro_regiao: [lat, lon]' no config.yaml. A escolha fica em brutos/UKF/regiao.json.
Carteira: a mesma razão de somas de Utrecht (potência por kWp dos sistemas com dado em cada hora).
"""

from __future__ import annotations

import json
import logging
import os

import numpy as np
import pandas as pd

from ..agregacao import AcumuladorHorario, hora_de_inicio
from ..util import RAIZ, baixar_arquivo, nova_sessao
from .utrecht import _em_servico, _mascarar_paradas

log = logging.getLogger("coleta")

REPO = "openclimatefix/uk_pv"
URL = "https://huggingface.co/datasets/" + REPO + "/resolve/main/{caminho}"
PASSO = pd.Timedelta(minutes=30)


# ---------------------------------------------------------------------------
# Acesso
# ---------------------------------------------------------------------------
def _token() -> str:
    tok = os.environ.get("HF_TOKEN", "").strip()
    if tok:
        return tok
    for arq in (RAIZ / "hf_token.txt", RAIZ / "hf_token.txt.txt"):
        if arq.exists():
            tok = arq.read_text(encoding="utf-8-sig").strip().splitlines()[0].strip() if arq.stat().st_size else ""
            if tok:
                return tok
    raise RuntimeError(
        "UK PV exige um token do Hugging Face. Entre em huggingface.co, aceite as condições em "
        f"https://huggingface.co/datasets/{REPO}, crie um token de leitura (Settings > Access Tokens) e "
        f"salve-o em {RAIZ / 'hf_token.txt'}")


def _sessao():
    s = nova_sessao()
    s.headers["Authorization"] = f"Bearer {_token()}"
    return s


def _checar_acesso(sess) -> None:
    r = sess.head(URL.format(caminho="metadata.csv"), allow_redirects=True, timeout=60)
    if r.status_code in (401, 403):
        raise RuntimeError(f"Hugging Face recusou o acesso (HTTP {r.status_code}): confira se o token em "
                           f"hf_token.txt é válido e se você aceitou as condições em "
                           f"https://huggingface.co/datasets/{REPO}")
    r.raise_for_status()


def verificar(site: dict, cfg: dict, sess) -> str:
    s = _sessao()
    _checar_acesso(s)
    return "token aceito; metadata.csv acessível"


# ---------------------------------------------------------------------------
# Metadados e escolha da região
# ---------------------------------------------------------------------------
def ler_metadados(caminho) -> pd.DataFrame:
    m = pd.read_csv(caminho)
    m.columns = [str(c).strip() for c in m.columns]
    m["ss_id"] = pd.to_numeric(m["ss_id"], errors="coerce").astype("Int64")
    m = m.dropna(subset=["ss_id"]).copy()
    m["ss_id"] = m["ss_id"].astype("int64")
    for c in ("latitude_rounded", "longitude_rounded", "kWp", "orientation", "tilt"):
        if c in m.columns:
            m[c] = pd.to_numeric(m[c], errors="coerce")
    for c in ("start_datetime_GMT", "end_datetime_GMT"):
        if c in m.columns:
            m[c] = pd.to_datetime(m[c], utc=True, errors="coerce")
    m = m.rename(columns={"start_datetime_GMT": "begin_ts", "end_datetime_GMT": "end_ts"})
    return m.drop_duplicates("ss_id").set_index("ss_id")


def _dist_km(lat1, lon1, lat2, lon2):
    r = np.pi / 180.0
    a = (np.sin((lat2 - lat1) * r / 2) ** 2
         + np.cos(lat1 * r) * np.cos(lat2 * r) * np.sin((lon2 - lon1) * r / 2) ** 2)
    return 2 * 6371.0 * np.arcsin(np.sqrt(np.clip(a, 0, 1)))


def _periodo_utc(site):
    ini = pd.Timestamp(site["inicio"]).tz_localize(site["fuso_lst"]).tz_convert("UTC")
    fim = (pd.Timestamp(site["fim"]) + pd.Timedelta(days=1)).tz_localize(site["fuso_lst"]).tz_convert("UTC")
    return ini, fim


def candidatos(meta: pd.DataFrame, site: dict) -> pd.DataFrame:
    """Sistemas residenciais com coordenadas e ativos (pelo metadata) em todo o período."""
    ini, fim = _periodo_utc(site)
    folga = pd.Timedelta(days=int(site.get("folga_dias_periodo", 31)))
    kmin, kmax = site.get("kwp_faixa", [0.5, 20.0])
    c = meta[np.isfinite(meta["latitude_rounded"]) & np.isfinite(meta["longitude_rounded"])
             & meta["kWp"].between(kmin, kmax)]
    c = c[(c["begin_ts"] <= ini + folga) & (c["end_ts"] >= fim - folga)]
    return c


def escolher_regiao(meta: pd.DataFrame, site: dict) -> dict:
    raio = float(site.get("raio_km", 25.0))
    c = candidatos(meta, site)
    if c.empty:
        raise RuntimeError("UK PV: nenhum sistema ativo em todo o período com as regras do config.yaml")
    lat = c["latitude_rounded"].to_numpy()
    lon = c["longitude_rounded"].to_numpy()
    if site.get("centro_regiao"):
        clat, clon = (float(v) for v in site["centro_regiao"])
        regra = "centro fixo no config.yaml"
    else:
        # centro = posição de sistema com mais vizinhos no raio (em blocos, para caber na memória)
        n = len(c)
        melhor, idx = -1, 0
        for i0 in range(0, n, 500):
            d = _dist_km(lat[i0:i0 + 500, None], lon[i0:i0 + 500, None], lat[None, :], lon[None, :])
            cont = (d <= raio).sum(axis=1)
            j = int(np.argmax(cont))
            if cont[j] > melhor:
                melhor, idx = int(cont[j]), i0 + j
        viz = _dist_km(lat[idx], lon[idx], lat, lon) <= raio
        clat, clon = float(lat[viz].mean()), float(lon[viz].mean())  # recentra na média dos vizinhos
        regra = f"círculo de {raio:.0f} km com mais sistemas ativos em todo o período"
    d = _dist_km(clat, clon, lat, lon)
    ids = c.index[d <= raio].tolist()
    # guarda um conjunto mais largo (2x o raio, sem exigir o período inteiro) para não precisar
    # baixar de novo se a regra mudar
    todos = meta[np.isfinite(meta["latitude_rounded"]) & np.isfinite(meta["longitude_rounded"])]
    d2 = _dist_km(clat, clon, todos["latitude_rounded"].to_numpy(), todos["longitude_rounded"].to_numpy())
    largos = todos.index[d2 <= 2 * raio].tolist()
    return {"centro_lat": round(clat, 4), "centro_lon": round(clon, 4), "raio_km": raio, "regra": regra,
            "ss_ids": [int(i) for i in ids], "ss_ids_guardados": [int(i) for i in largos],
            "n_sistemas": len(ids), "kwp_total": round(float(c.loc[ids, "kWp"].sum()), 2)}


# ---------------------------------------------------------------------------
# Download
# ---------------------------------------------------------------------------
def _meses(site) -> list:
    ini, fim = pd.Timestamp(site["inicio"]), pd.Timestamp(site["fim"])
    # a 1ª meia hora do mês (00:30 GMT do dia 1) fica no arquivo do próprio mês; o último intervalo do
    # período local pode cair no mês seguinte em UTC: inclui um mês de folga em cada ponta
    return list(pd.period_range(ini - pd.DateOffset(months=1), fim + pd.DateOffset(months=1), freq="M"))


def _caminho_mes(sess, p: pd.Period) -> str:
    for mes in (f"{p.month:02d}", f"{p.month}"):
        cam = f"30_minutely/year={p.year}/month={mes}/data.parquet"
        r = sess.head(URL.format(caminho=cam), allow_redirects=True, timeout=60)
        if r.status_code == 200:
            return cam
    return ""


def baixar(site: dict, cfg: dict, pastas, **_) -> None:
    sess = _sessao()
    _checar_acesso(sess)
    pasta = pastas.bruto(site["codigo"])
    baixar_arquivo(URL.format(caminho="metadata.csv"), pasta / "metadata.csv", sessao=sess,
                   descricao="UK PV metadata.csv")
    baixar_arquivo(URL.format(caminho="bad_data.csv"), pasta / "bad_data.csv", sessao=sess,
                   descricao="UK PV bad_data.csv")
    meta = ler_metadados(pasta / "metadata.csv")
    arq_reg = pasta / "regiao.json"
    reg = escolher_regiao(meta, site)
    if arq_reg.exists():
        antigo = json.loads(arq_reg.read_text(encoding="utf-8"))
        if set(reg["ss_ids_guardados"]) - set(antigo.get("ss_ids_guardados", [])):
            log.warning("  UK PV: a região mudou; os meses já recortados serão baixados de novo")
            for a in (pasta / "30min").glob("*.parquet"):
                a.unlink()
    arq_reg.write_text(json.dumps(reg, indent=1), encoding="utf-8")
    (pasta / "coordenadas.json").write_text(json.dumps({"lat": reg["centro_lat"], "lon": reg["centro_lon"]}),
                                            encoding="utf-8")
    log.info("  UK PV: região %s, centro (%.4f, %.4f), %d sistemas, %.1f kWp", reg["regra"], reg["centro_lat"],
             reg["centro_lon"], reg["n_sistemas"], reg["kwp_total"])
    guardar = set(reg["ss_ids_guardados"])
    sub = pasta / "30min"
    sub.mkdir(exist_ok=True)
    tmp_dir = pasta / "_tmp"
    tmp_dir.mkdir(exist_ok=True)
    for p in _meses(site):
        destino = sub / f"{p.year}_{p.month:02d}.parquet"
        if destino.exists():
            log.info("  já existe: %s", destino.name)
            continue
        cam = _caminho_mes(sess, p)
        if not cam:
            log.warning("  UK PV: sem arquivo de 30 min para %s", p)
            continue
        tmp = tmp_dir / f"{p.year}_{p.month:02d}_completo.parquet"
        baixar_arquivo(URL.format(caminho=cam), tmp, sessao=sess, descricao=f"UK PV {cam}", timeout=120)
        import pyarrow.dataset as ds
        import pyarrow.parquet as pq

        tab = ds.dataset(str(tmp), format="parquet").to_table(
            filter=ds.field("ss_id").isin(sorted(guardar)))
        pq.write_table(tab, destino.with_suffix(".tmp"))
        destino.with_suffix(".tmp").replace(destino)
        tmp.unlink()
        log.info("  recorte %s: %d linhas de %d sistemas", destino.name, tab.num_rows,
                 len(set(tab.column("ss_id").to_pylist())) if tab.num_rows else 0)


# ---------------------------------------------------------------------------
# Série horária
# ---------------------------------------------------------------------------
def _ler_bad(caminho) -> pd.DataFrame:
    if not caminho.exists():
        return pd.DataFrame(columns=["ss_id", "ini", "fim"])
    b = pd.read_csv(caminho)
    b.columns = [str(c).strip() for c in b.columns]
    b["ss_id"] = pd.to_numeric(b["ss_id"], errors="coerce")
    b["ini"] = pd.to_datetime(b.get("start_datetime_GMT"), utc=True, errors="coerce")
    b["fim"] = pd.to_datetime(b.get("end_datetime_GMT"), utc=True, errors="coerce")
    return b.dropna(subset=["ss_id"])[["ss_id", "ini", "fim"]]


def horario(site: dict, cfg: dict, pastas, atributos_fn) -> tuple:
    pasta = pastas.bruto(site["codigo"])
    arq_reg = pasta / "regiao.json"
    if not arq_reg.exists() or not (pasta / "metadata.csv").exists():
        raise FileNotFoundError("falta o UK PV; rode 'python coletar.py baixar --fontes ukpv'")
    reg = json.loads(arq_reg.read_text(encoding="utf-8"))
    meta = ler_metadados(pasta / "metadata.csv")
    ids = [i for i in reg["ss_ids"] if i in meta.index]
    cap_w = (meta.loc[ids, "kWp"] * 1000.0).astype(float)
    ini, fim = _periodo_utc(site)

    arqs = sorted((pasta / "30min").glob("*.parquet"))
    if not arqs:
        raise FileNotFoundError("nenhum recorte de 30 min do UK PV; rode 'python coletar.py baixar --fontes ukpv'")
    bad = _ler_bad(pasta / "bad_data.csv")
    bad = bad[bad["ss_id"].isin(ids)]
    acc = AcumuladorHorario()
    paradas = pd.Series(0, index=pd.Index(ids), dtype="int64")
    n_bad = 0
    for a in arqs:  # mês a mês, para caber na memória
        d = pd.read_parquet(a, columns=["ss_id", "datetime_GMT", "generation_Wh"])
        d = d[d["ss_id"].isin(ids)].copy()
        if d.empty:
            continue
        d["t"] = pd.to_datetime(d["datetime_GMT"], utc=True, errors="coerce")
        d = d.dropna(subset=["t"])
        d = d[(d["t"] > ini) & (d["t"] <= fim)]
        if d.empty:
            continue
        g = pd.to_numeric(d["generation_Wh"], errors="coerce")
        kwp = d["ss_id"].map(meta["kWp"])
        # limpeza recomendada no cartão do dataset: negativos e mais de 750 Wh por kWp em 30 min
        d["w"] = (g * 2.0).where((g >= 0) & (g <= 750.0 * kwp))  # Wh em 30 min -> W médio
        larga = d.pivot_table(index="t", columns="ss_id", values="w", aggfunc="mean").sort_index()
        larga.columns = [int(c) for c in larga.columns]
        for _, r in bad[bad["ss_id"].isin(larga.columns)].iterrows():
            m = np.ones(len(larga), dtype=bool)
            if pd.notna(r["ini"]):
                m &= larga.index >= r["ini"]
            if pd.notna(r["fim"]):
                m &= larga.index <= r["fim"]
            if m.any():
                c = int(r["ss_id"])
                n_bad += int(larga.loc[m, c].notna().sum())
                larga.loc[m, c] = np.nan
        larga, par = _mascarar_paradas(larga.astype("float32"), cap_w)
        paradas = paradas.add(pd.Series(par, index=larga.columns), fill_value=0)
        acc.adicionar(larga, hora_de_inicio(larga.index, "fim", PASSO, site["fuso_lst"]))
    if acc.soma is None:
        raise RuntimeError("UK PV: nenhuma leitura dos sistemas da região no período")

    horas = pd.date_range(ini, fim, freq="h", inclusive="left")
    soma = acc.soma.reindex(horas)
    cont = acc.cont.reindex(horas).fillna(0.0)
    cols = [c for c in soma.columns if c in cap_w.index]
    attrs = atributos_fn(horas)
    diurno = (attrs["zenite"] < cfg["qc"]["zenite_max_graus"]).to_numpy()
    servico = _em_servico(horas, meta, cols, PASSO)
    c_w = cap_w.reindex(cols).to_numpy()
    num = soma[cols].fillna(0.0).to_numpy().sum(axis=1)
    den = (cont[cols].to_numpy() * c_w[None, :]).sum(axis=1)  # Wp x amostras
    cap_serv_w = (servico[cols].to_numpy(dtype=bool) * c_w[None, :]).sum(axis=1)
    with np.errstate(invalid="ignore", divide="ignore"):
        y = np.where(den > 0, num / den, np.nan)
        disp = np.where(cap_serv_w > 0, den / (2.0 * cap_serv_w), 0.0)
    disp = np.clip(disp, 0.0, 1.0)
    lim_frota = float(site.get("disponibilidade_min_frota", 0.5))
    y = np.where(disp >= lim_frota, y, np.nan)

    disp_h = (cont[cols] / 2.0).clip(upper=1.0).to_numpy()
    serv_d = servico[cols].to_numpy(dtype=bool) & diurno[:, None]
    n_serv = serv_d.sum(axis=0)
    tab = meta.loc[cols, ["latitude_rounded", "longitude_rounded", "kWp", "orientation", "tilt",
                          "begin_ts", "end_ts"]].copy()
    tab["disponibilidade_diurna_em_servico"] = np.round(
        np.where(n_serv > 0, (disp_h * serv_d).sum(axis=0) / np.maximum(n_serv, 1), np.nan), 4)
    tab["meias_horas_parado_mascaradas"] = paradas.reindex(cols).fillna(0).astype(int).to_numpy()
    tab_out = tab.reset_index()
    for c in ("begin_ts", "end_ts"):
        tab_out[c] = tab_out[c].dt.strftime("%Y-%m-%d %H:%M")

    w = cap_w.reindex(cols).to_numpy()
    lat = float(np.average(tab["latitude_rounded"], weights=w))
    lon = float(np.average(tab["longitude_rounded"], weights=w))
    out = pd.DataFrame(index=horas)
    out["y"] = y
    out["capacidade_kw"] = cap_serv_w / 1000.0
    out["p_kw"] = out["y"] * out["capacidade_kw"]
    out["disponibilidade"] = disp
    out["n_unidades"] = (cont[cols].to_numpy().sum(axis=1) / 2.0).round(1)
    pnom = float(np.mean(cap_serv_w[cap_serv_w > 0]) / 1000.0)
    info = {
        "pnom_kw": round(pnom, 3),
        "unidade_pnom": "kWp (capacidade DC média em serviço; y = potência por kWp dos sistemas com dado)",
        "n_unidades": len(cols), "n_sistemas": len(cols),
        "tabela_unidades": tab_out,
        "lat": round(lat, 5), "lon": round(lon, 5),
        "regiao": f"{reg['regra']}; centro ({reg['centro_lat']}, {reg['centro_lon']}), raio {reg['raio_km']} km",
        "capacidade_total_kwp": round(float(cap_w.sum() / 1000.0), 2),
        "disponibilidade_frota_diurna_media": round(float(disp[diurno].mean()), 4),
        "inclinacao_ref": round(float(np.average(tab["tilt"].fillna(tab["tilt"].median()), weights=w)), 1),
        "azimute_ref": round(float(np.average(tab["orientation"].fillna(180.0), weights=w)), 1),
    }
    log.info("  UKF: %d sistemas, %.1f kWp, centróide (%.4f, %.4f); %d leituras do bad_data.csv removidas; "
             "disponibilidade média da frota nas horas diurnas %.1f%%", len(cols), info["capacidade_total_kwp"],
             lat, lon, n_bad, 100 * info["disponibilidade_frota_diurna_media"])
    return out, info
