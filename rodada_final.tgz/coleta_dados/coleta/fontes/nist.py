"""GTB: arranjo 'Ground' do campus do NIST em Gaithersburg, MD (EUA).

Fonte: https://pvdata.nist.gov  (doi:10.18434/M3S67G)
Os arquivos anuais 'onemin-Ground-AAAA.zip' (médias de 1 min) ficam no Box do NIST.
O site entrega, via socket.io, um token de leitura do Box e o id de cada arquivo;
este módulo reproduz esse fluxo ('Bulk Download' -> '1-min avg.').
Carimbo de tempo: hora padrão local (EST, UTC-5, sem horário de verão).
"""

from __future__ import annotations

import io
import json
import logging
import re
import time
import zipfile

import pandas as pd

from ..agregacao import AcumuladorHorario, hora_de_inicio
from ..util import baixar_arquivo, nova_sessao

log = logging.getLogger("coleta")

WS_URL = "wss://pvdata.nist.gov/socket.io/?EIO=4&transport=websocket"
BOX_API = "https://api.box.com/2.0/files/{id}?fields=download_url,name,size"
# ids observados em out/2026 (usados só se o site não responder ao pedido de 'bulk boxfile')
IDS_CONHECIDOS = {2015: "500736558308", 2016: "500741050416", 2017: "500737992340", 2018: "501051140107"}

INSTRUCOES_MANUAIS = """\
Download manual do NIST (se o automático falhar):
  1. abra https://pvdata.nist.gov
  2. escolha a localização 'Ground' e uma data qualquer dentro do ano desejado
  3. em 'Downloads' selecione '1-min avg.' e clique em 'Bulk Download'
  4. salve o arquivo como {destino}"""


def anos(site: dict) -> list:
    return list(range(pd.Timestamp(site["inicio"]).year, pd.Timestamp(site["fim"]).year + 1))


def arquivos(site: dict, pastas) -> dict:
    return {a: pastas.bruto(site["codigo"]) / f"onemin-Ground-{a}.zip" for a in anos(site)}


class _ClienteNIST:
    """Cliente mínimo do socket.io v4 (Engine.IO v4) usado pelo pvdata.nist.gov."""

    def __init__(self, timeout: int = 30):
        import websocket  # pacote websocket-client

        self.ws = websocket.create_connection(WS_URL, timeout=timeout, origin="https://pvdata.nist.gov",
                                              header=["User-Agent: Mozilla/5.0 (coleta-dados)"])
        self.token = None
        self._abrir()

    def _abrir(self):
        msg = self.ws.recv()
        if not msg.startswith("0"):
            raise IOError(f"handshake inesperado: {msg[:80]}")
        self.ws.send("40")
        self._esperar(lambda ev, d: ev == "__conectado__")
        self._emitir("get box token", {})
        self.token = self._esperar(lambda ev, d: ev == "box token")

    def _emitir(self, evento, dados):
        self.ws.send("42" + json.dumps([evento, dados]))

    def _esperar(self, cond, limite_s: float = 60):
        t0 = time.time()
        while time.time() - t0 < limite_s:
            msg = self.ws.recv()
            if msg == "2":
                self.ws.send("3")
                continue
            if msg.startswith("40"):
                if cond("__conectado__", None):
                    return True
                continue
            if msg.startswith("42"):
                ev, dados = json.loads(msg[2:])
                if cond(ev, dados):
                    return dados
        raise TimeoutError("o servidor do NIST não respondeu a tempo")

    def boxfile(self, ano: int, local: str = "Ground", conjunto: str = "1-min-avg") -> str:
        data = pd.Timestamp(year=ano, month=6, day=1, hour=5).strftime("%Y-%m-%dT%H:%M:%S.000Z")
        self._emitir("get bulk boxfile", {"date": data, "location": local, "dataset": conjunto})
        resp = self._esperar(lambda ev, d: ev == "bulk boxfile")
        if not resp or not resp.get("boxfile"):
            raise IOError(f"o NIST não retornou arquivo para {local} {ano}")
        return str(resp["boxfile"])

    def fechar(self):
        try:
            self.ws.close()
        except Exception:  # noqa: BLE001
            pass


def verificar(site: dict, cfg: dict, sess) -> str:
    c = _ClienteNIST()
    fid = c.boxfile(2016)
    r = sess.get(BOX_API.format(id=fid), headers={"Authorization": f"Bearer {c.token['access_token']}"},
                 timeout=60)
    c.fechar()
    r.raise_for_status()
    j = r.json()
    return f"{j.get('name')} ({j.get('size', 0) / 1e6:.1f} MB)"


def baixar(site: dict, cfg: dict, pastas, **_) -> None:
    pendentes = {a: d for a, d in arquivos(site, pastas).items() if not d.exists()}
    if not pendentes:
        for d in arquivos(site, pastas).values():
            log.info("  já existe: %s", d.name)
        return
    cli = _ClienteNIST()
    sess = nova_sessao()
    try:
        for ano, destino in pendentes.items():
            try:
                fid = cli.boxfile(ano)
            except Exception as e:  # noqa: BLE001
                fid = IDS_CONHECIDOS.get(ano)
                log.warning("  pedido do arquivo %d falhou (%s); usando id conhecido %s", ano, e, fid)
            r = sess.get(BOX_API.format(id=fid), headers={"Authorization": f"Bearer {cli.token['access_token']}"},
                         timeout=60)
            r.raise_for_status()
            info = r.json()
            if not info.get("download_url"):
                raise IOError(f"Box não retornou link de download para {fid}: {info}")
            if info.get("name") and info["name"] != destino.name:
                log.warning("  nome no Box (%s) difere do esperado (%s)", info["name"], destino.name)
            baixar_arquivo(info["download_url"], destino, tamanho_esperado=info.get("size"), sessao=sess,
                           descricao=f"NIST {info.get('name', destino.name)}")
    except Exception:
        for destino in pendentes.values():
            if not destino.exists():
                log.error(INSTRUCOES_MANUAIS.format(destino=destino))
        raise
    finally:
        cli.fechar()


# ---------------------------------------------------------------------------
# Leitura dos zips
# ---------------------------------------------------------------------------
def _ler_membro(z: zipfile.ZipFile, membro: str, colunas_potencia: list) -> pd.DataFrame:
    """Lê um CSV de dentro do zip do NIST (cabeçalho simples ou TOA5 da Campbell)."""
    import gzip

    def abrir():
        f = z.open(membro)
        if membro.lower().endswith(".gz"):
            f = gzip.open(f)
        return io.TextIOWrapper(f, encoding="utf-8", errors="replace", newline="")

    with abrir() as fh:
        primeira = fh.readline()
    skip = [0, 2, 3] if "TOA5" in primeira else None
    with abrir() as fh:
        cab = pd.read_csv(fh, skiprows=skip, nrows=0).columns
    mapa = {str(c).strip().strip('"'): c for c in cab}
    col_t = next((mapa[c] for c in mapa if c.upper() == "TIMESTAMP"), None)
    if col_t is None:
        col_t = next((mapa[c] for c in mapa if re.search(r"time|date", c, re.I)), None)
    if col_t is None:
        raise ValueError("coluna de tempo não encontrada")
    usar = [col_t] + [mapa[c] for c in colunas_potencia if c in mapa]
    if len(usar) == 1:
        raise ValueError(f"nenhuma coluna de potência {colunas_potencia}")
    with abrir() as fh:
        df = pd.read_csv(fh, skiprows=skip, usecols=usar, low_memory=False)
    df = df.rename(columns={col_t: "TIMESTAMP", **{mapa[c]: c for c in colunas_potencia if c in mapa}})
    df["TIMESTAMP"] = pd.to_datetime(df["TIMESTAMP"], errors="coerce")
    for c in df.columns[1:]:
        df[c] = pd.to_numeric(df[c], errors="coerce").astype("float32")
    return df.dropna(subset=["TIMESTAMP"])


def horario(site: dict, cfg: dict, pastas, atributos_fn) -> tuple:
    cols_pot = site.get("coluna_potencia", ["PwrMtrP_kW_Avg", "InvPAC_kW_Avg"])
    acc = AcumuladorHorario()
    usadas = {}
    passo = pd.Timedelta(minutes=1)
    for ano, caminho in arquivos(site, pastas).items():
        if not caminho.exists():
            raise FileNotFoundError(f"falta {caminho.name}; rode 'python coletar.py baixar --fontes nist'")
        log.info("  lendo %s", caminho.name)
        partes = []

        def ler_zip(z: zipfile.ZipFile):
            for m in sorted(z.namelist()):
                if m.lower().endswith(".zip"):  # zips mensais dentro do anual
                    with zipfile.ZipFile(io.BytesIO(z.read(m))) as z2:
                        ler_zip(z2)
                elif m.lower().endswith((".csv", ".csv.gz", ".dat", ".txt")):
                    try:
                        partes.append(_ler_membro(z, m, cols_pot))
                    except Exception as e:  # noqa: BLE001
                        log.warning("    ignorando %s: %s", m, e)

        with zipfile.ZipFile(caminho) as z:
            ler_zip(z)
        if not partes:
            raise RuntimeError(f"nenhum CSV legível em {caminho.name}")
        df = pd.concat(partes, ignore_index=True).drop_duplicates("TIMESTAMP").set_index("TIMESTAMP").sort_index()
        # escolhe a primeira coluna disponível na ordem de preferência; completa com as seguintes
        pot = None
        for c in cols_pot:
            if c in df.columns:
                usadas[c] = usadas.get(c, 0) + int(df[c].notna().sum())
                pot = df[c] if pot is None else pot.fillna(df[c])
        if pot is None:
            raise RuntimeError(f"nenhuma coluna de potência {cols_pot} em {caminho.name}")
        idx = pd.DatetimeIndex(pot.index)
        t_utc = idx.tz_convert("UTC") if idx.tz is not None else idx.tz_localize(site["fuso_dados"]).tz_convert("UTC")
        horas = hora_de_inicio(t_utc, site.get("rotulo_intervalo", "fim"), passo, site["fuso_lst"])
        acc.adicionar(pot.to_frame("p_kw").set_axis(t_utc), horas)
    media, disp = acc.resultado(amostras_por_hora=60)

    ini = pd.Timestamp(site["inicio"]).tz_localize(site["fuso_lst"]).tz_convert("UTC")
    fim = (pd.Timestamp(site["fim"]) + pd.Timedelta(days=1)).tz_localize(site["fuso_lst"]).tz_convert("UTC")
    horas = pd.date_range(ini, fim, freq="h", inclusive="left")
    media = media.reindex(horas)
    disp = disp.reindex(horas).fillna(0)
    pnom = float(site["pnom_kw"])
    p = media["p_kw"].clip(lower=0)
    ok = disp["p_kw"] >= cfg["qc"]["disponibilidade_min_hora"]
    out = pd.DataFrame(index=horas)
    out["p_kw"] = p.where(ok)
    out["y"] = out["p_kw"] / pnom
    out["disponibilidade"] = disp["p_kw"]
    meta = {
        "pnom_kw": pnom,
        "unidade_pnom": "kW_dc (placa do arranjo Ground)",
        "colunas_potencia_usadas": usadas,
        "p_max_observado_kw": round(float(out["p_kw"].max()), 3) if out["p_kw"].notna().any() else None,
        "lat": site["lat"], "lon": site["lon"],
    }
    log.info("  GTB: Pnom = %.1f kW; potência máxima horária observada = %s kW",
             pnom, meta["p_max_observado_kw"])
    return out, meta
