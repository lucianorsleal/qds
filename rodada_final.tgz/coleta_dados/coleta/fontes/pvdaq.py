"""GEO: usina Simon Solar Farm (Social Circle, Geórgia, EUA), sistema 9069 do PVDAQ (NREL/OEDI).

Fonte: OEDI data lake, conjunto do DOE Solar Data Prize 2023 (CC-BY 4.0)
  https://oedi-data-lake.s3.amazonaws.com/pvdaq/2023-solar-data-prize/9069_OEDI/
    data/9069_electrical_ac.csv           grandezas AC de cada inversor, 5 min (1,77 GB). A série usa a
                                          potência AC dos 40 inversores (inverter_NN_ac_power_(kw)): de
                                          jun/2022 em diante parte deles fica parada e o medidor da usina
                                          passa a entregar só 65–75% da nominal. Com os inversores,
                                          y = potência dos inversores ligados / capacidade deles.
    data/9069_meter_data.csv              medidor de exportação da usina, 5 min, kW (meter_1 até ~2019,
                                          meter_2 de 2020 em diante). Usado para conferir a soma dos
                                          inversores e como série alternativa (potencia: medidor).
    metadata/9069_system_metadata.json    38.687 kW DC; 40 inversores de 825 kW (33 MW AC); fixo,
                                          azimute 180°, inclinação 20°; 'time_interval' L (carimbo no
                                          início do intervalo)
measured_on está em hora civil local (EST/EDT, com horário de verão): fuso_dados = America/New_York.
À noite inversores e medidor marcam consumo auxiliar (valores negativos): vira 0.
"""

from __future__ import annotations

import json
import logging
import re

import numpy as np
import pandas as pd

from ..agregacao import AcumuladorHorario, hora_de_inicio
from ..util import baixar_arquivo, nova_sessao
from .utrecht import _mascarar_paradas

log = logging.getLogger("coleta")

URL_BASE = "https://oedi-data-lake.s3.amazonaws.com/pvdaq/2023-solar-data-prize/{sid}_OEDI/"
ARQUIVOS = {"medidor": "data/{sid}_meter_data.csv", "inversores": "data/{sid}_electrical_ac.csv",
            "metadados": "metadata/{sid}_system_metadata.json"}
TAMANHOS = {9069: {"medidor": 73_345_005, "inversores": 1_767_155_102}}
_RE_POT = re.compile(r"^meter_(\d+)_ac_power_\(kw\)_meter_\d+$")
_RE_INV = re.compile(r"^inverter_(\d+)_ac_power_\(kw\)_inv_\d+$")
AMOSTRAS_H = 12  # 5 min


def _url(site, chave):
    sid = int(site["system_id"])
    return URL_BASE.format(sid=sid) + ARQUIVOS[chave].format(sid=sid)


def _caminho(site, pastas, chave):
    return pastas.bruto(site["codigo"]) / ARQUIVOS[chave].format(sid=int(site["system_id"])).split("/")[-1]


def usa_inversores(site: dict) -> bool:
    return str(site.get("potencia", "medidor")).strip().lower().startswith("inversor")


def verificar(site: dict, cfg: dict, sess) -> str:
    partes = []
    for chave in ("medidor",) + (("inversores",) if usa_inversores(site) else ()):
        r = sess.head(_url(site, chave), timeout=60)
        r.raise_for_status()
        partes.append(f"{ARQUIVOS[chave].format(sid=site['system_id'])}: "
                      f"{int(r.headers.get('Content-Length', 0)) / 1e6:.1f} MB")
    return "; ".join(partes)


def baixar(site: dict, cfg: dict, pastas, **_) -> None:
    sess = nova_sessao()
    tam = TAMANHOS.get(int(site["system_id"]), {})
    chaves = ["metadados", "medidor"] + (["inversores"] if usa_inversores(site) else [])
    for chave in chaves:
        baixar_arquivo(_url(site, chave), _caminho(site, pastas, chave), tamanho_esperado=tam.get(chave),
                       sessao=sess, descricao=f"PVDAQ {site['system_id']} {chave}", timeout=120)


def _ler_metadados(caminho) -> dict:
    try:
        m = json.loads(caminho.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {}
    inv = m.get("Inverters", {}) or {}
    cap = {}
    for v in inv.values():
        n = re.search(r"(\d+)\s*$", str(v.get("name", "")))
        if n and v.get("AC capacity(kW)"):
            cap[int(n.group(1))] = float(v["AC capacity(kW)"]) * float(v.get("quantity", 1) or 1)
    ac = sum(float(v.get("AC capacity(kW)", 0) or 0) * float(v.get("quantity", 1) or 1) for v in inv.values())
    sis = m.get("System", {}) or {}
    return {"dc_kw": sis.get("power(kW DC)"), "ac_kw_inversores": ac or None, "n_inversores": len(inv),
            "intervalo": next((v.get("time_interval") for v in inv.values() if v.get("time_interval")), None),
            "cap_inversor_kw": cap}


def ler_medidor(caminho) -> pd.DataFrame:
    """kW da usina por carimbo local (sem fuso), já combinando os medidores."""
    cab = pd.read_csv(caminho, nrows=0).columns
    cols = [c for c in cab if _RE_POT.match(c.strip())]
    if not cols:
        raise RuntimeError(f"nenhuma coluna de potência AC de medidor em {caminho.name}")
    df = pd.read_csv(caminho, usecols=["measured_on"] + cols, low_memory=False)
    df.columns = [c.strip() for c in df.columns]
    cols = [c.strip() for c in cols]
    for c in cols:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df["measured_on"] = pd.to_datetime(df["measured_on"], errors="coerce")
    df = df.dropna(subset=["measured_on"]).drop_duplicates("measured_on").set_index("measured_on").sort_index()
    # o medidor de número maior (mais novo) tem prioridade; o anterior completa
    ordem = sorted(cols, key=lambda c: -int(_RE_POT.match(c).group(1)))
    p = df[ordem[0]]
    for c in ordem[1:]:
        p = p.combine_first(df[c])
    out = pd.DataFrame({"p_kw": p})
    out["medidor"] = np.select([df[c].notna() for c in ordem], [int(_RE_POT.match(c).group(1)) for c in ordem], 0)
    return out


def _utc(indice_local, fuso_dados):
    t = pd.DatetimeIndex(indice_local).tz_localize(fuso_dados, ambiguous="NaT", nonexistent="NaT")
    ok = ~t.isna()
    return t, ok


def _horas_periodo(site):
    ini = pd.Timestamp(site["inicio"]).tz_localize(site["fuso_lst"]).tz_convert("UTC")
    fim = (pd.Timestamp(site["fim"]) + pd.Timedelta(days=1)).tz_localize(site["fuso_lst"]).tz_convert("UTC")
    return pd.date_range(ini, fim, freq="h", inclusive="left")


def _medidor_horario(site, pastas, passo):
    """(kW médio horário do medidor, disponibilidade, faixas dos medidores)."""
    arq = _caminho(site, pastas, "medidor")
    log.info("  lendo %s", arq.name)
    d = ler_medidor(arq)
    faixas = []
    for m in sorted(set(d["medidor"]) - {0}):
        idx = d.index[d["medidor"] == m]
        faixas.append(f"medidor {int(m)}: {idx.min():%Y-%m-%d} a {idx.max():%Y-%m-%d}")
    t, ok = _utc(d.index, site["fuso_dados"])
    d = d[ok]
    t_utc = t[ok].tz_convert("UTC")
    p = d["p_kw"].clip(lower=0.0)  # consumo auxiliar noturno -> 0
    acc = AcumuladorHorario()
    serie = pd.DataFrame({"p": p.to_numpy(dtype="float64")}, index=t_utc)
    acc.adicionar(serie, hora_de_inicio(t_utc, site.get("rotulo_intervalo", "inicio"), passo, site["fuso_lst"]))
    media, disp = acc.resultado(amostras_por_hora=pd.Timedelta(hours=1) / passo)
    return media["p"], disp["p"], faixas


def ler_inversores(caminho, site: dict, cap_por_numero: dict, passo, bloco: int = 100_000):
    """Soma e contagem horárias de kW por inversor (amostras de inversor parado já mascaradas).

    Lê só o carimbo e as 40 colunas de potência AC, em blocos, para caber na memória."""
    cab = pd.read_csv(caminho, nrows=0).columns
    tcol = next((c for c in cab if c.strip().lower() == "measured_on"), cab[0])
    cols = [c for c in cab if _RE_INV.match(c.strip())]
    if not cols:
        raise RuntimeError(f"nenhuma coluna de potência AC de inversor em {caminho.name}")
    nums = [int(_RE_INV.match(c.strip()).group(1)) for c in cols]
    padrao = float(np.median(list(cap_por_numero.values()))) if cap_por_numero else 825.0
    cap = pd.Series([cap_por_numero.get(n, padrao) for n in nums], index=nums, dtype=float)
    acc = AcumuladorHorario()
    paradas = pd.Series(0, index=nums, dtype="int64")
    n_amostras = 0
    rotulo = site.get("rotulo_intervalo", "inicio")
    for ch in pd.read_csv(caminho, usecols=[tcol] + cols, chunksize=bloco, low_memory=False):
        t = pd.to_datetime(ch[tcol], errors="coerce")
        ch = ch[t.notna().to_numpy()]
        t = t[t.notna()]
        tz, ok = _utc(t, site["fuso_dados"])
        ch = ch[ok]
        if ch.empty:
            continue
        p = ch[cols].apply(pd.to_numeric, errors="coerce").to_numpy(dtype="float32", copy=True)
        p[p < 0] = 0.0                                   # consumo noturno
        p[p > 1.2 * cap.to_numpy(dtype="float32")[None, :]] = np.nan   # leitura impossível
        df = pd.DataFrame(p, index=tz[ok].tz_convert("UTC"), columns=nums)
        df = df[~df.index.duplicated(keep="first")]
        df, par = _mascarar_paradas(df, cap)
        paradas = paradas.add(pd.Series(par, index=nums), fill_value=0)
        acc.adicionar(df, hora_de_inicio(df.index, rotulo, passo, site["fuso_lst"]))
        n_amostras += len(df)
    if acc.soma is None:
        raise RuntimeError(f"{caminho.name}: nenhuma leitura de inversor")
    return acc.soma.sort_index(), acc.cont.sort_index(), cap, paradas, n_amostras


def mascarar_dias_parados(soma: pd.DataFrame, cont: pd.DataFrame, cap: pd.Series, fuso_lst: str,
                          frac_max: float = 0.05, energia_min_h: float = 0.5):
    """Inversor que, num dia com sol, produz <= 5% da energia (por kW) da mediana dos outros fica de
    fora naquele dia inteiro. Pega os inversores desligados por semanas ou meses também nas horas de
    pouca luz, que o filtro amostra a amostra (mediana >= 0,2) não alcança.
    energia_min_h: mediana mínima, em horas equivalentes de plena potência, para o dia contar."""
    dia = soma.index.tz_convert(fuso_lst).floor("D")
    e = soma.groupby(dia).sum(min_count=1).div(cap.reindex(soma.columns), axis=1) / AMOSTRAS_H
    n = cont.groupby(dia).sum()
    e = e.where(n > 0)
    med = e.median(axis=1, skipna=True)
    parado = e.le(frac_max * med.to_numpy()[:, None]) & med.ge(energia_min_h).to_numpy()[:, None]
    m = parado.reindex(dia).to_numpy()
    soma = soma.mask(m)
    cont = cont.mask(m, 0)
    return soma, cont, parado.sum()


def _horario_inversores(site, cfg, pastas, atributos_fn, md, passo):
    arq = _caminho(site, pastas, "inversores")
    log.info("  lendo a potência dos inversores em %s (%.2f GB, leva alguns minutos)", arq.name,
             arq.stat().st_size / 1e9)
    soma, cont, cap, par_amostra, n_amostras = ler_inversores(arq, site, md.get("cap_inversor_kw", {}), passo)
    soma, cont, par_dia = mascarar_dias_parados(soma, cont, cap, site["fuso_lst"])
    horas = _horas_periodo(site)
    soma = soma.reindex(horas)
    cont = cont.reindex(horas).fillna(0.0)
    c = cap.reindex(soma.columns).to_numpy(dtype=float)
    num = soma.fillna(0.0).to_numpy().sum(axis=1)          # kW x amostras
    den = (cont.to_numpy() * c[None, :]).sum(axis=1)       # kW de capacidade x amostras
    with np.errstate(invalid="ignore", divide="ignore"):
        y = np.where(den > 0, num / den, np.nan)
    disp = np.clip(den / (AMOSTRAS_H * c.sum()), 0.0, 1.0)  # fração da capacidade instalada com dado
    lim = float(site.get("disponibilidade_min_frota", 0.5))
    y = np.where(disp >= lim, y, np.nan)

    attrs = atributos_fn(horas)
    diurno = (attrs["zenite"] < cfg["qc"]["zenite_max_graus"]).to_numpy()
    disp_inv = (cont / AMOSTRAS_H).clip(upper=1.0).to_numpy()
    tab = pd.DataFrame({
        "inversor": soma.columns.astype(int),
        "capacidade_kw": c,
        "disponibilidade_diurna": np.round(disp_inv[diurno].mean(axis=0), 4),
        "dias_parado_mascarados": par_dia.reindex(soma.columns).fillna(0).astype(int).to_numpy(),
        "amostras_parado_mascaradas": par_amostra.reindex(soma.columns).fillna(0).astype(int).to_numpy(),
    })

    out = pd.DataFrame(index=horas)
    out["y"] = y
    out["capacidade_kw"] = den / AMOSTRAS_H
    out["p_kw"] = out["y"] * out["capacidade_kw"]
    out["disponibilidade"] = disp
    out["n_unidades"] = (cont.to_numpy().sum(axis=1) / AMOSTRAS_H).round(1)

    # conferência com o medidor da usina nas horas com todos os inversores ligados
    meta_extra = {}
    try:
        pm, dm, faixas = _medidor_horario(site, pastas, passo)
        pm = pm.reindex(horas).where(dm.reindex(horas) >= 0.8)
        cheia = (disp >= 0.98) & diurno & (y > 0.3) & np.isfinite(pm.to_numpy())
        r = pm.to_numpy()[cheia] / (num[cheia] / AMOSTRAS_H)
        if r.size:
            meta_extra["razao_medidor_soma_inversores"] = round(float(np.median(r)), 4)
        meta_extra["canais_potencia"] = "inversores (40 x potência AC); " + "; ".join(faixas)
    except Exception as e:  # noqa: BLE001
        log.warning("  não consegui conferir com o medidor: %s", e)
        meta_extra["canais_potencia"] = "inversores (40 x potência AC)"
    pnom = float(site.get("pnom_kw") or c.sum())
    meta = {
        "pnom_kw": pnom,
        "unidade_pnom": (f"kW_ac instalados ({len(c)} inversores de {np.median(c):.0f} kW); y = potência AC dos "
                         "inversores com dado / capacidade deles"),
        "n_unidades": int(len(c)),
        "tabela_unidades": tab,
        "system_id": int(site["system_id"]),
        "lat": site["lat"], "lon": site["lon"],
        "disponibilidade_frota_diurna_media": round(float(np.nanmean(disp[diurno])), 4),
        "inversores_dias_parados_mascarados": int(par_dia.sum()),
        **meta_extra,
    }
    if md:
        meta["metadados_pvdaq"] = {k: v for k, v in md.items() if k != "cap_inversor_kw"}
    log.info("  GEO: PVDAQ %s pelos inversores, %d amostras de 5 min, %d horas com dado; %d dias-inversor "
             "parados tirados; disponibilidade diurna média %.1f%%; medidor/soma dos inversores = %s",
             site["system_id"], n_amostras, int(np.isfinite(y).sum()), int(par_dia.sum()),
             100 * meta["disponibilidade_frota_diurna_media"], meta.get("razao_medidor_soma_inversores"))
    return out, meta


def horario(site: dict, cfg: dict, pastas, atributos_fn) -> tuple:
    md = _ler_metadados(_caminho(site, pastas, "metadados"))
    passo = pd.Timedelta(minutes=int(site.get("passo_min", 5)))
    if usa_inversores(site):
        if not _caminho(site, pastas, "inversores").exists():
            raise FileNotFoundError(f"falta {_caminho(site, pastas, 'inversores').name}; rode "
                                    "'python coletar.py baixar --fontes pvdaq'")
        return _horario_inversores(site, cfg, pastas, atributos_fn, md, passo)

    arq = _caminho(site, pastas, "medidor")
    if not arq.exists():
        raise FileNotFoundError(f"falta {arq.name}; rode 'python coletar.py baixar --fontes pvdaq'")
    media, disp, faixas = _medidor_horario(site, pastas, passo)
    horas = _horas_periodo(site)
    media = media.reindex(horas)
    disp = disp.reindex(horas).fillna(0.0)
    lim = float(cfg["qc"].get("disponibilidade_min_hora", 0.8))
    p_h = media.where(disp >= lim)
    pnom = float(site.get("pnom_kw") or md.get("ac_kw_inversores") or np.nan)
    out = pd.DataFrame(index=horas)
    out["p_kw"] = p_h
    out["y"] = p_h / pnom
    out["disponibilidade"] = disp
    meta = {
        "pnom_kw": pnom,
        "unidade_pnom": "kW_ac (40 inversores de 825 kW; 38,7 MW DC)",
        "system_id": int(site["system_id"]),
        "lat": site["lat"], "lon": site["lon"],
        "p_max_observado_kw": round(float(np.nanmax(p_h.to_numpy())), 1) if p_h.notna().any() else None,
        "canais_potencia": "; ".join(faixas),
    }
    if md:
        meta["metadados_pvdaq"] = {k: v for k, v in md.items() if k != "cap_inversor_kw"}
    log.info("  GEO: PVDAQ %s, Pnom = %.0f kW AC, %d horas com dado; %s", site["system_id"], pnom,
             int(p_h.notna().sum()), meta["canais_potencia"])
    return out, meta
