"""UTR: 175 sistemas FV residenciais em Utrecht (Holanda), Visser et al. (2022).

Fonte: Zenodo, doi:10.5281/zenodo.10953360 (CC-BY 4.0)
Potência em W, resolução de 1 min, carimbo em UTC. Usa a versão filtrada
'filtered_pv_power_measurements_ac.csv' (filtros de sistema único + entre sistemas).

Como os filtros da base deixam lacunas espalhadas em todos os sistemas (~13% dos minutos com sol
alto e ~25% com o sol a menos de 10°, numa amostra de 2015–2017) e os sistemas entram e saem do
estudo em datas diferentes (colunas begin_ts/end_ts do metadata.csv), a carteira é montada como
razão de somas sobre os minutos válidos:

    y(h) = soma_i soma_min P_i / soma_i (minutos válidos_i * C_i)

isto é, a potência média por kWp dos sistemas que mediram naquela hora. A hora é válida quando a
capacidade com dado cobre pelo menos 'disponibilidade_min_frota' da capacidade em serviço.
"""

from __future__ import annotations

import logging
import warnings

import numpy as np
import pandas as pd

from ..agregacao import AcumuladorHorario, hora_de_inicio
from ..util import baixar_arquivo, nova_sessao

log = logging.getLogger("coleta")

REGISTRO = "10953360"
URL = "https://zenodo.org/api/records/" + REGISTRO + "/files/{nome}/content"
ARQUIVOS = {
    "metadata.csv": (22902, "df6b38f4ca7c0ca5191c33acd2dc5b7b"),
    "metadata_units.csv": (22221, "fa21b348c1dd0b8ad772b6139788a5dd"),
    "filtered_pv_power_measurements_ac.csv": (2985408767, "13896fef43016d4f08cf671f7f37af4b"),
    "filtered_pv_power_measurements_sc.csv": (3018099557, "be944824679089c77ea71f3123f896d9"),
    "unfiltered_pv_power_measurements.csv": (4802459927, "0bd1947e87e4f9b6302c3c82d2217a0d"),
}


def verificar(site: dict, cfg: dict, sess) -> str:
    r = sess.get("https://zenodo.org/api/records/" + REGISTRO, timeout=60)
    r.raise_for_status()
    return f"registro '{r.json()['metadata']['title'][:50]}...'"


def baixar(site: dict, cfg: dict, pastas, **_) -> None:
    sess = nova_sessao()
    destino = pastas.bruto(site["codigo"])
    nomes = ["metadata.csv", "metadata_units.csv", site.get("arquivo_potencia", "filtered_pv_power_measurements_ac.csv")]
    for nome in nomes:
        tam, md5 = ARQUIVOS[nome]
        baixar_arquivo(URL.format(nome=nome), destino / nome, tamanho_esperado=tam, md5=md5, sessao=sess,
                       descricao=f"Zenodo {nome}", timeout=120)


def ler_metadados(caminho) -> pd.DataFrame:
    m = pd.read_csv(caminho, sep=";")
    m = m.loc[:, [c for c in m.columns if not str(c).startswith("Unnamed")]]
    m["ID"] = m["ID"].astype(str).str.strip()
    for c in ["estimated_dc_capacity", "estimated_ac_capacity", "tilt", "azimuth", "annual_yield",
              "north", "south", "west", "east"]:
        if c in m.columns:
            m[c] = pd.to_numeric(m[c], errors="coerce")
    for c in ("begin_ts", "end_ts"):
        if c in m.columns:
            m[c] = pd.to_datetime(m[c], utc=True, errors="coerce")
    return m.dropna(subset=["ID"]).set_index("ID")


def _blocos_potencia(caminho, ini_utc, fim_utc):
    """Itera blocos (DataFrame em W, índice UTC) do CSV largo de 3 GB, só no período pedido."""
    try:
        import pyarrow as pa
        import pyarrow.csv as pacsv

        cab = pd.read_csv(caminho, nrows=0).columns.tolist()
        tipos = {c: pa.float32() for c in cab if c != "DateTime"}
        tipos["DateTime"] = pa.string()
        leitor = pacsv.open_csv(caminho, read_options=pacsv.ReadOptions(block_size=32 << 20),
                                convert_options=pacsv.ConvertOptions(column_types=tipos))
        for lote in leitor:
            df = lote.to_pandas()
            t = pd.to_datetime(df.pop("DateTime"), format="%Y-%m-%d %H:%M:%S%z", utc=True, errors="coerce")
            df.index = pd.DatetimeIndex(t)
            df = df[df.index.notna()]
            if len(df) == 0:
                continue
            if df.index.max() < ini_utc:
                continue
            if df.index.min() > fim_utc:
                break
            yield df[(df.index >= ini_utc) & (df.index <= fim_utc)]
    except ImportError:
        for df in pd.read_csv(caminho, chunksize=100_000, dtype={"DateTime": str}):
            t = pd.to_datetime(df.pop("DateTime"), format="%Y-%m-%d %H:%M:%S%z", utc=True, errors="coerce")
            df.index = pd.DatetimeIndex(t)
            df = df[df.index.notna()].astype("float32")
            if len(df) == 0 or df.index.max() < ini_utc:
                continue
            if df.index.min() > fim_utc:
                break
            yield df[(df.index >= ini_utc) & (df.index <= fim_utc)]


def _mascarar_paradas(bloco: pd.DataFrame, cap_w: pd.Series, y_mediana_min: float = 0.2,
                      y_unidade_max: float = 0.02):
    """Minuto a minuto: sistema em ~0 enquanto a mediana da frota produz = inversor parado -> NaN."""
    p = bloco.to_numpy(dtype=np.float32, copy=True)
    y = p / cap_w.reindex(bloco.columns).to_numpy(dtype=np.float32)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=RuntimeWarning)
        med = np.nanmedian(y, axis=1)
    parada = (y <= y_unidade_max) & (med >= y_mediana_min)[:, None]
    p[parada] = np.nan
    return pd.DataFrame(p, index=bloco.index, columns=bloco.columns), parada.sum(axis=0)


def _em_servico(horas: pd.DatetimeIndex, meta: pd.DataFrame, cols,
                passo_rotulo: pd.Timedelta = pd.Timedelta(0)) -> pd.DataFrame:
    """True quando a hora [h, h+1h) contém algum minuto de serviço do sistema (sem datas = sempre).

    begin_ts/end_ts são o primeiro e o último carimbo com dado. Com rótulo 'fim', o carimbo t
    representa [t - passo, t), então o serviço vai de begin_ts - passo a end_ts (exclusivo):
    passo_rotulo = passo. Com rótulo 'inicio', passo_rotulo = 0.
    Tudo em nanossegundos explícitos: no pandas 3 as datas podem vir em microssegundos.
    """
    ti = pd.DatetimeIndex(horas).as_unit("ns").asi8[:, None]
    nat = pd.Series(pd.NaT, index=list(cols), dtype="datetime64[ns, UTC]")
    b = meta["begin_ts"].reindex(cols) if "begin_ts" in meta else nat
    e = meta["end_ts"].reindex(cols) if "end_ts" in meta else nat
    b_ns = np.where(b.isna(), np.iinfo(np.int64).min, pd.DatetimeIndex(b - passo_rotulo).as_unit("ns").asi8)
    e_ns = np.where(e.isna(), np.iinfo(np.int64).max, pd.DatetimeIndex(e - passo_rotulo).as_unit("ns").asi8)
    uma_hora_ns = 3_600 * 1_000_000_000
    return pd.DataFrame((ti + uma_hora_ns > b_ns[None, :]) & (ti <= e_ns[None, :]), index=horas,
                        columns=list(cols))


def _coluna(df: pd.DataFrame, nome: str) -> pd.Series:
    return pd.to_numeric(df[nome], errors="coerce") if nome in df.columns else pd.Series(np.nan, index=df.index)


def horario(site: dict, cfg: dict, pastas, atributos_fn) -> tuple:
    pasta = pastas.bruto(site["codigo"])
    meta_arq = pasta / "metadata.csv"
    pot_arq = pasta / site.get("arquivo_potencia", "filtered_pv_power_measurements_ac.csv")
    for a in (meta_arq, pot_arq):
        if not a.exists():
            raise FileNotFoundError(f"falta {a.name}; rode 'python coletar.py baixar --fontes utrecht'")
    meta = ler_metadados(meta_arq)
    cap_w = meta["estimated_dc_capacity"].where(meta["estimated_dc_capacity"] > 0).dropna().astype(float)

    ini = pd.Timestamp(site["inicio"]).tz_localize(site["fuso_lst"]).tz_convert("UTC")
    fim = (pd.Timestamp(site["fim"]) + pd.Timedelta(days=1)).tz_localize(site["fuso_lst"]).tz_convert("UTC")
    acc = AcumuladorHorario()
    passo = pd.Timedelta(minutes=1)
    n = 0
    n_paradas = pd.Series(0, index=cap_w.index, dtype="int64")
    sem_capacidade = set()
    log.info("  lendo %s (arquivo grande: leva alguns minutos)", pot_arq.name)
    for bloco in _blocos_potencia(pot_arq, ini - pd.Timedelta(hours=2), fim + pd.Timedelta(hours=2)):
        sem_capacidade.update(c for c in bloco.columns if c not in cap_w.index)
        cols = [c for c in bloco.columns if c in cap_w.index]
        if not cols or len(bloco) == 0:
            continue
        bloco, paradas = _mascarar_paradas(bloco[cols], cap_w)
        n_paradas[cols] += paradas
        horas = hora_de_inicio(bloco.index, site.get("rotulo_intervalo", "fim"), passo, site["fuso_lst"])
        acc.adicionar(bloco, horas)
        n += len(bloco)
        if n and n % 500_000 < len(bloco):
            log.info("    %s linhas processadas (até %s)", f"{n:,}".replace(",", "."), bloco.index.max())
    if acc.soma is None:
        if sem_capacidade:
            raise RuntimeError(f"nenhuma coluna de {pot_arq.name} tem capacidade no metadata.csv (os IDs "
                               f"batem? ex.: {', '.join(sorted(sem_capacidade)[:5])})")
        raise RuntimeError(f"nenhuma linha de {pot_arq.name} no período {site['inicio']} a {site['fim']}")
    if sem_capacidade:
        log.warning("  UTR: %d coluna(s) sem capacidade no metadata.csv, ignorada(s): %s",
                    len(sem_capacidade), ", ".join(sorted(sem_capacidade)[:10]))

    horas = pd.date_range(ini, fim, freq="h", inclusive="left")
    soma = acc.soma.reindex(horas)                  # W·min válidos por sistema e hora
    cont = acc.cont.reindex(horas).fillna(0.0)      # minutos válidos por sistema e hora
    cols = list(soma.columns)
    attrs = atributos_fn(horas)
    diurno = (attrs["zenite"] < cfg["qc"]["zenite_max_graus"]).to_numpy()
    rotulo = site.get("rotulo_intervalo", "fim")
    servico = _em_servico(horas, meta, cols, passo if rotulo == "fim" else pd.Timedelta(0))

    # ---- diagnóstico por sistema
    disp_h = (cont / 60.0).clip(upper=1.0)
    serv_d = servico.to_numpy(dtype=bool) & diurno[:, None]
    horas_serv_d = serv_d.sum(axis=0)
    disp_ativo = np.where(horas_serv_d > 0,
                          (disp_h.to_numpy() * serv_d).sum(axis=0) / np.maximum(horas_serv_d, 1), np.nan)
    tab = meta.reindex(cols).copy()
    tab["kwp"] = (cap_w.reindex(cols) / 1000.0).round(4)
    tab["frac_periodo_em_servico"] = np.round(horas_serv_d / max(int(diurno.sum()), 1), 4)
    tab["disponibilidade_diurna_em_servico"] = np.round(disp_ativo, 4)
    tab["minutos_parado_mascarados"] = n_paradas.reindex(cols).fillna(0).astype(int).to_numpy()
    lim = float(site.get("disponibilidade_min_sistema", 0.0) or 0.0)
    tab["selecionado"] = (tab["kwp"] > 0) & (tab["frac_periodo_em_servico"] > 0) & \
        (tab["disponibilidade_diurna_em_servico"].fillna(0) >= lim) & (cont.sum(axis=0).reindex(cols) > 0).to_numpy()
    tab_out = tab.reset_index().rename(columns={"index": "ID"})
    for c in ("begin_ts", "end_ts"):
        if c in tab_out:
            tab_out[c] = tab_out[c].dt.strftime("%Y-%m-%d %H:%M")
    sel = tab[tab["selecionado"]]
    if sel.empty:
        tab_out.to_csv(pastas.processado(site["codigo"]) / "unidades.csv", index=False)
        raise RuntimeError("nenhum sistema de UTR passou na seleção; veja dados/processados/UTR/unidades.csv "
                           "e o 'disponibilidade_min_sistema' do config.yaml")

    # ---- carteira: razão de somas sobre os minutos válidos
    s_cols = list(sel.index)
    c_w = cap_w.reindex(s_cols).to_numpy()
    num = soma[s_cols].fillna(0.0).to_numpy().sum(axis=1)                 # W·min
    den = (cont[s_cols].to_numpy() * c_w[None, :]).sum(axis=1)            # Wp·min
    cap_serv_w = (servico[s_cols].to_numpy(dtype=bool) * c_w[None, :]).sum(axis=1)  # Wp em serviço
    with np.errstate(invalid="ignore", divide="ignore"):
        y = np.where(den > 0, num / den, np.nan)
        disp = np.where(cap_serv_w > 0, den / (60.0 * cap_serv_w), 0.0)
    disp = np.clip(disp, 0.0, 1.0)
    lim_frota = float(site.get("disponibilidade_min_frota", 0.5))
    y = np.where(disp >= lim_frota, y, np.nan)

    pnom = float(np.mean(cap_serv_w[cap_serv_w > 0]) / 1000.0)
    w = sel["kwp"].to_numpy()
    lat_s = ((_coluna(sel, "north") + _coluna(sel, "south")) / 2).to_numpy(dtype=float)
    lon_s = ((_coluna(sel, "west") + _coluna(sel, "east")) / 2).to_numpy(dtype=float)
    ok_ll = np.isfinite(lat_s) & np.isfinite(lon_s)
    lat = float(np.average(lat_s[ok_ll], weights=w[ok_ll])) if ok_ll.any() else float(site["lat"])
    lon = float(np.average(lon_s[ok_ll], weights=w[ok_ll])) if ok_ll.any() else float(site["lon"])

    til = _coluna(sel, "tilt").to_numpy(dtype=float)
    azi = _coluna(sel, "azimuth").to_numpy(dtype=float)  # 180 = sul, como no pvlib
    ok_o = np.isfinite(til) & np.isfinite(azi)

    out = pd.DataFrame(index=horas)
    out["y"] = y
    out["capacidade_kw"] = cap_serv_w / 1000.0
    out["p_kw"] = out["y"] * out["capacidade_kw"]
    out["disponibilidade"] = disp
    out["n_unidades"] = (cont[s_cols].to_numpy().sum(axis=1) / 60.0).round(1)
    cap_d = cap_serv_w[diurno] / 1000.0
    info = {
        "pnom_kw": round(pnom, 3),
        "unidade_pnom": "kWp (capacidade DC média em serviço; y = potência por kWp dos sistemas com dado)",
        "n_unidades": int(len(sel)),
        "tabela_unidades": tab_out,
        "lat": round(lat, 5), "lon": round(lon, 5),
        "capacidade_total_kwp": round(float(sel["kwp"].sum()), 3),
        "capacidade_em_servico_kwp_min_max": (round(float(cap_d.min()), 1), round(float(cap_d.max()), 1)),
        "disponibilidade_frota_diurna_media": round(float(disp[diurno].mean()), 4),
        "pct_horas_diurnas_abaixo_limite_frota": round(100.0 * float((disp[diurno] < lim_frota).mean()), 3),
    }
    if ok_o.any():  # orientação média da frota, ponderada por kWp (usada só no diagnóstico de teto)
        info["inclinacao_ref"] = round(float(np.average(til[ok_o], weights=w[ok_o])), 1)
        info["azimute_ref"] = round(float(np.average(azi[ok_o], weights=w[ok_o])), 1)
    log.info("  UTR: %d de %d sistemas, %.1f kWp no total; em serviço %.1f–%.1f kWp (média %.1f); "
             "disponibilidade média da frota nas horas diurnas %.1f%%; centróide (%.4f, %.4f)",
             len(sel), len(tab), info["capacidade_total_kwp"], cap_d.min(), cap_d.max(), pnom,
             100 * info["disponibilidade_frota_diurna_media"], lat, lon)
    return out, info
