"""Uma fonte por site: DKASC (ASP), NIST (GTB), Zenodo/Utrecht (UTR) e ONS (BRA)."""
