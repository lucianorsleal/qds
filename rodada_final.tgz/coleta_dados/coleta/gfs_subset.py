"""GFS dos pedidos de subset do GDEX (d084001, "Get a Subset"), gravado nos mesmos npz diários do THREDDS.

Pelo THREDDS cada (ciclo, hora de previsão, site) é um pedido; o servidor do NCAR passou a responder
~0,5 pedido/s, o que levaria de 6 a 12 dias. No subset o NCAR recorta os GRIB do lado dele (um pedido
por site, saída netCDF) e a coleta só baixa e lê o resultado:

    python coletar.py gdex                     # baixa os pedidos prontos da sua conta (token) e importa
    python coletar.py importar-gfs PASTA       # importa arquivos já baixados (.nc, .tar, .zip, .gz)

Cada arquivo do pedido é um GRIB original (gfs.0p25.AAAAMMDDHH.fFFF.grib2) recortado e convertido.
Para cada site cuja caixa 4x4 cabe na área do arquivo, as seis variáveis vão para
dados/brutos/gfs/<SITE>/<AAAA>/<AAAAMMDD>.npz com status ok. Um (ciclo, hora) sem alguma das seis
variáveis não é gravado: fica para o THREDDS completar ('python coletar.py baixar --fontes gfs').

O token da API do GDEX fica em gdex_token.txt (pasta do coletar.py) ou na variável GDEX_TOKEN; ele está
em https://gdex.ucar.edu/accounts/profile/. Nunca aparece no log.
"""

from __future__ import annotations

import gzip
import io
import logging
import os
import re
import tarfile
import threading
import time
import zipfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Iterator, Optional

import numpy as np
import pandas as pd
import requests

from . import gfs
from .util import RAIZ, USER_AGENT

log = logging.getLogger("coleta")

API = "https://gdex.ucar.edu/api/"
DATASET = "d084001"
_RE_ARQ = re.compile(r"(\d{10})\.f(\d{3})")

# nomes das variáveis nas convenções conhecidas (netCDF-java/THREDDS, NCL, wgrib2 -netcdf, cfgrib)
PADROES = {
    "dswrf": [r"^Downward_Short-Wave_Radiation_Flux_surface", r"^DSWRF_P\d+_L1_", r"^DSWRF_surface",
              r"^s?dswrf$", r"^DSWRF"],
    "tcc": [r"^Total_cloud_cover_entire_atmosphere", r"^TCDC_P\d+_L(10|200)_", r"^TCDC_entireatmosphere",
            r"^tcc$"],
    "t2m": [r"^Temperature_height_above_ground$", r"^TMP_P\d+_L103_", r"^TMP_2maboveground$", r"^t2m$"],
    "rh2m": [r"^Relative_humidity_height_above_ground$", r"^RH_P\d+_L103_", r"^RH_2maboveground$", r"^r2$"],
    "u10": [r"^u-component_of_wind_height_above_ground$", r"^UGRD_P\d+_L103_", r"^UGRD_10maboveground$",
            r"^u10$"],
    "v10": [r"^v-component_of_wind_height_above_ground$", r"^VGRD_P\d+_L103_", r"^VGRD_10maboveground$",
            r"^v10$"],
}
MEDIAS = ("dswrf", "tcc")
_NOMES_LAT = ("latitude", "lat", "lat_0", "g0_lat_0", "lat_0_0")
_NOMES_LON = ("longitude", "lon", "lon_0", "g0_lon_1", "lon_0_0")


class ArquivoInvalido(ValueError):
    pass


# ---------------------------------------------------------------------------
# netCDF em memória (clássico via scipy; netCDF-4/HDF5 via netCDF4 ou h5py, se instalados)
# ---------------------------------------------------------------------------
class _Var:
    __slots__ = ("nome", "dims", "dados", "attrs")

    def __init__(self, nome, dims, dados, attrs):
        self.nome, self.dims, self.dados, self.attrs = nome, tuple(dims), dados, attrs


def _txt(x) -> str:
    if isinstance(x, bytes):
        return x.decode(errors="replace")
    if isinstance(x, np.ndarray) and x.dtype.kind in "SU":
        return "".join(_txt(v) for v in x.ravel())
    return str(x)


def abrir_nc(conteudo: bytes) -> dict:
    """{nome: _Var} com os dados já lidos (arquivos pequenos)."""
    if conteudo[:2] == b"\x1f\x8b":
        conteudo = gzip.decompress(conteudo)
    if conteudo[:3] == b"CDF":
        from scipy.io import netcdf_file

        with netcdf_file(io.BytesIO(conteudo), "r", mmap=False) as nc:
            out = {}
            for n, v in nc.variables.items():
                attrs = {k: (_txt(a) if isinstance(a, (bytes, str)) else np.ravel(a)) for k, a in v._attributes.items()}
                out[n] = _Var(n, v.dimensions, np.array(v.data), attrs)
            out["__global__"] = _Var("__global__", (), None, {k: _txt(a) for k, a in nc._attributes.items()})
            return out
    if conteudo[:4] == b"\x89HDF":
        try:
            import netCDF4  # noqa: F401
            return _abrir_netcdf4(conteudo)
        except ImportError:
            return _abrir_h5py(conteudo)
    raise ArquivoInvalido("não é netCDF (nem clássico nem HDF5)")


def _abrir_netcdf4(conteudo: bytes) -> dict:
    import netCDF4

    with netCDF4.Dataset("subset", memory=conteudo) as nc:
        nc.set_auto_mask(False)
        out = {}
        for n, v in nc.variables.items():
            attrs = {k: (v.getncattr(k) if isinstance(v.getncattr(k), str) else np.ravel(v.getncattr(k)))
                     for k in v.ncattrs()}
            out[n] = _Var(n, v.dimensions, np.array(v[:]), attrs)
        out["__global__"] = _Var("__global__", (), None, {k: _txt(nc.getncattr(k)) for k in nc.ncattrs()})
        return out


def _abrir_h5py(conteudo: bytes) -> dict:
    try:
        import h5py
    except ImportError as e:
        raise ArquivoInvalido("arquivo netCDF-4; instale 'netCDF4' (pip install netCDF4)") from e
    out = {}
    with h5py.File(io.BytesIO(conteudo), "r") as f:
        for n, ds in f.items():
            if not isinstance(ds, h5py.Dataset):
                continue
            dims = []
            for i in range(ds.ndim):
                escalas = ds.dims[i]
                dims.append(escalas[0].name.split("/")[-1] if len(escalas) else f"dim{i}")
            attrs = {k: (_txt(a) if isinstance(a, (bytes, str)) else np.ravel(a)) for k, a in ds.attrs.items()
                     if k not in ("DIMENSION_LIST", "REFERENCE_LIST", "CLASS", "NAME")}
            out[n] = _Var(n, dims, ds[()], attrs)
        out["__global__"] = _Var("__global__", (), None, {k: _txt(a) for k, a in f.attrs.items()})
    return out


# ---------------------------------------------------------------------------
# Leitura de um arquivo do pedido
# ---------------------------------------------------------------------------
def _e_media(v: _Var) -> bool:
    txt = (v.nome + " " + " ".join(f"{k}={_txt(a)}" for k, a in v.attrs.items())).lower()
    return any(s in txt for s in ("avg", "average", "_ave", "steptype=avg", "time: mean"))


def _escolher(V: dict, chave: str) -> Optional[_Var]:
    for pad in PADROES[chave]:
        cand = [v for n, v in V.items() if n != "__global__" and re.match(pad, n) and v.dados is not None
                and v.dados.ndim >= 2]
        if not cand:
            continue
        if chave in MEDIAS:
            medias = [v for v in cand if _e_media(v)]
            if medias:
                cand = medias
            elif len(cand) > 1:
                continue
        return sorted(cand, key=lambda v: len(v.nome))[0]
    return None


def _coord(V: dict, nomes) -> Optional[np.ndarray]:
    for n in nomes:
        if n in V and V[n].dados is not None and V[n].dados.ndim == 1:
            return np.asarray(V[n].dados, dtype=float)
    return None


def _campo(v: _Var, V: dict, chave: str) -> np.ndarray:
    """Recorte 2-D (lat, lon) da variável: dimensões extras de tamanho 1 caem; a de altura escolhe 2 m/10 m."""
    arr = np.array(v.dados, dtype=np.float64)
    for att in ("_FillValue", "missing_value"):
        if att in v.attrs:
            fv = np.ravel(v.attrs[att])
            if fv.size:
                arr[arr == float(fv[0])] = np.nan
    sel = []
    for i, d in enumerate(v.dims):
        nome = d.lower()
        if any(s in nome for s in ("lat", "lon")) or i >= arr.ndim - 2:
            sel.append(slice(None))
            continue
        tam = arr.shape[i]
        if tam == 1:
            sel.append(0)
            continue
        if chave in gfs._NIVEL and any(s in nome for s in ("height", "htgl", "lv_", "level")):
            niv = V.get(d)
            if niv is not None and niv.dados is not None:
                k = np.where(np.isclose(np.asarray(niv.dados, dtype=float), gfs._NIVEL[chave]))[0]
                if k.size:
                    sel.append(int(k[0]))
                    continue
        raise ArquivoInvalido(f"{v.nome}: dimensão {d} com {tam} valores (esperado 1)")
    out = arr[tuple(sel)]
    if out.ndim != 2:
        raise ArquivoInvalido(f"{v.nome}: recorte com {out.ndim} dimensões")
    return out


def _ciclo_do_nome(s: str) -> pd.Timestamp:
    return pd.Timestamp(f"{s[:4]}-{s[4:6]}-{s[6:8]} {s[8:10]}:00", tz="UTC")


def _ciclo_fh(nome: str, V: dict):
    m = _RE_ARQ.search(nome)
    if m:
        return _ciclo_do_nome(m.group(1)), int(m.group(2))
    # NCL: atributos initial_time "MM/DD/YYYY (HH:MM)" e forecast_time (horas)
    for v in V.values():
        it, ft = v.attrs.get("initial_time"), v.attrs.get("forecast_time")
        if it is not None and ft is not None:
            c = pd.to_datetime(_txt(it).replace("(", "").replace(")", ""), format="%m/%d/%Y %H:%M", utc=True)
            un = _txt(v.attrs.get("forecast_time_units", "hours")).lower()
            f = float(np.ravel(ft)[0]) * (1 / 60.0 if un.startswith("min") else 1.0)
            return c, int(round(f))
    # CF: reftime + time (horas desde ...)
    def cf(n):
        x = V.get(n)
        if x is None or x.dados is None or "units" not in x.attrs or "since" not in _txt(x.attrs["units"]):
            return None
        un, base = _txt(x.attrs["units"]).split("since", 1)
        mult = {"s": 1 / 3600.0, "m": 1 / 60.0, "h": 1.0, "d": 24.0}[un.strip().lower()[0]]
        return pd.Timestamp(base.strip().replace("Z", "")).tz_localize("UTC") + \
            pd.Timedelta(hours=float(np.ravel(x.dados)[0]) * mult)
    ref = next((cf(n) for n in ("reftime", "reftime1", "reference_time") if cf(n) is not None), None)
    val = next((cf(n) for n in ("time", "time1", "valid_time") if cf(n) is not None), None)
    if ref is not None and val is not None:
        return ref, int(round((val - ref).total_seconds() / 3600.0))
    raise ArquivoInvalido("não achei o ciclo e a hora de previsão (nome do arquivo nem atributos)")


def ler_arquivo(conteudo: bytes, nome: str = "") -> dict:
    """{'ciclo', 'fh', 'lats', 'lons', 'campos': {var: 2-D}, 'faltam': [...]} de um arquivo do pedido."""
    V = abrir_nc(conteudo)
    lats, lons = _coord(V, _NOMES_LAT), _coord(V, _NOMES_LON)
    if lats is None or lons is None:
        raise ArquivoInvalido("sem latitude/longitude 1-D")
    ciclo, fh = _ciclo_fh(nome, V)
    campos, faltam = {}, []
    for chave in gfs.VARS:
        v = _escolher(V, chave)
        if v is None:
            faltam.append(chave)
            continue
        campos[chave] = _campo(v, V, chave)
    return {"ciclo": ciclo, "fh": fh, "lats": lats, "lons": lons % 360.0, "campos": campos, "faltam": faltam}


def _indices(grade: np.ndarray, alvo: np.ndarray, periodo: Optional[float] = None) -> Optional[list]:
    out = []
    for a in alvo:
        d = np.abs(grade - a)
        if periodo:
            d = np.minimum(d, periodo - d)
        i = int(np.argmin(d))
        if d[i] > 0.01:
            return None
        out.append(i)
    return out


def recortar(info: dict, cx: dict) -> Optional[np.ndarray]:
    """(6, 4, 4) na ordem da caixa (lats decrescentes, lons crescentes), ou None se a caixa não cabe."""
    il = _indices(info["lats"], cx["lats"])
    io_ = _indices(info["lons"], np.asarray(cx["lons"]) % 360.0, 360.0)
    if il is None or io_ is None:
        return None
    dados = np.full((len(gfs.VARS), 4, 4), np.nan, dtype=np.float32)
    for k, v in enumerate(gfs.VARS):
        if v in info["campos"]:
            dados[k] = info["campos"][v][np.ix_(il, io_)]
    return dados


def janela_media(fh: int) -> tuple:
    """Janela da média do DSWRF/nebulosidade no GFS: 3 h quando fh % 6 == 3, 6 h quando fh % 6 == 0."""
    return (float(fh - 3), float(fh)) if fh % 6 == 3 else (float(fh - 6), float(fh))


# ---------------------------------------------------------------------------
# Gravação (mescla com o que já está nos npz diários)
# ---------------------------------------------------------------------------
class Gravador:
    def __init__(self, pastas, sites: list, cfg_gfs: dict, max_dias: int = 400):
        self.pastas = pastas
        self.caixas = {s["codigo"]: gfs.caixa(s["lat"], s["lon"]) for s in sites}
        self.planos = {}
        for s in sites:
            self.planos[s["codigo"]] = {(int(c.timestamp()), fh) for c in gfs.ciclos_site(s, cfg_gfs)
                                        for fh in gfs.horas_previsao(s, cfg_gfs, c)}
        self.buf: dict = {}
        self.max_dias = max_dias
        self.cont = {"arquivos": 0, "gravados": 0, "fora_do_plano": 0, "fora_da_area": 0, "incompletos": 0,
                     "ilegiveis": 0}
        self.faltas: dict = {}
        self.trava = threading.Lock()

    def feitos(self, cod: str, dia: str) -> set:
        return gfs._chaves_feitas(gfs.arquivo_dia(self.pastas.gfs(cod), dia), True, self.caixas[cod])

    def adicionar(self, info: dict) -> None:
        c, fh = info["ciclo"], info["fh"]
        chave = (int(c.timestamp()), fh)
        algum = False
        for cod, cx in self.caixas.items():
            if chave not in self.planos[cod]:
                continue
            dados = recortar(info, cx)
            if dados is None:
                continue
            algum = True
            if info["faltam"]:
                self.cont["incompletos"] += 1
                for v in info["faltam"]:
                    self.faltas[v] = self.faltas.get(v, 0) + 1
                continue
            t0, t1 = janela_media(fh)
            dia = c.strftime("%Y%m%d")
            self.buf.setdefault(cod, {}).setdefault(dia, {})[(c, fh)] = (gfs.ST_OK, dados, t0, t1)
            self.cont["gravados"] += 1
        if not algum:
            if any(chave in p for p in self.planos.values()):
                self.cont["fora_da_area"] += 1
            else:
                self.cont["fora_do_plano"] += 1
        if sum(len(d) for d in self.buf.values()) >= self.max_dias:
            self.descarregar()

    def descarregar(self) -> None:
        for cod, dias in self.buf.items():
            cx = self.caixas[cod]
            for dia, novos in dias.items():
                cam = gfs.arquivo_dia(self.pastas.gfs(cod), dia)
                antigas = []
                if cam.exists():
                    try:
                        with np.load(cam) as z:
                            mesma = gfs._mesma_caixa(z, cx)
                        antigas = gfs._ler_dia(cam) if mesma else []
                    except Exception as e:  # noqa: BLE001
                        log.warning("  GFS: %s ilegível (%s); será regravado", cam.name, e)
                linhas = [x for x in antigas if (x[0], x[1]) not in novos]
                linhas += [(c, fh, st, d, t0, t1) for (c, fh), (st, d, t0, t1) in novos.items()]
                gfs.gravar_dia(cam, linhas, cx)
        self.buf = {}


# ---------------------------------------------------------------------------
# Origens: pasta local ou API do GDEX
# ---------------------------------------------------------------------------
def desempacotar(nome: str, conteudo: bytes) -> Iterator[tuple]:
    """(nome, bytes) de cada netCDF dentro de um .tar/.tgz/.zip, ou o próprio arquivo."""
    if conteudo[:3] == b"CDF" or conteudo[:4] == b"\x89HDF":
        yield nome, conteudo
        return
    baixo = nome.lower()
    if baixo.endswith((".tar", ".tar.gz", ".tgz")) or tarfile.is_tarfile(io.BytesIO(conteudo)):
        try:
            with tarfile.open(fileobj=io.BytesIO(conteudo), mode="r:*") as t:
                for m in t:
                    if m.isfile():
                        f = t.extractfile(m)
                        if f is not None:
                            yield m.name, f.read()
            return
        except tarfile.TarError:
            pass
    if baixo.endswith(".zip") or conteudo[:4] == b"PK\x03\x04":
        with zipfile.ZipFile(io.BytesIO(conteudo)) as z:
            for m in z.namelist():
                if not m.endswith("/"):
                    yield m, z.read(m)
        return
    yield nome, conteudo


def _conteudos_locais(origem: Path) -> Iterator[tuple]:
    arquivos = [origem] if origem.is_file() else sorted(p for p in origem.rglob("*") if p.is_file())
    for a in arquivos:
        nome = a.name.lower()
        if nome.endswith((".tar", ".tar.gz", ".tgz")):
            try:
                with tarfile.open(a, "r:*") as t:  # lido em fluxo: o .tar pode ter vários GB
                    for m in t:
                        if m.isfile():
                            f = t.extractfile(m)
                            if f is not None:
                                yield m.name, f.read()
            except (tarfile.TarError, OSError) as e:
                log.warning("  não consegui ler %s: %s", a.name, e)
        elif nome.endswith(".zip") or nome.endswith((".nc", ".nc4", ".netcdf", ".cdf", ".gz")) or ".nc" in nome:
            try:
                yield from desempacotar(a.name, a.read_bytes())
            except (zipfile.BadZipFile, OSError) as e:
                log.warning("  não consegui ler %s: %s", a.name, e)


def _token() -> str:
    t = os.environ.get("GDEX_TOKEN", "").strip()
    if not t:
        arq = RAIZ / "gdex_token.txt"
        if arq.exists():
            t = arq.read_text(encoding="utf-8").strip()
    if not t:
        raise RuntimeError("falta o token do GDEX: copie o 'API Token' de https://gdex.ucar.edu/accounts/profile/ "
                           f"e salve em {RAIZ / 'gdex_token.txt'}")
    return t


def _api(sess, caminho: str, token: str) -> dict:
    r = sess.get(API + caminho, params={"token": token}, timeout=120)
    if r.status_code in (401, 403):
        raise RuntimeError(f"o GDEX recusou o token (HTTP {r.status_code}); confira o gdex_token.txt")
    r.raise_for_status()
    j = r.json()
    return j.get("data", j.get("result", j))


def pedidos_prontos(sess, token: str) -> list:
    """[(id, status, info)] dos pedidos da conta no d084001."""
    dados = _api(sess, "status/ALL", token)
    itens = dados if isinstance(dados, list) else dados.get("requests", dados.get("data", [dados]))
    out = []
    for it in itens if isinstance(itens, list) else []:
        if not isinstance(it, dict):
            continue
        rid = it.get("request_index") or it.get("rindex") or it.get("request_id") or it.get("id")
        ds = str(it.get("dataset") or it.get("dsid") or "")
        if rid is None or (ds and DATASET[1:] not in ds.replace(".", "")):
            continue
        out.append((str(rid), str(it.get("status", "")), it))
    if not out:
        amostra = itens[0] if isinstance(itens, list) and itens else itens
        chaves = sorted(amostra) if isinstance(amostra, dict) else type(amostra).__name__
        log.warning("GDEX: não reconheci pedidos do %s na resposta da API (campos: %s)", DATASET, chaves)
    return out


def _arquivos_do_pedido(sess, token: str, rid: str) -> list:
    dados = _api(sess, f"get_req_files/{rid}", token)
    arqs = dados.get("web_files", []) if isinstance(dados, dict) else []
    return [(a.get("wfile") or a["web_path"].rsplit("/", 1)[-1], a["web_path"]) for a in arqs if a.get("web_path")]


def _baixar_bytes(sess, url: str, tentativas: int = 6) -> bytes:
    espera = 5
    for k in range(1, tentativas + 1):
        try:
            r = sess.get(url, timeout=120)
            r.raise_for_status()
            return r.content
        except requests.RequestException:
            if k == tentativas:
                raise
            time.sleep(espera)
            espera = min(espera * 2, 120)
    return b""


def importar(cfg: dict, pastas, sites: list, origem: Optional[Path] = None, trabalhadores: int = 8,
             pedidos: Optional[list] = None) -> dict:
    """Importa os arquivos de `origem` (pasta/arquivo) ou, sem origem, de todos os pedidos prontos do GDEX."""
    grav = Gravador(pastas, sites, cfg["gfs"])
    t_ini = time.time()

    def processar(nome: str, conteudo: bytes) -> None:
        grav.cont["arquivos"] += 1
        try:
            info = ler_arquivo(conteudo, nome)
        except Exception as e:  # noqa: BLE001
            grav.cont["ilegiveis"] += 1
            if grav.cont["ilegiveis"] <= 5:
                log.warning("  %s: %s", nome, e)
            return
        grav.adicionar(info)
        if grav.cont["arquivos"] % 2000 == 0:
            log.info("  GFS subset: %d arquivos lidos (%.0f/s), %d (ciclo, hora, site) gravados", grav.cont["arquivos"],
                     grav.cont["arquivos"] / max(time.time() - t_ini, 1e-6), grav.cont["gravados"])

    if origem is not None:
        log.info("== Importando o GFS de %s ==", origem)
        for nome, conteudo in _conteudos_locais(Path(origem)):
            processar(nome, conteudo)
    else:
        token = _token()
        sess = requests.Session()
        sess.headers["User-Agent"] = USER_AGENT
        lista = pedidos_prontos(sess, token)
        if pedidos:
            lista = [x for x in lista if x[0] in set(map(str, pedidos))]
        if not lista:
            log.warning("GDEX: nenhum pedido do d084001 na sua conta (ou o token não é desta conta)")
        for rid, status, _ in lista:
            if status.lower() not in ("completed", "complete", "o", "online"):
                log.info("GDEX: pedido %s ainda não está pronto (%s)", rid, status)
                continue
            arqs = _arquivos_do_pedido(sess, token, rid)
            # sites cuja caixa cabe na área do pedido (pelo primeiro netCDF dele)
            na_area = set(grav.caixas)
            for nome, url in arqs[:3]:
                try:
                    n1, c1 = next(desempacotar(nome, _baixar_bytes(sess, url)))
                    info = ler_arquivo(c1, n1)
                    na_area = {cod for cod, cx in grav.caixas.items() if recortar(info, cx) is not None}
                    break
                except Exception:  # noqa: BLE001
                    continue
            log.info("GDEX: pedido %s cobre %s", rid, ", ".join(sorted(na_area)) or "nenhum site do config.yaml")
            pend = []
            feitos_cache: dict = {}
            for nome, url in arqs:
                m = _RE_ARQ.search(nome)
                if m:
                    c = _ciclo_do_nome(m.group(1))
                    chave, dia = (int(c.timestamp()), int(m.group(2))), c.strftime("%Y%m%d")
                    cods = [cod for cod, p in grav.planos.items() if chave in p and cod in na_area]
                    for cod in cods:
                        if (cod, dia) not in feitos_cache:
                            feitos_cache[(cod, dia)] = grav.feitos(cod, dia)
                    if cods and all(chave in feitos_cache[(cod, dia)] for cod in cods):
                        continue
                pend.append((nome, url))
            log.info("== GDEX: pedido %s, %d arquivos, %d a baixar ==", rid, len(arqs), len(pend))
            with ThreadPoolExecutor(max_workers=trabalhadores) as ex:
                for i in range(0, len(pend), 256):
                    lote = pend[i:i + 256]
                    futs = [(nome, ex.submit(_baixar_bytes, sess, url)) for nome, url in lote]
                    for nome, f in futs:
                        try:
                            conteudo = f.result()
                        except Exception as e:  # noqa: BLE001
                            grav.cont["ilegiveis"] += 1
                            log.warning("  falha ao baixar %s: %s", nome, e)
                            continue
                        for n2, c2 in desempacotar(nome, conteudo):
                            processar(n2, c2)
                    grav.descarregar()
    grav.descarregar()
    c = grav.cont
    log.info("GFS subset: %d arquivos; %d (ciclo, hora, site) gravados; %d fora do plano, %d fora da área dos "
             "sites, %d incompletos%s, %d ilegíveis", c["arquivos"], c["gravados"], c["fora_do_plano"],
             c["fora_da_area"], c["incompletos"],
             f" (faltou {', '.join(f'{k}: {v}' for k, v in grav.faltas.items())})" if grav.faltas else "",
             c["ilegiveis"])
    return c
