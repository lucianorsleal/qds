"""Pacote de coleta e preparação dos dados do artigo CCP-Boot-TFT-ICSO-PP."""

__version__ = "2.0.0"
