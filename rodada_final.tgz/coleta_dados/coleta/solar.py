"""Geometria solar, céu claro (Ineichen-Perez, pvlib) e checagem de fuso horário."""

from __future__ import annotations

import logging
from typing import Optional

import numpy as np
import pandas as pd
import pvlib

log = logging.getLogger("coleta")

PASSO_FINO = pd.Timedelta(minutes=5)


def altitude_site(site: dict) -> float:
    if site.get("altitude_m") is not None:
        return float(site["altitude_m"])
    try:
        from pvlib.location import lookup_altitude
        return float(lookup_altitude(site["lat"], site["lon"]))
    except Exception:  # noqa: BLE001
        return 0.0


def local(site: dict) -> pvlib.location.Location:
    return pvlib.location.Location(site["lat"], site["lon"], tz="UTC", altitude=altitude_site(site))


class CeuClaro:
    """GHI de céu claro (Ineichen-Perez) em passo de 5 min, com médias em intervalos arbitrários."""

    def __init__(self, site: dict, inicio, fim):
        loc = local(site)
        inicio = _utc(inicio).floor("D") - pd.Timedelta(days=2)
        fim = _utc(fim).ceil("D") + pd.Timedelta(days=5)
        bordas = pd.date_range(inicio, fim, freq=PASSO_FINO)
        meios = bordas[:-1] + PASSO_FINO / 2  # [t, t+5min) representado por t+2.5min
        cs = loc.get_clearsky(meios, model="ineichen")
        ghi = cs["ghi"].clip(lower=0).to_numpy(dtype=float)
        self.t0 = bordas[0]
        self.passo_s = PASSO_FINO.total_seconds()
        self.cum = np.concatenate([[0.0], np.cumsum(ghi)])
        self.n = len(ghi)

    def media(self, ini, fim) -> np.ndarray:
        """Média do GHI de céu claro em [ini, fim) em W/m² (bordas no passo de 5 min)."""
        a = ((pd.DatetimeIndex(ini) - self.t0).total_seconds() / self.passo_s)
        b = ((pd.DatetimeIndex(fim) - self.t0).total_seconds() / self.passo_s)
        a = np.clip(np.round(np.asarray(a, dtype=float)).astype(int), 0, self.n)
        b = np.clip(np.round(np.asarray(b, dtype=float)).astype(int), 0, self.n)
        larg = np.maximum(b - a, 1)
        return (self.cum[b] - self.cum[a]) / larg


def _utc(t) -> pd.Timestamp:
    t = pd.Timestamp(t)
    return t.tz_localize("UTC") if t.tzinfo is None else t.tz_convert("UTC")


def atributos_horarios(site: dict, horas_utc, ceu: Optional[CeuClaro] = None) -> pd.DataFrame:
    """Zênite no meio da hora, cos(zênite) e GHI de céu claro médio da hora [t, t+1h)."""
    horas_utc = pd.DatetimeIndex(horas_utc)
    meio = horas_utc + pd.Timedelta(minutes=30)
    pos = pvlib.solarposition.get_solarposition(meio, site["lat"], site["lon"],
                                                altitude=altitude_site(site), method="nrel_numpy")
    if ceu is None:
        ceu = CeuClaro(site, horas_utc.min(), horas_utc.max())
    ghi_cs = ceu.media(horas_utc, horas_utc + pd.Timedelta(hours=1))
    zen = pos["apparent_zenith"].to_numpy(dtype=float)
    return pd.DataFrame({
        "zenite": zen,
        "cos_zenite": np.cos(np.radians(zen)),
        "ghi_cs": ghi_cs,
    }, index=horas_utc)


def poa_ceu_claro(site: dict, horas_utc, inclinacao: float, azimute: float) -> pd.Series:
    """Irradiância de céu claro no plano dos módulos (W/m², Ineichen-Perez + modelo isotrópico) no
    meio de cada hora. azimute na convenção do pvlib: 180 = sul, 0 = norte."""
    horas_utc = pd.DatetimeIndex(horas_utc)
    meio = horas_utc + pd.Timedelta(minutes=30)
    loc = local(site)
    sp = loc.get_solarposition(meio)
    cs = loc.get_clearsky(meio, model="ineichen", solar_position=sp)
    poa = pvlib.irradiance.get_total_irradiance(float(inclinacao), float(azimute), sp["apparent_zenith"],
                                                sp["azimuth"], cs["dni"], cs["ghi"], cs["dhi"])["poa_global"]
    return pd.Series(np.clip(poa.to_numpy(dtype=float), 0.0, None), index=horas_utc)


def orientacao_referencia(site: dict, meta: Optional[dict] = None) -> tuple:
    """(inclinação, azimute) usados para descontar o céu claro: da fonte, do config.yaml ou, na
    falta, inclinação = |lat| (até 35°) voltada para o equador."""
    meta = meta or {}
    inc = meta.get("inclinacao_ref", site.get("inclinacao_ref"))
    az = meta.get("azimute_ref", site.get("azimute_ref"))
    if inc is None:
        inc = min(abs(float(site["lat"])), 35.0)
    if az is None:
        az = 180.0 if float(site["lat"]) >= 0 else 0.0
    return float(inc), float(az)


def _centro_circular(horas: np.ndarray, pesos: np.ndarray) -> float:
    ang = 2 * np.pi * horas / 24.0
    s = float(np.sum(pesos * np.sin(ang)))
    c = float(np.sum(pesos * np.cos(ang)))
    return np.arctan2(s, c) * 24.0 / (2 * np.pi)


def estimar_defasagem(y: pd.Series, ghi_cs: pd.Series, fuso_lst: str = "UTC", periodo: str = "mes") -> pd.DataFrame:
    """Diferença (h) entre o centro de massa diurno da potência e o do céu claro, por período.

    periodo='mes' ou 'semana' (domingo a sábado em hora local, alinhado às trocas do horário
    de verão brasileiro). Perto de 0: fuso e rótulo corretos. Perto de +-1 h: deslocamento de
    uma hora (horário de verão, fuso errado ou rótulo de início/fim da hora trocado).
    """
    df = pd.DataFrame({"y": y, "cs": ghi_cs}).dropna()
    df = df[df["cs"] > 0]
    if df.empty:
        return pd.DataFrame(columns=["periodo", "inicio_lst", "defasagem_h", "n_horas"])
    idx = df.index
    loc = idx.tz_convert(fuso_lst).tz_localize(None)
    if periodo == "semana":
        ini = (loc.normalize() - pd.to_timedelta((loc.dayofweek + 1) % 7, unit="D"))
        chave = ini.strftime("%Y-%m-%d")
    else:
        ini = loc.to_period("M").to_timestamp()
        chave = loc.strftime("%Y-%m")
    df = df.assign(h=idx.hour + idx.minute / 60.0, chave=chave, ini=ini)
    linhas = []
    for k, g in df.groupby("chave"):
        perfil = g.groupby("h")[["y", "cs"]].mean()
        if perfil["y"].clip(lower=0).sum() <= 0 or len(perfil) < 6:
            continue
        h = perfil.index.to_numpy(dtype=float)
        d = (_centro_circular(h, perfil["y"].clip(lower=0).to_numpy())
             - _centro_circular(h, perfil["cs"].to_numpy()))
        d = (d + 12) % 24 - 12
        linhas.append({"periodo": k, "inicio_lst": g["ini"].iloc[0], "defasagem_h": round(float(d), 3),
                       "n_horas": int(len(g))})
    return pd.DataFrame(linhas)
