"""Partição cronológica de cada site (Seção III-A e Fig. 2 do artigo).

  teste      : os 12 meses a partir de 'inicio_teste' (padrão: 1º de janeiro de 'ano_teste'),
               mês m = 1..12
  calibração : para cada mês de teste m, as 12 semanas imediatamente anteriores ao mês
  validação  : os 3 meses que antecedem a 1ª janela de calibração
  treino     : todo o período anterior à validação
Datas em hora padrão local do site; os limites finais são exclusivos.
"""

from __future__ import annotations

import pandas as pd


def inicio_teste(site: dict) -> pd.Timestamp:
    """1º dia do período de teste (data local, sem fuso)."""
    if site.get("inicio_teste"):
        return pd.Timestamp(str(site["inicio_teste"])).normalize()
    return pd.Timestamp(f"{site['ano_teste']}-01-01")


def descricao_teste(site: dict) -> str:
    """Ex.: '2025' para o ano civil ou 'dez/2022–nov/2023'."""
    ini = inicio_teste(site)
    fim = ini + pd.DateOffset(months=11)
    if ini.month == 1:
        return str(ini.year)
    meses = ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"]
    return f"{meses[ini.month - 1]}/{ini.year}–{meses[fim.month - 1]}/{fim.year}"


def tabela_particoes(site: dict) -> pd.DataFrame:
    fuso = site["fuso_lst"]
    ini_dados = pd.Timestamp(site["inicio"]).tz_localize(fuso)
    fim_dados = (pd.Timestamp(site["fim"]) + pd.Timedelta(days=1)).tz_localize(fuso)
    ini_teste = inicio_teste(site).tz_localize(fuso)
    ini_cal1 = ini_teste - pd.Timedelta(weeks=12)
    ini_val = ini_cal1 - pd.DateOffset(months=3)
    linhas = [
        {"bloco": "treino", "mes_teste": 0, "inicio_lst": ini_dados, "fim_lst": ini_val},
        {"bloco": "validacao", "mes_teste": 0, "inicio_lst": ini_val, "fim_lst": ini_cal1},
    ]
    for m in range(1, 13):
        ini_m = ini_teste + pd.DateOffset(months=m - 1)
        fim_m = min(ini_teste + pd.DateOffset(months=m), fim_dados)
        linhas.append({"bloco": "calibracao", "mes_teste": m,
                       "inicio_lst": ini_m - pd.Timedelta(weeks=12), "fim_lst": ini_m})
        linhas.append({"bloco": "teste", "mes_teste": m, "inicio_lst": ini_m, "fim_lst": fim_m})
    t = pd.DataFrame(linhas)
    t["inicio_utc"] = t["inicio_lst"].dt.tz_convert("UTC")
    t["fim_utc"] = t["fim_lst"].dt.tz_convert("UTC")
    t["inicio_lst"] = t["inicio_lst"].dt.tz_localize(None)
    t["fim_lst"] = t["fim_lst"].dt.tz_localize(None)
    return t


def rotular(indice_utc: pd.DatetimeIndex, site: dict) -> pd.DataFrame:
    """Bloco principal (treino/validacao/teste) e mês de teste para cada hora."""
    t = tabela_particoes(site)
    bloco = pd.Series("fora", index=indice_utc, dtype=object)
    mes = pd.Series(0, index=indice_utc, dtype="int16")
    # a 1ª janela de calibração (12 semanas antes do teste) não pertence a treino/validação/teste
    cal1 = t[(t["bloco"] == "calibracao") & (t["mes_teste"] == 1)].iloc[0]
    m = (indice_utc >= cal1["inicio_utc"]) & (indice_utc < cal1["fim_utc"])
    bloco[m] = "calibracao_inicial"
    for _, r in t[t["bloco"] != "calibracao"].iterrows():
        m = (indice_utc >= r["inicio_utc"]) & (indice_utc < r["fim_utc"])
        bloco[m] = r["bloco"]
        mes[m] = r["mes_teste"]
    return pd.DataFrame({"bloco": bloco, "mes_teste": mes})
