"""Monta, para cada site, a série horária limpa, o QC diário, o GFS horário e o relatório."""

from __future__ import annotations

import json
import logging
from datetime import datetime

import numpy as np
import pandas as pd

from . import gfs as gfs_mod
from . import particoes, qc
from .fontes import dkasc, hkg, nist, ons, pvdaq, ukpv, utrecht
from .nwp_selecao import entradas_dia_seguinte
from .solar import (CeuClaro, atributos_horarios, estimar_defasagem, orientacao_referencia,
                    poa_ceu_claro)

log = logging.getLogger("coleta")

FONTES = {"dkasc": dkasc, "nist": nist, "utrecht": utrecht, "ons": ons, "pvdaq": pvdaq, "ukpv": ukpv,
          "hkg": hkg}


def _periodo_utc(site):
    ini = pd.Timestamp(site["inicio"]).tz_localize(site["fuso_lst"]).tz_convert("UTC")
    fim = (pd.Timestamp(site["fim"]) + pd.Timedelta(days=1)).tz_localize(site["fuso_lst"]).tz_convert("UTC")
    return ini, fim


def _chave_semana(idx: pd.DatetimeIndex, fuso: str) -> np.ndarray:
    loc = idx.tz_convert(fuso).tz_localize(None)
    return (loc.normalize() - pd.to_timedelta((loc.dayofweek + 1) % 7, unit="D")).strftime("%Y-%m-%d").to_numpy()


def _corrigir_defasagem(h: pd.DataFrame, defas: pd.DataFrame, cols: list, chaves: np.ndarray) -> list:
    """Desloca semanas com defasagem inteira clara (|d| ~ 1 ou 2 h). Retorna as semanas corrigidas."""
    corrigidos = []
    originais = {c: h[c].copy() for c in cols}
    for _, r in defas.iterrows():
        d = float(r["defasagem_h"])
        s = int(round(d))
        if abs(s) >= 1 and abs(d - s) < 0.35:
            m = chaves == r["periodo"]
            for c in cols:
                h.loc[m, c] = originais[c].shift(-s)[m]
            corrigidos.append({"semana_inicio": r["periodo"], "defasagem_h": d, "deslocamento_aplicado_h": -s})
    return corrigidos


def _salvar(df: pd.DataFrame, caminho_base, csv: bool = True) -> None:
    df.to_parquet(caminho_base.with_suffix(".parquet"), index=False)
    if csv:
        df.to_csv(caminho_base.with_suffix(".csv"), index=False, date_format="%Y-%m-%d %H:%M:%S%z")


def processar_site(site: dict, cfg: dict, pastas, com_gfs: bool = True) -> dict:
    cod = site["codigo"]
    log.info("== Processando %s (%s) ==", cod, site["nome"])
    site = dict(site)
    ini, fim = _periodo_utc(site)
    ceu = CeuClaro(site, ini, fim)

    def attrs_fn(horas, s=site, c=ceu):
        return atributos_horarios(s, horas, c)

    mod = FONTES[site["fonte"]]
    h, meta = mod.horario(site, cfg, pastas, attrs_fn)
    if (abs(meta.get("lat", site["lat"]) - site["lat"]) > 1e-6) or (abs(meta.get("lon", site["lon"]) - site["lon"]) > 1e-6):
        log.info("  coordenadas do site atualizadas para (%.5f, %.5f)", meta["lat"], meta["lon"])
        site["lat"], site["lon"] = meta["lat"], meta["lon"]
        ceu = CeuClaro(site, ini, fim)
    pasta = pastas.processado(cod)

    attrs = atributos_horarios(site, h.index, ceu)
    h = h.join(attrs)
    h["diurno"] = h["zenite"] < cfg["qc"]["zenite_max_graus"]
    # valores fisicamente impossíveis viram faltantes; negativos pequenos viram 0
    h.loc[h["y"] > 1.2, ["y", "p_kw"]] = np.nan
    h.loc[h["y"] < 0, ["y", "p_kw"]] = 0.0

    corr = []
    if not site.get("corrigir_defasagem"):
        (pasta / "checagem_fuso_semanal.csv").unlink(missing_ok=True)  # sobra de uma rodada antiga
    if site.get("corrigir_defasagem"):
        sem = estimar_defasagem(h["y"].where(h["diurno"]), h["ghi_cs"], site["fuso_lst"], "semana")
        if not sem.empty:
            cols = [c for c in ("y", "p_kw", "disponibilidade", "n_unidades") if c in h.columns]
            corr = _corrigir_defasagem(h, sem, cols, _chave_semana(h.index, site["fuso_lst"]))
            sem.to_csv(pasta / "checagem_fuso_semanal.csv", index=False, date_format="%Y-%m-%d")
        if corr:
            log.warning("  %s: %d semana(s) com deslocamento de hora inteira corrigida(s) (horário de verão?): %s",
                        cod, len(corr), ", ".join(c["semana_inicio"] for c in corr[:12])
                        + (" ..." if len(corr) > 12 else ""))
            if len(corr) > 0.5 * len(sem):
                log.warning("  %s: mais da metade das semanas estava deslocada; o mais provável é que o rótulo "
                            "ou o fuso no config.yaml esteja errado (ex.: rotulo_intervalo: fim). Corrija e "
                            "reprocesse.", cod)
    defas = estimar_defasagem(h["y"].where(h["diurno"]), h["ghi_cs"], site["fuso_lst"], "mes")
    defas.to_csv(pasta / "checagem_fuso_mensal.csv", index=False, date_format="%Y-%m-%d")
    med = float(defas["defasagem_h"].median()) if not defas.empty else float("nan")
    ruins = defas[(defas["defasagem_h"].abs() > 0.5)] if not defas.empty else defas
    if not np.isnan(med) and abs(med) > 0.5:
        log.warning("  %s: a potência está deslocada ~%.2f h em relação ao sol; confira 'fuso_dados' e "
                    "'rotulo_intervalo' no config.yaml", cod, med)

    t_qc = qc.qc_diario(h, site, cfg["qc"])
    t_qc.to_csv(pasta / "qc_diario.csv", index=False, date_format="%Y-%m-%d")
    # teto mensal (p99 de y nas horas diurnas, relativo ao p99 da irradiância de céu claro no plano dos
    # módulos no mesmo mês): mostra quedas de capacidade disponível que duram meses.
    # Referência = percentil 90 dessa razão entre os meses.
    yd = h.loc[h["diurno"], "y"]
    mes_lst = yd.index.tz_convert(site["fuso_lst"]).tz_localize(None).to_period("M")
    teto_m = yd.groupby(mes_lst).quantile(0.99).rename("y_p99").to_frame()
    teto_m["y_max"] = yd.groupby(mes_lst).max()
    inc_ref, az_ref = orientacao_referencia(site, meta)
    poa = poa_ceu_claro(site, yd.index, inc_ref, az_ref)
    teto_m["poa_cs_p99"] = poa.groupby(mes_lst).quantile(0.99)
    razao = teto_m["y_p99"] / teto_m["poa_cs_p99"].where(teto_m["poa_cs_p99"] > 0)
    ref_razao = razao.quantile(0.9)
    teto_m["teto_relativo"] = razao / ref_razao if ref_razao and np.isfinite(ref_razao) else np.nan
    teto_m = teto_m.round(4)
    teto_m.index = teto_m.index.astype(str)
    teto_m.rename_axis("mes").reset_index().to_csv(pasta / "checagem_teto_mensal.csv", index=False)
    meses_baixos = teto_m.loc[teto_m["teto_relativo"] < 0.8, "teto_relativo"]
    lst = h.index.tz_convert(site["fuso_lst"])
    h["data_lst"] = pd.to_datetime(lst.date)
    h = h.join(t_qc.set_index("data_lst")["manter"].rename("manter_dia"), on="data_lst")
    h["manter_dia"] = h["manter_dia"].fillna(False).astype(bool)
    h["tempo_lst"] = lst.tz_localize(None)
    h["hora_lst"] = lst.hour.astype("int16")
    h["dia_ano"] = lst.dayofyear.astype("int16")
    h["mes"] = lst.month.astype("int16")
    h = h.join(particoes.rotular(h.index, site))
    h.index.name = "tempo_utc"
    saida = h.reset_index()
    ordem = ["tempo_utc", "tempo_lst", "data_lst", "hora_lst", "dia_ano", "mes", "y", "p_kw", "capacidade_kw",
             "disponibilidade", "n_unidades", "restrita", "zenite", "cos_zenite", "ghi_cs", "diurno", "manter_dia",
             "bloco", "mes_teste"]
    saida = saida[[c for c in ordem if c in saida.columns]]
    _salvar(saida, pasta / "potencia_horaria")
    particoes.tabela_particoes(site).to_csv(pasta / "particoes.csv", index=False)
    if isinstance(meta.get("tabela_unidades"), pd.DataFrame):
        meta["tabela_unidades"].to_csv(pasta / "unidades.csv", index=False)
    if isinstance(meta.get("composicao_cadastro_ons"), pd.DataFrame):
        meta["composicao_cadastro_ons"].to_csv(pasta / "composicao_ons.csv", index=False)

    res_qc = qc.resumo_qc(t_qc)
    validas = saida.loc[saida["diurno"] & saida["y"].notna(), "tempo_utc"]
    resumo = {
        "site": cod, "nome": site["nome"], "fonte": site["fonte"],
        "lat": round(float(site["lat"]), 5), "lon": round(float(site["lon"]), 5),
        "koppen": site.get("koppen"), "fuso_lst": site["fuso_lst"],
        "periodo": f"{site['inicio']} a {site['fim']}", "ano_teste": particoes.descricao_teste(site),
        "pnom_kw": meta["pnom_kw"], "unidade_pnom": meta.get("unidade_pnom"),
        "n_unidades": meta.get("n_unidades"),
        "primeira_hora_valida_utc": str(validas.min()) if len(validas) else None,
        "ultima_hora_valida_utc": str(validas.max()) if len(validas) else None,
        "horas_diurnas": int(saida["diurno"].sum()),
        "pct_horas_diurnas_com_dado": round(100.0 * saida.loc[saida["diurno"], "y"].notna().mean(), 2),
        "y_p999_diurno": round(float(saida.loc[saida["diurno"], "y"].quantile(0.999)), 4),
        "defasagem_mediana_h": round(med, 3) if not np.isnan(med) else None,
        "meses_defasagem_maior_0p5h": int(len(ruins)),
        "teto_mensal_p99_min_max": (round(float(teto_m["y_p99"].min()), 3), round(float(teto_m["y_p99"].max()), 3))
        if len(teto_m) else None,
        "orientacao_ref_teto": f"{inc_ref:.0f}° / azimute {az_ref:.0f}°",
        "meses_teto_abaixo_80pct": [f"{m} ({v:.2f})" for m, v in meses_baixos.items()],
        "semanas_corrigidas": corr,
        **{f"qc_{k}": v for k, v in res_qc.items()},
    }
    for k in ("p_max_observado_kw", "soma_potencia_efetiva_mw", "id_ons", "nome_ons", "colunas_potencia_usadas",
              "capacidade_instalada_mw_min_max", "capacidade_total_kwp", "capacidade_em_servico_kwp_min_max",
              "disponibilidade_frota_diurna_media", "pct_horas_diurnas_abaixo_limite_frota",
              "restricao_ons_periodo", "pct_horas_com_geracao_restritas", "system_id", "canais_potencia",
              "regiao", "n_sistemas"):
        if k in meta:
            resumo[k] = meta[k]

    if com_gfs:
        try:
            log.info("  processando GFS de %s", cod)
            g = gfs_mod.processar(site, cfg, pastas, ceu)
            g.to_parquet(pasta / "gfs_horario.parquet", index=False)
            da = entradas_dia_seguinte(g, site["fuso_lst"], latencia_h=cfg["gfs"].get("latencia_h", 5))
            da.to_parquet(pasta / "gfs_dia_seguinte.parquet", index=False)
            cob = gfs_mod.cobertura(pastas.gfs(cod), site["lat"], site["lon"])
            resumo.update({f"gfs_{k}": v for k, v in cob.items()})
            resumo["gfs_ciclos"] = int(g["ciclo_utc"].nunique())
            resumo["gfs_pct_ghi_faltante"] = round(100.0 * g["ghi_nwp"].isna().mean(), 3)
            log.info("  GFS %s: %d ciclos, %d linhas", cod, resumo["gfs_ciclos"], len(g))
        except FileNotFoundError as e:
            log.warning("  GFS de %s ainda não baixado (%s)", cod, e)
            resumo["gfs_dias"] = 0
    with open(pasta / "resumo.json", "w", encoding="utf-8") as f:
        json.dump(resumo, f, ensure_ascii=False, indent=2, default=str)
    log.info("  %s: Pnom = %s kW | %.1f%% das horas diurnas com dado | %s%% dos dias removidos no QC",
             cod, resumo["pnom_kw"], resumo["pct_horas_diurnas_com_dado"], resumo.get("qc_pct_removidos"))
    return resumo


def escrever_relatorio(resumos: list, pastas) -> None:
    if not resumos:
        return
    tab = pd.DataFrame(resumos)
    tab.to_csv(pastas.processados / "resumo_sites.csv", index=False)
    L = []
    L.append("# Relatório da coleta de dados — CCP-Boot-TFT-ICSO-PP\n")
    L.append(f"Gerado em {datetime.now():%Y-%m-%d %H:%M}.\n")
    L.append("## Valores para a Tabela 4 e para os itens em roxo do artigo\n")
    L.append("| Site | Local (lat, lon) | Köppen | Sistema | Pnom | Período (teste) | Dias removidos no QC |")
    L.append("|---|---|---|---|---|---|---|")
    for r in resumos:
        sistema = r.get("nome_ons") or r["nome"]
        if (r.get("n_unidades") or 0) > 1:
            sistema += f" — {r['n_unidades']} unidades"
        pn = r["pnom_kw"]
        pn_txt = f"{pn / 1000:.1f} MW" if pn >= 10000 else f"{pn:.1f} kW"
        L.append(f"| {r['site']} | {r['lat']:.4f}, {r['lon']:.4f} | {r.get('koppen')} | {sistema} | "
                 f"{pn_txt} ({r.get('unidade_pnom')}) | {r['periodo']} ({r['ano_teste']}) | "
                 f"{r.get('qc_pct_removidos', '—')}% |")
    L.append("")
    for r in resumos:
        L.append(f"## {r['site']} — {r['nome']}\n")
        L.append(f"- Horas diurnas com dado: {r['pct_horas_diurnas_com_dado']}% "
                 f"(primeira {r['primeira_hora_valida_utc']}, última {r['ultima_hora_valida_utc']} UTC)")
        L.append(f"- Percentil 99,9 de y nas horas diurnas: {r['y_p999_diurno']} (limite físico ȳ)")
        L.append(f"- QC: {r.get('qc_dias_removidos')} de {r.get('qc_dias')} dias removidos "
                 f"(faltantes {r.get('qc_pct_faltante')}%, saída zero {r.get('qc_pct_saida_zero')}%, "
                 f"curtailment {r.get('qc_pct_curtailment')}%, clipping {r.get('qc_pct_clipping')}%)")
        d = r.get("defasagem_mediana_h")
        L.append(f"- Checagem de fuso: defasagem mediana {d} h; meses com |defasagem| > 0,5 h: "
                 f"{r.get('meses_defasagem_maior_0p5h')}"
                 + (f"; semanas corrigidas: {', '.join(c['semana_inicio'] for c in r['semanas_corrigidas'])}"
                    if r.get("semanas_corrigidas") else ""))
        if r.get("teto_mensal_p99_min_max"):
            baixos = r.get("meses_teto_abaixo_80pct") or []
            L.append(f"- Teto mensal (p99 de y nas horas diurnas): de {r['teto_mensal_p99_min_max'][0]} a "
                     f"{r['teto_mensal_p99_min_max'][1]}; meses com teto < 80% do usual (já descontado o céu "
                     f"claro do mês no plano {r.get('orientacao_ref_teto')}): "
                     + (f"{len(baixos)} — {', '.join(baixos[:24])}" + (" ..." if len(baixos) > 24 else "")
                        if baixos else "nenhum")
                     + " (quedas longas indicam capacidade indisponível; veja checagem_teto_mensal.csv)")
        if r.get("gfs_dias"):
            L.append(f"- GFS: {r['gfs_ciclos']} ciclos; arquivos ok {r['gfs_ok']}, ausentes no arquivo do NCAR "
                     f"{r['gfs_ausentes_no_arquivo']}, falhas {r['gfs_falhas']}; GHI faltante "
                     f"{r['gfs_pct_ghi_faltante']}%")
        else:
            L.append("- GFS: ainda não baixado/processado")
        for k in ("p_max_observado_kw", "soma_potencia_efetiva_mw", "capacidade_instalada_mw_min_max",
                  "capacidade_total_kwp", "capacidade_em_servico_kwp_min_max", "disponibilidade_frota_diurna_media",
                  "pct_horas_diurnas_abaixo_limite_frota", "restricao_ons_periodo",
                  "pct_horas_com_geracao_restritas", "qc_pct_dias_com_restricao_ons", "system_id",
                  "canais_potencia", "regiao", "n_sistemas"):
            if r.get(k) is not None:
                L.append(f"- {k}: {r[k]}")
        L.append("")
    (pastas.processados / "relatorio_coleta.md").write_text("\n".join(L), encoding="utf-8")
    log.info("Relatório: %s", pastas.processados / "relatorio_coleta.md")
