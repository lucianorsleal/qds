"""Controle de qualidade diário (Seção V-B do artigo).

Remove dias com mais de 10% das horas diurnas faltando, falhas de inversor/neve
(potência ~0 com sol alto) e perfis achatados (curtailment ou clipping).
"""

from __future__ import annotations

import numpy as np
import pandas as pd


def _maior_sequencia(mask: np.ndarray) -> int:
    melhor = atual = 0
    for m in mask:
        atual = atual + 1 if m else 0
        melhor = max(melhor, atual)
    return melhor


def _platos(y: np.ndarray, delta_max: float, y_min: float, n_min: int) -> list:
    """Sequências de >= n_min horas consecutivas com y >= y_min e |dy| <= delta_max. Retorna médias."""
    medias = []
    i = 0
    n = len(y)
    while i < n:
        if not (np.isfinite(y[i]) and y[i] >= y_min):
            i += 1
            continue
        j = i
        while j + 1 < n and np.isfinite(y[j + 1]) and y[j + 1] >= y_min and abs(y[j + 1] - y[j]) <= delta_max:
            j += 1
        if j - i + 1 >= n_min:
            medias.append(float(np.mean(y[i:j + 1])))
        i = j + 1
    return medias


def qc_diario(h: pd.DataFrame, site: dict, cfg_qc: dict) -> pd.DataFrame:
    """h: índice UTC horário com colunas y, zenite, ghi_cs. Retorna tabela por dia (hora padrão local)."""
    lst = h.index.tz_convert(site["fuso_lst"])
    dados = h.assign(data_lst=lst.date, diurno=h["zenite"] < cfg_qc["zenite_max_graus"])
    sz = cfg_qc["saida_zero"]
    pl = cfg_qc["plato"]
    linhas = []
    platos_dia = []
    for data, g in dados.groupby("data_lst", sort=True):
        d = g[g["diurno"]]
        n_d = int(len(d))
        y = d["y"].to_numpy(dtype=float)
        validas = np.isfinite(y)
        # horas cortadas pelo operador (ONS) saem da série, mas não contam como dado faltante
        restr = d["restrita"].to_numpy(dtype=bool) if "restrita" in d.columns else np.zeros(n_d, dtype=bool)
        n_base = n_d - int(restr.sum())
        frac_falta = 1.0 - validas.sum() / n_base if n_base > 0 else (0.0 if n_d else 1.0)
        zero = validas & (y <= sz["y_max"]) & (d["ghi_cs"].to_numpy() >= sz["ghi_cs_min"])
        seq_zero = _maior_sequencia(zero)
        platos_dia.append(_platos(y, pl["delta_max"], pl["y_min"], pl["horas_consecutivas"]))
        linhas.append({
            "data_lst": pd.Timestamp(data),
            "horas_diurnas": n_d,
            "horas_validas": int(validas.sum()),
            "frac_faltante": round(float(frac_falta), 4),
            "energia_norm": round(float(np.nansum(y)), 4),
            "y_max": round(float(np.nanmax(y)), 4) if validas.any() else np.nan,
            "horas_restritas": int(restr.sum()),
            "flag_faltante": bool(frac_falta > cfg_qc["frac_max_faltante_diurno"]),
            "flag_saida_zero": bool(seq_zero >= sz["horas_consecutivas"]),
            "flag_restricao_ons": bool(restr.any()),
        })
    t = pd.DataFrame(linhas)
    # Teto do período: percentil 90 do máximo diário numa janela de 31 dias. Um platô no teto é
    # clipping (limite do inversor ou da capacidade disponível naquelas semanas); um platô bem
    # abaixo do teto é uma limitação pontual (curtailment).
    teto = t["y_max"].rolling(31, center=True, min_periods=10).quantile(0.9).to_numpy()
    frac_teto = float(pl.get("frac_teto_clipping", 0.9))
    clip, curt, nivel = [], [], []
    for platos, tt in zip(platos_dia, teto):
        e_clip = [m >= pl["limiar_clipping"] or (np.isfinite(tt) and m >= frac_teto * tt) for m in platos]
        clip.append(any(e_clip))
        curt.append(any(not c for c in e_clip))
        nivel.append(round(float(max(platos)), 4) if platos else np.nan)
    t["teto_31d"] = np.round(teto, 4)
    t["plato_nivel"] = nivel
    t["flag_curtailment"] = curt
    t["flag_clipping"] = clip
    remover = t["flag_faltante"] | t["flag_saida_zero"]
    if cfg_qc.get("remover_dias_com_restricao_ons", False):
        remover |= t["flag_restricao_ons"]
    if pl.get("remover_curtailment", True):
        remover |= t["flag_curtailment"]
    if pl.get("remover_clipping", True):
        remover |= t["flag_clipping"]
    t["manter"] = ~remover
    return t


def resumo_qc(t: pd.DataFrame) -> dict:
    n = len(t)
    if n == 0:
        return {}
    return {
        "dias": n,
        "dias_removidos": int((~t["manter"]).sum()),
        "pct_removidos": round(100.0 * (~t["manter"]).mean(), 2),
        "pct_faltante": round(100.0 * t["flag_faltante"].mean(), 2),
        "pct_saida_zero": round(100.0 * t["flag_saida_zero"].mean(), 2),
        "pct_curtailment": round(100.0 * t["flag_curtailment"].mean(), 2),
        "pct_clipping": round(100.0 * t["flag_clipping"].mean(), 2),
        "pct_dias_com_restricao_ons": round(100.0 * t["flag_restricao_ons"].mean(), 2),
    }
