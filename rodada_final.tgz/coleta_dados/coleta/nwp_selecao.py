"""Seleção do ciclo GFS 'disponível' em cada instante de emissão (sem olhar o futuro).

Regra do artigo (Seção III-A): uma previsão emitida em t0 usa o ciclo mais recente
disponível em t0 com latência de disseminação de 5 h, isto é, o maior ciclo c com c + 5 h <= t0.
No teste de estresse S3 (falha do NWP) usa-se o ciclo emitido 24 h antes (atraso_h=24).
Se o ciclo escolhido não tiver dado para uma hora-alvo, recua 6 h por vez (até 24 h)
e marca 'ciclo_substituto'.

Uso típico (no código dos modelos):
    import pandas as pd
    from coleta.nwp_selecao import entradas_intradiarias, entradas_dia_seguinte
    gfs = pd.read_parquet("dados/processados/GTB/gfs_horario.parquet")
    emissoes = pd.date_range("2018-01-01 05:00", "2018-01-31 23:00", freq="h", tz="UTC")
    x = entradas_intradiarias(gfs, emissoes)          # 36 horas-alvo por emissão
    da = entradas_dia_seguinte(gfs, "Etc/GMT+5")      # dia seguinte, emissão 12:00 local
"""

from __future__ import annotations

import pandas as pd

VARS_NWP = ["ghi_nwp", "k_nwp", "tcc", "t2m", "rh2m", "t2m_x_rh2m", "u10", "v10", "ghi_cs"]


def ciclo_disponivel(t0_utc, latencia_h: float = 5, atraso_h: float = 0):
    """Maior ciclo c (00/06/12/18 UTC) com c + latência <= t0, recuado de atraso_h."""
    if isinstance(t0_utc, pd.Timestamp):
        t = t0_utc.tz_convert("UTC") if t0_utc.tzinfo else t0_utc.tz_localize("UTC")
    else:
        t = pd.DatetimeIndex(pd.to_datetime(t0_utc, utc=True))
    return (t - pd.Timedelta(hours=latencia_h)).floor("6h") - pd.Timedelta(hours=atraso_h)


def _juntar(alvos: pd.DataFrame, gfs: pd.DataFrame, recuos=(0, 6, 12, 18, 24)) -> pd.DataFrame:
    g = gfs.set_index(["ciclo_utc", "valido_utc"])
    cols = [c for c in VARS_NWP + ["lead_h"] if c in g.columns]
    res = None
    for r in recuos:
        chave = pd.MultiIndex.from_arrays([alvos["ciclo_utc"] - pd.Timedelta(hours=r), alvos["valido_utc"]])
        parte = g.reindex(chave)[cols].reset_index(drop=True)
        parte["ciclo_usado"] = (alvos["ciclo_utc"] - pd.Timedelta(hours=r)).to_numpy()
        if res is None:
            res = parte
        else:
            falta = res["ghi_nwp"].isna() & parte["ghi_nwp"].notna()
            res.loc[falta] = parte.loc[falta]
    out = pd.concat([alvos.reset_index(drop=True), res], axis=1)
    out["ciclo_substituto"] = out["ciclo_usado"] != out["ciclo_utc"]
    return out


def entradas_intradiarias(gfs: pd.DataFrame, emissoes_utc, horizonte_h: int = 36,
                          latencia_h: float = 5, atraso_h: float = 0) -> pd.DataFrame:
    """Para cada emissão t0, as horas-alvo [t0+k-1, t0+k), k = 1..horizonte_h, com o NWP do ciclo disponível."""
    t0 = pd.DatetimeIndex(pd.to_datetime(emissoes_utc, utc=True))
    c = ciclo_disponivel(t0, latencia_h, atraso_h)
    k = pd.RangeIndex(1, horizonte_h + 1)
    alvos = pd.DataFrame({
        "emissao_utc": t0.repeat(len(k)),
        "k": list(k) * len(t0),
        "ciclo_utc": c.repeat(len(k)),
    })
    alvos["valido_utc"] = alvos["emissao_utc"] + pd.to_timedelta(alvos["k"] - 1, unit="h")
    return _juntar(alvos, gfs)


def entradas_dia_seguinte(gfs: pd.DataFrame, fuso_lst: str, hora_emissao_local: int = 12,
                          latencia_h: float = 5, atraso_h: float = 0, dias_lst=None) -> pd.DataFrame:
    """Para cada dia D (hora padrão local), emissão às 12:00 de D-1 e as 24 horas de D."""
    if dias_lst is None:
        v = pd.DatetimeIndex(gfs["valido_utc"]).tz_convert(fuso_lst)
        dias_lst = pd.date_range(v.min().normalize() + pd.Timedelta(days=2), v.max().normalize(), freq="D")
    dias = pd.DatetimeIndex(dias_lst)
    if dias.tz is None:
        dias = dias.tz_localize(fuso_lst)
    t0 = (dias - pd.Timedelta(days=1) + pd.Timedelta(hours=hora_emissao_local)).tz_convert("UTC")
    c = ciclo_disponivel(t0, latencia_h, atraso_h)
    alvos = pd.DataFrame({
        "dia_lst": dias.tz_localize(None).repeat(24),
        "hora_lst": list(range(24)) * len(dias),
        "emissao_utc": t0.repeat(24),
        "ciclo_utc": c.repeat(24),
    })
    validos = pd.DatetimeIndex(dias.repeat(24)) + pd.to_timedelta(alvos["hora_lst"].to_numpy(), unit="h")
    alvos["valido_utc"] = validos.tz_convert("UTC")
    return _juntar(alvos, gfs)
