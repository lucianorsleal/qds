@echo off
REM 1a etapa da coleta: baixa e processa a POTENCIA das 3 usinas (YUL, BRA, GEO), sem o GFS.
REM Nao precisa de login nem de arquivo manual: DKASC, ONS e PVDAQ sao abertos.
REM Ja registra o aceite dos termos do DKASC (https://dkasolarcentre.com.au/download/terms-conditions).
call "%~dp0rodar_coleta.bat" --aceito-termos-dkasc --so-potencia
