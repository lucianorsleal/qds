@echo off
REM Coleta dos dados do artigo CCP-Boot-TFT-ICSO-PP (Windows)
REM Clique duas vezes neste arquivo ou rode-o no Prompt de Comando.
REM Argumentos extras sao repassados ao "coletar.py tudo" (ex.: --aceito-termos-dkasc).
setlocal EnableExtensions
cd /d "%~dp0"
title Coleta de dados - CCP-Boot-TFT-ICSO-PP
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
if not exist dados\logs mkdir dados\logs

REM ---------- localizar o Python (launcher py, PATH ou instalacao por usuario) ----------
set "PYEXE="
for /f "delims=" %%P in ('py -3 -c "import sys;print(sys.executable)" 2^>nul') do set "PYEXE=%%P"
if defined PYEXE if not exist "%PYEXE%" set "PYEXE="
if not defined PYEXE for /f "delims=" %%P in ('python -c "import sys;print(sys.executable)" 2^>nul') do set "PYEXE=%%P"
if defined PYEXE if not exist "%PYEXE%" set "PYEXE="
if not defined PYEXE for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do if exist "%%D\python.exe" set "PYEXE=%%D\python.exe"
if not defined PYEXE (
  echo Python nao encontrado. Instale o Python 3.10 ou mais novo em https://www.python.org/downloads/
  pause
  exit /b 1
)
echo Python encontrado: %PYEXE%

REM ---------- ambiente virtual e dependencias ----------
if not exist ".venv\Scripts\python.exe" (
  echo Criando o ambiente virtual .venv ...
  "%PYEXE%" -m venv .venv
  if errorlevel 1 (
    echo Falha ao criar o ambiente virtual.
    pause
    exit /b 1
  )
)
set "VPY=%~dp0.venv\Scripts\python.exe"
echo Instalando as dependencias (detalhes em dados\logs\instalacao.log) ...
"%VPY%" -m pip install --upgrade pip > dados\logs\instalacao.log 2>&1
"%VPY%" -m pip install -r requirements.txt >> dados\logs\instalacao.log 2>&1
if errorlevel 1 (
  echo Falha ao instalar as dependencias. Veja dados\logs\instalacao.log
  pause
  exit /b 1
)
echo Dependencias instaladas.

REM ---------- coleta ----------
"%VPY%" coletar.py verificar
"%VPY%" coletar.py tudo %*
echo.
echo Fim. O resumo esta em dados\processados\relatorio_coleta.md
pause
