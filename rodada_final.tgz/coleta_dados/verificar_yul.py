"""Confere o Desert Gardens (YUL) nos arquivos anuais do DKASC antes de processar a coleta.

Para cada trimestre do período do YUL no config.yaml, compara o Desert Gardens com três vizinhos de Yulara
(Service Station, Laundry e Connellan Airport) nos dias claros (piranômetro):
  * razão meio-dia/máximo do dia: perto de 1 numa usina sem limitação; em jan-abr/2021 o Desert Gardens ficou em
    0,20-0,36 (corte de potência pela microrrede do resort), enquanto os vizinhos ficaram em 0,98;
  * pico do dia / kWp: separa colunas trocadas (em mai/2021-dez/2022 a coluna da usina mostrava ~6% da nominal).

Uso:   python verificar_yul.py [--config config.yaml]
Saída: tabela por trimestre e veredito. Código de saída 1 se algum trimestre parecer limitado ou com canal trocado
(aí não processe o YUL com esse período; mande a tabela para análise).
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

SISTEMAS = {5: ("DG", 1058.4), 10: ("SS", 226.8), 11: ("LD", 327.6), 8: ("CA", 105.9)}
VIZINHOS = ("SS", "LD", "CA")
RE_POT = re.compile(r"^(\d+)_.*Active_Power$")


def ler_ano(arq: Path) -> pd.DataFrame:
    cab = pd.read_csv(arq, nrows=0).columns
    usar = {}
    for c in cab:
        m = RE_POT.match(c)
        if m and int(m.group(1)) in SISTEMAS:
            usar[c] = SISTEMAS[int(m.group(1))][0]
        elif c.lower() == "timestamp":
            usar[c] = "t"
        elif c.endswith("Pyranometer_1") and "PYR" not in usar.values():
            usar[c] = "PYR"
    faltam = {"t", "PYR", "DG"} - set(usar.values())
    if faltam:
        raise SystemExit(f"{arq.name}: colunas não encontradas: {sorted(faltam)}")
    df = pd.read_csv(arq, usecols=list(usar)).rename(columns=usar)
    df["t"] = pd.to_datetime(df["t"], errors="coerce")
    df = df.dropna(subset=["t"]).set_index("t").sort_index()
    df = df[~df.index.duplicated()].apply(pd.to_numeric, errors="coerce")
    df.loc[(df["PYR"] > 2000) | (df["PYR"] < -50), "PYR"] = np.nan
    return df


def dias_claros(df: pd.DataFrame) -> pd.DataFrame:
    h = df.resample("30min").mean()
    linhas = []
    for dia, x in h.groupby(h.index.normalize()):
        x = x.between_time("07:00", "18:00")
        p = x["PYR"].to_numpy(dtype=float)
        if len(p) == 0 or np.isnan(p).sum() > 2 or np.nanmax(p) < 750:
            continue
        pp = pd.Series(p).interpolate().to_numpy()
        if np.nansum(np.abs(np.diff(pp, 2))) > 0.6 * np.nanmax(pp):      # dia com nuvens passando
            continue
        meio = x.between_time("11:30", "13:30")
        r = {"dia": dia}
        for _, (nome, kwp) in SISTEMAS.items():
            if nome not in x:
                continue
            mx = x[nome].max()
            r[f"{nome}_razao"] = meio[nome].mean() / mx if mx and mx > 0 else np.nan
            r[f"{nome}_pico"] = mx / kwp if mx == mx else np.nan
        linhas.append(r)
    return pd.DataFrame(linhas).set_index("dia") if linhas else pd.DataFrame()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.yaml")
    a = ap.parse_args()
    raiz = Path(a.config).resolve().parent
    cfg = yaml.safe_load(open(a.config, encoding="utf-8"))
    site = cfg["sites"]["YUL"]
    ini, fim = pd.Timestamp(str(site["inicio"])), pd.Timestamp(str(site["fim"])) + pd.Timedelta(days=1)
    pasta = raiz / cfg.get("pasta_dados", "dados") / "brutos" / "YUL"
    partes = []
    for ano in range(ini.year, fim.year + 1):
        arq = pasta / f"Yulara_{ano}.csv"
        if not arq.exists():
            if ano < fim.year or fim > pd.Timestamp(f"{ano}-01-01"):
                print(f"falta {arq} (rode antes: python coletar.py baixar --sites YUL --fontes dkasc "
                      "--aceito-termos-dkasc)")
                return 1
            continue
        partes.append(ler_ano(arq))
    df = pd.concat(partes).sort_index()
    df = df[(df.index >= ini) & (df.index < fim)]
    r = dias_claros(df)
    if r.empty:
        print("nenhum dia claro encontrado: confira o piranômetro nos arquivos")
        return 1
    tri = r.index.to_period("Q")
    tab = pd.DataFrame({"dias_claros": r.groupby(tri).size()})
    for nome in ["DG", *VIZINHOS]:
        if f"{nome}_razao" in r:
            tab[f"{nome}_corte"] = (r[f"{nome}_razao"] < 0.8).where(r[f"{nome}_razao"].notna()).groupby(tri).mean()
            tab[f"{nome}_pico"] = r[f"{nome}_pico"].groupby(tri).median()
    viz_corte = tab[[f"{v}_corte" for v in VIZINHOS if f"{v}_corte" in tab]].max(axis=1)
    picos = tab[[f"{v}_pico" for v in VIZINHOS if f"{v}_pico" in tab]]
    viz_pico = picos.where(picos <= 1.5).median(axis=1)          # > 1,5 kWp: contador de energia, não potência
    tab["limitado"] = (tab["DG_corte"] >= 0.25) & (tab["DG_corte"] - viz_corte >= 0.2)
    tab["canal_suspeito"] = tab["DG_pico"] < 0.6 * viz_pico
    pd.set_option("display.width", 200)
    print("Desert Gardens (DG) e vizinhos nos dias claros, por trimestre")
    print("  *_corte = fração dos dias claros com o meio-dia abaixo de 80% do máximo do dia (0 = sem corte)")
    print("  *_pico  = mediana do pico do dia / kWp")
    print(tab.round(2).to_string())
    ruins = tab.index[tab["limitado"] | tab["canal_suspeito"]]
    if len(ruins):
        print(f"\nATENÇÃO: trimestres com corte de potência ou canal trocado no Desert Gardens: "
              f"{', '.join(str(q) for q in ruins)}. Não processe o YUL com este período.")
        return 1
    print(f"\nOK: o Desert Gardens não mostra corte nem canal trocado entre {ini.date()} e "
          f"{(fim - pd.Timedelta(days=1)).date()}.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
