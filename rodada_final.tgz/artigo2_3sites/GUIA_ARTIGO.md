# Guia para levar os resultados ao artigo

Pacote de experimentos v3.0.

Sites: **BRA e GEO** (2 sites, 8 pares site–horizonte); sementes: **3**; membros do ensemble: **10**. Site desértico (o papel que o ASP tinha no texto): **BRA**.

**Avisos**

- O matplotlib não está instalado: as figuras PDF/PNG (pasta figuras/) não foram geradas. Rode de novo o instalar_experimentos.bat e depois o gerar_relatorio.bat.

## 1. O que tem nesta pasta

| Arquivo | Onde entra no artigo |
|---|---|
| `tables/tab_data.tex` | Tab. 4 (sites e dados): troque a tabela escrita à mão por `\input{tables/tab_data}` |
| `tables/tab_main.tex` | Tab. 5 (comparação geral), `\input{tables/tab_main}` |
| `tables/tab_sites.tex` | Tab. 6 (por site, DM com Holm) |
| `tables/tab_layers.tex` | Tab. 7 (camadas de calibração) |
| `tables/tab_groups.tex` | Tab. 8 (cobertura por grupo no DA) |
| `tables/tab_ablation.tex` | Tab. 9 (ablação B1–B5, B4h e B5a–B5g; a linha B4h faz o papel da antiga Tab. 10) |
| `tables/tab_stress.tex` | Tab. 11 (estresse S0–S5) |
| `tables/tab_cost.tex` | Tab. 12 (custo computacional) |
| `macros/results_macros.tex` | todos os números do texto (`\R...`), com os mesmos nomes do `main.tex` |
| `macros/wgc_reference.tex` | referência amostral do WGC (Seção IV e Fig. 6b) |
| `data/*.csv` | dados das figuras em pgfplots (Figs. 6–12) |
| `figuras/fig_*.pdf` (e `.png`) | as mesmas figuras em matplotlib, para `\includegraphics` |
| `figuras/fig_vsn_pgfplots.tex` | Fig. 9 em pgfplots para estes sites (a do `main.tex` tem 4 colunas fixas) |
| `figuras/fig_example.pdf` | figura nova (opcional): uma semana de previsões DA por site, proposto × antecessor |
| `figuras/fig_weights.pdf` | figura nova da v3: peso do TFT escolhido em cada mês de teste, por horizonte e site (substitui a Fig. 8, de convergência dos otimizadores; dados em `data/fig_weights.csv`) |
| `results/*.csv` | as tabelas em CSV (o que gerou tudo acima) |

## 2. Como levar para o projeto LaTeX

1. Copie `tables/`, `macros/`, `data/` e `figuras/` para a pasta do artigo (ou rode `python executar.py artigo --latex <pasta do artigo>`, que copia tudo).
2. **Não rode** `tools/render_tables.py` nem o `build.sh` do zip de 16/10: eles regeram tabelas e macros com a lista fixa ASP, GTB, UTR e BRA e sobrescrevem estas. Compile direto: `latexmk -pdf main.tex`.
3. No `main.tex`: troque a Tab. 4 por `\input{tables/tab_data}` e o bloco da Fig. 9 por `\input{figuras/fig_vsn_pgfplots}` (assim ela acompanha o número de sites de cada rodada). As outras figuras em pgfplots já leem `data/*.csv` e não dependem do número de sites. Se preferir as versões em matplotlib, use por exemplo `\includegraphics[width=\textwidth]{figuras/fig_horizon.pdf}` no lugar do `tikzpicture`.
4. Figura nova: `figuras/fig_example.pdf` não existe no artigo; se quiser usá-la (bloco pronto, com legenda, em `figuras/fig_example.tex`: `\input{figuras/fig_example}`), ela cabe na Seção VI-A (mostra os intervalos acompanhando os regimes).
5. Quando os números forem os finais, ponha `\showplaceholdersfalse` no preâmbulo.

A pasta `artigo2_3sites`, entregue com o pacote, é o projeto do zip de 16/10 já com os passos 2–3 e as mudanças da seção 3 abaixo. Para pôr nela os números de uma rodada nova: `gerar_relatorio.bat --latex ..\artigo2_3sites` e compile.

## 3. O que muda no texto (modelo da v3 e sites)

**Modelo da v3 (TFT + LightGBM, sem o ICSO-PP nas cabeças).** Estas mudanças valem para o texto todo; as seguintes são as de sites.

- **Nome:** “CCP-Boot-TFT-ICSO-PP” → `\RModelName` (provisório: CCP-Boot-TFT-GBM; troque a constante MODELO em exp/artigo.py se escolher outro). O ICSO-PP continua só no antecessor (CP-Boot-LSTM-ICSO-PP) e na ablação B4h.
- **Resumo, contribuições e conclusão:** a contribuição do Estágio 3 com ICSO-PP sai. Entram: (i) a combinação, por horizonte, do ensemble de TFTs com modelos quantílicos de gradient boosting, com o peso escolhido em cada janela de calibração pelo IS condicional em validação cruzada; (ii) escalas separadas para os lados de baixo e de cima na camada condicional, tiradas dos quantis de cada modelo.
- **Fig. 1 (pipeline):** a caixa do Estágio 3 (ICSO-PP) vira “LightGBM quantiles + per-window combination”; a do Estágio 4, “conditional CP with lower/upper scales”. A cabeça mediana deixa de ter o rótulo ICSO-PP.
- **Seção III (Estágio 3, antes ICSO-PP):** texto sugerido: “LightGBM quantile models (21 levels, one set per horizon) are fitted on the tabular inputs, including the clear-sky indices of the last three hours. The TFT and LightGBM medians are combined as $\hat y = w\,\hat y_{\mathrm{TFT}} + (1-w)\,\hat y_{\mathrm{GBM}}$, and their lower and upper scales likewise. The weight $w\in\{0, 0.2, 0.4, 0.6, 0.8, 1\}$ is chosen in every calibration window (horizon $\times$ test month) as the one with the lowest conditional interval score, cross-fitted over the two halves of the window's days; nothing from the test month enters the choice.”
- **Seção III (Estágio 4):** os escores passam a ter uma escala por lado: $E^{+}=(y-\hat y)^{+}/s^{\uparrow}$ e $E^{-}=(\hat y-y)^{+}/s^{\downarrow}$. No TFT, $s^{\downarrow}$ e $s^{\uparrow}$ combinam a dispersão entre os membros com as metades de baixo ($q_{0.5}-q_{0.1}$) e de cima ($q_{0.9}-q_{0.5}$) da faixa das cabeças; no LightGBM, as metades da faixa 2,5–97,5%. Os tercis de dispersão usam a média das duas escalas.
- **Tab. 3 (hiperparâmetros):** acrescente a linha do LightGBM (até 500 árvores, taxa 0,05, 63 folhas, mínimo de 20 amostras por folha, subamostragem de 0,8 das linhas e 0,8 das colunas, parada antecipada de 50 rodadas na validação, 21 quantis por horizonte) e a grade do peso (0, 0.2, 0.4, 0.6, 0.8, 1); os hiperparâmetros do ICSO-PP vão para a descrição do antecessor e da ablação B4h.
- **Seção V-C (baselines):** “Boot-TFT + BatchMVP” → “Hybrid + BatchMVP”: o BatchMVP é aplicado à mesma base híbrida, para isolar a camada de calibração.
- **Tab. 10 e Fig. 8 (otimizadores):** saem. A linha B4h da Tab. 9 mostra o efeito do ICSO-PP nas cabeças (macros `\RAbICSO<h>`). A Seção VI-F passa a discutir os pesos da combinação (figura `figuras/fig_weights.pdf`, macros `\RWeight<h>` e `\RWeight<SITE><h>`).
- **Tab. 9 (ablação):** B1–B3 como antes; B4 = escalas de cada lado; B5 = proposto (+ LightGBM com peso por janela); B4h = B4 + ICSO-PP; B5a–B5d = as variantes antigas B4a–B4d, agora sobre B5; B5e = Boot-LSTM do artigo 1; B5f = peso fixo por horizonte (validação); B5g = só o LightGBM. Macros novos: `\RAbAsym<h>`, `\RAbHyb<h>`, `\RAbFixed<h>`, `\RAbGBMOnly<h>`.
- **Tab. 12 (custo):** colunas novas (LightGBM e escolha dos pesos no Estágio 3); macros `\RCostLGBM` e `\RCostWeights` no lugar de `\RCostICSO`.

**Mudanças de sites:**

Linhas do `main.tex` do zip de 16/10 (as linhas podem ter mudado na sua versão). Os macros `\RNSites` (2), `\RNSitesWord` (two), `\RNPairs` (8), `\RSiteList` (BRA and GEO), `\RKoppenList` e `\RDesertSite` (BRA) já estão em `results_macros.tex`.

- **Resumo (l. 143), contribuições (l. 266) e conclusão (l. 1026):** “four public datasets that span both hemispheres and four Köppen climates (BWh, Cfa, Cfb and BSh)” → “two single PV plants that span both hemispheres (BRA in the south, GEO in the north) and two Köppen climates (BSh, Cfa)”.
- **Seção V-A, Sites and Data (l. 713–720):** troque os quatro itens (ASP, GTB, UTR, BRA) por 2 itens:
    - *BRA (Northeast Brazil).* The Conj. Ituverava utility-scale complex (196\,MW$_\mathrm{ac}$, seven 28-MW plants) in the semi-arid interior of Bahia, with hourly verified generation published by the system operator ONS under a CC-BY license~\cite{ons2026geracao}, before the large-scale constrained-off of 2024–2025.
    - *GEO (Georgia, USA).* The Simon Solar Farm (33\,MW$_\mathrm{ac}$, 40 inverters) of the NREL PVDAQ archive (system 9069, 2023 DOE Solar Data Prize) in a humid subtropical climate, with 5-min inverter data~\cite{pvdaq9069}.
- **Tab. 4 (l. 722–735):** `\input{tables/tab_data}` (gerada com os dados da coleta).
- **Seção V-B, QC (l. 741):** as porcentagens de dias removidos por site estão em `\RQCRemoved<SITE>` (BRA 5.13%, GEO 8.16%). Acrescente a regra de disponibilidade: “Periods in which the recorded output stays far below the plant's capability for days at a time (the weekly maximum below 30% of its 99th percentile for at least three days, which flags outages and corrupted records) are also removed.”
- **Significância (l. 706) e Fig. 12:** “16 site–horizon pairs” → “eight site–horizon pairs” (`\RNPairsWord`).
- **Resultados por site (l. 821):** “all 16 site–horizon pairs” → `\RNPairsWord` (8); “the three cloudier sites” → `\RCloudierSites` (“the cloudier site”); “the desert climate of ASP” → “the desert climate of `\RDesertSite`” (BRA); `\RDMASPMinMVP` e `\RMergedASP` já trazem os valores de BRA (há também `\RDMDesertMinMVP` e `\RMergedDesert`).
- **Interpretabilidade (l. 981):** “At ASP, solar geometry…” → “At `\RDesertSite`, …” (`\RVSNGeoASPDA` já é de BRA). Fig. 9: troque o bloco por `\input{figuras/fig_vsn_pgfplots}` (2 colunas nesta rodada). A legenda gerada não traz a frase “Past power dominates at 1 h and NWP inputs dominate the day-ahead horizon”: confira na seção 4 se os pesos a confirmam antes de pô-la de volta.
- **Implementação (l. 763):** “PyTorch, PyTorch Forecasting” → “PyTorch, LightGBM”; a frase das “2,000 fitness evaluations” passa a valer só para o ICSO-PP da ablação B4h (se ficar, “2,040”, `\ROptEvals`).
- **Tab. 3 (l. 651):** “at most 100 epochs” → “at most 100 epochs of 4,000 randomly drawn windows” (`tft: amostras_por_epoca` do config; item 22 da seção 6 do README).
- **Entradas do TFT (tabela de entradas, l. 442–445, e Seção III-B, l. 452):** com `tft: lags_decodificador: 3` o decodificador recebe também os 3 últimos índices de céu claro observados ($k_{t_0}$, $k_{t_0-1}$, $k_{t_0-2}$), repetidos nos 36 passos, como o LightGBM e o HEC-XGB. Na tabela, acrescente antes da linha “Static” a linha “At origin (decoder, 36\,h) & last three observed clear-sky indices $k_{t_0}$, $k_{t_0-1}$, $k_{t_0-2}$, repeated at every step \\”; na l. 452, “and the decoder reads the known inputs of the next 36\,h” → “and the decoder reads the known inputs of the next 36\,h together with the last three observed clear-sky indices” (item 23 da seção 6 do README).
- **Perda do TFT (Seção III-B, depois da frase das três cabeças de quantis, e Tab. 3):** com `tft: peso_intradiario: 5`, os 6 primeiros passos do decodificador pesam 5 vezes mais na perda quantílica e na parada antecipada. Texto sugerido: “The quantile loss weights the first six decoder steps by 5, so that the intraday horizons, six of the 36 steps, receive half of the training signal; with uniform weights the TFT barely uses the latest observations.” Na Tab. 3, acrescente “intraday loss weight 5 (first 6 steps)” (item 23 da seção 6 do README).
- **Sem modelo de fundação (pacote v2):** tire o item “Chronos + CP” da lista de baselines (l. 749) e troque “Eight baselines” por “Seven baselines” (l. 745); apague a frase sobre modelos de fundação na revisão da literatura (l. 226, “Pretrained time-series foundation models now offer zero-shot forecasts…”) e a frase sobre o Chronos na Seção VI-A (l. 774, “The zero-shot foundation model sees no NWP…”). A Tab. 5 e a Fig. 12 já saem sem ele.
- **Limitações (l. 1018):** “at the desert site” continua valendo; confira com a Tab. 6.
- **Disponibilidade de dados (l. 1030–1033):** troque Alice Springs/NIST/Utrecht por DKASC Yulara, ONS e NREL PVDAQ. Os termos do DKASC não permitem redistribuir os dados processados de YUL: publique só os scripts que baixam da fonte.
- **Bibliografia:** acrescente a entrada do PVDAQ e generalize a do DKASC (o título atual cita Alice Springs):

```bibtex
@misc{pvdaq9069,
  author       = {{National Renewable Energy Laboratory (NREL)}},
  title        = {Photovoltaic Data Acquisition ({PVDAQ}) Public Datasets: System 9069 (2023 {DOE} Solar Data Prize)},
  howpublished = {[Online]. Available: \url{https://data.openei.org/submissions/4568}},
  note         = {License CC-BY 4.0},
  year         = {2023}
}
```

## 4. O que os números dizem sobre cada frase dos resultados

A Seção VI do rascunho foi escrita para o modelo da v2 (com o ICSO-PP), com valores hipotéticos (blocos em laranja). Na v3, as frases abaixo são as que o texto novo deve sustentar, com os números desta rodada. ✅ confirma, ❌ não confirma (reescreva a frase), ➖ não dá para decidir com estes dados.

| Seção | Afirmação do texto | Números | |
|---|---|---|---|
| VI-A Visão geral | O proposto tem o menor IS em todos os horizontes | 1h: LightGBM + CQR; 3h: Hybrid + BatchMVP; 6h: Hybrid + BatchMVP; DA: TFT, native quantiles | ❌ |
| VI-A Visão geral | O proposto tem o maior WGC em todos os horizontes | 1h: CCP-Boot-TFT-GBM (ours) (94.4); 3h: CCP-Boot-TFT-GBM (ours) (94.5); 6h: CCP-Boot-TFT-GBM (ours) (94.9); DA: CCP-Boot-TFT-GBM (ours) (94.3) | ✅ |
| VI-A Visão geral | Entre os métodos com WGC perto da referência, o proposto tem o menor IS | 1h: Hybrid + BatchMVP; 3h: Hybrid + BatchMVP; 6h: Hybrid + BatchMVP; DA: CCP-Boot-TFT-GBM (ours) | ❌ |
| VI-A Visão geral | O IS cai em relação ao antecessor (PRIOR) | redução de 7.1–13.4% | ✅ |
| VI-A Visão geral | O WGC sobe do antecessor para o proposto | PRIOR 89.3–90.7% → proposto 94.3–94.9% | ✅ |
| VI-A Visão geral | O antecessor é marginalmente válido, mas o pior grupo fica bem abaixo da referência | PICP 94.6–94.8%; WGC 89.3–90.7% (referência 93.9%) | ✅ |
| VI-A Visão geral | O proposto fica perto da referência amostral do WGC (±2 pontos) | WGC 94.3–94.9% (referência 93.9%) | ✅ |
| VI-A Visão geral | O BatchMVP chega a um WGC parecido (±2 pontos) | MVP 92.9–93.5% vs proposto 94.3–94.9% | ✅ |
| VI-A Visão geral | Os intervalos do BatchMVP são mais largos (o proposto reduz o IS do MVP) | redução por horizonte: 1h -2.8%, 3h -1.1%, 6h -0.5%, DA +1.0% (negativo = IS do proposto maior) | ❌ |
| VI-A Visão geral | Os quantis nativos do TFT subcobrem (PICP < 95%) e o WGC desce bastante | PICP 92.4–93.6%; WGC mín. 84.8% | ✅ |
| VI-A Visão geral | O CQR leva o PICP do TFT perto do alvo, mas o WGC fica baixo | PICP 95.4–95.8%; WGC 84.7–90.2% | ✅ |
| VI-A Visão geral | FSS e CRPSS do proposto (valores do texto) | FSS 1 h 0.097, DA 0.419; CRPSS 1 h 0.545, DA 0.360 | ✅ |
| VI-B Sites | O proposto tem o menor IS em todos os 8 pares site–horizonte | 0 de 8; perde em: BRA 1h (LightGBM + CQR), BRA 3h (Hybrid + BatchMVP), BRA 6h (TFT + CQR), BRA DA (TFT + CQR), GEO 1h (LightGBM + CQR), GEO 3h (Hybrid + BatchMVP), GEO 6h (TFT, native quantiles), GEO DA (TFT, native quantiles) | ❌ |
| VI-B Sites | A melhora sobre o antecessor é significativa em todos os pares (Holm, p < 0,05) | maior p = 0.001 | ✅ |
| VI-B Sites | A melhora sobre o BatchMVP é significativa fora do site desértico (BRA) | maior p fora de BRA = 1.000 | ❌ |
| VI-B Sites | No site desértico (BRA) a diferença para o BatchMVP não é significativa | menor p em BRA = 1.000; regime fundido em 56% das janelas | ✅ |
| VI-B Sites | O WGC do proposto fica perto da referência em todos os sites | WGC por site e horizonte 93.4–96.2% (referência 93.9%); PRIOR desce a 89.1% | ✅ |
| VI-C Camadas | O Mondrian por hora (L3) tem WGC baixo no DA; o condicional (L6) sobe | L3 91.7% vs L6 94.3% | ✅ |
| VI-C Camadas | Mondrian regime × hora (L4) sobe o WGC, mas custa IS em relação ao L6 | WGC L4 91.6%; IS L4/L6 − 1 = 1.0% | ✅ |
| VI-C Camadas | O condicional é mais estreito que o BatchMVP (L5) | IS L5/L6 − 1 = 1.0% | ✅ |
| VI-C Camadas | O CCD do condicional é menos da metade do CCD do Mondrian por hora | CCD L6 1.48 vs L3 1.30 | ❌ |
| VI-C Camadas | As interações (L7) ganham pouco WGC e custam IS | WGC L7 94.5% vs L6 94.3%; IS +1.0% | ✅ |
| VI-D Grupos | No antecessor o regime encoberto subcobre e o claro sobrecobre; o proposto aproxima os dois de 95% | encoberto PRIOR 94.5% → 96.9%; claro PRIOR 95.6% → 96.0% | ❌ |
| VI-D Grupos | O tercil de alta dispersão sobe | 92.4% → 96.5% | ✅ |
| VI-D Grupos | Dias de nuvens leves (diagnóstico) e o verão sobem | LC 94.4% → 96.2%; verão 92.2% → 96.0% | ✅ |
| VI-E Ablação | B1→B2 (dispersão total) reduz o IS | DA: 4.7% | ✅ |
| VI-E Ablação | B2→B3 (camada condicional) sobe o WGC e reduz o IS | DA: WGC +4.4 pontos, IS 6.2% | ✅ |
| VI-E Ablação | B3→B4 (escalas de cada lado) reduz o IS em todos os horizontes | 1h: 2.3%; 6h: 3.6%; DA: 2.9% | ✅ |
| VI-E Ablação | B4→B5 (LightGBM com peso por janela) reduz o IS, sobretudo em 1 h | 1h: 9.5%; 6h: -2.0%; DA: 0.3% | ❌ |
| VI-E Ablação | O ICSO-PP nas cabeças (B4h) não reduz o IS do B4 no teste | 1h: -1.5%; 6h: -1.5%; DA: -1.7% | ✅ |
| VI-E Ablação | Sem os regimes do NWP (B5a) o WGC do DA cai | 94.1% vs B5 94.3% | ✅ |
| VI-E Ablação | As interações (B5b) custam IS | DA: +1.0% | ✅ |
| VI-E Ablação | Sem o buffer (B5c) o PICP e o WGC caem | PICP 94.6% (B5 96.1%), WGC 92.4% (B5 94.3%) | ✅ |
| VI-E Ablação | Sem a recalibração mensal (B5d) o WGC cai | PICP 96.1%, WGC 90.2% | ✅ |
| VI-E Ablação | Com o Boot-LSTM do artigo 1 (B5e) o IS é maior | 1h: +12.6%; 6h: +11.9%; DA: +12.5% | ✅ |
| VI-E Ablação | O peso escolhido mês a mês (B5) supera o peso fixo da validação (B5f) | 1h: +0.2%; 6h: +2.6%; DA: +0.8% | ✅ |
| VI-E Ablação | Só o LightGBM (B5g) perde do híbrido, sobretudo no DA | 1h: +3.0%; 6h: +5.2%; DA: +10.1% | ✅ |
| VI-F Combinação | O peso do TFT cresce com o horizonte (o LightGBM pesa mais em 1 h) | 1h: 0.33, 3h: 0.76, 6h: 0.68, DA: 0.72 | ✅ |
| VI-G Interpretabilidade | Em 1 h o passado (k e estatísticas móveis) domina a seleção | 23–24% | ❌ |
| VI-G Interpretabilidade | No DA o NWP (k, GHI, nuvens) domina a seleção | 12–14% | ❌ |
| VI-G Interpretabilidade | O regime encoberto infla o limiar superior (ψ > 1) e o claro o encolhe (ψ < 1) | encoberto inverno 1.18, verão 1.43; claro inverno 0.91, verão 0.90 | ✅ |
| VI-H Robustez | O Friedman rejeita desempenho igual | χ² = 39.5, p = 1.6e-06; posto do proposto 2.50 | ✅ |
| VI-H Robustez | O Nemenyi não separa o proposto do BatchMVP e do antecessor | CD = 3.71; diferença de posto MVP -0.38, PRIOR 3.25 | ✅ |
| VI-H Robustez | Sob as 5 degradações o proposto mantém PICP e WGC; o WGC do antecessor cai | proposto: PICP ≥ 96.1%, WGC ≥ 94.1%; PRIOR: WGC ≥ 90.2% | ✅ |

Resumo: 34 confirmadas, 10 não confirmadas, 0 indefinidas.

## 5. Números principais (para o resumo e a conclusão)

| Horizonte | IS proposto | IS antecessor | IS BatchMVP | PICP proposto | WGC proposto | WGC antecessor | CRPSS proposto |
|---|---|---|---|---|---|---|---|
| 1h | 51.9 | 55.9 | 50.5 | 96.7 | 94.4 | 89.3 | 0.545 |
| 3h | 63.0 | 71.5 | 62.3 | 96.6 | 94.5 | 90.0 | 0.407 |
| 6h | 67.2 | 75.9 | 66.8 | 96.6 | 94.9 | 90.7 | 0.382 |
| DA | 67.1 | 77.5 | 67.8 | 96.1 | 94.3 | 90.2 | 0.360 |

Referência amostral do WGC: 93.9% (grupos a 96%) e 92.7% (a 95%).

## 6. Decisões de implementação que o texto precisa refletir

Veja a seção 6 do README do pacote de experimentos (TFT em PyTorch puro, regra de fusão com n_ef = max(30, ⌈τ/(1−τ)⌉ + 1), interações por blocos de horas, BatchMVP com 10 faixas, janela de calibração do DA causal, pares sem GFS excluídos, QC de disponibilidade da usina, ȳ pelo treino, pesos da Fig. 9 com as conexões residuais do TFT, época do TFT de 4.000 janelas sorteadas, k recentes e peso intradiário no TFT, e o modelo híbrido da v3: itens 23 a 25).
