#!/usr/bin/env bash
# Compila o PDF. As tabelas, macros e dados vêm do pacote de experimentos:
#   python executar.py artigo --latex <esta pasta>
# (não rode o tools/render_tables.py antigo: ele tem a lista fixa ASP, GTB, UTR e BRA).
set -euo pipefail
cd "$(dirname "$0")"
latexmk -pdf -interaction=nonstopmode main.tex
