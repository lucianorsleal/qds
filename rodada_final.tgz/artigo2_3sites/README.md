# CCP-Boot-TFT-ICSO-PP — versão com YUL, BRA e GEO

Esta pasta é o projeto do zip de 16/10 com o texto que depende dos sites trocado para **YUL** (Desert
Gardens, Yulara, DKASC), **BRA** (Conj. Ituverava, ONS) e **GEO** (Simon Solar Farm, PVDAQ 9069), e com as
tabelas, macros, dados e figuras gerados pelo pacote de experimentos (`..\experimentos`).

- **Números de agora:** teste rápido do pacote (1 semente, 2 membros, 2 épocas) com os dados reais dos três
  sites. Saem em vermelho no PDF e **não servem para o artigo**.
- **Para pôr os números da rodada completa:** na pasta `experimentos`, rode
  `gerar_relatorio.bat --latex ..\artigo2_3sites` e compile de novo (`latexmk -pdf main.tex`, ou envie a
  pasta ao Overleaf).
- **Não rode** `tools/render_tables.py`, `tools/wgc_reference.py` nem `tools/make_placeholder_results.py`:
  eles têm a lista fixa ASP, GTB, UTR e BRA e sobrescreveriam as tabelas e macros. O `build.sh` agora só
  compila.
- **`GUIA_ARTIGO.md`:** onde entra cada saída, o que mudou no texto e, frase por frase, se os números
  confirmam o que a Seção VI do rascunho diz.
- **O que mudou no `main.tex`:** resumo, contribuições e conclusão (três usinas, três climas); Seção V-A
  (três itens); Tab. 4 (`\input{tables/tab_data}`); QC (regra de disponibilidade da usina e dias removidos
  por site); significância e Fig. 12 (`\RNPairs` pares site–horizonte); implementação (TFT em PyTorch,
  2.040 avaliações); resultados por site (YUL no papel do ASP); interpretabilidade e Fig. 9 (três colunas);
  disponibilidade de dados e agradecimentos; bibliografia (PVDAQ incluído, título do DKASC generalizado);
  sem modelo de fundação (pacote v2): o Chronos saiu da lista de baselines (agora sete), da revisão da
  literatura e da Seção VI-A; Tab. 3 com a época do TFT de 4.000 janelas sorteadas.
- **TFT para os horizontes intradiários (pacote v2.1):** a tabela de entradas, a Seção III-B e a Tab. 3 já descrevem os k das 3 últimas horas no decodificador e o peso 5 nos 6 primeiros passos da perda. Os números só refletem essa mudança depois da nova rodada e do `gerar_relatorio.bat --latex ..\artigo2_3sites`.
- O texto em laranja continua o do rascunho: reescreva-o com os resultados finais (seção 4 do guia).
- **YUL em revisão:** a saída do Desert Gardens é limitada pela rede isolada de Yulara na maioria dos dias de
  sol de 2023–2025 (item 21 da seção 6 do README do pacote de experimentos). O item do YUL na Seção V-A traz
  um aviso em roxo até a troca do sistema.

O restante deste arquivo é o README original (quatro sites). Onde divergir, vale o que está acima.

---

# CCP-Boot-TFT-ICSO-PP — rascunho IEEE Access (artigo 2)

Rascunho completo (17 páginas, template IEEE Access) do segundo artigo da linha
**Boot-LSTM-ICSO-PP → Conformalized Boot-LSTM-ICSO-PP → CCP-Boot-TFT-ICSO-PP**,
com a mesma estrutura de seções do artigo 1 (ver seção 2).

**Título:** *CCP-Boot-TFT-ICSO-PP: Prediction Intervals With Weather-Regime Conditional
Guarantees for Multi-Horizon PV Power Forecasting*

**Pergunta científica nova:** dá para garantir a cobertura dos intervalos *ao mesmo tempo*
por hora do dia, por regime de tempo previsto pelo NWP (céu claro, parcialmente nublado,
encoberto) e por nível de dificuldade da previsão, sem fragmentar os dados de calibração?

> **Todos os resultados numéricos, tabelas de resultados e figuras de resultados são
> HIPOTÉTICOS.** Eles existem apenas para dar forma final ao PDF e estão marcados
> no texto, nas legendas e nas figuras (ver "Convenções de marcação").

---

## 1. O que mudou em relação ao artigo 1

| Artigo 1 (Conformalized Boot-LSTM-ICSO-PP) | Artigo 2 (CCP-Boot-TFT-ICSO-PP) |
|---|---|
| Ensemble bootstrap de **LSTM** | Ensemble bootstrap de **Temporal Fusion Transformers** (NWP como entrada futura conhecida, quantis nativos, pesos de seleção de variáveis e atenção interpretáveis) |
| Dispersão = discordância entre membros | Dispersão **decomposta**: epistêmica (membros) + aleatória (cabeças de quantis), com peso γ aprendido |
| Mondrian por **hora** (células disjuntas) | **Predição conformal condicional** sobre classe de funções (Gibbs, Cherian & Candès, JRSS-B 2025): garantia simultânea para 19 grupos sobrepostos (13 horas + 3 regimes NWP + 3 tercis de dispersão), sem fragmentar a janela |
| ICSO-PP otimiza as cabeças contra o IS conformal | ICSO-PP otimiza as cabeças **e γ** contra um IS **condicional** com validação cruzada; comparado com CMA-ES, L-SHADE, PSO e TPE no mesmo orçamento |
| Métricas marginais (PICP, IS, CRPSS) | + **WGC** (pior cobertura entre grupos), **CCD** e uma **referência amostral do WGC** |
| — | Baseline multigrupo concorrente (BatchMVP), modelo fundacional (Chronos), testes de Friedman–Nemenyi, DM com Holm, testes de estresse no NWP e lacunas de dados |

O artigo 1 é citado como `prior2026conformalized` (placeholder em `references.bib`;
atualize autores, situação e DOI quando ele for submetido ou aceito).

## 2. Estrutura do artigo (igual à do artigo 1)

| Seção | Conteúdo |
|---|---|
| Resumo, palavras-chave, Nomenclature | o resumo e as palavras-chave dizem que a especificação é *climate-invariant* |
| I. Introduction | A. Motivation · B. Literature Review (Tab. 1) · C. Contributions + parágrafo de organização |
| II. Individual Methods | TFT · Bootstrap Ensembles · CSO · Improved CSO e PP · Split CP · Conditional CP |
| III. Proposed Framework | Fig. 1 · A. Problem Formulation (Fig. 2) · B. Input Features · C. Stage 1: TFT Backbone · D. Stage 2: Daily-Block Bootstrap Ensemble · E. Stage 3: ICSO-PP (Fig. 4) · F. Stage 4: Conditional Conformal Layer · G. Interpretability Outputs · H. Validity and Climate Invariance |
| IV. Evaluation Metrics | IS, cobertura e largura, CRPSS/FSS, WGC/CCD, referência amostral, testes |
| V. Case Studies | A. Sites and Data · B. Quality Control and Day Classification · C. Baselines · D. Stress Tests · E. Implementation |
| VI. Results and Discussion | Overall · Site-Level Results and Climate Invariance · Conditional Coverage and Calibration Layers · Group, Seasonal and Sky-Condition Analysis · Ablation · Stage-3 Optimizer · Interpretability · Robustness and Stress Tests · Cost · Limitations · Future Research |
| VII. Conclusion | + Data Availability, Acknowledgment, referências e biografias |

Não há *research questions*; as contribuições ficam numa lista, como no artigo 1.

## 3. Arquivos

```
main.tex                      artigo (texto, equações, algoritmos, figuras TikZ/pgfplots)
references.bib                101 entradas, 64 citadas (estilo IEEEtran)
ieeeaccess.cls, images/       classe IEEE Access + logos
tables/*.tex                  tabelas de resultados      (GERADAS — não editar à mão)
macros/results_macros.tex     números citados no texto   (GERADOS — não editar à mão)
macros/wgc_reference.tex      referência amostral do WGC (GERADA)
results/*.csv                 resultados tabulares       (hoje: placeholders)
data/*.csv                    dados das figuras          (hoje: placeholders)
tools/make_placeholder_results.py   gera os placeholders (NÃO usar para resultados reais)
tools/render_tables.py              CSVs -> tabelas + macros + flags de marca d'água
tools/wgc_reference.py              simula o WGC esperado de um método perfeitamente calibrado
build.sh                      render_tables + wgc_reference + latexmk
main.pdf                      prévia compilada
```

## 4. Como compilar

**Local** (TeX Live com `IEEEtran`, `pgfplots`, `algorithmicx`; Python 3 com numpy e pandas):

```bash
./build.sh
```

**Overleaf:** envie o zip inteiro e compile com pdfLaTeX. Tabelas e macros já estão
geradas; só é preciso rodar Python quando os CSVs mudarem.

Se o `latexmk` reclamar do BibTeX depois de você apagar arquivos auxiliares à mão,
rode `latexmk -C` e compile de novo.

## 5. Convenções de marcação

| Marcação | Aparência no PDF | Significado | O que fazer |
|---|---|---|---|
| `\hyp{…}` | número em **vermelho** | valor hipotético | substituído automaticamente via CSV |
| ambiente `hypblock` / `\hyptext{…}` | texto em **laranja** | interpretação de resultados hipotéticos | **reescrever** após os experimentos |
| `\tbc{…}` | texto em **roxo** | dado a confirmar | editar no `main.tex` ou no `.bib` |
| marca d'água "HYPOTHETICAL" | figura | figura com dados hipotéticos | some sozinha quando o CSV for real |
| quadro "DRAFT NOTICE" | 1ª página | aviso geral | some com `\showplaceholdersfalse` |

Versão final: troque `\showplaceholderstrue` por `\showplaceholdersfalse` no preâmbulo.

## 6. Fluxo para inserir os resultados reais

1. Rode os experimentos e grave os resultados em `results/*.csv` e `data/*.csv` com
   **as mesmas colunas** (seção 7). Remova a primeira linha `# HYPOTHETICAL …` de cada
   CSV (ou não a inclua). A troca pode ser feita arquivo por arquivo.
2. Grave `results/group_sizes.csv` com o tamanho real de cada grupo no ano de teste e rode
   `python3 tools/wgc_reference.py`. A referência do WGC deixa de ser provisória.
3. Rode `./build.sh`. Tabelas, macros `\R…` do texto, linha pontilhada da Fig. 6b e
   marcas d'água se atualizam sozinhas.
4. **Reescreva os parágrafos em laranja.** Eles descrevem o cenário hipotético (por exemplo,
   "o BatchMVP não difere do modelo proposto em ASP").
5. Resolva os itens em roxo (seção 8) e passe para `\showplaceholdersfalse`.

Testei esse fluxo numa cópia: sem a linha `# HYPOTHETICAL` e com `\showplaceholdersfalse`,
o PDF sai sem nenhuma cor, aviso ou marca d'água.

## 7. Esquema dos CSVs

Unidades: IS, PINAW×100, RMSE e CRPS em % da capacidade nominal; PICP, WGC e coberturas em %.
Sites: `ASP, GTB, UTR, BRA`. Horizontes: `1h, 3h, 6h, DA`.
Métodos: `CHPeEn, LGBM_CQR, CHRONOS, HEC` (HEC-XGB do arXiv:2607.11470), `PRIOR`
(CP-Boot-LSTM-ICSO-PP, artigo 1), `TFT` (quantis nativos), `CQR_TFT`, `MVP`
(Boot-TFT + BatchMVP, cabeças Adam) e `PROP` (proposto).

| Arquivo | Colunas | Usado em |
|---|---|---|
| `results/main_metrics.csv` | site, horizon, method, RMSE, FSS, PICP, WGC, WGC_sky, CCD, PINAW, IS, IS_sd, CRPS, CRPSS | Tab. 5, Tab. 6, Fig. 6, Fig. 12 |
| `results/site_diagnostics.csv` | site, horizon, dm_p_vs_MVP, dm_p_vs_PRIOR (já com Holm), merged_pct (% de janelas com fusão de grupo) | Tab. 6 |
| `results/group_coverage.csv` | site, horizon, method, family (`hour, regime, tertile, season, sky`), group, share (%), PICP | Tab. 8 |
| `results/calib_layers.csv` | layer (L1 split CP absoluto, L2 split normalizado, L3 Mondrian hora, L4 Mondrian regime×hora, L5 BatchMVP, L6 proposto, L7 proposto + interações), horizon (1h/DA), PICP, WGC, WGC_sky, CCD, IS, PINAW | Tab. 7 |
| `results/ablation.csv` | variant (B1…B4, B4a…B4e), horizon (1h/6h/DA), IS, PICP, WGC, RMSE | Tab. 9 |
| `results/optimizer.csv` | optimizer, IS_mean, IS_sd, WGC_mean, WGC_sd, Fval_mean, Fval_sd, p_wilcoxon, evals, time_min | Tab. 10 |
| `results/stress.csv` | scenario (S0…S5), method (PRIOR/PROP), PICP, WGC, IS | Tab. 11 |
| `results/cost.csv` | site, n_train, ensemble_min (Stages 1–2), icso_min (Stage 3), calib_s (Stage 4, por mês), infer_s | Tab. 12 |
| `results/group_sizes.csv` (novo, opcional) | site, family (hour/regime/tertile), group, n_test | referência do WGC |
| `data/fig_heat_mondrian.csv`, `data/fig_heat_cc.csv` | hour (6…18), reg (0 claro, 1 parcial, 2 encoberto), cov — regime por fora, hora por dentro | Fig. 7 |
| `data/fig_convergence.csv` | generation; ICSOPP, CMAES, LSHADE, PSO, TPE e respectivos `_lo`/`_hi` (±1 dp), fitness normalizado | Fig. 8 |
| `data/fig_vsn_1h.csv`, `data/fig_vsn_DA.csv` | site (0…3 = ASP, GTB, UTR, BRA), feat (0…8, na ordem da Fig. 9), w (%) — ordenado por feat e depois site | Fig. 9 |
| `data/fig_attention.csv` | lag (−120…−1), Clear, Overcast | Fig. 10 |
| `data/fig_cc_multipliers.csv` | regime (0…2), label, Winter, Summer (fator ψ_r) | Fig. 11 |
| `data/fig_is_horizon.csv`, `data/fig_wgc_horizon.csv`, `data/fig_ranks.csv` | **derivados automaticamente** de `main_metrics.csv` | Fig. 6, Fig. 12 |

Os rótulos do eixo da Fig. 12 também são gerados na ordem real dos ranks.

## 8. Itens a confirmar (em roxo no PDF)

- [ ] Autores, afiliações, e-mail de correspondência, financiamento, biografias e fotos.
      A afiliação POLI/UPE e o e-mail foram preenchidos como sugestão.
- [ ] Referência do artigo 1 (`prior2026conformalized`): autores, situação e DOI.
- [ ] Dados: capacidades de ASP e UTR; usina, coordenadas, Köppen e capacidade de BRA
      (mesmos itens do artigo 1; prefira 2019–2022, antes do *curtailment* de 2023).
- [ ] `results/group_sizes.csv` e a referência do WGC (Seção IV do artigo, parágrafo *Sampling reference*).
- [ ] Hardware, versões das bibliotecas e URL do repositório.
- [ ] DOI de Renkema, Visser & AlSkaif (2024), *Solar Energy Advances* 4, 100059
      (o Crossref limitou o acesso durante a conferência).
- [ ] Reconfirmar, antes da submissão, a frase "to the best of our knowledge, this is the first
      application of function-class conditional CP to renewable generation". Busquei em
      outubro/2026 e não achei aplicação anterior; os trabalhos mais próximos (Renkema et al. 2024;
      Moradi et al. 2025) usam Mondrian por faixas e calibração ponderada por similaridade, e já
      estão citados.

## 9. Roteiro experimental (o que gera cada CSV)

1. **Stages 1–2** — por site: 10 TFTs (PyTorch Forecasting, `TemporalFusionTransformer`,
   `QuantileLoss([0.1, 0.5, 0.9])`), réplicas bootstrap por blocos diários, ±10 % de jitter.
   Exporte `interpret_output()` para as Figs. 9 e 10 (pesos de seleção e atenção, por regime).
2. **Stage 3** — guarde a penúltima representação no bloco de validação e rode ICSO-PP sobre
   as cabeças medianas + log γ (331 dimensões). Na mesma função de fitness, rode CMA-ES (`cma`),
   L-SHADE (ex.: `pyade`), PSO, CSO, ICSO e TPE (Optuna) com 2.000 avaliações e 10 sementes
   (Tab. 10, Fig. 8).
3. **Stage 4** — conformal condicional com o pacote `conditionalconformal` (Gibbs et al.)
   ou com Algoritmo 1 + `scipy.optimize.linprog(method="highs")`. Recalibração mensal em
   janelas de 12 semanas; σ_fl e cortes de tercil fixos no bloco de validação.
4. **Baselines** — CH-PeEn, LightGBM+CQR, Chronos zero-shot (`chronos-forecasting`) + split CP,
   HEC-XGB e o modelo do artigo 1 (mesmo protocolo do artigo 1), TFT nativo (quantis 0,025/0,5/0,975),
   TFT+CQR e BatchMVP sobre os mesmos grupos (código dos autores de Jung et al., ICLR 2023).
5. **Camadas (Tab. 7)** — mesmo ensemble refinado, troque só a camada (L1–L7).
6. **Ablação (Tab. 9)** — B1–B4 acumulativas; B4a–B4e trocam um item de B4 por vez.
7. **Estresse (Tab. 11)** — S1–S5 aplicados à calibração e ao teste; recalibre normalmente.
8. **Estatística** — DM unilateral com Newey–West e Holm sobre o IS diário; Friedman e
   Nemenyi sobre os 16 pares site–horizonte (calculados por `render_tables.py`);
   Wilcoxon para os otimizadores.

## 10. Notas técnicas sobre o template

- `ieeeaccess.cls` é a mesma cópia do artigo 1 (repositório público
  `erwinrmendez/ieee-access-template`, com o ano do rodapé corrigido). **Para a submissão,
  baixe o template oficial no IEEE Author Center.**
- O preâmbulo mantém as três correções do artigo 1: restaura `\year` (a classe o redefine e
  isso quebra o pgf), troca a cor *spot* PANTONE por RGB (senão título e cabeçalhos somem em
  alguns leitores de PDF) e define `\xfigwd` para legendas do ambiente `figure`.
- Os avisos `Font shape … undefined` e os *overfull* do cabeçalho e do `\maketitle` vêm da
  própria classe e são inofensivos.
